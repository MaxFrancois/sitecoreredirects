﻿using Sitecore.Mvc.Controllers;
using Sitecore.Avanade.Foundation.Extensions;
using System.Web.Mvc;
using Sitecore.Mvc.Presentation;
using Sitecore.Avanade.Foundation.Extensions.Attributes;

namespace Sitecore.Avanade.Feature.SiteLogo.Controllers
{
    public class SiteLogoController : SitecoreController
    {
        [DataSourceRequired]
        public ActionResult Logo()
        {
            return PartialView(RenderingContext.CurrentOrNull?.GetDataSourceItem());
        }
    }
}