﻿namespace Sitecore.Avanade.Feature.Tiles
{
    public static class Constants
    {
        #region Tile Field Names

        public const string LinkFieldName = "TileLink";
        public const string TitleFieldName = "TileTitle";
        public const string TextFieldName = "TileText";
        public const string ImageFieldName = "TileImage";

        #endregion

        #region Section Field Names

        public const string SectionTitleFieldName = "TileSectionTitle";

        #endregion
    }
}