﻿using Sitecore.Data.Items;
using Sitecore.Data.Fields;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Feature.Tiles.Models
{
    public class TileViewModel
    {
        // The full item for general reference
        public Item Item { get; set; }
        // Fields for deconstructed display
        public ImageField Image { get; set; }
        public TextField Title { get; set; }
        public TextField Text { get; set; }
        public LinkField Link { get; set; }

        public TileViewModel(Item datasource)
        {
            if (datasource == null) return;
            Item = datasource;
            Image = datasource.Fields[Constants.ImageFieldName].ConvertToImageField();
            Title = datasource.Fields[Constants.TitleFieldName];
            Text = datasource.Fields[Constants.TextFieldName];
            Link = datasource.Fields[Constants.LinkFieldName].ConvertToLinkField();
        }

        /// <summary>
        /// Does the Image field have an image set
        /// </summary>
        public bool HasImageMedia
        {
            get
            {
                return Image != null && Image.MediaItem != null;
            }
        }

        // Return the image URL or null
        public string ImageUrl
        {
            get
            {
                return HasImageMedia ? Image.GetValidURL(false) : null;
            }
        }

        public bool HasValidLink
        {
            get
            {
                return Link != null && !string.IsNullOrEmpty(Link.GetValidURL()) || Context.PageMode.IsExperienceEditor;
            }
        }

        public string LinkUrl
        {
            get
            {
                return HasValidLink ? Link.GetValidURL() : "#";
            }
        }
    }
}