﻿using Sitecore.Avanade.Feature.Tiles.Models;
using Sitecore.Avanade.Foundation.Extensions.Attributes;
using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Tiles.Controllers
{
    public class TilesController : SitecoreController
    {
        protected Item RenderContext { get; } = RenderingContext.Current.Rendering.Item ?? RenderingContext.Current.PageContext.Item;


        // GET: Tiles - General
        [DataSourceRequired]
        public ActionResult GenericTile()
        {
            return PartialView("GenericTiles/GenericTile", RenderContext != null ? new TileViewModel(RenderContext) : null);
        }

        // GET: Tiles - Image
        [DataSourceRequired]
        public ActionResult ImageTile()
        {
            return PartialView("NavigationTiles/ImageContentTile", RenderContext != null ? new MediaItem(RenderContext) : null);
        }

        // GET: Tiles - BackgroundBase
        [DataSourceRequired]
        public ActionResult TileBackgroundBase()
        {
            return PartialView("TileWrappers/TileBackgroundBase", RenderContext != null ? new MediaItem(RenderContext) : null);
        }

        // GET: Tiles - Tile Base
        [DataSourceRequired]
        public ActionResult TileBase()
        {
            return PartialView("TileWrappers/TileBase", RenderContext != null ? RenderContext : null);
        }
    }
}