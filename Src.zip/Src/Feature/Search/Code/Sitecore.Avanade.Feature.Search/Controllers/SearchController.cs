﻿using Sitecore.Avanade.Foundation.ContentListing.Models;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Search;
using Sitecore.Avanade.Foundation.Search.Manager;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch.Linq.Utilities;
using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Search
{
    public class SearchController : SitecoreController
    {
        public ActionResult SearchBox()
        {
            return PartialView("~/Views/Search/SearchBox.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }
        public ActionResult SearchBoxForMobile()
        {
            return PartialView("~/Views/Search/SearchBoxForMobile.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }
        public ActionResult SearchButtonForSearchBox()
        {
            return PartialView("~/Views/Search/SearchButtonForSearchBox.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }
        public ActionResult SearchBoxForResultsPage()
        {
            return PartialView("~/Views/Search/SearchBoxForResultsPage.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }


        public ActionResult SearchResults(string q = null, int page = 1)
        {
            ListModel model;

            Item searchPage = Sitecore.Context.Item;

            var contextItem = RenderingContext.CurrentOrNull?.GetDataSourceItem(true);
            var searchRootItem = Sitecore.Context.Database.GetItem(Sitecore.Context.Site.StartPath);

            var pageItems = searchPage.Fields["MaxItemsPerPage"].As<int>(10); //Items to show per page

            using (var searchContext = SearchManager.GetSearchContext(contextItem))
            {
                var searchResults = PerformSearch(searchContext, searchRootItem, GetSearchText(), page, pageItems);
                if (searchResults == null)
                {
                    model = new ListModel(q,
                    searchPage,
                    0,
                    null,
                    1,
                    0);

                    return PartialView("~/Views/Search/SearchResults.cshtml", model);
                }

                IEnumerable<Item> items;
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    items = searchResults.Hits.Select(c => c.Document.GetItem()).Where(c => c != null).ToList();
                }

                // setup default for no results
                string searchPageTitle = "No search hits found";
                string searchPageEventGuid = Sitecore.Avanade.Foundation.Search.Constants.Analytics.NoSearchHitsFound;


                //THERE IS A PAGINATION MODULE, ALREADY WRITTEN!!! WHY DIDNT WE USE IT????
                //TODO: Change to pagination module
                Dictionary<string, IList<Item>> results = new Dictionary<string, IList<Item>>();
                if (items.Any())
                {
                    //The total item count
                    var count = searchResults.TotalSearchResults;

                    //Work out the range value
                    var start = page == 1 ? page : ((page * pageItems) - pageItems) + 1;
                    var end = (start + pageItems - 1) > count ? count : (start + pageItems - 1);

                    //TODO This format may need to move into Sitecore so it can be content managed
                    var key = string.Format("Results: Showing {0} - {1} of {2} for \"{3}\"", start, end, count, q);
                    results[key] = items.ToList();

                    // register event to found data
                    searchPageTitle = "Search";
                    searchPageEventGuid = Sitecore.Avanade.Foundation.Search.Constants.Analytics.SearchHitsFound;
                }

                model = new ListModel(q,
                    searchPage,
                    pageItems,
                    results,
                    page,
                    searchResults.TotalSearchResults);

                // make sure we enable tracking
                if (Sitecore.Analytics.Tracker.Enabled
                    && Sitecore.Analytics.Tracker.Current?.Interaction?.CurrentPage != null)
                {
                    // register the call to analytics
                    var pageEventData = new Sitecore.Analytics.Data.PageEventData(searchPageTitle, Sitecore.Data.ID.Parse(searchPageEventGuid).Guid)
                    {
                        ItemId = Sitecore.Context.Item.ID.ToGuid(),
                        Data = q,
                        DataKey = q,
                        Text = q
                    };

                    Sitecore.Analytics.Tracker.Current.Interaction.CurrentPage.Register(pageEventData);
                }
            }



            return PartialView("~/Views/Search/SearchResults.cshtml", model);

        }

        /// <summary>
        /// Perform a lucene search to retrieve CampaignDetailPage items
        /// </summary>
        /// <returns>Lucene search results using the standard SearchResultItem model</returns>
        private SearchResults<AISearchResultItem> PerformSearch(IProviderSearchContext context, Item contextItem, string search, int pageNumber, int pageSize, bool excludeContextItem = true)
        {
            //TODO Take out this forced exception and apply a proper check
            if (context == null)
                throw new ArgumentNullException("context");

            if (search.IsNullOrEmpty())
            {
                // return an empty result
                return new SearchResults<AISearchResultItem>(null, 0);
            }

            //queryable object
            var query = context.GetQueryable<AISearchResultItem>().Filter(x => x.Paths.Contains(contextItem.ID));


            //Make sure we have some terms and perform them
            if (!String.IsNullOrEmpty(search))
            {
                //create a predicate of criteria
                var predicate = PredicateBuilder.True<AISearchResultItem>();

                //boost the full term
                if (search.Trim().Contains(" "))
                {
                    predicate = predicate.Or(p =>
                        !p.DisableSearch && (
                            p.Content.Contains(search).Boost(5f) ||
                            p.ParsedPageContent.Contains(search).Boost(5f)));
                }

                //split term
                var splitTerm = search.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                    .Aggregate(predicate, (current, s) => current.Or(p =>
                        !p.DisableSearch && (
                            p.Content.Contains(s) ||
                            p.ParsedPageContent.Contains(s))));

                //Apply the aggregated term
                query = query.Where(splitTerm);

                //Check for flag and run
                if (excludeContextItem)
                {
                    query.Where(c => !c.ItemId.EqualsTo(contextItem.ID.ToString()));
                }
            }

            return query.Page(pageNumber - 1, pageSize).GetResults();
        }

        private string GetSearchText()
        {
            if (Sitecore.Context.PageMode.IsExperienceEditor)
            {
                return "Sample Search Text";
            }
            string searchText = Request.QueryString["q"];
            if (!searchText.IsNullOrEmpty() && searchText.Length > 2)
                return searchText.Replace(" i ", " "); //QUICK FIX ONLY...need to implement some sort of stopwords functionality, "I" causes a too many clauses error 
            else
                return "";

        }

    }
}