﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Feature.Alerts.Models
{
    public class Alert
    {
        public string ID { get; set; }
        public string AlertClass { get; set; }
        public string SVGClass { get; set; }
        public string KeyMarker { get; set; }
        public bool Dismissable { get; set; }
        public string Message { get; set; }
        public string DefaultText { get; set; }

        public static implicit operator Alert(Sitecore.Data.Items.Item itm)
        {
            return new Alert
            {
                ID = itm.ID.ToString(),
                AlertClass = itm.Fields[Constants.AlertTemplate.Fields.AlertClass].ValueSafe(),
                SVGClass = itm.Fields[Constants.AlertTemplate.Fields.SVGClass].ValueSafe(),
                KeyMarker = itm.Fields[Constants.AlertTemplate.Fields.KeyMarker].ValueSafe(),
                Dismissable = itm.Fields[Constants.AlertTemplate.Fields.Dismissable].ValueSafe<bool>(false),
                DefaultText = itm.Fields[Constants.AlertTemplate.Fields.DefaultText].ValueSafe()
            };
        }
    }
}