﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.Avanade.Feature.Alerts
{
    public static class Settings
    {
        #region Private Variables
        /// <summary>
        /// Is Alerts enabled
        /// </summary>
        private static bool? _isEnabled;

        /// <summary>
        /// Do we use temp data instead of session
        /// </summary>
        private static bool? _useTempData;
        #endregion

        #region Public Properties
        /// <summary>
        /// Is Alerts Enabled
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Feature.Alerts.Enabled", false);
            
                return _isEnabled.Value;

            }
        }

        /// <summary>
        /// Are we using TempData or Session
        /// </summary>
        public static bool UseTempData
        {
            get
            {
                _useTempData = _useTempData ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Feature.Alerts.TempData", false);

                return _useTempData.Value;

            }
        }
        #endregion
    }
}
