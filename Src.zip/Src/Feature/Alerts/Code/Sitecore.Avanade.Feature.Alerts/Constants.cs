﻿namespace Sitecore.Avanade.Feature.Alerts
{
    public static class Constants
    {
        public static class AlertFolderTemplate
        {
            public const string CacheKey = "AlertBase";

            public const string UniqueCacheKey = "AlertBaseUniqueKey";

            public const string ID = "{5CD5DEDF-FC53-4E1C-A821-4602D96D7D18}";

            public static class Fields
            {
                public const string UniqueIdentifier = "UniqueIdentifier";
            }
        }

        public static class AlertTemplate
        {
            public const string CacheListKey = "Alertlist";

            public static class Fields
            {
                public const string AlertClass = "AlertClass";
                public const string SVGClass = "SVGClass";
                public const string DefaultText = "DefaultText";
                public const string KeyMarker = "KeyMarker";
                public const string MarkAsDefault = "MarkAsDefault";
                public const string Dismissable = "Dismissable";
            }
        }
    }
}