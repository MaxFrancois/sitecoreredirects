﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Feature.Alerts.Extensions
{
    public static class TempDataDictionary
    {
        /// <summary>
        /// Get the unique key for the site
        /// </summary>
        /// <param name="tmp"></param>
        /// <returns></returns>
        private static string GetAlertUniqueKey(this System.Web.Mvc.TempDataDictionary tmp)
        {
            string uniqueKey = Sitecore.Avanade.Foundation.Cache.Cache.Get<string>(Constants.AlertFolderTemplate.UniqueCacheKey);

            if (uniqueKey.IsNullOrEmpty())
            {
                // get the cached instance
                Item alertFolderItem = tmp.GetAlertBase();

                if (alertFolderItem == null)
                {
                    return string.Empty;
                }

                uniqueKey = alertFolderItem.Fields[Constants.AlertFolderTemplate.Fields.UniqueIdentifier].ValueSafe();

                // add the key
                Sitecore.Avanade.Foundation.Cache.Cache.Add(Constants.AlertFolderTemplate.UniqueCacheKey, uniqueKey);
            }

            // get the unique identifer
            return uniqueKey;
        }

        private static Item GetAlertBase(this System.Web.Mvc.TempDataDictionary tmp)
        {
            // get the cached instance
            Item alertFolderItem = Sitecore.Avanade.Foundation.Cache.Cache.Get<Item>(Constants.AlertFolderTemplate.CacheKey);

            // have we got the data
            if (alertFolderItem == null)
            {
                // get the folder
                alertFolderItem = Sitecore.Context.Site.GetValidSiteContext().GetSettings(xPath: $"./*[@@templateid='{Constants.AlertFolderTemplate.ID}']");

                // add the item
                Sitecore.Avanade.Foundation.Cache.Cache.Add(Constants.AlertFolderTemplate.CacheKey, alertFolderItem);
            }

            return alertFolderItem;
        }

        /// <summary>
        /// Add an alert to the vie data
        /// </summary>
        /// <param name="tmp"></param>
        /// <param name="markerKey">The marker to add, if not found will use default</param>
        /// <param name="message">Add the message</param>
        public static void AddAlert(this System.Web.Mvc.TempDataDictionary tmp, string markerKey, string message)
        {
            // make sure we have what we want
            if (!Settings.IsEnabled
                || tmp == null
                || markerKey.IsNullOrEmpty())
            {
                return;
            }

            // make sure it is lower
            markerKey = markerKey.ToLower();

            IDictionary<string, Item> alertItems = Sitecore.Avanade.Foundation.Cache.Cache.Get<IDictionary<string, Item>>(Constants.AlertTemplate.CacheListKey);

            if (alertItems == null)
            {
                // create the new object
                alertItems = new Dictionary<string, Item>();

                // get the cached instance
                Item alertFolderItem = tmp.GetAlertBase();

                if (alertFolderItem == null)
                {
                    return;
                }

                alertFolderItem.GetChildren().ForEach(x =>
                {
                    alertItems.Add(x.Fields[Constants.AlertTemplate.Fields.KeyMarker].ValueSafe(), x);
                });

                Sitecore.Avanade.Foundation.Cache.Cache.Add(Constants.AlertTemplate.CacheListKey, alertItems);
            }

            if (alertItems == null || alertItems.Count ==0)
            {
                return;
            }

            Models.Alert alert = null;

            if (alertItems.ContainsKey(markerKey))
            {
                // get the alert
                alert = (Models.Alert)alertItems[markerKey];
            }

            if (alert == null)
            {
                // find the default
                var firstItem = alertItems.Values.FirstOrDefault(x => x.Fields[Constants.AlertTemplate.Fields.MarkAsDefault].IsChecked());

                // 
                if (firstItem == null)
                {
                    return;
                }

                alert = (Models.Alert)firstItem;
            }

            // add the correct msg
            alert.Message = message.IsNullOrEmpty() ? alert.DefaultText : message;

            IList<Models.Alert> alerts = tmp.GetAlerts();
            alerts.Add(alert);

            // get the unique identifer
            string uniqueIdentifer = tmp.GetAlertUniqueKey();

            // are we using temp data
            if (Settings.UseTempData)
            {
                // add back inttmpo the view ata
                tmp.Remove(uniqueIdentifer);
                tmp.Add(uniqueIdentifer, alerts);
            }
            else
            {
                // remove and then add just in case of issues
                System.Web.HttpContext.Current.Session.Remove(uniqueIdentifer);
                System.Web.HttpContext.Current.Session.Add(uniqueIdentifer, alerts);
            }
            
        }
        
        /// <summary>
        /// Removes the Alert
        /// </summary>
        /// <param name="tmp"></param>
        public static void RemoveAlerts(this System.Web.Mvc.TempDataDictionary tmp)
        {
            if (tmp == null)
            {
                return;
            }

            // get the unique key
            string uniqueIdentifer = tmp.GetAlertUniqueKey();

            // are we using temp data
            if (Settings.UseTempData)
            {
                tmp.Remove(uniqueIdentifer);

                // get the list
                return;
            }

            // remove the ession
            System.Web.HttpContext.Current.Session.Remove(uniqueIdentifer);
        }

        /// <summary>
        /// Get the listing of alerts
        /// </summary>
        /// <param name="tmp">The current temp data to look at</param>
        /// <returns>Returns the listing of alerts</returns>
        public static IList<Models.Alert> GetAlerts(this System.Web.Mvc.TempDataDictionary tmp)
        {
            if (tmp != null)
            {
                // get the unique key
                string uniqueIdentifer = tmp.GetAlertUniqueKey();

                // are we using temp data
                if (Settings.UseTempData)
                {
                    // get the list
                    return tmp.ContainsKey(uniqueIdentifer) ? (IList<Models.Alert>)tmp[uniqueIdentifer] : new List<Models.Alert>();
                }

                object alertsList = System.Web.HttpContext.Current.Session[uniqueIdentifer];

                if (alertsList != null)
                {
                    return (IList<Models.Alert>)alertsList;
                }
            }

            // get the list
            return new List<Models.Alert>();
        }
    }
}