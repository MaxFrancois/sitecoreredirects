﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Extensions.Attributes;
using Sitecore.Avanade.Feature.Alerts.Extensions;
using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Alerts.Controllers
{
    public class AlertsController : SitecoreController
    {
        /// <summary>
        /// Get the Alerts
        /// </summary>
        /// <returns></returns>
        public ActionResult Display()
        {
            // we have disabled
            if (!Settings.IsEnabled)
            {
                return new EmptyResult();
            }

             // get the list
            IList<Models.Alert> list = TempData.GetAlerts();

            // if we have no alerts
            if (list == null || list.Count == 0)
            {
                return new EmptyResult();
            }

            // remove any alerts
            TempData.RemoveAlerts();

            // return the required view with data
            return PartialView("~/Views/Alerts/Alerts.cshtml", list);
        }

        public ActionResult DisplayStatic()
        {
            return PartialView("~/Views/Alerts/AlertsStatic.cshtml");
        }
    }
}