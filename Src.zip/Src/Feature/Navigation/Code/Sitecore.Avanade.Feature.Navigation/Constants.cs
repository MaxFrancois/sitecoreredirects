﻿namespace Sitecore.Avanade.Feature.Navigation
{
    public static class Constants
    {
        public static class Navigation
        {
            #region Field Names
            public const string ShowInNavField = "ShowInNavigation";
            public const string LinkField = "NavgiationLink";
            public const string TitleField = "NavigationTitle";
            public const string AltTitleField = "AlternateNavigationTitle";
            public const string GreetingPrefixField = "GreetingTextPrefix";
            public const string GreetingSuffixField = "GreetingTextSuffix";
            public const string SubItemsField = "IncludeSubItems";
            public const string SectionClassField = "SectionClass";
            public const string DisplayClassField = "DisplayClass";
            public const string ButtonTitle = "ButtonTitle";
            #endregion

            #region Template Names
            public const string NavSectionTemplate = "NavigationSection";
            public const string NavItemTemplate = "NavigationItem";
            #endregion
        }
    }
}