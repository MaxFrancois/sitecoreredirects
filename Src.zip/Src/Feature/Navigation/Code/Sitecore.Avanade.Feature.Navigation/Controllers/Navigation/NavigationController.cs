﻿using Sitecore.Avanade.Feature.Navigation.Extensions;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Cache;


namespace Sitecore.Avanade.Feature.Navigation.Controllers.Navigation
{
    public class NavigationController : SitecoreController
    {
        private const string NavItemsKey = "NavItemsKey";

        // GET Footer Navigation
        public ActionResult GetFooterNavigation()
        {
            var navItems = RenderingContext.CurrentOrNull?.GetDataSourceItem()?.Children;

            //Nav type hasn't been set right or something else has gone wrong if we get here
            return PartialView("~/Views/Footer/FooterNavigation.cshtml", navItems);
        }

        // GET Main Navigation
        public ActionResult GetMainNavigation()
        {
            // navigation items list from cache
            Dictionary<Item, List<Item>> navItems = Cache.Get<Dictionary<Item, List<Item>>>(NavItemsKey);

            // have we got a cached item
            if (navItems == null || navItems.Count == 0)
            {
                //Model to send back to view
               navItems = new Dictionary<Item, List<Item>>();

                //data source items. Process to retrieve second level if mega menu
                //If the field isn't applied to the item, default it to show in the nav.
                RenderingContext.CurrentOrNull?.GetDataSourceItem()?.Children?.Where(c => c.TargetItemFieldChecked(Constants.Navigation.ShowInNavField))
                                                                              .ForEach(x => navItems.Add(x, x.Fields[Constants.Navigation.SubItemsField]?.ConvertToCheckboxField().Checked == true
                                                                              ? x.Fields[Constants.Navigation.LinkField]?.ConvertToLinkField()?.TargetItem?.Children?
                                                                                  .Where(c => c.IsValid() && c.Fields[Constants.Navigation.ShowInNavField]?.ConvertToCheckboxField().Checked == true)
                                                                                  .ToList()
                                                                              : new List<Item>()));


                // add to cache
                Cache.Add(NavItemsKey, navItems);
            }
        
            return PartialView("~/Views/Navigation/MainNavigation.cshtml", navItems ?? new Dictionary<Item, List<Item>>());
        }
    }
}