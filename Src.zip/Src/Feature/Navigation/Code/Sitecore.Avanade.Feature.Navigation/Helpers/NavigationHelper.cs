﻿using Sitecore.Avanade.Feature.Navigation.Models;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;
using System.Linq;

namespace Sitecore.Avanade.Feature.Navigation.Helpers
{
    public static class NavigationHelper
    {
        public static NavigationViewModel PopulateNavigationModel(Item itm, Item currentPage = null)
        {
            // Process each child item based on their template fields
            if (itm == null) return null;
            var navigation = new NavigationViewModel();
            var children = itm.Children;

            // Add immediate child Navigation items to their own section
            foreach (Item navItm in children.Where(child => child.TemplateName.Equals(Constants.Navigation.NavItemTemplate)).ToArray())
            {
                // Create a section for the loose items
                if (!navigation.Sections.Any()) { navigation.Sections.Add(new NavigationSection()); }
                navigation.Sections.FirstOrDefault()?.NavigationList.Add(PopulateNavigationItem(navItm, currentPage));
            }

            // Process section items
            foreach(Item secItm in children.Where(child => child.TemplateName.Equals(Constants.Navigation.NavSectionTemplate)).ToArray())
            {
                // Create the section item
                var section = new NavigationSection { SectionItem = secItm };

                // Add all sub items of template sections
                section.NavigationList.AddRange(secItm.Children.Select(nav => PopulateNavigationItem(nav, currentPage)).ToList());
                navigation.Sections.Add(section);
            }

            return navigation;
        }

        // TODO: Handle different link types than internal
        private static NavigationItem PopulateNavigationItem(Item itm, Item page)
        {
            var navItm = new NavigationItem { LinkItem = itm };
            
            // Only process internal link fields for now
            var link = itm.Fields[Constants.Navigation.LinkField]?.ConvertToLinkField();
            var target = link?.TargetItem;

            navItm.LinkUrl = link?.GetFriendlyUrl();
            navItm.Summary = target?.Fields["PageSummary"]?.Value;
            navItm.Title = target?.Fields[Constants.Navigation.TitleField]?.Value ?? itm.Name;
            navItm.DisplayClass = itm?.Fields[Constants.Navigation.DisplayClassField]?.Value;
            navItm.DataAttribute = SubMenuDataAttribute(link?.GetFinalText());
            navItm.Active = page?.ID.Equals(target?.ID) == true;

            return navItm;
        }

        // TODO: Move to be a HTML helper in project
        public static string SubMenuDataAttribute(string suffix)
        {
            return string.Format("submenu-{0}", suffix?.Replace(" ", "-").ToLower());
        }
    }
}