﻿using Sitecore.Data.Items;

namespace Sitecore.Avanade.Feature.Navigation.Models
{
    public class NavigationItem
    {
        public Item LinkItem { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public string LinkUrl { get; set; }
        public string DataAttribute { get; set; }
        public string DisplayClass { get; set; }
        public bool Active { get; set; }
    }
}