﻿using Sitecore.Data.Items;
using System.Collections.Generic;

namespace Sitecore.Avanade.Feature.Navigation.Models
{
    public class NavigationViewModel
    {
        public Item ListItem { get; set; }

        public List<NavigationSection> Sections { get; set; } = new List<NavigationSection>();
    }
}