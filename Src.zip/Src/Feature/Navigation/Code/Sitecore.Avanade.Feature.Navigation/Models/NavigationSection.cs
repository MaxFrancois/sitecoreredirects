﻿using Sitecore.Data.Items;
using System.Collections.Generic;

namespace Sitecore.Avanade.Feature.Navigation.Models
{
    public class NavigationSection
    {
        public Item SectionItem { get; set; }
        public List<NavigationItem> NavigationList { get; set; } = new List<NavigationItem>();
    }
}