﻿using Sitecore.Data.Items;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Feature.Navigation.Extensions
{
    public static class ItemExtensions
    {
        // Evaluate if a linked item is enabled for the main navigation menu
        public static bool TargetItemFieldChecked(this Item itm, string checkField)
        {
            if (!itm.HasField(Constants.Navigation.LinkField)) return false;
            var field = itm.Fields[Constants.Navigation.LinkField].ConvertToLinkField();
            if (field == null || !field.IsInternal) return false;
            var target = field.TargetItem;

            return target != null &&
                   target.HasField(checkField) &&
                   target.Fields[checkField].ConvertToCheckboxField().Checked;
        }
    }
}