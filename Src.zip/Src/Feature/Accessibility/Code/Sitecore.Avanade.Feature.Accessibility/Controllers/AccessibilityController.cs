﻿using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using Sitecore.Avanade.Foundation.Extensions;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions.Attributes;
using Sitecore.Avanade.Foundation.Site.Extensions;

namespace Sitecore.Avanade.Feature.Accessibility
{
    public class AccessibilityController : SitecoreController
    {
        /// <summary>
        /// Skip to content area
        /// </summary>
        /// <returns></returns>
        [DataSourceRequired]
        public ActionResult SkipToContent()
        {
            return PartialView("~/views/accessibility/skiptocontent.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem());
        }


        [DisableExperienceEditor]
        public ActionResult Metadata()
        {
            return PartialView("~/views/accessibility/metadata.cshtml",RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }


        [DisableExperienceEditor]
        public ActionResult OpenGraph()
        {
            return PartialView("~/views/accessibility/opengraph.cshtml",RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }


        [DisableExperienceEditor]
        public ActionResult TwitterCard()
        {
            return PartialView("~/views/accessibility/twittercard.cshtml",RenderingContext.CurrentOrNull?.GetDataSourceItem(true));
        }

        [DataSourceRequired]
        public ActionResult BrowserManagement()
        {
            return PartialView("~/views/accessibility/browsermanagement.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem());
        }

        [DataSourceRequired]
        public ActionResult SVGRender()
        {
            return PartialView("~/views/accessibility/svgrender.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem());
        }

        [DataSourceRequired]
        public ActionResult Robots()
        {
            // set the datasouce
            return PartialView("~/views/accessibility/robots.cshtml", RenderingContext.CurrentOrNull?.GetDataSourceItem()?.Axes.SelectSingleDomainItem(true));
        }

        [DataSourceRequired]
        [DisableExperienceEditor(DisableIsDebug = true, DisableIsPreview = true, DisableIsProfiling = true, DisableIsSimulatedDevicePreviewing = true)]
        public ActionResult ExternalAnalytics()
        {
            var itm = RenderingContext.CurrentOrNull?.GetDataSourceItem();

            // set the datasouce
            return PartialView("~/views/accessibility/externalanalytics.cshtml", itm == null ? null : itm.Axes.SelectSingleDomainItem(true));
        }
        
        public ActionResult MediaStreamer()
        {
            var itm = RenderingContext.CurrentOrNull?.GetDataSourceItem(true);

            if (itm != null
                && itm.HasBaseTemplate(Data.ID.Parse("{EB9ECC74-166D-4EE0-B54F-2B864C9F1344}")))
            {
                System.Tuple<string, string, string, Sitecore.Data.Items.DeviceItem> matchedDevice = Sitecore.Context.Items["DeviceExtensionContext"] as System.Tuple<string, string, string, Sitecore.Data.Items.DeviceItem>;

                // This is a fix to resolve the error issue but it should not even hit this point
                return RedirectToAction("MediaStreamerFile", new { itm = itm.ID.ToString(), contentType = matchedDevice.Item2 });
            }
            
            return null;

        }

        [HttpGet]
        public ActionResult MediaStreamerFile(string itm, string contentType)
        {
            // make sure we have what we need
            if (itm.IsNullOrEmpty() || contentType.IsNullOrEmpty())
            {
                return null;
            }

            // the file media
            Data.Items.Item fileMedia = Sitecore.Context.Database.GetItem(itm);

            if (fileMedia == null)
            {
                return null;
            }

            return File(fileMedia.Fields["media"].ConvertToMediaItem().GetMediaStream(), contentType, null);
        }


    }
}