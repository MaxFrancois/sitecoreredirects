﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Feature.Accessibility.Model
{
    public class DynamicMetaData
    {
        /*
        <link rel="icon" type="image/png" sizes="16x16" href="/resources/img/favicon-16x16.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/resources/css/quitline-styles.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
    <script type="text/javascript">
    //<![CDATA[
        (window.Modernizr) || document.write('<script type="text/javascript" src="/resources/js/libs/modernizr.custom.min.js"><\/script>');//]]>
    </script>

            <!--
            COPY RIGHT INFORMATION MAY BE REQUIRED
            -->
        */
        public string ElementType { get; set; }
        public string Name { get; set; }
        public string Content { get; set; }
        public string Type { get; set; }
        public string Sizes { get; set; }
        public string Href { get; set; }
        public string Body { get; set; }
        public bool UseHrefInBody { get; set; }
        public string CommentText { get; set; }
    }

    public enum ElementTypes
    {
        Link,
        Meta,
        Script
    }
}