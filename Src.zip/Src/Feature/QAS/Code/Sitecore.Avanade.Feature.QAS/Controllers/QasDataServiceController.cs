﻿using Experian.Qas.Capture.IntegrationCode;
using Sitecore.Avanade.Feature.QAS.Helpers;
using Sitecore.Avanade.Feature.QAS.Models;
using Sitecore.Diagnostics;
using Sitecore.Services.Infrastructure.Web.Http;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.SessionState;

namespace Sitecore.Avanade.Feature.QAS.Controllers
{
    /// <summary>
    /// QAS address services
    /// </summary>
    /// <remarks>Acts as a wrapper for a json based service calls</remarks>
    [SessionState(SessionStateBehavior.Disabled)]
    public class QasDataServiceController : ServicesApiController
    {
        // GET: /QasDataService/GetFormattedAddress
        public dynamic GetAddress(string moniker, string layout, string requestTag, string localisation)
        {
            FormattedAddress address;

            try
            {
                // Create new search connection
                var searchService = QasHelper.CreateQasCaptureFromConfig();
                address = QasHelper.GetAddress(searchService, moniker, layout, requestTag, localisation);
            }
            catch (Exception ex)
            {
                Log.Error("QAS getaddress threw an exception", ex, this);
                return new { hasError = true, data = ex.Message };
            }

            return address;
        }

        // GET: /QasDataService/Search
        public dynamic Search(string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold,
            int? timeout, string layout, string search, bool? formattedAddressInPicklist, string requestTag, string localisation)
        {
            List<QasAddressItem> list;

            try
            {
                // Create new search connection
                var searchService = QasHelper.CreateQasCaptureFromConfig();

                // Check that searching with this engine and layout is available
                if (QasHelper.CanSearch(searchService, countryId, engine, flatten, intensity, promptSet, threshold,
                    timeout, layout, localisation))
                {
                    // Search on the address
                    list = QasHelper.PerformSearch(searchService, countryId, engine, flatten, intensity, promptSet,
                        threshold, timeout, layout, search, formattedAddressInPicklist, requestTag, localisation);
                }
                else
                {
                    return new { hasError = true, data = "Unable to search with the current configuration" };
                }
            }
            catch (Exception ex)
            {
                Log.Error("QAS search threw an exception", ex, this);
                return new { hasError = true, data = ex.Message };
            }

            // Take the top 10 items
            return list;
        }

        // GET: /QasDataService/Refine
        public dynamic Refine(string moniker, string refinement, string layout, bool? formattedAddressInPicklist,
            int? threshold, int? timeout, string requestTag, string localisation)
        {
            var list = new List<QasAddressItem>();

            try
            {
                QasHelper.RefineSearch(QasHelper.CreateQasCaptureFromConfig(), moniker, refinement, layout,
                    formattedAddressInPicklist, threshold, timeout, requestTag, localisation);
            }
            catch (Exception ex)
            {
                Log.Error("QAS refine threw an exception", ex, this);
                return new { hasError = true, data = ex.Message };
            }

            return list;
        }

        // GET: /QasDataService/ValidateEmailAddress
        public dynamic ValidateEmailAddress(string email)
        {
            QasEmailValidationResponse response;

            try
            {
                response = QasHelper.ValidateEmailAddress(email);
                if (response == null) throw new System.Data.DataException("Response from QAS email validation was empty.");
            }
            catch (Exception ex)
            {
                Log.Error("QAS email validation threw an exception", ex, this);
                return new QasEmailValidationResponse
                       {
                           Certainty = "unknown",
                           Corrections = null,
                           Email = email,
                           Message = "OK"
                       };
            }

            return response;
        }

        #if DEBUG
        // GET: /QasDataService/GetExampleAddress
        [HttpGet]
        public dynamic GetExampleAddress(string countryId, string layout, string requestTag, string localisation)
        {
            if (string.IsNullOrWhiteSpace(countryId)) countryId = Data.Configuration.CountryId;
            if (string.IsNullOrWhiteSpace(layout)) layout = Data.Configuration.Layout;
            if (string.IsNullOrWhiteSpace(requestTag)) requestTag = Data.Configuration.RequestTag;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return QasHelper.CreateQasCaptureFromConfig()
                        .GetExampleAddresses(countryId, layout, requestTag,
                            localisation);
        }

        // GET: /QasDataService/GetPromptSet
        [HttpGet]
        public dynamic GetPromptSet(string countryId, string engine, bool? flatten, string promptSet,
            int? threshold, int? timeout, string localisation)
        {
            if (string.IsNullOrWhiteSpace(countryId)) countryId = Data.Configuration.CountryId;
            if (string.IsNullOrWhiteSpace(engine)) engine = Data.Configuration.Engine;
            if (flatten == null) flatten = Data.Configuration.Flatten;
            if (string.IsNullOrWhiteSpace(promptSet)) promptSet = Data.Configuration.Promptset;
            if (threshold == null) threshold = Data.Configuration.Threshold;
            if (timeout == null) timeout = Data.Configuration.Timeout;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return QasHelper.CreateQasCaptureFromConfig()
                        .GetPromptSet(countryId, engine, flatten,
                            promptSet, threshold, timeout,
                            localisation);
        }

        // GET: /QasDataService/GetData
        [HttpGet]
        public dynamic GetData(string localisation)
        {
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return QasHelper.CreateQasCaptureFromConfig().GetData(localisation);
        }

        // GET: /QasDataService/GetLayouts
        [HttpGet]
        public dynamic GetLayouts(string countryId, string localisation)
        {
            if (string.IsNullOrWhiteSpace(countryId)) countryId = Data.Configuration.CountryId;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return QasHelper.CreateQasCaptureFromConfig().GetLayouts(countryId, localisation);
        }
        #endif
    }
}