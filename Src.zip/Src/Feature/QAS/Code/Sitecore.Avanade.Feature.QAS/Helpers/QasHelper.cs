﻿using Experian.Qas.Capture.IntegrationCode;
using Experian.Qas.Capture.IntegrationCode.V3;
using Sitecore.Avanade.Feature.QAS.Models;
using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using Picklist = Experian.Qas.Capture.IntegrationCode.Picklist;

namespace Sitecore.Avanade.Feature.QAS.Helpers
{
    /// <summary>
    /// Handles calls to the main Qas assembly 
    /// Includes pulling items from configuration for those that aren't required
    /// </summary>
    public static class QasHelper
    {
        /// <summary>
        /// Initialise the main client 
        /// </summary>
        /// <returns>Configuration based search client object</returns>
        public static IQASCapture CreateQasCaptureFromConfig()
        {
            // Retrieve settings from web.config
            var ondemandUrl = Data.Configuration.OnDemandUrl;
            var username = Data.Configuration.OnDemandUsername;
            var password = Data.Configuration.OnDemandPassword;
            var proxyUrl = Data.Configuration.OnDemandProxyUrl;
            var proxyUsername = Data.Configuration.OnDemandProxyUsername;
            var proxyPassword = Data.Configuration.OnDemandProxyPassword;

            // Create QuickAddress search object
            if (string.IsNullOrEmpty(proxyUrl)) return new QASCapture(ondemandUrl, username, password);

            // Proxy based implementation
            var proxy = new WebProxy(proxyUrl, true);
            var credentials = new NetworkCredential(proxyUsername, proxyPassword);
            proxy.Credentials = credentials;

            // Create QuickAddress search object with proxy server
            return new QASCapture(ondemandUrl, username, password, proxy);
        }

        /// <summary>
        /// Check that the current configuration will result in search results
        /// </summary>
        /// <returns>Use a pre-created search object to check if a search is possible</returns>
        public static bool CanSearch(IQASCapture searchService, string countryId, string engine, bool? flatten, string intensity, string promptSet,
            int? threshold, int? timeout, string layout, string localisation)
        {
            // We always need a search terms so don't waste time calling the service
            if (searchService == null) searchService = CreateQasCaptureFromConfig();
            if (string.IsNullOrWhiteSpace(countryId)) countryId = Data.Configuration.CountryId;
            if (string.IsNullOrWhiteSpace(engine)) engine = Data.Configuration.Engine;
            if (flatten == null) flatten = Data.Configuration.Flatten;
            if (string.IsNullOrWhiteSpace(intensity)) intensity = Data.Configuration.Intensity;
            if (string.IsNullOrWhiteSpace(promptSet)) promptSet = Data.Configuration.Promptset;
            if (threshold == null) threshold = Data.Configuration.Threshold;
            if (timeout == null) timeout = Data.Configuration.Timeout;
            if (string.IsNullOrWhiteSpace(layout)) layout = Data.Configuration.Layout;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            var result = searchService.CanSearch(countryId, engine, flatten, intensity, promptSet, threshold,
                    timeout, layout, localisation);

            return result.IsOk;
        }

        /// <summary>
        /// Pure configuration based Qas address search
        /// </summary>
        /// <returns></returns>
        public static List<QasAddressItem> PerformSearch(IQASCapture searchService, string searchText)
        {
            return PerformSearch(searchService, string.Empty, string.Empty, null, string.Empty, string.Empty, null, null,
                string.Empty, searchText, null, string.Empty, string.Empty);
        }

        /// <summary>
        /// Make requests to the email validation service
        /// </summary>
        /// <returns></returns>
        public static QasEmailValidationResponse ValidateEmailAddress(string email)
        {
            // Create the json object
            var serializer = new JavaScriptSerializer();
            var emailItem = new QasEmailItem { Email = HttpUtility.HtmlEncode(email) };
            var emailJson = serializer.Serialize(emailItem);
            QasEmailValidationResponse validationResponse = null;
            HttpWebResponse getResponse = null;
            string getUrl;

            // Call the post request Url
            using (var postResponse = CallQasValidation(Data.Configuration.EmailValidationUrl, WebRequestMethods.Http.Post, emailJson))
            {
                getUrl = postResponse.Headers[Data.Constants.HeaderContentLocation];
            }

            // Call the get request returned from the post
            var retries = Data.Configuration.EmailValidationRetries;
            do
            {
                retries--;
                // To facilitate reties after response errors
                try
                {
                    // Ensure the url is a valid html request
                    getResponse = CallQasValidation(HttpUtility.HtmlEncode(getUrl), WebRequestMethods.Http.Get);
                    
                    if (getResponse != null)
                    {
                        var responseStream = getResponse.GetResponseStream();

                        if (responseStream == null) continue;
                        using (var reader = new StreamReader(responseStream))
                        {
                            var getResponseData = reader.ReadToEnd();
                            validationResponse = serializer.Deserialize<QasEmailValidationResponse>(getResponseData);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(string.Format("QAS email validation for '{0}' failed: {1} retries left. Response: {2}", email, retries, getResponse == null ? "null" : getResponse.StatusCode.ToString()), ex);
                    System.Threading.Thread.Sleep(Data.Configuration.EmailValidationTimeout ?? 0);
                }
            } while ((getResponse == null || !getResponse.StatusCode.Equals(HttpStatusCode.OK)) && retries > 0);
            if (getResponse != null) getResponse.Close();

            return validationResponse ?? new QasEmailValidationResponse
            {
                Certainty = "unknown",
                Corrections = null,
                Email = email,
                Message = "OK"
            };
        }

        /// <summary>
        /// Call the Qas email validation service
        /// </summary>
        private static HttpWebResponse CallQasValidation(string url, string method, string dataString = null)
        {
            var request = WebRequest.Create(url) as HttpWebRequest;

            if (request == null) return null;
            request.Method = method;
            request.ContentType = Data.Configuration.EmailRequestContentType;
            request.Headers.Add(Data.Constants.HeaderAuthToken, Data.Configuration.EmailToken);

            if (!string.IsNullOrWhiteSpace(dataString))
            {
                // Retrieve the data stream
                var data = Encoding.UTF8.GetBytes(dataString);
                request.ContentLength = data.Length;
                var dataStream = request.GetRequestStream();
                dataStream.Write(data, 0, data.Length);
                dataStream.Close();
            }

            return request.GetResponse() as HttpWebResponse;
        }

        /// <summary>
        /// Wrapper method that handles missing items with standard values
        /// </summary>
        /// <returns>List of <see cref="QasAddressItem"/>s</returns>
        public static List<QasAddressItem> PerformSearch(IQASCapture searchService, string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold,
            int? timeout, string layout, string searchText, bool? formattedAddressInPicklist, string requestTag, string localisation)
        {
            // We always need a search terms so don't waste time calling the service
            if (string.IsNullOrWhiteSpace(searchText)) throw new ArgumentNullException("searchText", "Value cannot be null or empty.");
            if (searchService == null) searchService = CreateQasCaptureFromConfig();
            if (string.IsNullOrWhiteSpace(countryId)) countryId = Data.Configuration.CountryId;
            if (string.IsNullOrWhiteSpace(engine)) engine = Data.Configuration.Engine;
            if (flatten == null) flatten = Data.Configuration.Flatten;
            if (string.IsNullOrWhiteSpace(intensity)) intensity = Data.Configuration.Intensity;
            if (string.IsNullOrWhiteSpace(promptSet)) promptSet = Data.Configuration.Promptset;
            if (threshold == null) threshold = Data.Configuration.Threshold;
            if (timeout == null) timeout = Data.Configuration.Timeout;
            if (string.IsNullOrWhiteSpace(layout)) layout = Data.Configuration.Layout;
            if (formattedAddressInPicklist == null) formattedAddressInPicklist = Data.Configuration.FormattedAddressInPicklist;
            if (string.IsNullOrWhiteSpace(requestTag)) requestTag = Data.Configuration.RequestTag;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            var searchResult = searchService.Search(countryId, engine, flatten, intensity, promptSet, threshold,
                        timeout, layout, searchText, formattedAddressInPicklist,
                        requestTag, localisation);

            return ProcessQasSearchResult(searchResult.Picklist);
        }

        /// <summary>
        /// Refine a list of results using an address moniker
        /// </summary>
        /// <returns>The search item is always </returns>
        public static List<QasAddressItem> RefineSearch(IQASCapture searchService, string moniker, string refinement, string layout,
            bool? formattedAddressInPicklist, int? threshold, int? timeout, string requestTag, string localisation)
        {
            if (string.IsNullOrWhiteSpace(moniker)) throw new ArgumentNullException("moniker", "Value cannot be null or empty.");
            if (searchService == null) searchService = CreateQasCaptureFromConfig();
            if (threshold == null) threshold = Data.Configuration.Threshold;
            if (timeout == null) timeout = Data.Configuration.Timeout;
            if (string.IsNullOrWhiteSpace(layout)) layout = Data.Configuration.Layout;
            if (formattedAddressInPicklist == null) formattedAddressInPicklist = Data.Configuration.FormattedAddressInPicklist;
            if (string.IsNullOrWhiteSpace(requestTag)) requestTag = Data.Configuration.RequestTag;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return ProcessQasSearchResult(searchService.Refine(moniker, refinement, layout, formattedAddressInPicklist,
                    threshold, timeout, requestTag, localisation));
        }

        public static FormattedAddress GetAddress(string moniker)
        {
            return GetAddress(null, moniker, string.Empty, string.Empty, string.Empty);
        }

        public static FormattedAddress GetAddress(IQASCapture searchService, string moniker)
        {
            return GetAddress(searchService, moniker, string.Empty, string.Empty, string.Empty);
        }

        public static FormattedAddress GetAddress(IQASCapture searchService, string moniker, string layout, string requestTag, string localisation)
        {
            if (string.IsNullOrWhiteSpace(moniker)) throw new ArgumentNullException("moniker", "Value cannot be null or empty.");
            if (searchService == null) searchService = CreateQasCaptureFromConfig();
            if (string.IsNullOrWhiteSpace(layout)) layout = Data.Configuration.Layout;
            if (string.IsNullOrWhiteSpace(requestTag)) requestTag = Data.Configuration.RequestTag;
            if (string.IsNullOrWhiteSpace(localisation)) localisation = Data.Configuration.Localisation;

            return searchService.GetAddress(moniker, layout, requestTag, localisation);
        }

        /// <summary>
        /// Translate a picklist into a QasAddress list using the moniker and partial address
        /// </summary>
        /// <param name="picklist">List of addresses returned from a search or refinement call</param>
        /// <returns>List of QasAddress objects</returns>
        public static List<QasAddressItem> ProcessQasSearchResult(Picklist picklist)
        {
            var list = new List<QasAddressItem>();

            // Clear address list
            if (picklist != null && picklist.Total > 0)
            {
                // Get pick list entries
                // Write the results to the address list. Also store the SPMs for use in formatting
                var items = (from i in picklist.GetItems()
                            where string.IsNullOrWhiteSpace(i.PartialAddress) == false
                                && i.PartialAddress.StartsWith("PO Box") == false
                                && i.PartialAddress.StartsWith("Private Bag") == false
                            select new QasAddressItem { Address = i.PartialAddress, Key = i.Moniker }).ToList();

                list.AddRange(items);
            }

            return list;
        }
    }
}