﻿The following steps are needed to configure the QAS services

######## Sitcore Settings Configuration #########
Update the following settings in the QAS sitecore include file

<!-- QAS Application Settings -->
  <sitecore>
    <settings>
      <!-- QAS SERVICE URL
           The web service to call for 
           all address validation requests -->
      <setting name="Experian.Qas.Capture.OnDemandUrl" value="https://ws2.ondemand.qas.com/ProOnDemand/V3/ProOnDemandService.asmx" />
      <setting name="Experian.Qas.Capture.OnDemandUsername" value="QAS_ACCOUNT_USERNAME" />
      <setting name="Experian.Qas.Capture.OnDemandPassword" value="QAS_ACCOUNT_PASSWORD" />
      <!-- QAS LAYOUT -->
      <setting name="Experian.Qas.Capture.Layout" value="QAS_LAYOUT_CODE" />
      <!-- QAS COUNTRY ID -->
      <setting name="Experian.Qas.Capture.CountryId" value="QAS_COUNTRY_CODE" />
      <!-- QAS EMAIL TOKEN -->
      <setting name="Experian.Qas.Capture.EmailToken" value="QAS_EMAIL_TOKEN" />
    </settings>
  </sitecore>
########### TBC ###############
