﻿using System.Linq;
using Sitecore.Avanade.Feature.QAS.Helpers;
using Sitecore.Diagnostics;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sitecore.Avanade.Feature.QAS.Data.Validation
{
    public class QasEmailValidationAttribute : ValidationAttribute
    {
        public string[] ValidStatuses { get; set; }

        public QasEmailValidationAttribute(string[] validStatuses)
            : base("The provided email address '{0}' was not valid.")
        {
            ValidStatuses = validStatuses;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var email = value as string;
            if (string.IsNullOrWhiteSpace(email)) return ValidationResult.Success;

            try
            {
                var response = QasHelper.ValidateEmailAddress(email);

                if (!ValidStatuses.Contains(response.Certainty, StringComparer.InvariantCultureIgnoreCase))
                {
                    return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
                }
            }
            catch (Exception ex)
            {
                // Pass the email address 
                Log.Error("Qas email validation failed.", ex);
            }

            return ValidationResult.Success;
        }
    }
}