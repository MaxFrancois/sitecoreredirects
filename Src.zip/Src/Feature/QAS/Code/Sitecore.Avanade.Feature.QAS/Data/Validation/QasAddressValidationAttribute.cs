﻿using Sitecore.Avanade.Feature.QAS.Helpers;
using Sitecore.Avanade.Feature.QAS.Models;
using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Sitecore.Avanade.Feature.QAS.Data.Validation
{
    public class QasAddressValidationAttribute : ValidationAttribute
    {
        public AddressFields[] RequiredFields { get; set; }

        public QasAddressValidationAttribute(AddressFields[] requiredFields)
            : base("No address was entered for the {0} field.")
        {
            RequiredFields = requiredFields ?? new AddressFields[0];
        }

        /// <summary>
        /// Validates the specified value with respect to the current validation attribute.
        /// </summary>
        /// <param name="value">The value to validate.</param>
        /// <param name="validationContext">The context information about the validation operation.</param>
        /// <returns>
        /// An instance of the <see cref="T:System.ComponentModel.DataAnnotations.ValidationResult"/> class.
        /// </returns>
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            // We aren't checking for required status
            var address = value as QasAddressField;
            if (address == null)
            {
                return ValidationResult.Success;
            }

            try
            {
                var item = address.AddressItem;
                var returnMembers = HasRequiredFields(address, validationContext.DisplayName);

                // Check the auto-complete QAS field
                if (!address.NotFound && (item == null ||
                    string.IsNullOrWhiteSpace(item.Key) ||
                    QasHelper.GetAddress(item.Key) == null))
                {
                    returnMembers.Add(validationContext.DisplayName + ".AddressItem");
                }

                // If any members have been selected return an validation error
                if (returnMembers.Any())
                {
                    return new ValidationResult(FormatErrorMessage(validationContext.DisplayName), returnMembers);
                }
            }
            catch (Exception ex)
            {
                Log.Error("An exception occured while validating qas address fields", ex, this);
                return new ValidationResult("A problem was encountered validating address input");
            }

            return ValidationResult.Success;
        }

        /// <summary>
        /// Check each field
        /// </summary>
        /// <param name="address">Required parameter</param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        private List<string> HasRequiredFields(QasAddressField address, string fieldName)
        {
            Assert.ArgumentNotNull(address, fieldName);
            var members = new List<string>();

            if (address.NotFound)
            {
                if (RequiredFields.Contains(AddressFields.UnitNumber) &&
                    string.IsNullOrWhiteSpace(address.UnitNumber))
                {
                    members.Add(fieldName + ".UnitNumber");
                }

                if (RequiredFields.Contains(AddressFields.StreetNumber) &&
                    string.IsNullOrWhiteSpace(address.StreetNumber))
                {
                    members.Add(fieldName + ".StreetNumber");
                }

                if (RequiredFields.Contains(AddressFields.StreetName) &&
                    string.IsNullOrWhiteSpace(address.StreetName))
                {
                    members.Add(fieldName + ".StreetName");
                }

                if (RequiredFields.Contains(AddressFields.StreetType) &&
                    address.StreetType != null &&
                    string.IsNullOrWhiteSpace(address.StreetType.id))
                {
                    members.Add(fieldName + ".StreetType");
                }

                if (RequiredFields.Contains(AddressFields.Suburb) &&
                    string.IsNullOrWhiteSpace(address.Suburb))
                {
                    members.Add(fieldName + ".Suburb");
                }

                if (RequiredFields.Contains(AddressFields.City) &&
                    string.IsNullOrWhiteSpace(address.City))
                {
                    members.Add(fieldName + ".City");
                }

                if (RequiredFields.Contains(AddressFields.Country) &&
                    address.Country != null &&
                    string.IsNullOrWhiteSpace(address.Country.id))
                {
                    members.Add(fieldName + ".Country");
                }
            }

            return members;
        }

        #region Enums
        public enum AddressFields
        {
            UnitNumber,
            StreetNumber,
            StreetName,
            StreetType,
            Suburb,
            City,
            Country
        }
        #endregion
    }
}