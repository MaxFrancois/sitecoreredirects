﻿using System;
using Sitecore.Configuration;

namespace Sitecore.Avanade.Feature.QAS.Data
{
    public static class Configuration
    {
        static Configuration()
        {
            OnDemandUrl = Settings.GetSetting(Constants.KeyConfigOnDemandUrl);
            OnDemandUsername = Settings.GetSetting(Constants.KeyConfigOnDemandUsername);
            OnDemandPassword = Settings.GetSetting(Constants.KeyConfigOnDemandPassword);
            OnDemandProxyUrl = Settings.GetSetting(Constants.KeyConfigOnDemandProxyUrl);
            OnDemandProxyUsername = Settings.GetSetting(Constants.KeyConfigOnDemandProxyUsername);
            OnDemandProxyPassword = Settings.GetSetting(Constants.KeyConfigOnDemandProxyPassword);
            Layout = Settings.GetSetting(Constants.KeyConfigLayout);
            CountryId = Settings.GetSetting(Constants.KeyConfigCountryId);
            EmailValidationUrl = Settings.GetSetting(Constants.KeyConfigEmailValidationUrl);
            EmailToken = Settings.GetSetting(Constants.KeyConfigEmailToken);
            EmailRequestContentType = Settings.GetSetting(Constants.KeyConfigEmailRequestType);
            EmailValidationRetries = Int32.Parse(Settings.GetSetting(Constants.KeyConfigEmailValidationRetries) ?? "0");
            EmailValidationTimeout = Int32.Parse(Settings.GetSetting(Constants.KeyConfigEmailValidationTimeout) ?? "0");
            Engine = Settings.GetSetting(Constants.KeyConfigEngine, "Singleline");
            Flatten = Boolean.Parse(Settings.GetSetting(Constants.KeyConfigFlatten) ?? "true");
            Intensity = Settings.GetSetting(Constants.KeyConfigIntensity);
            Promptset = Settings.GetSetting(Constants.KeyConfigPromptset);
            Threshold = Int32.Parse(Settings.GetSetting(Constants.KeyConfigThreshold) ?? "0");
            Timeout = Int32.Parse(Settings.GetSetting(Constants.KeyConfigTimeout) ?? "0");
            FormattedAddressInPicklist = Boolean.Parse(Settings.GetSetting(Constants.KeyConfigFlatten) ?? "true");
            Localisation = Settings.GetSetting(Constants.KeyConfigLocalisation);
            Refinement = Settings.GetSetting(Constants.KeyConfigRefinement);
        }

        public static string OnDemandUrl { get; set; }
        public static string OnDemandUsername { get; set; }
        public static string OnDemandPassword { get; set; }
        public static string OnDemandProxyUrl { get; set; }
        public static string OnDemandProxyUsername { get; set; }
        public static string OnDemandProxyPassword { get; set; }
        public static string Layout { get; set; }
        public static string CountryId { get; set; }
        public static string EmailValidationUrl { get; set; }
        public static string EmailToken { get; set; }
        public static string Engine { get; set; }
        public static bool? Flatten { get; set; }
        public static string Intensity { get; set; }
        public static string Promptset { get; set; }
        public static int? Threshold { get; set; }
        public static int? Timeout { get; set; }
        public static bool? FormattedAddressInPicklist { get; set; }
        public static string RequestTag { get; set; }
        public static string Localisation { get; set; }
        public static string Refinement { get; set; }
        public static string EmailRequestContentType { get; set; }
        public static int? EmailValidationRetries { get; set; }
        public static int? EmailValidationTimeout { get; set; }
    }
}