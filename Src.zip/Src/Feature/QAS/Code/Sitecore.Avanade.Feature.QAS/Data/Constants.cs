﻿namespace Sitecore.Avanade.Feature.QAS.Data
{
    /// <summary>
    /// Pulled from the example implementation code version 1903
    /// </summary>
    public static class Constants
    {
        // rpc param keys
        internal static readonly string ParamKeyMethod = "method";
        internal static readonly string ParamKeyCountryId = "countryId";
        internal static readonly string ParamKeyEngine = "engine";
        internal static readonly string ParamKeyFlatten = "flatten";
        internal static readonly string ParamKeyIntensity = "intensity";
        internal static readonly string ParamKeyPromptset = "promptset";
        internal static readonly string ParamKeyThreshold = "threshold";
        internal static readonly string ParamKeyTimeout = "timeout";
        internal static readonly string ParamKeyLayout = "layout";
        internal static readonly string ParamKeySearch = "search";
        internal static readonly string ParamKeyIsFormattedAddressInPicklist = "formattedAddressInPicklist";
        internal static readonly string ParamKeyRequestTag = "requestTag";
        internal static readonly string ParamKeyLocalisation = "localisation";
        internal static readonly string ParamKeyMoniker = "moniker";
        internal static readonly string ParamKeyRefinement = "refinement";

        // web.config keys - ondemand account
        internal static readonly string KeyConfigOnDemandUrl = "Experian.Qas.Capture.OnDemandUrl";
        internal static readonly string KeyConfigOnDemandUsername = "Experian.Qas.Capture.OnDemandUsername";
#pragma warning disable S2068 // Credentials should not be hard-coded
        internal static readonly string KeyConfigOnDemandPassword = "Experian.Qas.Capture.OnDemandPassword";
#pragma warning restore S2068 // Credentials should not be hard-coded

        // web.config keys - proxy settings
        internal static readonly string KeyConfigOnDemandProxyUrl = "Experian.Qas.Capture.ProxyUrl";
        internal static readonly string KeyConfigOnDemandProxyUsername = "Experian.Qas.Capture.ProxyUsername";
#pragma warning disable S2068 // Credentials should not be hard-coded
        internal static readonly string KeyConfigOnDemandProxyPassword = "Experian.Qas.Capture.ProxyPassword";
#pragma warning restore S2068 // Credentials should not be hard-coded

        // Custom QAS settings items
        internal static readonly string KeyConfigLayout = "Experian.Qas.Capture.Layout";
        internal static readonly string KeyConfigCountryId = "Experian.Qas.Capture.CountryId";
        internal static readonly string KeyConfigEngine = "Experian.Qas.Capture.Engine";
        internal static readonly string KeyConfigFlatten = "Experian.Qas.Capture.Flatten";
        internal static readonly string KeyConfigIntensity = "Experian.Qas.Capture.Intensity";
        internal static readonly string KeyConfigPromptset = "Experian.Qas.Capture.Promptset";
        internal static readonly string KeyConfigThreshold = "Experian.Qas.Capture.Threshold";
        internal static readonly string KeyConfigTimeout = "Experian.Qas.Capture.Timeout";
        internal static readonly string KeyConfigSearch = "Experian.Qas.Capture.Search";
        internal static readonly string KeyConfigIsFormattedAddressInPicklist = "Experian.Qas.Capture.FormattedAddressInPicklist";
        internal static readonly string KeyConfigRequestTag = "Experian.Qas.Capture.RequestTag";
        internal static readonly string KeyConfigLocalisation = "Experian.Qas.Capture.Localisation";
        internal static readonly string KeyConfigRefinement = "Experian.Qas.Capture.Refinement";
        // Email related settings
        internal static readonly string KeyConfigEmailValidationUrl = "Experian.Qas.Capture.EmailValidationUrl";
        internal static readonly string KeyConfigEmailToken = "Experian.Qas.Capture.EmailToken";
        internal static readonly string KeyConfigEmailRequestType = "Experian.Qas.Capture.EmailRequestType";
        internal static readonly string KeyConfigEmailValidationRetries = "Experian.Qas.Capture.EmailValidationRetries";
        internal static readonly string KeyConfigEmailValidationTimeout = "Experian.Qas.Capture.EmailValidationTimeout";

        // Request Header names
        internal static readonly string HeaderAuthToken = "Auth-Token";
        internal static readonly string HeaderContentType = "Content-Type";
        internal static readonly string HeaderContentLocation = "Content-Location";
    }
}