﻿using System.Runtime.Serialization;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    [DataContract]
    public class QasAddressItem
    {
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string Key { get; set; }
    }
}