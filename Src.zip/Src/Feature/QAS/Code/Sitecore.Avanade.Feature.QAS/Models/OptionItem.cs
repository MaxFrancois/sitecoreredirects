﻿using System.Runtime.Serialization;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    [DataContract]
    public class OptionItem
    {
        [DataMember]
        public string id { get; set; }

        [DataMember]
        public string title { get; set; }
    }
}