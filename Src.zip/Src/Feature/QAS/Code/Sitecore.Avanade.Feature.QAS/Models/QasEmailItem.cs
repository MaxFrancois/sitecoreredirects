﻿using System.Runtime.Serialization;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    [DataContract]
    public class QasEmailItem
    {
        [DataMember]
        public string Email { get; set; }
    }
}