﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    [DataContract]
    public class QasEmailValidationResponse
    {
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string Certainty { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public List<string> Corrections { get; set; }
    }
}