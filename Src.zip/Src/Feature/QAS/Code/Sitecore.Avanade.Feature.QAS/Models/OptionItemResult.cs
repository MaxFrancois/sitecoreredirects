﻿using System.Runtime.Serialization;
using Sitecore.ContentSearch.SearchTypes;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    [DataContract]
    public class OptionItemResult : SearchResultItem
    {
        [DataMember]
        public string Text { get; set; }

        [DataMember]
        public string Value { get; set; }
    }
}