﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace Sitecore.Avanade.Feature.QAS.Models
{
    /// <summary>
    /// Warehouse Money specific implementation
    /// </summary>
    [DataContract]
    public class QasAddressField
    {
        // QAS autocomplete field
        [DataMember, DisplayName("Address")]
        public QasAddressItem AddressItem { get; set; }

        // Manual fields
        [DataMember, DisplayName("Address Number")]
        public string UnitNumber { get; set; }

        [DataMember, DisplayName("Address Line 1")]
        public string StreetNumber { get; set; }

        [DataMember, DisplayName("Address Line 2")]
        public string StreetName { get; set; }

        [DataMember, DisplayName("Address Line 3")]
        public OptionItem StreetType { get; set; }

        [DataMember, DisplayName("Address Line 4")]
        public string Suburb { get; set; }

        [DataMember, DisplayName("Address Line 5")]
        public string City { get; set; }

        [DataMember, DisplayName("Country")]
        public OptionItem Country { get; set; }

        [DataMember, DisplayName("Postcode")]
        public string PostCode { get; set; }

        [DataMember, DisplayName("Address not found?")]
        public bool NotFound { get; set; }
    }
}