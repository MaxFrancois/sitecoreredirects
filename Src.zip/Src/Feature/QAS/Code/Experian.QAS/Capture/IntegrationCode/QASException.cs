﻿using System;
using System.Runtime.Serialization;
using System.Web.Services.Protocols;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Represents an exception class that is used within the integration code.
    /// </summary>
    [Serializable]
    public class QASException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the QasException class.
        /// </summary>
        public QASException()
            : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the QasException class with a specified error message.
        /// </summary>
        /// <param name="message">Description of exception</param>
        public QASException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the QasException class with a specified error message and a reference to the inner exception that is the cause of this exception.
        /// </summary>
        /// <param name="message">Description of exception</param>
        /// <param name="inner">Inner exception</param>
        public QASException(string message, Exception inner)
            : base(message, inner)
        {
        }

        /// <summary>
        /// Initializes a new instance of the QasException class with serialized data.
        /// </summary>
        /// <param name="info">SerializationInfo object</param>
        /// <param name="context">StreamingContext object</param>
        protected QASException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        /// <summary>
        /// Static method to throw a QasException wrapping SoapException.
        /// </summary>
        /// <param name="soapException">SoapException object</param>
        public static void HandleException(SoapException soapException)
        {
            // Parse out qas:QAFault string
            System.Xml.XmlNode xmlDetails = soapException.Detail;
            string soapMessage = string.Empty;
            foreach (System.Xml.XmlNode xmlDetail in xmlDetails.ChildNodes)
            {
                string[] asDetail = xmlDetail.InnerText.Split('\n');
                if (asDetail.Length == 2)
                {
                    soapMessage += xmlDetail.Name + ": [" + asDetail[1].Trim() + " " + asDetail[0].Trim() + "] ";
                }
                else
                {
                    soapMessage += xmlDetail.Name + ": [" + asDetail[0].Trim() + "] ";
                }
            }

            QASException exception = new QASException(soapMessage, soapException);
            throw exception;
        }
    }
}