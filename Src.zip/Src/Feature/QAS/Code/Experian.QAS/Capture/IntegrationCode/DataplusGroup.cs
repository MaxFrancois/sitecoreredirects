﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// DataplusGroup is a named collection of items attached to an address line
    /// </summary>
    public class DataplusGroup : IJsonSerializable
    {
        #region Private Members
        private string _groupName;
        private string[] _items;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="groupName">Dataplus group name.</param>
        /// <param name="items">Dataplus group items.</param>
        public DataplusGroup(string groupName, string[] items)
        {
            this._groupName = groupName;
            this._items = items;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the name of this dataplus group ( may be an empty string )
        /// </summary>
        public string Name
        {
            get
            {
                return _groupName;
            }
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Gets the dataplus items in this group
        /// </summary>
        /// <returns>Returns the list of items in this dataplus group.</returns>
        public string[] GetItems()
        {
            return _items;
        } 
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Name", _groupName);
            builder.Append(RpcJsonSyntax.Separator);
            builder.AppendMemberArray("Items", _items);
            builder.AppendEndObject();
            return builder.ToString();
        }
        #endregion
    }
}