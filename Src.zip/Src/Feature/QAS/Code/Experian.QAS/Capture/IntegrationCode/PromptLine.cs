namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// This class encapsulates one line of a search prompt set.
    /// </summary>
    public class PromptLine : IJsonSerializable
    {
        #region Private Members
        private string _promptMessage;
        private string _example;
        private int _suggestedInputLength = 0; // positive integer 
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="promptMessage">Prompt message displayed to user</param>
        /// <param name="example">Example of address value for user's reference</param>
        /// <param name="suggestedInputLength">Suggested input length for this field</param>
        public PromptLine(string promptMessage, string example, int suggestedInputLength)
        {
            this._promptMessage = promptMessage;
            this._example = example;
            this._suggestedInputLength = suggestedInputLength;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the prompt for this input line (e.g. "Town" or "Street")
        /// </summary>
        public string Prompt
        {
            get
            {
                return _promptMessage;
            }
        }

        /// <summary>
        /// Gets an example of what is expected for this input line (e.g. "London")
        /// </summary>
        public string Example
        {
            get
            {
                return _example;
            }
        }

        /// <summary>
        /// Gets the length in characters that is suggested for an input field for this line
        /// </summary>
        public int SuggestedInputLength
        {
            get
            {
                return _suggestedInputLength;
            }
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Prompt", _promptMessage);
            builder.AppendSeparator().AppendMember("Example", _example);
            builder.AppendSeparator().AppendMember("SuggestedInputLength", _suggestedInputLength);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
