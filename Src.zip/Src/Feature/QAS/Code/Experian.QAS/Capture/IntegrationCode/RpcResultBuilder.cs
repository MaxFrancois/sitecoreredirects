﻿using System.Globalization;
using System.Text;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Represents a RPC Result builder. This class can be used to build the result of the JSON response.
    /// </summary>
    internal class RpcResultBuilder
    {
        private StringBuilder _builder = new StringBuilder();

        /// <summary>
        /// Overrides ToString to return the json result created.
        /// </summary>
        /// <returns>JSON representation of this object.</returns>
        public override string ToString()
        {
            return _builder.ToString();
        }

        internal RpcResultBuilder AppendMember(string memberName, string memberValue)
        {
            _builder.AppendFormat(CultureInfo.InvariantCulture, "\"{0}\":", memberName);
            if (memberValue != null)
            {
                _builder.AppendFormat(CultureInfo.InvariantCulture, "\"{0}\"", memberValue);
            }
            else
            {
                _builder.AppendFormat(CultureInfo.InvariantCulture, RpcJsonSyntax.Null);
            }

            return this;
        }

        internal RpcResultBuilder AppendMember(string memberName, bool memberValue)
        {
            _builder.AppendFormat("\"{0}\":", memberName);
            if (memberValue)
            {
                _builder.Append(RpcJsonSyntax.BooleanTrue);
            }
            else
            {
                _builder.Append(RpcJsonSyntax.BooleanFalse);
            }

            return this;
        }

        internal RpcResultBuilder AppendMember(string memberName, int memberValue)
        {
            _builder.AppendFormat(CultureInfo.InvariantCulture, "\"{0}\":{1}", memberName, memberValue.ToString(CultureInfo.InvariantCulture));
            return this;
        }

        internal RpcResultBuilder Append(string value)
        {
            _builder.Append(value);
            return this;
        }

        internal RpcResultBuilder AppendMemberArray(string memberName, IJsonSerializable[] values)
        {
            _builder.AppendFormat("\"{0}\":", memberName);

            if (values != null)
            {
                _builder.Append(RpcJsonSyntax.BeginArray);

                for (int i = 0; i < values.Length; i++)
                {
                    _builder.Append(((IJsonSerializable)values[i]).ToJson());
                    if (i == (values.Length - 1))
                    {
                        break;
                    }

                    AppendSeparator();
                }

                _builder.Append(RpcJsonSyntax.EndArray);
            }
            else
            {
                _builder.Append(RpcJsonSyntax.Null);
            }

            return this;
        }

        internal RpcResultBuilder AppendMemberArray(string memberName, string[] values)
        {
            _builder.AppendFormat("\"{0}\":", memberName);

            if (values != null)
            {
                AppendBeginArray();

                for (int index = 0, indexLen = values.Length; index < indexLen; index++)
                {
                    string value = values[index];
                    _builder.AppendFormat("\"{0}\"", value);
                    int lastIndex = indexLen - 1;
                    if (index >= lastIndex)
                    {
                        break;
                    }
                    else
                    {
                        AppendSeparator();
                    }
                }

                AppendEndArray();
            }
            else
            {
                AppendNull();
            }

            return this;
        }

        internal RpcResultBuilder AppendMember(string memberName, IJsonSerializable value)
        {
            _builder.AppendFormat("\"{0}\":", memberName);
            if (value != null)
            {
                _builder.AppendFormat("{0}", value.ToJson());
            }
            else
            {
                _builder.Append(RpcJsonSyntax.Null);
            }

            return this;
        }

        internal RpcResultBuilder AppendMember(string memberName)
        {
            _builder.AppendFormat("\"{0}\":", memberName);
            _builder.Append(RpcJsonSyntax.Null);

            return this;
        }

        internal RpcResultBuilder AppendNull()
        {
            _builder.Append(RpcJsonSyntax.Null);
            return this;
        }

        internal RpcResultBuilder AppendBeginArray()
        {
            _builder.Append(RpcJsonSyntax.BeginArray);
            return this;
        }

        internal RpcResultBuilder AppendEndArray()
        {
            _builder.Append(RpcJsonSyntax.EndArray);
            return this;
        }

        internal RpcResultBuilder AppendBeginObject()
        {
            _builder.Append(RpcJsonSyntax.BeginObject);
            return this;
        }

        internal RpcResultBuilder AppendEndObject()
        {
            _builder.Append(RpcJsonSyntax.EndObject);
            return this;
        }

        internal RpcResultBuilder AppendSeparator()
        {
            _builder.Append(RpcJsonSyntax.Separator);
            return this;
        }
    } 
}