﻿using System;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Represents the response to be returned for every Json API invocation.
    /// </summary>
    public class RpcResult : IJsonSerializable
    {
        #region Private Members
        private RpcError _error;
        private object _result;
        #endregion

        #region Contructors
        /// <summary>
        /// Constructor. Create an error response.
        /// </summary>
        /// <param name="error">RpcResult object initialized with error.</param>
        public RpcResult(RpcError error)
        {
            this._result = null;
            this._error = error;
        }

        /// <summary>
        /// Constructor. Create a success response, with object auto assigned to the result property.
        /// </summary>
        /// <param name="result">RpcResult object initialized with result.</param>
        public RpcResult(object result)
        {
            this._result = result;
            this._error = null;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets or sets the error of the response.
        /// </summary>
        public RpcError Error
        {
            get { return _error; }
            set { _error = value; }
        }
        #endregion

        #region IJsonSerializable Members
        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();

            // result
            IJsonSerializable tempResult = _result as IJsonSerializable;
            if (tempResult != null)
            {
                builder.AppendMember("result", tempResult);
            }
            else if (_result is Array)
            {
                Type elementType = _result.GetType().GetElementType();

                // all complex objects should be IJsonSerializable. just serialize the array of objects
                if (elementType.GetInterface(typeof(IJsonSerializable).FullName) != null)
                {
                    IJsonSerializable[] temp = _result as IJsonSerializable[];
                    builder.AppendMemberArray("result", temp);
                }
                else
                {
                    // array of primitives (not a valid return value for current implementation code.
                    // return result as null.
                    builder.AppendMember("result");
                }
            }
            else
            {
                // if not ijsonserializable, and not array, null result
                builder.AppendMember("result");
            }

            builder.AppendSeparator();
            builder.AppendMember("error", _error as IJsonSerializable);
            builder.AppendEndObject();

            return builder.ToString();
        }
        #endregion
    }
}