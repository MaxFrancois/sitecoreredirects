namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// AddressLine encapsulates data associated with an address line of a Formatted address.
    /// </summary>
    public class AddressLine : IJsonSerializable
    {
        #region Private Members
        private string _label;
        private string _line;
        private CommonAddressLineType _lineType;
        private bool _isTruncated;
        private bool _isOverflow;
        private DataplusGroup[] _dataplusGroups;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="label">Label displayed to user</param>
        /// <param name="line">Address line value</param>
        /// <param name="lineType">Address line type</param>
        /// <param name="isTruncated">Flag indicating address line is truncated.</param>
        /// <param name="isOverflow">Flag indicating address line is overflow.</param>
        /// <param name="dataplusGroups">DataplusGroup object.</param>
        public AddressLine(string label, string line, CommonAddressLineType lineType, bool isTruncated, bool isOverflow, DataplusGroup[] dataplusGroups)
        {
            this._label = label;
            this._line = line;
            this._lineType = lineType;
            this._isTruncated = isTruncated;
            this._isOverflow = isOverflow;
            this._dataplusGroups = dataplusGroups;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets a value the label of the line, probably the name of the address element fixed to it
        /// </summary>
        public string Label
        {
            get
            {
                return _label;
            }
        }

        /// <summary>
        /// Gets the contents of the address line itself
        /// </summary>
        public string Line
        {
            get
            {
                return _line;
            }
        }

        /// <summary>
        /// Gets a value indicating whether type of the address line (Types enumeration: None ... DataPlus)
        /// </summary>
        public CommonAddressLineType LineType
        {
            get
            {
                return _lineType;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the line was truncated.
        /// </summary>
        public bool IsTruncated
        {
            get
            {
                return _isTruncated;
            }
        }

        /// <summary>
        /// Gets a value indicating whether some address elements were lost from this line
        /// </summary>
        public bool IsOverflow
        {
            get
            {
                return _isOverflow;
            }
        }
        #endregion

        #region public Methods
        /// <summary>
        /// Gets the Dataplus groups.
        /// </summary>
        /// <returns>Array of DataplusGroup object</returns>
        public DataplusGroup[] GetDataplusGroups()
        {
            return _dataplusGroups;
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();

            // jsonResult.append("{");
            builder.AppendBeginObject();

            // jsonResult.append(String.Format("\"Label\":\"%s\"", m_Label)).append(separator);
            builder.AppendMember("Label", _label);

            // jsonResult.append(String.Format("\"Line\":\"%s\"", m_Line)).append(separator);
            builder.AppendSeparator();
            builder.AppendMember("Line", _line);

            // jsonResult.append("\"DataplusGroups\":");
            builder.AppendSeparator();
            builder.AppendMemberArray("DataplusGroups", _dataplusGroups);

            // jsonResult.append(String.Format("\"LineType\":\"%s\"", m_LineType)).append(separator);
            builder.AppendSeparator();
            builder.AppendMember("LineType", _lineType.ToString("g"));

            // jsonResult.append(String.Format("\"IsTruncated\":%s", m_IsTruncated)).append(separator);
            builder.AppendSeparator();
            builder.AppendMember("IsTruncated", _isTruncated);

            // jsonResult.append(String.Format("\"IsOverFlow\":%s", m_IsOverflow));
            builder.AppendSeparator();
            builder.AppendMember("IsOverFlow", _isOverflow);

            // jsonResult.append("}");
            builder.AppendEndObject();

            return builder.ToString();
        }

        #endregion
    }
}
