﻿using System.Diagnostics.CodeAnalysis;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of available line types returned by getLineType()
    /// </summary>
    public enum CommonAddressLineType
    {
        /// <summary>
        /// No address in this line.
        /// </summary>
        None,

        /// <summary>
        /// Address element in this line.
        /// </summary>
        Address,

        /// <summary>
        /// Name information in this line.
        /// </summary>
        Name,

        /// <summary>
        /// Additional data in this line.
        /// </summary>
        Ancillary,

        /// <summary>
        /// Dataplus information in this line.
        /// </summary>
        [SuppressMessage("Microsoft.Naming", "CA1702:CompoundWordsShouldBeCasedCorrectly", MessageId = "DataPlus", Justification = "Follow WSDL naming.")]
        DataPlus
    }
}