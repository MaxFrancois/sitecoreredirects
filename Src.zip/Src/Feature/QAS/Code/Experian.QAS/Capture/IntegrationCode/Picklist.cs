namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate Picklist data
    /// </summary>
    public class Picklist : IJsonSerializable
    {
        #region Private Members
        private string _moniker;
        private PicklistItem[] _items;
        private string _promptMessage;
        private int _totalItems;

        private bool _isAutoStepInSafe;
        private bool _isAutoStepInPastClose;
        private bool _isAutoFormatSafe;
        private bool _isAutoFormatPastClose;
        private bool _isLargePotential;
        private bool _isMaxMatches;
        private bool _hasMoreMatches;
        private bool _isOverThreshold;
        private bool _isTimeout;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="moniker">Moniker of picklist</param>
        /// <param name="items">PicklistItems in the picklist collection</param>
        /// <param name="promptMessage">Message display to user</param>
        /// <param name="totalItems">Total items in the picklist collection</param>
        /// <param name="isAutoStepInSafe">Indicates a match to a single non-deliverable result that can be stepped into</param>
        /// <param name="isAutoStepInPastClose">Indicates a match to a single non-deliverable result that can be auto-stepped into, but also indicates that there are other lesser matches</param>
        /// <param name="isAutoFormatSafe">Indicates a match to a single deliverable result</param>
        /// <param name="isAutoFormatPastClose">Indicates a match to a single deliverable result, but also to other lesser matches</param>
        /// <param name="isLargePotential">Indicates that the search has potentially returned too many items to display in a picklist</param>
        /// <param name="isMaxMatches">Indicates that the number of matches returned from a search has exceeded the max allowed</param>
        /// <param name="hasMoreMatches">Indicates that the number of matches returned from a search has exceeded the picklist threshold, and that there are other matches that can be displayed.</param>
        /// <param name="isOverThreshold">Indicates that the number of matches returned from a search has exceeded the picklist threshold</param>
        /// <param name="isTimeout">Indicates that the search exceeded the timeout value</param>
        public Picklist(
            string moniker, 
            PicklistItem[] items, 
            string promptMessage, 
            int totalItems, 
            bool isAutoStepInSafe,
            bool isAutoStepInPastClose, 
            bool isAutoFormatSafe, 
            bool isAutoFormatPastClose, 
            bool isLargePotential,
            bool isMaxMatches,
            bool hasMoreMatches,
            bool isOverThreshold,
            bool isTimeout)
        {
            this._moniker = moniker;
            this._promptMessage = promptMessage;
            this._totalItems = totalItems;
            this._isAutoStepInSafe = isAutoStepInSafe;
            this._isAutoStepInPastClose = isAutoStepInPastClose;
            this._isAutoFormatSafe = isAutoFormatSafe;
            this._isAutoFormatPastClose = isAutoFormatPastClose;
            this._isLargePotential = isLargePotential;
            this._isMaxMatches = isMaxMatches;
            this._hasMoreMatches = hasMoreMatches;
            this._isOverThreshold = isOverThreshold;
            this._isTimeout = isTimeout;
            this._items = items;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the full picklist moniker; that is, the moniker that describes this entire picklist
        /// </summary>
        public string Moniker
        {
            get
            {
                return _moniker;
            }
        }

        /// <summary>
        /// Gets the number of items in the picklist
        /// </summary>
        public int Length
        {
            get
            {
                return _items != null ? _items.Length : 0;
            }
        }

        /// <summary>
        /// Gets the prompt indicating what should be entered next by the user
        /// </summary>
        public string Prompt
        {
            get
            {
                return _promptMessage;
            }
        }

        /// <summary>
        /// Gets the total number of addresses (excluding informationals) within this address location (approx)
        /// </summary>
        public int Total
        {
            get
            {
                return _totalItems;
            }
        }

        /// <summary>
        /// Gets a value indicating whether it is safe to automatically step-in to the first (and only) picklist item
        /// </summary>
        public bool IsAutoStepInSafe
        {
            get
            {
                return _isAutoStepInSafe;
            }
        }

        /// <summary>
        /// Gets a value indicating whether you may wish to automaticaly step-in to the first item, as there was only one exact match, and other close matches
        /// </summary>
        public bool IsAutoStepInPastClose
        {
            get
            {
                return _isAutoStepInPastClose;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the picklist contains a single non-informational step-in item
        /// which you may wish to automatically step into after a refinement
        /// </summary>
        public bool IsAutoStepInSingle
        {
            get
            {
                return Length == 1 && _items[0].CanStep;
            }
        }

        /// <summary>
        /// Gets a value indicating whether it is safe to automatically format the first (and only) picklist item
        /// </summary>
        public bool IsAutoFormatSafe
        {
            get
            {
                return _isAutoFormatSafe;
            }
        }

        /// <summary>
        /// Gets a value indicating whether you may wish to automatically format the first item, as
        /// there was only one exact match, and other close matches
        /// </summary>
        public bool IsAutoFormatPastClose
        {
            get
            {
                return _isAutoFormatPastClose;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the picklist contains a single non-informational final-address item
        /// which you may wish to automatically format after a refinement
        /// </summary>
        public bool IsAutoFormatSingle
        {
            get
            {
                return Length == 1
                    && _items[0].IsFullAddress
                    && !_items[0].IsInformation;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the picklist potentially contains too many items to display
        /// </summary>
        public bool IsLargePotential
        {
            get
            {
                return _isLargePotential;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the number of matches exceeded the maximum allowed
        /// </summary>
        public bool IsMaxMatches
        {
            get
            {
                return _isMaxMatches;
            }
        }

        /// <summary>
        /// Gets a value indicating whether there are additional matches that can be displayed
        /// Only exact matches to the refinement text have been shown, as including all matches would be over threshold
        /// They can be shown by stepping into the informational at the bottom of the picklist
        /// </summary>
        public bool AreMoreMatches
        {
            get
            {
                return _hasMoreMatches;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the number of matches exceeded the threshold
        /// </summary>
        public bool IsOverThreshold
        {
            get
            {
                return _isOverThreshold;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the search timed out
        /// </summary>
        public bool IsTimeout
        {
            get
            {
                return _isTimeout;
            }
        }
        #endregion

        /// <summary>
        /// Gets the array of PicklistItem objects
        /// </summary>
        /// <returns>A list of Items in the picklist.</returns>
        public PicklistItem[] GetItems()
        {
            return _items;
        }

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Moniker", _moniker);
            builder.AppendSeparator().AppendMemberArray("Items", _items);
            builder.AppendSeparator().AppendMember("Prompt", _promptMessage);
            builder.AppendSeparator().AppendMember("Total", _totalItems);
            builder.AppendSeparator().AppendMember("IsAutoStepinSafe", _isAutoStepInSafe);
            builder.AppendSeparator().AppendMember("IsAutoStepinPastClose", _isAutoStepInPastClose);
            builder.AppendSeparator().AppendMember("IsAutoformatSafe", _isAutoFormatSafe);
            builder.AppendSeparator().AppendMember("IsAutoformatPastClose", _isAutoFormatPastClose);
            builder.AppendSeparator().AppendMember("IsLargePotential", _isLargePotential);
            builder.AppendSeparator().AppendMember("IsMaxMatches", _isMaxMatches);
            builder.AppendSeparator().AppendMember("AreMoreOtherMatches", _hasMoreMatches);
            builder.AppendSeparator().AppendMember("IsOverThreshold", _isOverThreshold);
            builder.AppendSeparator().AppendMember("IsTimeout", _isTimeout);
            builder.AppendEndObject();
            return builder.ToString();
        }
        #endregion
    }
}
