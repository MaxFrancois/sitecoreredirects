namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Class to encapsulate data returned by a search
    /// </summary>
    public class SearchResult : IJsonSerializable
    {
        #region Private Members
        private FormattedAddress _address = null;
        private Picklist _picklist = null;
        private CommonVerificationLevel _verifyLevel = CommonVerificationLevel.None;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="formattedAddress">FormattedAddress of search result.</param>
        /// <param name="picklist">Picklist of search result.</param>
        /// <param name="verifyLevel">VerificationLevels of search result.</param>
        public SearchResult(FormattedAddress formattedAddress, Picklist picklist, CommonVerificationLevel verifyLevel)
        {
            this._address = formattedAddress;
            this._picklist = picklist;
            this._verifyLevel = verifyLevel;
        }
        #endregion

        #region Read-only Properties

        /// <summary>
        /// Gets the address (may be null)
        /// </summary>
        public FormattedAddress Address
        {
            get
            {
                return _address;
            }
        }

        /// <summary>
        /// Gets the picklist (may be null)
        /// </summary>
        public Picklist Picklist
        {
            get
            {
                return _picklist;
            }
        }

        /// <summary>
        /// Gets the verification level of the result (only relavant when using the verification engine)
        /// </summary>
        public CommonVerificationLevel VerifyLevel
        {
            get
            {
                return _verifyLevel;
            }
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Address", _address as IJsonSerializable);
            builder.AppendSeparator().AppendMember("Picklist", _picklist as IJsonSerializable);
            builder.AppendSeparator().AppendMember("VerifyLevel", _verifyLevel.ToString("g"));
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
