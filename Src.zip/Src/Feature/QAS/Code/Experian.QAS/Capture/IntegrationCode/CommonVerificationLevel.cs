﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of verification levels
    /// </summary>
    public enum CommonVerificationLevel
    {
        /// <summary>
        /// No verified matches found, or not application
        /// </summary>
        None,

        /// <summary>
        /// High confidence match found (address returned)
        /// </summary>
        Verified,

        /// <summary>
        /// Single match found, but user confirmation is recommended (address returned)
        /// </summary>
        InteractionRequired,

        /// <summary>
        /// Address was verified to premises level only (picklist returned)
        /// </summary>
        PremisesPartial,

        /// <summary>
        /// Address was verified to street level only (picklist returned)
        /// </summary>
        StreetPartial,

        /// <summary>
        /// Address was verified to multiple addresses (picklist returned)
        /// </summary>
        Multiple,

        /// <summary>
        /// Address was verified to place level (global data only)
        /// </summary>
        VerifiedPlace,

        /// <summary>
        /// Address was verified to street level (global data only)
        /// </summary>
        VerifiedStreet
    }
}