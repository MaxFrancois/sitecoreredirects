using System;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate a Dataset - a searchable 'country'
    /// </summary>
    public class DataSet : IComparable, IComparable<DataSet>, IJsonSerializable
    {
        #region Private Members
        private string _id = null;
        private string _name = null;
        #endregion

        #region Constructors
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="id">ID of dataset (3 character country ID)</param>
        /// <param name="name">Country name</param>
        public DataSet(string id, string name)
        {
            this._id = id;
            this._name = name;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of the data set
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
        }

        /// <summary>
        /// Gets the ID of the data set (DataId)
        /// </summary>
        public string Id
        {
            get
            {
                return _id;
            }
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns the Dataset which matches the data ID, otherwise null
        /// </summary>
        /// <param name="dataSets">Dataset array to search</param>
        /// <param name="dataId">Data identifier to search for</param>
        /// <returns>Dataset object.</returns>
        public static DataSet FindById(DataSet[] dataSets, string dataId)
        {
            for (int i = 0; i < dataSets.GetLength(0); i++)
            {
                if (dataSets[i].Id.Equals(dataId))
                {
                    return dataSets[i];
                }
            }

            return null;
        }

        #endregion

        #region Comparable static members

        /// <summary>
        /// Compares two specified Dataset objects and returns an integer that indicates their relative position in the sort order.
        /// </summary>
        /// <param name="first">First operand, Dataset object.</param>
        /// <param name="second">Second operand, Dataset object.</param>
        /// <returns>Less than zero if left comes first in sort order. Zero when equals. Greater than zero otherwise.</returns>
        public static int Compare(DataSet first, DataSet second)
        {
            if (object.ReferenceEquals(first, second))
            {
                return 0;
            }

            if (object.ReferenceEquals(first, null))
            {
                return -1;
            }

            return first.CompareTo(second);
        }

        /// <summary>
        /// Overload reference equality. Checks if two instances of dataset object is the same object.
        /// </summary>
        /// <param name="first">First operand, Dataset object.</param>
        /// <param name="second">Second operand, Dataset object.</param>
        /// <returns>True if its two operands refer to the same object</returns>
        public static bool operator ==(DataSet first, DataSet second)
        {
            return first.Equals(second);
        }

        /// <summary>
        /// Overload operator. Internally compares using == operator.
        /// </summary>
        /// <param name="first">First operand, Dataset object.</param>
        /// <param name="second">Second operand, Dataset object.</param>
        /// <returns>True if its two operands does not refer to the same object</returns>
        public static bool operator !=(DataSet first, DataSet second)
        {
            return !(first == second);
        }

        /// <summary>
        /// Overload operator. Internally compares using Compare(dataset, dataset) method.
        /// </summary>
        /// <param name="first">First operand, Dataset object.</param>
        /// <param name="second">Second operand, Dataset object.</param>
        /// <returns>True if the first operand is less than the second</returns>
        public static bool operator <(DataSet first, DataSet second)
        {
            return Compare(first, second) < 0;
        }

        /// <summary>
        /// Overload operator. Internally compares using Compare(dataset, dataset) method.
        /// </summary>
        /// <param name="first">First operand, Dataset object.</param>
        /// <param name="second">Second operand, Dataset object.</param>
        /// <returns>True if the first operand is greater than the second</returns>
        public static bool operator >(DataSet first, DataSet second)
        {
            return Compare(first, second) > 0;
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("ID", _id);
            builder.AppendSeparator().AppendMember("Name", _name);
            builder.AppendEndObject();
            return builder.ToString();
        }
        #endregion

        #region IComparable Members

        /// <summary>
        /// Implements IComparable interface.
        /// </summary>
        /// <param name="obj">An object to compare with this instance.</param>
        /// <returns>A value that indicates the relative order of the objects being compared.</returns>
        public int CompareTo(object obj)
        {
            DataSet dset = obj as DataSet;
            if (obj != null)
            {
                return string.Compare(this.Name, dset.Name, StringComparison.OrdinalIgnoreCase);
            }
            else
            {
                throw new ArgumentException("Object is not a Dataset");
            }
        }

        /// <summary>
        /// Override Equals method.
        /// </summary>
        /// <param name="obj">Another object to be compare with</param>
        /// <returns>True if current object and param is the same.</returns>
        public override bool Equals(object obj)
        {
            bool isSame = false;
            DataSet dataset = obj as DataSet;
            if (dataset != null)
            {
                bool isSameId = string.CompareOrdinal(this.Id, dataset.Id) == 0;
                bool isSameName = string.CompareOrdinal(this.Name, dataset.Name) == 0;
                isSame = isSameId && isSameName;
            }

            return isSame;
        }

        /// <summary>
        /// Override to hashcode.
        /// </summary>
        /// <returns>Hashcode created using private members</returns>
        public override int GetHashCode()
        {
            return (this.Id + this.Name).GetHashCode();
        }

        /// <summary>
        /// Compares this instance with a specified Dataset object and indicates whether this instance precedes, follows, or appears in the same position in the sort order as the specified Dataset.
        /// </summary>
        /// <param name="other">Another dataset object to be compared with</param>
        /// <returns>A value that indicates the relative order of the objects being compared.</returns>
        public int CompareTo(DataSet other)
        {
            if (object.ReferenceEquals(other, null))
            {
                return 1;
            }

            return string.Compare(this.Id, other.Id, StringComparison.OrdinalIgnoreCase);
        }

        #endregion
    }
}
