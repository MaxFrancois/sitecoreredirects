namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulates data for a single licensed set
    /// </summary>
    public class LicensedSet : IJsonSerializable
    {
        #region Private Members
        private string _id;
        private string _description;
        private string _copyright;
        private string _version;
        private string _baseCountry;
        private string _status;
        private string _server;
        private CommonLicenseWarningLevel _warningLevel;
        private int _daysLeft;
        private int _dataDaysLeft;
        private int _licenceDaysLeft;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="id">ID of this licensed set</param>
        /// <param name="description">Description of license</param>
        /// <param name="copyright">Copyright name of license</param>
        /// <param name="version">Version of license</param>
        /// <param name="baseCountry">Base country of license</param>
        /// <param name="status">Status of license</param>
        /// <param name="server">Server name</param>
        /// <param name="warningLevel">LicenseWarningLevel</param>
        /// <param name="daysLeft">Days left till expire</param>
        /// <param name="dataDaysLeft">Days left till expire for data</param>
        /// <param name="licenseDaysLeft">Days left till expire for license</param>
        public LicensedSet(string id, string description, string copyright, string version, string baseCountry, string status, string server, CommonLicenseWarningLevel warningLevel, int daysLeft, int dataDaysLeft, int licenseDaysLeft)
        {
            this._id = id;
            this._description = description;
            this._copyright = copyright;
            this._version = version;
            this._baseCountry = baseCountry;
            this._status = status;
            this._server = server;
            this._warningLevel = warningLevel;
            this._daysLeft = daysLeft;
            this._dataDaysLeft = dataDaysLeft;
            this._licenceDaysLeft = licenseDaysLeft;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the ID of the licensed data
        /// </summary>
        public string Id
        {
            get
            {
                return _id;
            }
        }

        /// <summary>
        /// Gets the description of the licensed data
        /// </summary>
        public string Description
        {
            get
            {
                return _description;
            }
        }

        /// <summary>
        /// Gets the owner of the copyright for the licensed data
        /// </summary>
        public string Copyright
        {
            get
            {
                return _copyright;
            }
        }

        /// <summary>
        /// Gets the version of the licensed data
        /// </summary>
        public string Version
        {
            get
            {
                return _version;
            }
        }

        /// <summary>
        /// Gets the DataId of the country with which this licensed dataset is associated
        /// </summary>
        public string BaseCountry
        {
            get
            {
                return _baseCountry;
            }
        }

        /// <summary>
        /// Gets status text detailing the amount of time left on the licensed set
        /// </summary>
        public string Status
        {
            get
            {
                return _status;
            }
        }

        /// <summary>
        /// Gets the name of the QAS server where the data is being used
        /// </summary>
        public string Server
        {
            get
            {
                return _server;
            }
        }

        /// <summary>
        /// Gets the enumeration of the state of the data set
        /// </summary>
        public CommonLicenseWarningLevel WarningLevel
        {
            get
            {
                return _warningLevel;
            }
        }

        /// <summary>
        /// Gets the number of days that the data will remain usable
        /// </summary>
        public int DaysLeft
        {
            get
            {
                return _daysLeft;
            }
        }

        /// <summary>
        /// Gets the number of days until the data expires
        /// </summary>
        public int DataDaysLeft
        {
            get
            {
                return _dataDaysLeft;
            }
        }

        /// <summary>
        /// Gets the number of days until the license expires for this data
        /// </summary>
        public int LicenceDaysLeft
        {
            get
            {
                return _licenceDaysLeft;
            }
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("ID", _id);
            builder.AppendSeparator().AppendMember("Description", _description);
            builder.AppendSeparator().AppendMember("CopyRight", _copyright);
            builder.AppendSeparator().AppendMember("Version", _version);
            builder.AppendSeparator().AppendMember("BaseCountry", _baseCountry);
            builder.AppendSeparator().AppendMember("Status", _status);
            builder.AppendSeparator().AppendMember("Server", _server);
            builder.AppendSeparator().AppendMember("WarningLevel", _warningLevel.ToString("g"));
            builder.AppendSeparator().AppendMember("DaysLeft", _daysLeft);
            builder.AppendSeparator().AppendMember("DataDaysLeft", _dataDaysLeft);
            builder.AppendSeparator().AppendMember("LicenceDaysLeft", _licenceDaysLeft);
            builder.AppendEndObject();
            return builder.ToString();
        }
        #endregion
    }
}
