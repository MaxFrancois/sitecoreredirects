using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net;
using System.Web.Services.Protocols;

namespace Experian.Qas.Capture.IntegrationCode.V3
{
    /// <inheritdoc />
    public class QASCapture : IDisposable, IQASCapture
    {
        /// <summary>
        /// Line separator - determined by a configuration setting on the server
        /// </summary>
        private const char LineSeparator = '|';

        #region Private Members

        /// <summary>
        /// QuickAddress Pro Web search service.
        /// </summary>
        private QASOnDemandIntermediary _qasCaptureService = null;

        #endregion

        #region Contructors

        /// <summary>
        /// Constructs the search service, using the URL, proxy server
        /// </summary>
        /// <param name="address">The URL of the QuickAddress SOAP service</param>
        /// <param name="userName">The Username for the proweb ondermand service</param>
        /// <param name="password">The Password for the proweb ondemand service</param>
        /// <param name="proxy">Proxy server</param>
        public QASCapture(string address, string userName, string password, IWebProxy proxy)
            : this(address, userName, password)
        {
            if (proxy != null)
            {
                _qasCaptureService.Proxy = proxy;
            }
        }

        /// <summary>
        /// Constructs the search service, using the URL of the QuickAddress Server
        /// </summary>
        /// <param name="address">The URL of the QuickAddress SOAP service</param>
        /// <param name="userName">Username of OnDemand account.</param>
        /// <param name="password">Password of OnDemand account.</param>
        /// <remarks>
        /// e.g.
        /// If you're integrating against the UK data centre: https://ws.ondemand.qas.com/ProOnDemand/V2/ProOnDemandService.asmx
        /// If you're integrating against the US data centre: https://ws2.ondemand.qas.com/ProOnDemand/V2/ProOnDemandService.asmx
        /// </remarks>
        public QASCapture(string address, string userName, string password)
        {
            _qasCaptureService = new QASOnDemandIntermediary();
            _qasCaptureService.Url = address;

            QAAuthentication authentication = new QAAuthentication();
            authentication.Username = userName;
            authentication.Password = password;

            QAQueryHeader header = new QAQueryHeader();
            header.QAAuthentication = authentication;

            _qasCaptureService.QAQueryHeaderValue = header;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the QuickAddress Pro Web SOAP service
        /// </summary>
        private QASOnDemandIntermediary SearchService
        {
            get
            {
                return _qasCaptureService;
            }
        }
        #endregion

        #region Public Methods - Searching Operations

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public CanSearch CanSearch(string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold, int? timeout, string layout, string localisation)
        {
            CanSearch soapResult = null;
            try
            {
                // Set up the parameter for the SOAP call
                QACanSearch param = new QACanSearch();
                param.Country = countryId ?? param.Country;
                CommonEngineType engineType = default(CommonEngineType);
                if (TryAssignEnum<CommonEngineType>(engine, ref engineType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Value = ProOnDemandObjectFactory.ToEngineEnumType(engineType);
                }

                if (flatten.HasValue)
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Flatten = flatten.Value;
                    param.Engine.FlattenSpecified = true;
                }

                CommonIntensityType tempIntensityType = default(CommonIntensityType);
                if (TryAssignEnum<CommonIntensityType>(intensity, ref tempIntensityType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Intensity = ProOnDemandObjectFactory.ToEngineIntensityType(tempIntensityType);
                    param.Engine.IntensitySpecified = true;
                }

                CommonPromptSetType tempPromptSetType = default(CommonPromptSetType);
                if (TryAssignEnum<CommonPromptSetType>(promptSet, ref tempPromptSetType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.PromptSet = ProOnDemandObjectFactory.ToPromptSetType(tempPromptSetType);
                    param.Engine.PromptSetSpecified = true;
                }

                param.Engine.Threshold = threshold.HasValue ? threshold.Value.ToString(CultureInfo.InvariantCulture) : param.Engine.Threshold;
                param.Engine.Timeout = timeout.HasValue ? timeout.Value.ToString(CultureInfo.InvariantCulture) : param.Engine.Timeout;
                param.Layout = layout ?? param.Layout;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QASearchOk cansearchResult = SearchService.DoCanSearch(param);
                soapResult = ProOnDemandObjectFactory.CreateCanSearch(cansearchResult);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return soapResult;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public SearchResult Search(string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold, int? timeout, string layout, string searchText, bool? formattedAddressInPicklist, string requestTag, string localisation)
        {
            SearchResult result = null;
            try
            {
                // Set up the parameter for the SOAP call
                QASearch param = new QASearch();
                param.Country = countryId ?? param.Country;
                if (threshold.HasValue)
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Threshold = threshold.Value.ToString(CultureInfo.InvariantCulture);
                }

                if (timeout.HasValue)
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Timeout = timeout.Value.ToString(CultureInfo.InvariantCulture);
                }

                param.Layout = layout ?? param.Layout;
                param.Search = searchText ?? param.Search;
                param.RequestTag = requestTag ?? param.RequestTag;
                param.FormattedAddressInPicklist = formattedAddressInPicklist ?? param.FormattedAddressInPicklist;
                param.Localisation = localisation ?? param.Localisation;
                CommonEngineType tempEngineType = default(CommonEngineType);
                if (TryAssignEnum<CommonEngineType>(engine, ref tempEngineType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Value = ProOnDemandObjectFactory.ToEngineEnumType(tempEngineType);
                }

                if (flatten.HasValue)
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Flatten = flatten.Value;
                    param.Engine.FlattenSpecified = true;
                }

                CommonIntensityType tempIntensityType = default(CommonIntensityType);
                if (TryAssignEnum<CommonIntensityType>(intensity, ref tempIntensityType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Intensity = ProOnDemandObjectFactory.ToEngineIntensityType(tempIntensityType);
                    param.Engine.IntensitySpecified = true;
                }

                CommonPromptSetType tempPromptSet = default(CommonPromptSetType);
                if (TryAssignEnum<CommonPromptSetType>(promptSet, ref tempPromptSet))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.PromptSet = ProOnDemandObjectFactory.ToPromptSetType(tempPromptSet);
                    param.Engine.PromptSetSpecified = true;
                }

                // Make the call to the server
                QASearchResult searchResult = SearchService.DoSearch(param);
                result = ProOnDemandObjectFactory.CreateSearchResult(searchResult);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return result;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public Experian.Qas.Capture.IntegrationCode.Picklist Refine(string moniker, string refinement, string layout, bool? formattedAddressInPicklist, int? threshold, int? timeout, string requestTag, string localisation)
        {
            Experian.Qas.Capture.IntegrationCode.Picklist result = null;
            try
            {
                // Set up the parameter for the SOAP call
                QARefine param = new QARefine();
                param.Moniker = moniker ?? param.Moniker;
                param.Refinement = refinement ?? param.Refinement;
                param.Layout = layout ?? param.Layout;
                param.FormattedAddressInPicklist = formattedAddressInPicklist ?? param.FormattedAddressInPicklist;
                param.Threshold = threshold.HasValue ? threshold.Value.ToString(CultureInfo.InvariantCulture) : param.Threshold;
                param.Timeout = timeout.HasValue ? timeout.Value.ToString(CultureInfo.InvariantCulture) : param.Timeout;
                param.RequestTag = requestTag ?? param.RequestTag;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QAPicklistType picklist = SearchService.DoRefine(param).QAPicklist;
                result = ProOnDemandObjectFactory.CreatePicklist(picklist);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return result;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public FormattedAddress GetAddress(string moniker, string layout, string requestTag, string localisation)
        {
            FormattedAddress result = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetAddress param = new QAGetAddress();
                param.Moniker = moniker ?? param.Moniker;
                param.Layout = layout ?? param.Layout;
                param.RequestTag = requestTag ?? param.RequestTag;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QAAddressType address = SearchService.DoGetAddress(param).QAAddress;
                result = ProOnDemandObjectFactory.CreateFormattedAddress(address);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return result;
        }

        #endregion

        #region Public Methods - Status Operations

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public DataSet[] GetData(string localisation)
        {
            DataSet[] datasetResults = null;
            try
            {
                // Make the call to the server
                QAGetData param = new QAGetData();
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QADataSet[] soapDatasets = SearchService.DoGetData(param);
                datasetResults = ProOnDemandObjectFactory.CreateDataSets(soapDatasets);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return datasetResults;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public LicensedSet[] GetDataMapDetail(string countryId, string localisation)
        {
            LicensedSet[] licenseResults = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetDataMapDetail param = new QAGetDataMapDetail();
                param.DataMap = countryId ?? param.DataMap;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QADataMapDetail soapDatamapDetail = SearchService.DoGetDataMapDetail(param);
                licenseResults = ProOnDemandObjectFactory.CreateLicensedSets(soapDatamapDetail);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return licenseResults;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public Layout[] GetLayouts(string countryId, string localisation)
        {
            Layout[] layoutResults = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetLayouts param = new QAGetLayouts();
                param.Country = countryId ?? param.Country;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QALayout[] soapLayouts = SearchService.DoGetLayouts(param);
                layoutResults = ProOnDemandObjectFactory.CreateLayouts(soapLayouts);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return layoutResults;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public ExampleAddress[] GetExampleAddresses(string countryId, string layout, string requestTag, string localisation)
        {
            ExampleAddress[] addressResults = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetExampleAddresses param = new QAGetExampleAddresses();
                param.Country = countryId ?? param.Country;
                param.Layout = layout ?? param.Layout;
                param.RequestTag = requestTag ?? param.RequestTag;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QAExampleAddress[] soapAddresses = SearchService.DoGetExampleAddresses(param);
                addressResults = ProOnDemandObjectFactory.CreateExampleAddresses(soapAddresses);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return addressResults;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public LicensedSet[] GetLicenceInfo(string localisation)
        {
            LicensedSet[] licenseResults = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetLicenseInfo param = new QAGetLicenseInfo();
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QALicenceInfo info = SearchService.DoGetLicenseInfo(param);
                licenseResults = ProOnDemandObjectFactory.CreateLicensedSets(info);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return licenseResults;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public PromptSet GetPromptSet(string countryId, string engine, bool? flatten, string promptSet, int? threshold, int? timeout, string localisation)
        {
            PromptSet result = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetPromptSet param = new QAGetPromptSet();
                param.Country = countryId ?? param.Country;
                CommonEngineType tempEngineType = default(CommonEngineType);
                if (TryAssignEnum<CommonEngineType>(engine, ref tempEngineType))
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Value = ProOnDemandObjectFactory.ToEngineEnumType(tempEngineType);
                }

                if (flatten.HasValue)
                {
                    if (param.Engine == null)
                    {
                        param.Engine = new EngineType();
                    }

                    param.Engine.Flatten = flatten.Value;
                    param.Engine.FlattenSpecified = true;
                }

                CommonPromptSetType tempPromptSetType = default(CommonPromptSetType);
                if (TryAssignEnum<CommonPromptSetType>(promptSet, ref tempPromptSetType))
                {
                    param.PromptSet = ProOnDemandObjectFactory.ToPromptSetType(tempPromptSetType);
                }

                param.Engine.Threshold = threshold.HasValue ? threshold.Value.ToString(CultureInfo.InvariantCulture) : param.Engine.Threshold;
                param.Engine.Timeout = timeout.HasValue ? timeout.Value.ToString(CultureInfo.InvariantCulture) : param.Engine.Timeout;
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                QAPromptSet soapPromptset = SearchService.DoGetPromptSet(param);
                result = ProOnDemandObjectFactory.CreatePromptSet(soapPromptset);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return result;
        }

        /// <inheritdoc />
        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Catch general exception and map to correct exception to be rethrown.")]
        public string[] GetSystemInfo(string localisation)
        {
            string[] strResults = null;
            try
            {
                // Set up the parameter for the SOAP call
                QAGetSystemInfo param = new QAGetSystemInfo();
                param.Localisation = localisation ?? param.Localisation;

                // Make the call to the server
                strResults = SearchService.DoGetSystemInfo(param);
            }
            catch (SoapException x)
            {
                QASException.HandleException(x);
            }

            return strResults;
        }

        #endregion

        #region IDisposable Members
        /// <summary>
        /// IDisposable Dispose method implementation.
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose overload.
        /// </summary>
        /// <param name="disposing">Indicates whether the called from user code or dispose method. When true, called from Dispose method. When false, called from user code.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Free other state (managed objects).
                IDisposable tempCapture = _qasCaptureService as IDisposable;
                if (tempCapture != null)
                {
                    tempCapture.Dispose();
                }
            }

            // Free your own state (unmanaged objects).
            // Set large fields to null.
        }

        #endregion

        #region Private Methods - Helpers

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes", Justification = "Enum.TryParse not available in dotnet2. Using Enum.Parse, general exception is ignored and default value used.")]
        private static bool TryAssignEnum<T>(string enumValue, ref T target)
        {
            bool isOk = false;
            try
            {
                target = (T)Enum.Parse(typeof(T), enumValue);
                isOk = true;
            }
            catch
            {
                // doing nothing
            }

            return isOk;
        }

        #endregion
    }
}
