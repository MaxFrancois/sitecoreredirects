namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate data associated with a formatted address
    /// </summary>
    public class FormattedAddress : IJsonSerializable
    {
        #region Private Members
        private AddressLine[] _addressLines;
        private bool _isOverflow;
        private bool _isTruncated;
        private CommonDPVStatusType _dpvStatusField;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="isOverflow">Indicates that not all the address elements could be fitted in the final address</param>
        /// <param name="isTruncated">Indicates that some address elements could not fit completely on the line and were cut short</param>
        /// <param name="status">DPV status of formatted address.</param>
        /// <param name="addressLines">array of individual formatted address lines</param>
        public FormattedAddress(bool isOverflow, bool isTruncated, CommonDPVStatusType status, AddressLine[] addressLines)
        {
            this._isOverflow = isOverflow;
            this._isTruncated = isTruncated;
            this._dpvStatusField = status;
            this._addressLines = addressLines;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets the number of lines in the address
        /// </summary>
        public int Length
        {
            get
            {
                return _addressLines != null ? _addressLines.Length : 0;
            }
        }

        /// <summary>
        /// Gets a value indicating whether there were not enough address lines configured to contain the address
        /// </summary>
        public bool IsOverflow
        {
            get
            {
                return _isOverflow;
            }
        }

        /// <summary>
        /// Gets a value indicating whether one or more address lines were truncated
        /// </summary>
        public bool IsTruncated
        {
            get
            {
                return _isTruncated;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating the Delivery point Validation of Address.
        /// </summary>
        public CommonDPVStatusType DPVStatus
        {
            get
            {
                return this._dpvStatusField;
            }

            set
            {
                this._dpvStatusField = value;
            }
        }
        #endregion

        #region Public methods

        /// <summary>
        /// Gets the array of address line objects
        /// </summary>
        /// <returns>Array of AddressLine object</returns>
        public AddressLine[] GetAddressLines()
        {
            return _addressLines;
        }

        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMemberArray("AddressLines", _addressLines);
            builder.AppendSeparator().AppendMember("DPVStatus", _dpvStatusField.ToString("g"));
            builder.AppendSeparator().AppendMember("IsTruncated", _isTruncated);
            builder.AppendSeparator().AppendMember("IsOverFlow", _isOverflow);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
