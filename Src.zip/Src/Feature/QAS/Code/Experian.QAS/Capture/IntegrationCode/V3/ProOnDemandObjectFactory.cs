﻿using System.Globalization;

namespace Experian.Qas.Capture.IntegrationCode.V3
{
    /// <summary>
    /// Represents a static class containing all methods to convert soap objects to common class objects.
    /// </summary>
    public static class ProOnDemandObjectFactory
    {
        /// <summary>
        /// Create common class AddressLine object using SOAP AddressLineType object.
        /// </summary>
        /// <param name="soapAddressLineType">SOAP AddressLineType object</param>
        /// <returns>Common class AddressLine object</returns>
        public static AddressLine CreateAddressLine(AddressLineType soapAddressLineType)
        {
            string label = soapAddressLineType.Label;
            string line = soapAddressLineType.Line;
            bool isTruncated = soapAddressLineType.Truncated;
            bool isOverflow = soapAddressLineType.Overflow;
            CommonAddressLineType lineType = ProOnDemandObjectFactory.ToCommonAddressLineType(soapAddressLineType.LineContent);
            DataplusGroup[] dataplusGroups = CreateDataGroups(soapAddressLineType);
            return new AddressLine(label, line, lineType, isTruncated, isOverflow, dataplusGroups);
        }

        /// <summary>
        /// Create common class DataplusGroup array using SOAP AddressLineType object.
        /// </summary>
        /// <param name="soapAddressLineType">SOAP AddressLineType object</param>
        /// <returns>Common class DataplusGroup array</returns>
        public static DataplusGroup[] CreateDataGroups(AddressLineType soapAddressLineType)
        {
            DataplusGroup[] dataplusGroups = null;
            if (soapAddressLineType.DataplusGroup != null)
            {
                dataplusGroups = new DataplusGroup[soapAddressLineType.DataplusGroup.Length];
                for (int i = 0; i < soapAddressLineType.DataplusGroup.Length; i++)
                {
                    DataplusGroup dataplusGroup = CreateDataGroup(soapAddressLineType.DataplusGroup[i]);
                    dataplusGroups[i] = dataplusGroup;
                }
            }

            return dataplusGroups;
        }

        /// <summary>
        /// Create common class DataplusGroup object using SOAP DataplusGroupType object.
        /// </summary>
        /// <param name="dataplusGroupType">SOAP DataplusGroupType object</param>
        /// <returns>Common class DataplusGroup object</returns>
        public static DataplusGroup CreateDataGroup(DataplusGroupType dataplusGroupType)
        {
            // dataplus name
            string groupName = dataplusGroupType.GroupName;

            // dataplus items
            string[] items = dataplusGroupType.DataplusGroupItem;

            return new DataplusGroup(groupName, items);
        }

        /// <summary>
        /// Create common class CanSearch object using SOAP QASearchOk object.
        /// </summary>
        /// <param name="soapSearchOk">SOAP QASearchOk object</param>
        /// <returns>Common class CanSearch object</returns>
        public static CanSearch CreateCanSearch(QASearchOk soapSearchOk)
        {
            // isok
            bool isOk = soapSearchOk.IsOk;

            // error code. if parse error, it is due to ondemand server error. currently, and defaults to 0.
            int errorCode;
            if (!int.TryParse(soapSearchOk.ErrorCode, NumberStyles.Integer, CultureInfo.InvariantCulture, out errorCode))
            {
                errorCode = 0;
            }

            // error message
            string errorMessage = string.Empty;
            if (soapSearchOk.ErrorMessage != null)
            {
                errorMessage = soapSearchOk.ErrorMessage + " [" + errorCode + "]";
            }

            return new CanSearch(isOk, errorCode, errorMessage);
        }

        /// <summary>
        /// Create common class Dataset object using SOAP QADataSet object.
        /// </summary>
        /// <param name="soapDataSet">Common class Dataset object</param>
        /// <returns>SOAP QADataSet object</returns>
        public static DataSet CreateDataSet(QADataSet soapDataSet)
        {
            string id = soapDataSet.ID;
            string name = soapDataSet.Name;
            return new DataSet(id, name);
        }

        /// <summary>
        /// Create common class FormattedAddress object using SOAP QAAddressType object.
        /// </summary>
        /// <param name="soapAddress">Common class FormattedAddress object</param>
        /// <returns>SOAP QAAddressType object</returns>
        public static FormattedAddress CreateFormattedAddress(QAAddressType soapAddress)
        {
            bool isOverflow = soapAddress.Overflow;
            bool isTruncated = soapAddress.Truncated;
            CommonDPVStatusType dpvStatus = ProOnDemandObjectFactory.ToCommonDPVStatusType(soapAddress.DPVStatus);
            AddressLine[] addressLines = CreateAddressLines(soapAddress.AddressLine);

            return new FormattedAddress(isOverflow, isTruncated, dpvStatus, addressLines);
        }

        /// <summary>
        /// Create common class AddressLine array using SOAP AddressLineType array.
        /// </summary>
        /// <param name="soapAddressLines">SOAP AddressLineType array</param>
        /// <returns>Common class AddressLine array</returns>
        public static AddressLine[] CreateAddressLines(AddressLineType[] soapAddressLines)
        {
            AddressLine[] addressLines = null;
            int size = soapAddressLines.GetLength(0);
            if (size > 0)
            {
                addressLines = new AddressLine[size];
                for (int i = 0; i < size; i++)
                {
                    addressLines[i] = ProOnDemandObjectFactory.CreateAddressLine(soapAddressLines[i]);
                }
            }

            return addressLines;
        }

        /// <summary>
        /// Create common class ExampleAddress object using SOAP QAExampleAddress object.
        /// </summary>
        /// <param name="soapExampleAddress">SOAP QAExampleAddress object</param>
        /// <returns>Common class ExampleAddress object</returns>
        public static ExampleAddress CreateExampleAddress(QAExampleAddress soapExampleAddress)
        {
            string comment = soapExampleAddress.Comment;
            FormattedAddress formattedAddress = CreateFormattedAddress(soapExampleAddress.Address);
            return new ExampleAddress(comment, formattedAddress);
        }

        /// <summary>
        /// Create common class PromptLine object using SOAP PromptLine object.
        /// </summary>
        /// <param name="soapPromptLine">SOAP PromptLine object</param>
        /// <returns>Common class PromptLine object</returns>
        public static Experian.Qas.Capture.IntegrationCode.PromptLine CreatePromptLine(PromptLine soapPromptLine)
        {
            string promptMessage = soapPromptLine.Prompt;
            string example = soapPromptLine.Example;

            // suggested input length. if parse error, it is due to ondemand server error. currently, and defaults to 0.
            int suggestedInputLength;
            if (!int.TryParse(soapPromptLine.SuggestedInputLength, NumberStyles.Integer, CultureInfo.InvariantCulture, out suggestedInputLength))
            {
                suggestedInputLength = 0;
            }

            return new Experian.Qas.Capture.IntegrationCode.PromptLine(promptMessage, example, suggestedInputLength);
        }

        /// <summary>
        /// Create common class PromptSet object using SOAP QAPromptSet object.
        /// </summary>
        /// <param name="soapPromptSet">SOAP QAPromptSet object.</param>
        /// <returns>Common class PromptSet object.</returns>
        public static PromptSet CreatePromptSet(QAPromptSet soapPromptSet)
        {
            bool isDynamic = soapPromptSet.Dynamic;
            Experian.Qas.Capture.IntegrationCode.PromptLine[] promptLines = CreatePromptLines(soapPromptSet.Line);
            return new PromptSet(isDynamic, promptLines);
        }

        /// <summary>
        /// Create common class PromptLine array using SOAP PromptLine array.
        /// </summary>
        /// <param name="soapPromptLines">SOAP PromptLine array</param>
        /// <returns>Common class PromptLine array</returns>
        public static Experian.Qas.Capture.IntegrationCode.PromptLine[] CreatePromptLines(PromptLine[] soapPromptLines)
        {
            Experian.Qas.Capture.IntegrationCode.PromptLine[] promptLines = null;
            if (soapPromptLines != null)
            {
                int size = soapPromptLines.GetLength(0);
                if (size > 0)
                {
                    promptLines = new Experian.Qas.Capture.IntegrationCode.PromptLine[size];
                    for (int i = 0; i < size; i++)
                    {
                        promptLines[i] = ProOnDemandObjectFactory.CreatePromptLine(soapPromptLines[i]);
                    }
                }
            }

            return promptLines;
        }

        /// <summary>
        /// Create common class Layout object using SOAP QALayout object.
        /// </summary>
        /// <param name="soapLayout">SOAP QALayout object</param>
        /// <returns>Common class Layout object</returns>
        public static Layout CreateLayout(QALayout soapLayout)
        {
            string name = soapLayout.Name;
            string comment = soapLayout.Comment;
            return new Layout(name, comment);
        }

        /// <summary>
        /// Create common class Layout object using SOAP QALayout array.
        /// </summary>
        /// <param name="soapLayouts">SOAP QALayout array</param>
        /// <returns>Common class Layout object</returns>
        public static Layout[] CreateLayouts(QALayout[] soapLayouts)
        {
            Layout[] results = null;
            if (soapLayouts != null)
            {
                int size = soapLayouts.GetLength(0);
                if (size > 0)
                {
                    results = new Layout[size];
                    for (int i = 0; i < size; i++)
                    {
                        results[i] = ProOnDemandObjectFactory.CreateLayout(soapLayouts[i]);
                    }
                }
            }

            return results;
        }

        /// <summary>
        /// Create common class LicensedSet object using SOAP QALicensedSet object.
        /// </summary>
        /// <param name="soapLicensedSet">SOAP QALicensedSet object</param>
        /// <returns>Common class LicensedSet object</returns>
        public static LicensedSet CreateLicensedSet(QALicensedSet soapLicensedSet)
        {
            string id = soapLicensedSet.ID;
            string description = soapLicensedSet.Description;
            string copyright = soapLicensedSet.Copyright;
            string version = soapLicensedSet.Version;
            string baseCountry = soapLicensedSet.BaseCountry;
            string status = soapLicensedSet.Status;
            string server = soapLicensedSet.Server;
            CommonLicenseWarningLevel warningLevel = ProOnDemandObjectFactory.ToCommonLicenseWarningLevel(soapLicensedSet.WarningLevel);

            // days left. if parse error, it is due to ondemand server error. currently, and defaults to 0.
            int daysLeft;
            bool isParseOkDaysLeft = int.TryParse(soapLicensedSet.DaysLeft, NumberStyles.Integer, CultureInfo.InvariantCulture, out daysLeft);
            if (!isParseOkDaysLeft)
            {
                daysLeft = 0;
            }

            // data days left. if parse error, it is due to ondemand server error. currently, and defaults to 0.
            int dataDaysLeft;
            bool isParseOkData = int.TryParse(soapLicensedSet.DataDaysLeft, NumberStyles.Integer, CultureInfo.InvariantCulture, out dataDaysLeft);
            if (!isParseOkData)
            {
                dataDaysLeft = 0;
            }

            // license days left. if parse error, it is due to ondemand server error. currently, and defaults to 0.
            int licenceDaysLeft;
            bool isParseOkLicense = int.TryParse(soapLicensedSet.LicenceDaysLeft, NumberStyles.Integer, CultureInfo.InvariantCulture, out licenceDaysLeft);
            if (!isParseOkLicense)
            {
                licenceDaysLeft = 0;
            }

            return new LicensedSet(id, description, copyright, version, baseCountry, status, server, warningLevel, daysLeft, dataDaysLeft, licenceDaysLeft);
        }

        /// <summary>
        /// Create common class PicklistItem object using SOAP PicklistEntryType object.
        /// </summary>
        /// <param name="soapPicklistEntryType">SOAP PicklistEntryType object</param>
        /// <returns>Common class PicklistItem object</returns>
        public static PicklistItem CreatePicklistItem(PicklistEntryType soapPicklistEntryType)
        {
            string moniker = soapPicklistEntryType.Moniker;
            string text = soapPicklistEntryType.Picklist;
            string postcode = soapPicklistEntryType.Postcode;

            int score;
            if (!int.TryParse(soapPicklistEntryType.Score, NumberStyles.Integer, CultureInfo.InvariantCulture, out score))
            {
                score = 0;
            }

            string partialAddress = soapPicklistEntryType.PartialAddress;
            bool isFullAddress = soapPicklistEntryType.FullAddress;
            bool isMultiples = soapPicklistEntryType.Multiples;
            bool isCanStep = soapPicklistEntryType.CanStep;
            bool isAliasMatch = soapPicklistEntryType.AliasMatch;
            bool isPostcodeRecode = soapPicklistEntryType.PostcodeRecoded;
            bool isCrossBorderMatch = soapPicklistEntryType.CrossBorderMatch;
            bool isDummyPOBox = soapPicklistEntryType.DummyPOBox;
            bool isName = soapPicklistEntryType.Name;
            bool isInformation = soapPicklistEntryType.Information;
            bool isWarnInformation = soapPicklistEntryType.WarnInformation;
            bool isIncompleteAddress = soapPicklistEntryType.IncompleteAddr;
            bool isUnresolvableRange = soapPicklistEntryType.UnresolvableRange;
            bool isPhantomPrimaryPoint = soapPicklistEntryType.PhantomPrimaryPoint;
            bool isSubsidiaryData = soapPicklistEntryType.SubsidiaryData;
            bool isExtendedData = soapPicklistEntryType.ExtendedData;
            bool isEnhancedData = soapPicklistEntryType.EnhancedData;

            return new PicklistItem(moniker, text, postcode, score, partialAddress, isFullAddress, isMultiples, isCanStep, isAliasMatch, isPostcodeRecode, isCrossBorderMatch, isDummyPOBox, isName, isInformation, isWarnInformation, isIncompleteAddress, isUnresolvableRange, isPhantomPrimaryPoint, isSubsidiaryData, isExtendedData, isEnhancedData);
        }

        /// <summary>
        /// Create common class PicklistItem array using SOAP PicklistEntryType array.
        /// </summary>
        /// <param name="soapPicklistItems">SOAP PicklistEntryType array</param>
        /// <returns>Common class PicklistItem array</returns>
        public static PicklistItem[] CreatePicklistItems(PicklistEntryType[] soapPicklistItems)
        {
            PicklistItem[] picklistItems = null;

            // Check for null as we can have an empty picklist
            if (soapPicklistItems != null)
            {
                int size = soapPicklistItems.GetLength(0);
                if (size > 0)
                {
                    picklistItems = new PicklistItem[size];
                    for (int i = 0; i < size; i++)
                    {
                        picklistItems[i] = ProOnDemandObjectFactory.CreatePicklistItem(soapPicklistItems[i]);
                    }
                }
            }

            return picklistItems;
        }

        /// <summary>
        /// Create common class Picklist object using SOAP QAPicklistType object.
        /// </summary>
        /// <param name="soapPicklist">SOAP QAPicklistType object</param>
        /// <returns>Common class Picklist object</returns>
        public static Experian.Qas.Capture.IntegrationCode.Picklist CreatePicklist(QAPicklistType soapPicklist)
        {
            int total;
            if (!int.TryParse(soapPicklist.Total, NumberStyles.Integer, CultureInfo.InvariantCulture, out total))
            {
                total = 0;
            }

            string moniker = soapPicklist.FullPicklistMoniker;
            string promptMessage = soapPicklist.Prompt;
            bool isAutoStepInSafe = soapPicklist.AutoStepinSafe;
            bool isAutoStepInPastClose = soapPicklist.AutoStepinPastClose;
            bool isAutoFormatSafe = soapPicklist.AutoFormatSafe;
            bool isAutoFormatPastClose = soapPicklist.AutoFormatPastClose;
            bool isLargePotential = soapPicklist.LargePotential;
            bool isMaxMatches = soapPicklist.MaxMatches;
            bool hasMoreMatches = soapPicklist.MoreOtherMatches;
            bool isOverThreshold = soapPicklist.OverThreshold;
            bool isTimeout = soapPicklist.Timeout;
            PicklistItem[] items = CreatePicklistItems(soapPicklist.PicklistEntry);

            return new Experian.Qas.Capture.IntegrationCode.Picklist(moniker, items, promptMessage, total, isAutoStepInSafe, isAutoStepInPastClose, isAutoFormatSafe, isAutoFormatPastClose, isLargePotential, isMaxMatches, hasMoreMatches, isOverThreshold, isTimeout);
        }

        /// <summary>
        /// Create common class SearchResult object using SOAP QASearchResult object.
        /// </summary>
        /// <param name="soapSearchResult">SOAP QASearchResult object</param>
        /// <returns>Common class SearchResult object</returns>
        public static SearchResult CreateSearchResult(QASearchResult soapSearchResult)
        {
            FormattedAddress formattedAddress = null;
            Experian.Qas.Capture.IntegrationCode.Picklist picklist = null;
            CommonVerificationLevel verifyLevel = ProOnDemandObjectFactory.ToCommonVerificationLevel(soapSearchResult.VerifyLevel);

            if (soapSearchResult.QAAddress != null)
            {
                formattedAddress = ProOnDemandObjectFactory.CreateFormattedAddress(soapSearchResult.QAAddress);
            }

            if (soapSearchResult.QAPicklist != null)
            {
                picklist = ProOnDemandObjectFactory.CreatePicklist(soapSearchResult.QAPicklist);
            }

            return new SearchResult(formattedAddress, picklist, verifyLevel);
        }

        /// <summary>
        /// Create common class Dataset array using SOAP QADataSet array.
        /// </summary>
        /// <param name="soapDataSet">SOAP QADataSet array</param>
        /// <returns>Common class Dataset array</returns>
        public static DataSet[] CreateDataSets(QADataSet[] soapDataSet)
        {
            DataSet[] results = null;
            if (soapDataSet != null)
            {
                int size = soapDataSet.GetLength(0);
                if (size > 0)
                {
                    results = new DataSet[size];
                    for (int i = 0; i < size; i++)
                    {
                        results[i] = ProOnDemandObjectFactory.CreateDataSet(soapDataSet[i]);
                    }
                }
            }

            return results;
        }

        /// <summary>
        /// Create common class ExampleAddress array using SOAP QAExampleAddress array.
        /// </summary>
        /// <param name="soapAddresses">SOAP QAExampleAddress array</param>
        /// <returns>Common class ExampleAddress array</returns>
        public static ExampleAddress[] CreateExampleAddresses(QAExampleAddress[] soapAddresses)
        {
            ExampleAddress[] results = null;
            if (soapAddresses != null)
            {
                int size = soapAddresses.GetLength(0);
                if (size > 0)
                {
                    results = new ExampleAddress[size];
                    for (int i = 0; i < size; i++)
                    {
                        results[i] = ProOnDemandObjectFactory.CreateExampleAddress(soapAddresses[i]);
                    }
                }
            }

            return results;
        }

        /// <summary>
        /// Create common class LicensedSet array using SOAP QALicenceInfo object.
        /// </summary>
        /// <param name="soapInfo">SOAP QALicenceInfo object</param>
        /// <returns>common class LicensedSet array</returns>
        public static LicensedSet[] CreateLicensedSets(QALicenceInfo soapInfo)
        {
            LicensedSet[] results = null;
            QALicensedSet[] soapLicenseSets = soapInfo.LicensedSet;
            if (soapLicenseSets != null)
            {
                int size = soapLicenseSets.GetLength(0);
                if (size > 0)
                {
                    results = new LicensedSet[size];
                    for (int i = 0; i < size; i++)
                    {
                        results[i] = ProOnDemandObjectFactory.CreateLicensedSet(soapLicenseSets[i]);
                    }
                }
            }

            return results;
        }

        /// <summary>
        /// Create common class LicensedSet array using SOAP QADataMapDetail object.
        /// </summary>
        /// <param name="soapDataMapDetail">SOAP QADataMapDetail object</param>
        /// <returns>Common class LicensedSet array</returns>
        public static LicensedSet[] CreateLicensedSets(QADataMapDetail soapDataMapDetail)
        {
            LicensedSet[] results = null;
            QALicensedSet[] soapLicenseSet = soapDataMapDetail.LicensedSet;

            if (soapLicenseSet != null)
            {
                if (soapLicenseSet.Length > 0)
                {
                    results = new LicensedSet[soapLicenseSet.Length];

                    for (int i = 0; i < soapLicenseSet.Length; ++i)
                    {
                        results[i] = ProOnDemandObjectFactory.CreateLicensedSet(soapLicenseSet[i]);
                    }
                }
            }

            return results;
        }

        internal static EngineEnumType ToEngineEnumType(CommonEngineType engineType)
        {
            EngineEnumType resultType = default(EngineEnumType);
            switch (engineType)
            {
                case CommonEngineType.Intuitive:
                    resultType = EngineEnumType.Intuitive;
                    break;
                case CommonEngineType.Keyfinder:
                    resultType = EngineEnumType.Keyfinder;
                    break;
                case CommonEngineType.Singleline:
                    resultType = EngineEnumType.Singleline;
                    break;
                case CommonEngineType.Typedown:
                    resultType = EngineEnumType.Typedown;
                    break;
                case CommonEngineType.Verification:
                    resultType = EngineEnumType.Verification;
                    break;
                default:
                    resultType = default(EngineEnumType);
                    break;
            }

            return resultType;
        }

        internal static EngineIntensityType ToEngineIntensityType(CommonIntensityType tempIntensityType)
        {
            EngineIntensityType resultType = default(EngineIntensityType);
            switch (tempIntensityType)
            {
                case CommonIntensityType.Close:
                    resultType = EngineIntensityType.Close;
                    break;
                case CommonIntensityType.Exact:
                    resultType = EngineIntensityType.Exact;
                    break;
                case CommonIntensityType.Extensive:
                    resultType = EngineIntensityType.Extensive;
                    break;
                default:
                    resultType = default(EngineIntensityType);
                    break;
            }

            return resultType;
        }

        internal static PromptSetType ToPromptSetType(CommonPromptSetType tempPromptSetType)
        {
            PromptSetType resultType = default(PromptSetType);
            switch (tempPromptSetType)
            {
                case CommonPromptSetType.Alternate:
                    resultType = PromptSetType.Alternate;
                    break;
                case CommonPromptSetType.Alternate2:
                    resultType = PromptSetType.Alternate2;
                    break;
                case CommonPromptSetType.Alternate3:
                    resultType = PromptSetType.Alternate3;
                    break;
                case CommonPromptSetType.Default:
                    resultType = PromptSetType.Default;
                    break;
                case CommonPromptSetType.Generic:
                    resultType = PromptSetType.Generic;
                    break;
                case CommonPromptSetType.OneLine:
                    resultType = PromptSetType.OneLine;
                    break;
                case CommonPromptSetType.Optimal:
                    resultType = PromptSetType.Optimal;
                    break;
                default:
                    resultType = default(PromptSetType);
                    break;
            }

            return resultType;
        }

        internal static CommonAddressLineType ToCommonAddressLineType(LineContentType lineContentType)
        {
            CommonAddressLineType commonAddressLineType = default(CommonAddressLineType);
            switch (lineContentType)
            {
                case LineContentType.Address:
                    commonAddressLineType = CommonAddressLineType.Address;
                    break;
                case LineContentType.Ancillary:
                    commonAddressLineType = CommonAddressLineType.Ancillary;
                    break;
                case LineContentType.DataPlus:
                    commonAddressLineType = CommonAddressLineType.DataPlus;
                    break;
                case LineContentType.Name:
                    commonAddressLineType = CommonAddressLineType.Name;
                    break;
                case LineContentType.None:
                    commonAddressLineType = CommonAddressLineType.None;
                    break;
                default:
                    commonAddressLineType = default(CommonAddressLineType);
                    break;
            }

            return commonAddressLineType;
        }

        internal static CommonDPVStatusType ToCommonDPVStatusType(DPVStatusType dpvStatusType)
        {
            CommonDPVStatusType result = default(CommonDPVStatusType);
            switch (dpvStatusType)
            {
                case DPVStatusType.DPVConfigured:
                    result = CommonDPVStatusType.DPVConfigured;
                    break;
                case DPVStatusType.DPVConfirmed:
                    result = CommonDPVStatusType.DPVConfirmed;
                    break;
                case DPVStatusType.DPVConfirmedMissingSec:
                    result = CommonDPVStatusType.DPVConfirmedMissingSec;
                    break;
                case DPVStatusType.DPVLocked:
                    result = CommonDPVStatusType.DPVLocked;
                    break;
                case DPVStatusType.DPVNotConfigured:
                    result = CommonDPVStatusType.DPVNotConfigured;
                    break;
                case DPVStatusType.DPVNotConfirmed:
                    result = CommonDPVStatusType.DPVNotConfirmed;
                    break;
                case DPVStatusType.DPVSeedHit:
                    result = CommonDPVStatusType.DPVSeedHit;
                    break;
                default:
                    result = default(CommonDPVStatusType);
                    break;
            }

            return result;
        }

        internal static CommonLicenseWarningLevel ToCommonLicenseWarningLevel(LicenceWarningLevel licenceWarningLevel)
        {
            CommonLicenseWarningLevel resultType = default(CommonLicenseWarningLevel);
            switch (licenceWarningLevel)
            {
                case LicenceWarningLevel.ClicksLow:
                    resultType = CommonLicenseWarningLevel.ClicksLow;
                    break;
                case LicenceWarningLevel.DataExpired:
                    resultType = CommonLicenseWarningLevel.DataExpired;
                    break;
                case LicenceWarningLevel.DataExpiring:
                    resultType = CommonLicenseWarningLevel.DataExpiring;
                    break;
                case LicenceWarningLevel.DataUnreadable:
                    resultType = CommonLicenseWarningLevel.DataUnreadable;
                    break;
                case LicenceWarningLevel.EvalLicenceExpired:
                    resultType = CommonLicenseWarningLevel.EvalLicenceExpired;
                    break;
                case LicenceWarningLevel.Evaluation:
                    resultType = CommonLicenseWarningLevel.Evaluation;
                    break;
                case LicenceWarningLevel.FullLicenceExpired:
                    resultType = CommonLicenseWarningLevel.FullLicenceExpired;
                    break;
                case LicenceWarningLevel.LicenceExpiring:
                    resultType = CommonLicenseWarningLevel.LicenceExpiring;
                    break;
                case LicenceWarningLevel.LicenceNotFound:
                    resultType = CommonLicenseWarningLevel.LicenceNotFound;
                    break;
                case LicenceWarningLevel.NoClicks:
                    resultType = CommonLicenseWarningLevel.NoClicks;
                    break;
                case LicenceWarningLevel.None:
                    resultType = CommonLicenseWarningLevel.None;
                    break;
                default:
                    resultType = default(CommonLicenseWarningLevel);
                    break;
            }

            return resultType;
        }

        internal static CommonVerificationLevel ToCommonVerificationLevel(VerifyLevelType verifyLevelType)
        {
            CommonVerificationLevel resultType = default(CommonVerificationLevel);
            switch (verifyLevelType)
            {
                case VerifyLevelType.InteractionRequired:
                    resultType = CommonVerificationLevel.InteractionRequired;
                    break;
                case VerifyLevelType.Multiple:
                    resultType = CommonVerificationLevel.Multiple;
                    break;
                case VerifyLevelType.None:
                    resultType = CommonVerificationLevel.None;
                    break;
                case VerifyLevelType.PremisesPartial:
                    resultType = CommonVerificationLevel.PremisesPartial;
                    break;
                case VerifyLevelType.StreetPartial:
                    resultType = CommonVerificationLevel.StreetPartial;
                    break;
                case VerifyLevelType.Verified:
                    resultType = CommonVerificationLevel.Verified;
                    break;
                case VerifyLevelType.VerifiedPlace:
                    resultType = CommonVerificationLevel.VerifiedPlace;
                    break;
                case VerifyLevelType.VerifiedStreet:
                    resultType = CommonVerificationLevel.VerifiedStreet;
                    break;
                default:
                    resultType = default(CommonVerificationLevel);
                    break;
            }

            return resultType;
        }
    }
}