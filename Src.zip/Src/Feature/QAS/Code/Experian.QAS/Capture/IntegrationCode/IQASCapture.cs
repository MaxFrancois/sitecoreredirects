﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// This class is a facade into On Demand and provides the main functionality of the package.
    /// It uses the  package in a stateless manner, but some optional settings are maintained between construction and the main "business" call to the soap package.
    /// An instance of this class is not intended to be preserved across different pages.
    /// The intended usage idiom is: construct instance - set optional settings - call main method (e.g. search) - discard instance.
    /// IQASCapture interface must be implemented for every release of new On Demand web service.
    /// </summary>
    public interface IQASCapture
    {
        /// <summary>
        /// Test whether a search can be performed using a data set/layout/engine combination
        /// </summary>
        /// <param name="countryId">Three-letter data identifier</param>
        /// <param name="engine">Search engine to be used in this search</param>
        /// <param name="flatten">Flag indicating usage of flatten or hierachical mode</param>
        /// <param name="intensity">Intensity of search</param>
        /// <param name="promptSet">The prompt set to use</param>
        /// <param name="threshold">Threshold of search</param>
        /// <param name="timeout">Timeout of search</param>
        /// <param name="layout">Name of the layout; optional</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Is the country and layout combination available</returns>
        CanSearch CanSearch(string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold, int? timeout, string layout, string localisation);

        /// <summary>
        /// Retrieve the final address specifed by the moniker, formatted using the requested layout
        /// </summary>
        /// <param name="moniker">Search point moniker of the address item</param>
        /// <param name="layout">Name of the layout name (specifies how the address should be formatted)</param>
        /// <param name="requestTag">User supplied tag for the request</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Formatted address result</returns>
        FormattedAddress GetAddress(string moniker, string layout, string requestTag, string localisation);

        /// <summary>
        /// Retrieve all the available data sets
        /// </summary>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of available data sets</returns>
        DataSet[] GetData(string localisation);

        /// <summary>
        /// Gets the detail of the datamap.
        /// </summary>
        /// <param name="countryId">Three-letter identifier of the country to search</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of LicensedSet object.</returns>
        LicensedSet[] GetDataMapDetail(string countryId, string localisation);

        /// <summary>
        /// Retrieve an array of example addresses for this data set in the specified layouit
        /// </summary>
        /// <param name="countryId">Three-letter identifier of the country to search</param>
        /// <param name="layout">Layout to apply</param>
        /// <param name="requestTag">A string used to tag this search.</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of example addresses</returns>
        ExampleAddress[] GetExampleAddresses(string countryId, string layout, string requestTag, string localisation);

        /// <summary>
        /// Retrieve an array of all the layouts available for the specified data set
        /// </summary>
        /// <param name="countryId">3-letter identifier of the data set of interest</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of layouts within this data set</returns>
        Layout[] GetLayouts(string countryId, string localisation);

        /// <summary>
        /// Retrieve detailed licensing information about all the data sets and DataPlus sets installed
        /// </summary>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of licencing information, one per data set</returns>
        LicensedSet[] GetLicenceInfo(string localisation);

        /// <summary>
        /// Retrieve the search prompt set for a particular data set
        /// </summary>
        /// <param name="countryId">Three-letter identifier of the country to search</param>
        /// <param name="engine">Search engine to be used in this search</param>
        /// <param name="flatten">Flag indicating usage of flatten or hierachical mode</param>
        /// <param name="promptSet">Input template of interest</param>
        /// <param name="threshold">Threshold of search</param>
        /// <param name="timeout">Timeout of search</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Input template, array of template lines</returns>
        PromptSet GetPromptSet(string countryId, string engine, bool? flatten, string promptSet, int? threshold, int? timeout, string localisation);

        /// <summary>
        /// Retrieve system (diagnostic) information from the server
        /// </summary>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Array of strings, tab-separated key/value pairs of system info</returns>
        string[] GetSystemInfo(string localisation);

        /// <summary>
        /// Perform a refinement, filtering the specified picklist using the supplied text 
        /// NB: Stepin delegates to this function with blank refinement text
        /// </summary>
        /// <param name="moniker">The search point moniker of the picklist to refine</param>
        /// <param name="refinement">The refinement text</param>
        /// <param name="layout">The layout to use</param>
        /// <param name="formattedAddressInPicklist">Flag indicating whether search text is a formatted address in picklist</param>
        /// <param name="threshold">Threshold of search</param>
        /// <param name="timeout">Timeout of search</param>
        /// <param name="requestTag">Request tag supplied by user</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Picklist result</returns>
        Picklist Refine(string moniker, string refinement, string layout, bool? formattedAddressInPicklist, int? threshold, int? timeout, string requestTag, string localisation);

        /// <summary>
        /// Search function with search terms as a single string
        /// </summary>
        /// <param name="countryId">Three-letter identifier of the country to search</param>
        /// <param name="engine">Search engine to be used in this search</param>
        /// <param name="flatten">Flag indicating usage of flatten or hierachical mode</param>
        /// <param name="intensity">Intensity of search</param>
        /// <param name="promptSet">Name of the search prompt set applied to the search terms</param>
        /// <param name="threshold">Threshold of search</param>
        /// <param name="timeout">Timeout of search</param>
        /// <param name="layout">Name of the layout (verification engine only); optional</param>
        /// <param name="searchText">Search text</param>
        /// <param name="formattedAddressInPicklist">Flag indicating whether search text is a formatted address in picklist</param>
        /// <param name="requestTag">Request tag supplied by user</param>
        /// <param name="localisation">Localisation language to use</param>
        /// <returns>Search result, containing a picklist and/or formatted address</returns>
        SearchResult Search(string countryId, string engine, bool? flatten, string intensity, string promptSet, int? threshold, int? timeout, string layout, string searchText, bool? formattedAddressInPicklist, string requestTag, string localisation);
    }
}