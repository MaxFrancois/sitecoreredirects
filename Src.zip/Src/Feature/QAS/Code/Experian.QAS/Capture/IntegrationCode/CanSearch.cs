namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate the result of a CanSearch operation:
    /// searching availability, and the reasons when unavailable
    /// </summary>
    public class CanSearch : IJsonSerializable
    {
        #region Private Members
        private bool _isOk;
        private string _errorMessage;
        private int _errorCode;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="isOk">Indicates whether search is available</param>
        /// <param name="errorCode">Error code</param>
        /// <param name="errorMessage">Error message</param>
        public CanSearch(bool isOk, int errorCode, string errorMessage)
        {
            this._isOk = isOk;
            this._errorCode = errorCode;
            this._errorMessage = errorMessage;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets a value indicating whether searching is possible for the requested data-engine-layout combination
        /// </summary>
        public bool IsOk
        {
            get
            {
                return _isOk;
            }
        }

        /// <summary>
        /// Gets error inFormation relating why it is not possible to search the requested data-engine-layout
        /// </summary>
        public string ErrorMessage
        {
            get
            {
                return _errorMessage;
            }
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("IsOk", _isOk);
            builder.AppendSeparator().AppendMember("Error", _errorCode);
            builder.AppendSeparator().AppendMember("ErrorMessage", _errorMessage);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
