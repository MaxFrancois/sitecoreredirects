﻿using System.Diagnostics.CodeAnalysis;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// DPV status types.
    /// </summary>
    public enum CommonDPVStatusType
    {
        /// <summary>
        /// Default value. No DPV status type.
        /// </summary>
        None = 0,

        /// <summary>
        /// DPV not configured.
        /// </summary>
        DPVNotConfigured,

        /// <summary>
        /// DPV configured.
        /// </summary>
        DPVConfigured,

        /// <summary>
        /// DPV confirmed.
        /// </summary>
        DPVConfirmed,

        /// <summary>
        /// DPV confirmed with  missing secondary address.
        /// </summary>
        DPVConfirmedMissingSec,

        /// <summary>
        /// DPV not confirmed.
        /// </summary>
        DPVNotConfirmed,

        /// <summary>
        /// DPV locked.
        /// </summary>
        DPVLocked,

        /// <summary>
        /// DPV seed hit.
        /// </summary>
        DPVSeedHit,
    }
}