using System.Globalization;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate the data associated with one line of a picklist
    /// </summary>
    public class PicklistItem : IJsonSerializable
    {
        #region Private Members
        private string _moniker;
        private string _text;
        private string _postcode;
        private int _score;
        private string _partialAddress;

        private bool _isFullAddress;
        private bool _isMultiples;
        private bool _isCanStep;
        private bool _isAliasMatch;
        private bool _isPostcodeRecode;
        private bool _isCrossBorderMatch;
        private bool _isDummyPOBox;
        private bool _isName;
        private bool _isInformation;
        private bool _isWarnInformation;
        private bool _isIncompleteAddress;
        private bool _isUnresolvableRange;
        private bool _isPhantomPrimaryPoint;
        private bool _isSubsidiaryData;
        private bool _isExtendedData;
        private bool _isEnhancedData;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="moniker">Moniker of picklist item</param>
        /// <param name="text">Address text of piclist item</param>
        /// <param name="postcode">Postcode of picklist item</param>
        /// <param name="score">Score or confidence level of match</param>
        /// <param name="partialAddress">Full address details which have been captured so far</param>
        /// <param name="isFullAddress">Indicates whether this item represents a full deliverable address</param>
        /// <param name="isMultiples">Indicates that the picklist item represents multiple addresses</param>
        /// <param name="isCanStep">Indicates whether this item can be stepped into to produce a new picklist with more detail</param>
        /// <param name="isAliasMatch">Indicates whether a picklist item has been produced by a match to an alias of an item</param>
        /// <param name="isPostcodeRecode">Indicates that a postcode was searched on</param>
        /// <param name="isCrossBorderMatch">Indicates whether this item represents a nearby area, outside the strict initial boundaries of the search</param>
        /// <param name="isDummyPOBox">Indicates whether this item is a dummy PO Box</param>
        /// <param name="isName">Indicates that the picklist item contains names information</param>
        /// <param name="isInformation">Indicates that the picklist item is an informational item</param>
        /// <param name="isWarnInformation">Indicates that the picklist item is a warning informational item</param>
        /// <param name="isIncompleteAddress">Indicates that the picklist item does not contain all the information required to make it a deliverable address</param>
        /// <param name="isUnresolvableRange">Indicates that the picklist item is a range of premises which cannot be expended</param>
        /// <param name="isPhantomPrimaryPoint">Indicates that the picklist item is a phantom primary point</param>
        /// <param name="isSubsidiaryData">Indicates that the picklist item is an subsidiary data</param>
        /// <param name="isExtendedData">Indicates that the picklist item is an extended data</param>
        /// <param name="isEnhancedData">Indicates that the picklist item is an enhanced data</param>
        public PicklistItem(
            string moniker,
            string text,
            string postcode,
            int score,
            string partialAddress,
            bool isFullAddress,
            bool isMultiples,
            bool isCanStep,
            bool isAliasMatch,
            bool isPostcodeRecode,
            bool isCrossBorderMatch,
            bool isDummyPOBox,
            bool isName,
            bool isInformation,
            bool isWarnInformation,
            bool isIncompleteAddress,
            bool isUnresolvableRange,
            bool isPhantomPrimaryPoint,
            bool isSubsidiaryData,
            bool isExtendedData,
            bool isEnhancedData)
        {
            this._moniker = moniker;
            this._text = text;
            this._postcode = postcode;
            this._score = score;
            this._partialAddress = partialAddress;
            this._isFullAddress = isFullAddress;
            this._isMultiples = isMultiples;
            this._isCanStep = isCanStep;
            this._isAliasMatch = isAliasMatch;
            this._isPostcodeRecode = isPostcodeRecode;
            this._isCrossBorderMatch = isCrossBorderMatch;
            this._isDummyPOBox = isDummyPOBox;
            this._isName = isName;
            this._isInformation = isInformation;
            this._isWarnInformation = isWarnInformation;
            this._isIncompleteAddress = isIncompleteAddress;
            this._isUnresolvableRange = isUnresolvableRange;
            this._isPhantomPrimaryPoint = isPhantomPrimaryPoint;
            this._isSubsidiaryData = isSubsidiaryData;
            this._isExtendedData = isExtendedData;
            this._isEnhancedData = isEnhancedData;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the moniker representing this item 
        /// </summary>
        public string Moniker
        {
            get
            {
                return _moniker;
            }
        }

        /// <summary>
        /// Gets the picklist text for display
        /// </summary>
        public string Text
        {
            get
            {
                return _text;
            }
        }

        /// <summary>
        /// Gets the postcode for display; may be empty
        /// </summary>
        public string Postcode
        {
            get
            {
                return _postcode;
            }
        }

        /// <summary>
        /// Gets the percentage score of this item; 0 if not applicable
        /// </summary>
        public int Score
        {
            get
            {
                return _score;
            }
        }

        /// <summary>
        /// Gets the score of this item for display, as "100%", or "" if score not applicable
        /// </summary>
        public string ScoreAsString
        {
            get
            {
                if (Score > 0)
                {
                    return Score.ToString(CultureInfo.InvariantCulture) + "%";
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// Gets the full address details captured thus far 
        /// </summary>
        public string PartialAddress
        {
            get
            {
                return _partialAddress;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this item represents a full deliverable address, so can be formatted
        /// </summary>
        public bool IsFullAddress
        {
            get
            {
                return _isFullAddress;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this item represents multiple addresses (for display purposes)
        /// </summary>
        public bool IsMultipleAddresses
        {
            get
            {
                return _isMultiples;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the item can be stepped into
        /// </summary>
        public bool CanStep
        {
            get
            {
                return _isCanStep;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is an alias match, which you may wish to highlight to the user
        /// </summary>
        public bool IsAliasMatch
        {
            get
            {
                return _isAliasMatch;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry has a recoded postcode, which you may wish to highlight to the user
        /// </summary>
        public bool IsPostcodeRecoded
        {
            get
            {
                return _isPostcodeRecode;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a dummy (for DataSets without premise information)
        /// It can neither be stepped into nor formatted, but must be refined against with premise details
        /// </summary>
        public bool IsIncompleteAddress
        {
            get
            {
                return _isIncompleteAddress;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a range dummy (for DataSets with only ranges of premise information)
        /// It can neither be stepped into nor formatted, but must be refined against with premise details
        /// </summary>
        public bool IsUnresolvableRange
        {
            get
            {
                return _isUnresolvableRange;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a premise
        /// </summary>
        public bool IsPhantomPrimaryPoint
        {
            get
            {
                return _isPhantomPrimaryPoint;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry represents a nearby area, outside the strict initial
        /// boundaries of the search, which you may wish to highlight to the user
        /// </summary>
        public bool IsCrossBorderMatch
        {
            get
            {
                return _isCrossBorderMatch;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a dummy PO Box (which you may wish to display differently)
        /// </summary>
        public bool IsDummyPOBox
        {
            get
            {
                return _isDummyPOBox;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a Names item (which you may wish to display differently)
        /// </summary>
        public bool IsName
        {
            get
            {
                return _isName;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is an informational prompt, rather than an address
        /// </summary>
        public bool IsInformation
        {
            get
            {
                return _isInformation;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is a warning prompt, indicating that it is not possible to
        /// proceed any further (due to no matches, too many matches, etc.)
        /// </summary>
        public bool IsWarnInformation
        {
            get
            {
                return _isWarnInformation;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is from the subsidiary rather than the base data set
        /// </summary>
        public bool IsSubsidiaryData
        {
            get
            {
                return _isSubsidiaryData;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is from the base data set but extended by the subsidiary data set
        /// </summary>
        public bool IsExtendedData
        {
            get
            {
                return _isExtendedData;
            }
        }

        /// <summary>
        /// Gets a value indicating whether this entry is from the base data set but enhanced by the subsidiary data set
        /// </summary>
        public bool IsEnhancedData
        {
            get
            {
                return _isEnhancedData;
            }
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("IsAliasMatch", _isAliasMatch);
            builder.AppendSeparator().AppendMember("IsCanStep", _isCanStep);
            builder.AppendSeparator().AppendMember("IsCrossBorderMatch", _isCrossBorderMatch);
            builder.AppendSeparator().AppendMember("IsDummyPOBox", _isDummyPOBox);
            builder.AppendSeparator().AppendMember("IsEnhancedData", _isEnhancedData);
            builder.AppendSeparator().AppendMember("IsExtendedData", _isExtendedData);
            builder.AppendSeparator().AppendMember("IsFullAddress", _isFullAddress);
            builder.AppendSeparator().AppendMember("IsIncompleteAddress", _isIncompleteAddress);
            builder.AppendSeparator().AppendMember("IsInformation", _isInformation);
            builder.AppendSeparator().AppendMember("IsMultiples", _isMultiples);
            builder.AppendSeparator().AppendMember("IsName", _isName);
            builder.AppendSeparator().AppendMember("IsPhantomPrimaryPoint", _isPhantomPrimaryPoint);
            builder.AppendSeparator().AppendMember("IsPostcodeRecode", _isPostcodeRecode);
            builder.AppendSeparator().AppendMember("IsSubsidiaryData", _isSubsidiaryData);
            builder.AppendSeparator().AppendMember("IsUnresolvableRange", _isUnresolvableRange);
            builder.AppendSeparator().AppendMember("IsWarnInformation", _isWarnInformation);
            builder.AppendSeparator().AppendMember("Score", _score);
            builder.AppendSeparator().AppendMember("Moniker", _moniker);
            builder.AppendSeparator().AppendMember("PartialAddress", _partialAddress);
            builder.AppendSeparator().AppendMember("Postcode", _postcode);
            builder.AppendSeparator().AppendMember("Text", _text);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
