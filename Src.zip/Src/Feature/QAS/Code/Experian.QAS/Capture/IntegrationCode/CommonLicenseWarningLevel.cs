﻿using System.Diagnostics.CodeAnalysis;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of warning levels that can be returned
    /// </summary>
    public enum CommonLicenseWarningLevel
    {
        /// <summary>
        /// This indicates that there are no warnings relating to the data.
        /// </summary>
        None,

        /// <summary>
        /// This indicates that the data is close to its expiry date.
        /// </summary>
        DataExpiring,

        /// <summary>
        /// This indicates that the licence that controls the usage of the data is close to its expiry date.
        /// </summary>
        LicenceExpiring,

        /// <summary>
        /// This indicates that the number of available clicks for the data have run out and that overdraft clicks are being used.
        /// </summary>
        ClicksLow,

        /// <summary>
        /// This indicates that an evaluation licence is being used for the data
        /// </summary>
        Evaluation,

        /// <summary>
        /// This indicates that there are no more clicks remaining which can be used to search against the data, so the data cannot be used
        /// </summary>
        NoClicks,

        /// <summary>
        /// This indicates that the data has passed its expiry date and so cannot be used.
        /// </summary>
        DataExpired,

        /// <summary>
        /// This indicates that the evaluation licence which controls the use of this data has expired.
        /// </summary>
        [SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Eval", Justification = "Follow WSDL naming.")]
        EvalLicenceExpired,

        /// <summary>
        /// This indicates that the full (non-evaluation) licence which controls the use of this data has expired.
        /// </summary>
        FullLicenceExpired,

        /// <summary>
        /// This indicates that the product is unable to locate a licence for this data, and so it cannot be used.
        /// </summary>
        LicenceNotFound,

        /// <summary>
        /// This indicates that this data cannot be opened or read, and so is unusable.
        /// </summary>
        DataUnreadable
    }
}