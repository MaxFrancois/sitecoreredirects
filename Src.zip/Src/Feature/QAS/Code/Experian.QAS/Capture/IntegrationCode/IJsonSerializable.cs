﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Represents a object that can be serialized into Json string.
    /// </summary>
    public interface IJsonSerializable
    {
        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        string ToJson();
    } 
}
