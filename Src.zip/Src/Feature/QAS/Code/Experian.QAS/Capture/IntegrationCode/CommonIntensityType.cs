﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of engine searching intensity levels
    /// </summary>
    public enum CommonIntensityType
    {
        /// <summary>
        /// Exact intensity. Does not allow mistakes but fastest.
        /// </summary>
        Exact,

        /// <summary>
        /// Close intensity. Allow some mistake in the search.
        /// </summary>
        Close,

        /// <summary>
        /// Extensive intensity. Allow many mistakes in search, but takes longest.
        /// </summary>
        Extensive
    }
}