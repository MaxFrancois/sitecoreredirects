﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of engine types
    /// </summary>
    public enum CommonEngineType
    {
        /// <summary>
        /// Singleline engine type.
        /// </summary>
        Singleline,

        /// <summary>
        /// Typedown engine type.
        /// </summary>
        Typedown,

        /// <summary>
        /// Typedown engine type.
        /// </summary>
        Verification,

        /// <summary>
        /// Keyfinder engine type.
        /// </summary>
        Keyfinder,

        /// <summary>
        /// Intuitive engine type.
        /// </summary>
        Intuitive
    }
}