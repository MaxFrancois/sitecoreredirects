﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Represents an error in Json RPC invocation.
    /// </summary>
    public class RpcError : IJsonSerializable
    {
        #region Private Members
        private string _code;
        private string _message;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor. Creates an error using error code and message.
        /// </summary>
        /// <param name="code">Error code</param>
        /// <param name="message">Error message</param>
        public RpcError(string code, string message)
        {
            this._code = code;
            this._message = message;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the error code.
        /// </summary>
        public string Code
        {
            get { return _code; }
        }

        /// <summary>
        /// Gets the error message.
        /// </summary>
        public string Message
        {
            get { return _message; }
        }
        #endregion

        #region IJsonSerializable Members
        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("message", _message);
            builder.AppendSeparator().AppendMember("code", _code);
            builder.AppendEndObject();
            return builder.ToString();
        }
        #endregion
    }
}