using System.Diagnostics.CodeAnalysis;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate layout data
    /// </summary>
    [SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces", Justification = "Layout is the conventional name for QAS product. It cannot be renamed to another name.")]
    public class Layout : IJsonSerializable
    {
        #region Private Members
        private string _name = null;
        private string _comment = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="name">Name of layout</param>
        /// <param name="comment">Comment of layout</param>
        public Layout(string name, string comment)
        {
            this._name = name;
            this._comment = comment;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets the name of the layout
        /// </summary>
        public string Name
        {
            get
            {
                return _name;
            }
        }

        /// <summary>
        /// Gets any comment asscoiated with this layout
        /// </summary>
        public string Comment
        {
            get
            {
                return _comment;
            }
        }
        #endregion

        #region Static Method
        /// <summary>
        /// Returns the Layout which matches the name, otherwise null
        /// </summary>
        /// <param name="layouts">Array of layouts to search</param>
        /// <param name="layoutName">Layout name to search for</param>
        /// <returns>Layout object.</returns>
        public static Layout FindByName(Layout[] layouts, string layoutName)
        {
            for (int i = 0; i < layouts.GetLength(0); i++)
            {
                if (layouts[i].Name.Equals(layoutName))
                {
                    return layouts[i];
                }
            }

            return null;
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Name", _name);
            builder.AppendSeparator().AppendMember("Comment", _comment);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
