﻿namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Enumeration of available search prompt sets
    /// </summary>
    public enum CommonPromptSetType
    {
        /// <summary>
        /// All search text submitted as a single line.
        /// </summary>
        OneLine,

        /// <summary>
        /// Default promptset for the engine.
        /// </summary>
        Default,

        /// <summary>
        /// General data independent promptset.
        /// </summary>
        Generic,

        /// <summary>
        /// Minimal amount of search text.
        /// </summary>
        Optimal,

        /// <summary>
        /// Country specific set where information required for optimal search not available.
        /// </summary>
        Alternate,

        /// <summary>
        /// Alternative promptset (United States only).
        /// </summary>
        Alternate2,

        /// <summary>
        /// Alternative promptset.
        /// </summary>
        Alternate3
    }
}