﻿using System.Text;

namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Class containing JSON syntax constants.
    /// </summary>
    public static class RpcJsonSyntax
    {
        /// <summary>
        /// Boolean true
        /// </summary>
        public static readonly string BooleanTrue = "true";

        /// <summary>
        /// Boolean true
        /// </summary>
        public static readonly string BooleanFalse = "false";

        /// <summary>
        /// Begin array syntax.
        /// </summary>
        public static readonly string BeginArray = "[";

        /// <summary>
        /// End array syntax.
        /// </summary>
        public static readonly string EndArray = "]";

        /// <summary>
        /// Begin object syntax.
        /// </summary>
        public static readonly string BeginObject = "{";

        /// <summary>
        /// End object syntax.
        /// </summary>
        public static readonly string EndObject = "}";

        /// <summary>
        /// Separator systax.
        /// </summary>
        public static readonly string Separator = ",";

        /// <summary>
        /// Null syntax.
        /// </summary>
        public static readonly string Null = "null";
    }
}