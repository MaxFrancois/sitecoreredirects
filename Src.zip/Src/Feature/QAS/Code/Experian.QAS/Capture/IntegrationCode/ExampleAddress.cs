namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate example address data
    /// </summary>
    public class ExampleAddress : IJsonSerializable
    {
        #region Private Members
        private string _comment;
        private FormattedAddress _address;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="comment">Text description of the example address</param>
        /// <param name="formattedAddress">Formatted example address</param>
        public ExampleAddress(string comment, FormattedAddress formattedAddress)
        {
            this._comment = comment;
            this._address = formattedAddress;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets a comment describing the example address
        /// </summary>
        public string Comment
        {
            get
            {
                return _comment;
            }
        }

        /// <summary>
        /// Gets the formatted example address
        /// </summary>
        /// <returns>Array of address line</returns>
        public AddressLine[] GetAddressLines()
        {
            return _address.GetAddressLines();
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMember("Address", _address as IJsonSerializable);
            builder.AppendSeparator().AppendMember("Comment", _comment);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
