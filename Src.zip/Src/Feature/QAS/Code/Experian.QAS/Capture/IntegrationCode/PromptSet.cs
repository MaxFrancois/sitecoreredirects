namespace Experian.Qas.Capture.IntegrationCode
{
    /// <summary>
    /// Simple class to encapsulate data representing a search prompt set
    /// </summary>
    public class PromptSet : IJsonSerializable
    {
        #region Private Members
        private bool _isDynamic;
        private PromptLine[] _lines;
        #endregion

        #region Constructor
        /// <summary>
        /// Public constructor.
        /// </summary>
        /// <param name="isDynamic">Indicates whether dynamic search submission is recommended</param>
        /// <param name="promptLines">Array of promptlines in this promtset</param>
        public PromptSet(bool isDynamic, PromptLine[] promptLines)
        {
            this._isDynamic = isDynamic;
            this._lines = promptLines;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets a value indicating whether dynamic searching should be used (submitting the search as they type)
        /// </summary>
        public bool IsDynamic
        {
            get
            {
                return _isDynamic;
            }
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns a <code>string[]</code> of prompts (from the search prompt line array)
        /// </summary>
        /// <returns>Array of prompt messages.</returns>
        public string[] GetLinePrompts()
        {
            int size = _lines.GetLength(0);
            string[] results = new string[size];
            for (int i = 0; i < size; i++)
            {
                results[i] = _lines[i].Prompt;
            }

            return results;
        }

        /// <summary>
        /// Gets the array of search prompt lines that make up this search prompt set
        /// </summary>
        /// <returns>Promptlines.</returns>
        public PromptLine[] GetLines()
        {
            return _lines;
        }
        #endregion

        #region IJsonSerializable Members

        /// <summary>
        /// Serialize the object as Json notation string.
        /// </summary>
        /// <returns>Json representation of object.</returns>
        public string ToJson()
        {
            RpcResultBuilder builder = new RpcResultBuilder();
            builder.AppendBeginObject();
            builder.AppendMemberArray("Lines", _lines);
            builder.AppendSeparator().AppendMember("IsDynamic", _isDynamic);
            builder.AppendEndObject();
            return builder.ToString();
        }

        #endregion
    }
}
