﻿using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Hero.Controllers
{
    public class HeroController : SitecoreController
    {
        protected Item DataContext { get { return RenderingContext.Current.Rendering.Item ?? RenderingContext.Current.PageContext.Item; } }
        // GET: Hero
        public ActionResult Banner()
        {
            return PartialView("HeroBannerView", DataContext);
        }
    }
}