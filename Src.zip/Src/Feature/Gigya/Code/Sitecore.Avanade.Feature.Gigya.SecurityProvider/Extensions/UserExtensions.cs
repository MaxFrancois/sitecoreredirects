﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Extensions
{
    public static class UserExtensions
    {
        /// <summary>
        /// Is the current user a logged in user and part of the gigya domain
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static bool IsGigyaUser(this Sitecore.Security.Accounts.User user)
        {
            return (user.IsAuthenticated && user.GetDomainName().Equals("gigya", StringComparison.OrdinalIgnoreCase));
        }
    }
}
