using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore;
using Sitecore.Caching;
using Sitecore.Diagnostics;
using Sitecore.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	public class GigyaUser : ICacheable
	{
		private DataLengthChangedDelegate _dataLengthChanged;

		public event DataLengthChangedDelegate DataLengthChanged
		{
			add
			{
				this._dataLengthChanged = (DataLengthChangedDelegate)Delegate.Combine(this._dataLengthChanged, value);
			}
			remove
			{
				this._dataLengthChanged = (DataLengthChangedDelegate)Delegate.Remove(this._dataLengthChanged, value);
			}
		}

		public bool Cacheable
		{
			get;
			set;
		}

		public bool Immutable
		{
			get
			{
				return false;
			}
		}

		public string UID
		{
			get;
			protected set;
		}

		public string UIDDignature
		{
			get;
			protected set;
		}

		public DateTime LastLoginDate
		{
			get;
			protected set;
		}

		public DateTime OldestDataUpdated
		{
			get;
			protected set;
		}

		public DateTime LastUpdatedDate
		{
			get;
			protected set;
		}

		public DateTime CreatedDate
		{
			get;
			protected set;
		}

		public string Username
		{
			get;
			set;
		}

		public string Email
		{
			get;
			protected set;
		}

		public Dictionary<string, object> Profile
		{
			get;
			protected set;
		}

		public long GetDataLength()
		{
			return (long)(TypeUtil.SizeOfString(this.UID) + TypeUtil.SizeOfString(this.UIDDignature) + TypeUtil.SizeOfString(this.Username) + TypeUtil.SizeOfString(this.Email) + 8 + 8 + 8 + this.Profile.Sum((KeyValuePair<string, object> property) => TypeUtil.SizeOfString(StringUtil.GetString(property.Value, string.Empty))));
		}

		protected void InvokeDatalengthChanged()
		{
			if (this._dataLengthChanged != null)
			{
				this._dataLengthChanged.Invoke(this);
			}
		}

		public GigyaUser(string uid, string uidSignature, string socialProviders, DateTime lastLoginDate, DateTime oldestDataUpdated, DateTime lastUpdatedDate, DateTime createdDate, Dictionary<string, object> profileProperties, Dictionary<string, object> customProfileProperties)
		{
			Assert.IsNotNullOrEmpty(uid, "uid can not be null");
			this.UID = uid;
			this.UIDDignature = uidSignature;
			this.LastLoginDate = lastLoginDate;
			this.OldestDataUpdated = oldestDataUpdated;
			this.LastUpdatedDate = lastUpdatedDate;
			this.CreatedDate = createdDate;
			this.Profile = profileProperties;
			if (this.Profile == null)
			{
				this.Profile = new Dictionary<string, object>();
			}
			if (customProfileProperties != null && customProfileProperties.Any<KeyValuePair<string, object>>())
			{
				foreach (KeyValuePair<string, object> current in customProfileProperties)
				{
					if (!this.Profile.ContainsKey(current.Key))
					{
						this.Profile.Add(string.Format("{0}{1}", GigyaSettings.CustomPropertyNamePrefix, current.Key), current.Value);
					}
				}
			}
			if (!this.Profile.ContainsKey("fullname"))
			{
				StringBuilder stringBuilder = new StringBuilder();
				if (this.Profile.ContainsKey("firstName"))
				{
					stringBuilder.Append(StringUtil.GetString(this.Profile["firstName"], string.Empty));
				}
				if (this.Profile.ContainsKey("lastName"))
				{
					stringBuilder.AppendFormat(" {0}", StringUtil.GetString(this.Profile["lastName"], string.Empty));
				}
				this.Profile.Add("fullname", stringBuilder.ToString().Trim());
			}
			if (!this.Profile.ContainsKey("socialProviders"))
			{
				this.Profile.Add("socialProviders", StringUtil.GetString(new string[]
				{
					socialProviders,
					string.Empty
				}));
			}
			this.Email = (this.Profile.ContainsKey("email") ? this.Profile["email"].ToString() : string.Empty);
			this.Username = StringUtil.GetString(new string[]
			{
				this.Profile.ContainsKey("username") ? this.Profile["username"].ToString() : string.Empty,
				this.Email,
				this.UID
			});
			this.Cacheable = true;
		}

		public void ReloadUser()
		{
			this.InvokeDatalengthChanged();
		}
	}
}
