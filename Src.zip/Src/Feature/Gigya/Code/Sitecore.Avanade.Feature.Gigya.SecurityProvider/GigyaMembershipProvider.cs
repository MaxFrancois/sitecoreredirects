using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Repository;
using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore;
using Sitecore.Diagnostics;
using System;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Web.Security;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	public class GigyaMembershipProvider : MembershipProvider
	{
		private bool _enablePasswordReset;

		private bool _initialized;

		private int _maxInvalidPasswordAttempts;

		private int _minRequiredNonalphanumericCharacters;

		private int _minRequiredPasswordLength;

		private int _passwordAttemptWindow;

		private string _passwordStrengthRegularExpression;

		private bool _requiresQuestionAndAnswer;

		private bool _requiresUniqueEmail;

		private bool _enablePasswordRetrieval;

        private bool _adminEnabled;

		public override string ApplicationName
		{
			get;
			set;
		}

		public override int MaxInvalidPasswordAttempts
		{
			get
			{
				return this._maxInvalidPasswordAttempts;
			}
		}

		public override int MinRequiredNonAlphanumericCharacters
		{
			get
			{
				return this._minRequiredNonalphanumericCharacters;
			}
		}

		public override int MinRequiredPasswordLength
		{
			get
			{
				return this._minRequiredPasswordLength;
			}
		}

		public override int PasswordAttemptWindow
		{
			get
			{
				return this._passwordAttemptWindow;
			}
		}

		public override MembershipPasswordFormat PasswordFormat
		{
			get
			{
				return MembershipPasswordFormat.Hashed;
			}
		}

		public override string PasswordStrengthRegularExpression
		{
			get
			{
				return this._passwordStrengthRegularExpression;
			}
		}

		public override bool RequiresQuestionAndAnswer
		{
			get
			{
				return this._requiresQuestionAndAnswer;
			}
		}

		public override bool RequiresUniqueEmail
		{
			get
			{
				return this._requiresUniqueEmail;
			}
		}

		public override bool EnablePasswordReset
		{
			get
			{
				return this._enablePasswordReset;
			}
		}

		public override bool EnablePasswordRetrieval
		{
			get
			{
				return this._enablePasswordRetrieval;
			}
		}

        public bool AdminEnabled
        {
            get
            {
                return this._adminEnabled;
            }
        }

		public override void Initialize(string name, NameValueCollection config)
		{
			Profiler.StartOperation("initializing gigya membership provider");
			base.Initialize(name, config);
			try
			{
				//Error.AssertNotNull(GigyaSettings.APIKeyCollection, "Gigya API key not specified");
				Error.AssertNotNull(GigyaSettings.SecretKey, "Gigya Secret key not specified");
				this.ApplicationName = config.Get("applicationName");
				this._enablePasswordReset = MainUtil.GetBool(config.Get("enablePasswordReset"), false);
				this._maxInvalidPasswordAttempts = MainUtil.GetInt(config.Get("maxInvalidPasswordAttempts"), 5);
				this._minRequiredNonalphanumericCharacters = MainUtil.GetInt(config.Get("minRequiredNonalphanumericCharacters"), 1);
				this._minRequiredPasswordLength = MainUtil.GetInt(config.Get("minRequiredPasswordLength"), 1);
				this._passwordAttemptWindow = MainUtil.GetInt(config.Get("passwordAttemptWindow"), 10);
				this._passwordStrengthRegularExpression = StringUtil.GetString(new string[]
				{
					config.Get("passwordStrengthRegularExpression"),
					string.Empty
				});
				this._requiresQuestionAndAnswer = MainUtil.GetBool(config.Get("requiresQuestionAndAnswer"), false);
				this._requiresUniqueEmail = MainUtil.GetBool(config.Get("requiresUniqueEmail"), false);
				this._enablePasswordRetrieval = MainUtil.GetBool(config.Get("enablePasswordRetrieval"), false);
				this._initialized = true;
                this._adminEnabled = GigyaSettings.GigyaAdminUserManager;
			}
			catch (Exception ex)
			{
				this._initialized = false;
				Log.Error("could not initialize gigya provider", ex, this);
			}
			Profiler.EndOperation();
		}

		public override bool ValidateUser(string username, string password)
		{
			return this._initialized && UserRepository.ValidateUser(username, password);
		}

		public override MembershipUser GetUser(string username, bool userIsOnline)
		{
			if (!this._initialized)
			{
				return null;
			}
			if (string.IsNullOrEmpty(username) || username.Contains("\\"))
			{
				return null;
			}
			GigyaUser user = UserRepository.GetUser(username, userIsOnline);
			if (user == null)
			{
				return null;
			}
			return new GigyaMembershipUser(this.Name, user);
		}

		public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
		{
			if (!this._initialized || providerUserKey == null)
			{
				return null;
			}
			GigyaUser userByUID = UserRepository.GetUserByUID(providerUserKey.ToString());
			if (userByUID == null)
			{
				return null;
			}
			return new GigyaMembershipUser(this.Name, userByUID);
		}

		public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
            if (!this._initialized || !this._adminEnabled)
			{
				totalRecords = 0;
				return new MembershipUserCollection();
			}
			MembershipUserCollection users = new MembershipUserCollection();
			UserRepository.FindUsersByEmail(emailToMatch, pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (user != null)
				{
					users.Add(new GigyaMembershipUser(this.Name, user));
				}
			});
			return users;
		}

		public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
            if (!this._initialized || !this._adminEnabled)
			{
				totalRecords = 0;
				return new MembershipUserCollection();
			}
			MembershipUserCollection users = new MembershipUserCollection();
			UserRepository.FindUsersByName(usernameToMatch, pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (user != null)
				{
					users.Add(new GigyaMembershipUser(this.Name, user));
				}
			});
			return users;
		}

		public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
		{
            if (!this._initialized || !this._adminEnabled)
			{
				totalRecords = 0;
				return new MembershipUserCollection();
			}
			MembershipUserCollection users = new MembershipUserCollection();
			UserRepository.GetAllUsers(pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (user != null)
				{
					GigyaMembershipUser gigyaMembershipUser = new GigyaMembershipUser(this.Name, user);
					if (gigyaMembershipUser != null && users[gigyaMembershipUser.UserName] == null)
					{
						users.Add(gigyaMembershipUser);
					}
				}
			});
			return users;
		}

		public override string GetUserNameByEmail(string email)
		{
			if (!this._initialized || !this._adminEnabled)
			{
				return null;
			}
			return UserRepository.GetUserNameByEmail(email);
		}

		public override bool ChangePassword(string username, string oldPassword, string newPassword)
		{
			throw new NotImplementedException();
		}

		public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
		{
			throw new NotImplementedException();
		}

		public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
		{
			if (!this.ValidatePassword(password))
			{
				status = MembershipCreateStatus.InvalidPassword;
				return null;
			}
			string empty = string.Empty;
			GigyaUser gigyaUser = UserRepository.RegisterUser(username, password, email, passwordQuestion, passwordAnswer, out empty);
			if (gigyaUser != null)
			{
				status = MembershipCreateStatus.Success;
				return new GigyaMembershipUser(this.Name, gigyaUser);
			}
			status = MembershipCreateStatus.ProviderError;
			return null;
		}

		public override bool DeleteUser(string username, bool deleteAllRelatedData)
		{
			string empty = string.Empty;
			return UserRepository.DeleteUser(username, out empty);
		}

		public override int GetNumberOfUsersOnline()
		{
			throw new NotImplementedException();
		}

		public override string GetPassword(string username, string answer)
		{
			throw new NotImplementedException();
		}

		public override string ResetPassword(string username, string answer)
		{
			throw new NotImplementedException();
		}

		public override bool UnlockUser(string userName)
		{
			throw new NotImplementedException();
		}

		public override void UpdateUser(MembershipUser user)
		{
		}

		private bool ValidatePassword(string password)
		{
			return !string.IsNullOrEmpty(password) && password.Length >= this.MinRequiredPasswordLength && Regex.IsMatch(password, this.PasswordStrengthRegularExpression);
		}
	}
}
