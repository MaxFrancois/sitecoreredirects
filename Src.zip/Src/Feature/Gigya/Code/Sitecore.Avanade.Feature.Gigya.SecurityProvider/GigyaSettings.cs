using Sitecore;
using Sitecore.Configuration;
using Sitecore.Text;
using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Web;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils
{
    public class GigyaSettings
    {
        private static NameValueCollection _apiKeyCollection;

        public static NameValueCollection APIKeyCollection
        {
            get
            {
                if (GigyaSettings._apiKeyCollection == null)
                {
                    GigyaSettings._apiKeyCollection = (NameValueCollection)ConfigurationManager.GetSection("gigyaAPIKeyCollection");
                }
                return GigyaSettings._apiKeyCollection;
            }
        }
        public static bool GigyaAdminUserManager
        {
            get
            {
                return Settings.GetBoolSetting("Gigya.Admin.UserManager", true);
            }
        }



        public static bool GigyaValidateSignature
        {
            get
            {
                return Settings.GetBoolSetting("Gigya.ValidateSignature", false);
            }
        }

        public static bool GigyaHttps
        {
            get
            {
                return Settings.GetBoolSetting("Gigya.UseHTTPs", false);
            }
        }

        public static string SecretKey
        {
            get
            {
                return Settings.GetAppSetting("Gigya.SecretKey", string.Empty);
            }
        }

        public static string GigyaDataCenter
        {
            get
            {
                return Settings.GetAppSetting("Gigya.DataCenter", string.Empty);
            }
        }

        public static int GigyaSearchTimeoutMilliSeconds
        {
            get
            {
                string appSetting = Settings.GetAppSetting("Gigya.SearchTimeoutInSeconds", "60");
                return int.Parse(appSetting) * 1000;
            }
        }

        public static string GigyaJSUrl
        {
            get
            {
                string text = Settings.GetAppSetting("Gigya.JSUrl", "http://cdn.gigya.com/JS/socialize.js");
                if (HttpContext.Current.Request != null && HttpContext.Current.Request.IsSecureConnection)
                {
                    text = text.Replace("http:", "https:").Replace("cdn.", "cdns.");
                }
                else
                {
                    text = text.Replace("https:", "http:").Replace("cdns.", "cdn.");
                }
                return text;
            }
        }

        public static string GigyaUserCacheName
        {
            get
            {
                return Settings.GetSetting("Gigya.User.CacheName", "GUserCache");
            }
        }

        public static long GigyaUserCacheLength
        {
            get
            {
                return StringUtil.ParseSizeString(Settings.GetSetting("Gigya.User.CacheLength", "25MB"));
            }
        }

        public static TimeSpan GigyaUserCacheDuration
        {
            get
            {
                return Settings.GetTimeSpanSetting("Gigya.User.CacheDuration", TimeSpan.FromMinutes(20.0));
            }
        }

        public static string GigyaUserDomainName
        {
            get
            {
                return Settings.GetSetting("Gigya.User.DomainName", "gigya");
            }
        }

        public static string CustomPropertyNamePrefix
        {
            get
            {
                return Settings.GetSetting("Gigya.CustomPropertyNamePrefix", "d_");
            }
        }

        public static ListString GigyaDynamicFields
        {
            get
            {
                return new ListString(Settings.GetSetting("Gigya.DynamicFields", "Age|SocialProviders|FullName").ToLowerInvariant());
            }
        }

        /// <summary>
        /// The Gigya API Settings Formatter
        /// </summary>
        public static string GigyaSiteApiKeyFormatter
        {
            get
            {
                return Settings.GetSetting("Gigya.Site.ApiKey.Formatter", "");
            }
        }

        public static bool GigyaSiteApiKeySitecoreSetting
        {
            get
            {
                return Settings.GetBoolSetting("Gigya.Site.ApiKey.SitecoreSetting", true);
            }
        }

        public static string GetGigyaApiKeyForSite()
        {
            string siteName = Context.GetSiteName();
            return GigyaSettings.GetGigyaApiKeyForSite(siteName);
        }

        /*public static string GetGigyaApiKeyForSite(string siteName)
        {
            return StringUtil.GetString(new string[]
            {
                GigyaSettings.APIKeyCollection[siteName],
                GigyaSettings.APIKeyCollection["default"],
                ""
            });
        }*/
        public static string GetGigyaApiKeyForSite(string siteName)
        {
            if (string.IsNullOrEmpty(siteName))
            {
                return "";
            }

            // eg: Cricket.Sc.{0}.Gigya.ApiKey
            if (string.IsNullOrEmpty(GigyaSiteApiKeyFormatter))
            {
                return StringUtil.GetString(new string[]
			    {
				    GigyaSettings.APIKeyCollection[siteName],
				    GigyaSettings.APIKeyCollection["default"],
				    ""
			    });
            }

            // Get the key formmater
            string settingsKey = string.Format(GigyaSiteApiKeyFormatter, siteName);

            // are we working on the Sitecore Settings or AppSettings
            if (!GigyaSiteApiKeySitecoreSetting)
            {
                // Get the data from the app settings
                return Settings.GetAppSetting(settingsKey);
            }

            // get the sitecore setting
            return Settings.GetSetting(settingsKey);
        }
    }
}
