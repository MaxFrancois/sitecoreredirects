using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Rules
{
	public class ProfileValueCondition<T> : TrueCondition<T> where T : RuleContext
	{
		public string ProfileField
		{
			get;
			set;
		}

		public string Value
		{
			get;
			set;
		}

		protected override bool Execute(T ruleContext)
		{
			Assert.ArgumentNotNull(ruleContext, "ruleContext");
			if (ruleContext.Item == null)
			{
				return false;
			}
			if (string.IsNullOrEmpty(this.ProfileField) || Context.User == null)
			{
				return false;
			}
			if (this.Value == null)
			{
				string arg_4C_0 = string.Empty;
			}
            return !string.IsNullOrEmpty(Context.User.Profile[this.ProfileField]) && Context.User.Profile[this.ProfileField].Equals(this.Value, StringComparison.InvariantCultureIgnoreCase);
		}
	}
}
