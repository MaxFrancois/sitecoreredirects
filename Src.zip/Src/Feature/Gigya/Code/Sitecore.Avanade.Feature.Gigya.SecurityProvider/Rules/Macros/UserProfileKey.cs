using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore;
using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Globalization;
using Sitecore.Rules.RuleMacros;
using Sitecore.Security.Domains;
using Sitecore.SecurityModel;
using Sitecore.Shell.Applications.Dialogs.ItemLister;
using Sitecore.Text;
using Sitecore.Web.UI.Sheer;
using System;
using System.Xml.Linq;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Rules.Macros
{
	public class UserProfileKey : IRuleMacro
	{
		public void Execute(XElement element, string name, UrlString parameters, string value)
		{
			Assert.ArgumentNotNull(element, "element");
			Assert.ArgumentNotNull(name, "name");
			Assert.ArgumentNotNull(parameters, "parameters");
			Assert.ArgumentNotNull(value, "value");
			Domain domain = DomainManager.GetDomain(GigyaSettings.GigyaUserDomainName);
			Assert.IsNotNull(domain, "could not find gigya domain");
            Assert.IsNotNullOrEmpty(domain.DefaultProfileItemID, "no profile item id is specified");

			ID @null = ID.Null;
			ID.TryParse(domain.DefaultProfileItemID, out @null);

			Assert.IsFalse(ID.IsNullOrEmpty(@null), "could not parse id");
			SelectItemOptions selectItemOptions = new SelectItemOptions();
			using (new SecurityDisabler())
			{
				Database database = Factory.GetDatabase(Settings.ProfileItemDatabase);
				if (database != null)
				{
					Item item = database.GetItem(@null);
					Assert.IsNotNull(item, "could not find profile item");
					selectItemOptions.Root = item.Template;
					
                    selectItemOptions.IncludeTemplatesForSelection = SelectItemOptions.GetTemplateList(new string[]
					{
						TemplateIDs.TemplateField.ToString()
					});
					
                    selectItemOptions.Title = Translate.Text("Select Profile Field");
					selectItemOptions.Text = Translate.Text("Select the field item to use in this rule.");
					selectItemOptions.Icon = Translate.Text("People/16x16/cube_blue.png");
                    selectItemOptions.ResultType = SelectItemOptions.DialogResultType.Name;

					SheerResponse.ShowModalDialog(selectItemOptions.ToUrlString().ToString(), true);
				}
			}
		}
	}
}
