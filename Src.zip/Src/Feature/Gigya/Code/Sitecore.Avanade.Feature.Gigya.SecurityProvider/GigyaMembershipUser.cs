using System;
using System.Web.Security;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	public class GigyaMembershipUser : MembershipUser
	{
		public GigyaMembershipUser(string providerName, GigyaUser user) : base(providerName, user.Username, user.UID, user.Email, string.Empty, string.Empty, true, false, user.CreatedDate, user.LastLoginDate, DateTime.MinValue, DateTime.MinValue, DateTime.MinValue)
		{
		}
	}
}
