using Sitecore.Caching;
using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Caching
{
	internal class GigyaCache : CustomCache
	{
		protected TimeSpan LifeSpan
		{
			get;
			private set;
		}

		public GigyaCache(string name, long maxSize, TimeSpan lifespan) : base(name, maxSize)
		{
			this.LifeSpan = lifespan;
			base.InnerCache.Scavengable = true;
		}

		public void Add(string key, ICacheable item)
		{
			if (!base.InnerCache.Enabled)
			{
				return;
			}
			if (string.IsNullOrEmpty(key))
			{
				return;
			}
			DateTime dateTime = DateTime.UtcNow.Add(this.LifeSpan);
            #if Sitecore82
            base.InnerCache.Add(key, item, dateTime);
            # else
            base.InnerCache.Add(key, item, item.GetDataLength(), dateTime);
            #endif
        }

		public ICacheable Get(string key)
		{
            if (!base.InnerCache.Enabled)
			{
				return null;
			}
			if (string.IsNullOrEmpty(key))
			{
				return null;
			}
			object obj = base.InnerCache[key];
			if (obj != null)
			{
				return obj as ICacheable;
			}
			return null;
		}

		public bool Contains(string key)
		{
            return base.InnerCache.Enabled && !string.IsNullOrEmpty(key) && base.InnerCache.ContainsKey(key);
		}

		public void Remove(string key)
		{
            if (!base.InnerCache.Enabled)
			{
				return;
			}
			if (string.IsNullOrEmpty(key))
			{
				return;
			}
            object obj = base.InnerCache[key];
			if (obj != null)
			{
                base.InnerCache.Remove(key);
			}
		}
	}
}
