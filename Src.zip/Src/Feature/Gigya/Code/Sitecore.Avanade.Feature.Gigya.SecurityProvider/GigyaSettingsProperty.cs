using System;
using System.Configuration;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	internal class GigyaSettingsProperty : SettingsProperty
	{
		public string PropertyName
		{
			get;
			private set;
		}

		public string PropertyTypeName
		{
			get;
			private set;
		}

		public int Size
		{
			get
			{
				return 0;
			}
		}

		public GigyaSettingsProperty(string propertyName, string propertyTypeName, SettingsProperty property) : base(property)
		{
			this.PropertyName = propertyName;
			this.PropertyTypeName = propertyTypeName;
		}
	}
}
