using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Repository;
using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.Globalization;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Web.Configuration;
using System.Web.Profile;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	public class GigyaProfileProvider : ProfileProvider
	{
		private bool _initialized;

		private Dictionary<string, string> propertyNames;

		public override string ApplicationName
		{
			get;
			set;
		}

		public bool ReadOnly
		{
			get;
			private set;
		}

		public override void Initialize(string name, NameValueCollection config)
		{
			Profiler.StartOperation("initializing gigya profile provider");
			base.Initialize(name, config);
			try
			{
				//Error.AssertNotNull(GigyaSettings.APIKeyCollection, "Gigya API key not specified");
				Error.AssertNotNull(GigyaSettings.SecretKey, "Gigya Secret key not specified");
				this.ApplicationName = config.Get("applicationName");
				this.ReadOnly = (StringUtil.GetString(new string[]
				{
					config.Get("readOnly"),
					"true"
				}) == "true");
				this.SetupCustomPropertyNames();
				this._initialized = true;
			}
			catch (Exception ex)
			{
				this._initialized = false;
				Log.Error("could not initialize gigya profile provider", ex, this);
			}
			Profiler.EndOperation();
		}

		private void SetupCustomPropertyNames()
		{
			this.propertyNames = new Dictionary<string, string>();
            System.Web.Configuration.ProfileSection profileSection = (System.Web.Configuration.ProfileSection)WebConfigurationManager.OpenWebConfiguration("/aspnet").GetSection("system.web/profile");
			foreach (ProfilePropertySettings profilePropertySettings in profileSection.PropertySettings)
			{
				string text = profilePropertySettings.CustomProviderData.Trim();
				if (this.IsGigyaProperty(text))
				{
					string type = profilePropertySettings.Type;
					string[] array = text.Trim().Split(new char[]
					{
						'|'
					}, StringSplitOptions.RemoveEmptyEntries);
					string text2;
					if (array.Length >= 2 && !string.IsNullOrEmpty(text2 = array[1]))
					{
						text2 = text2.Trim();
						if (!this.propertyNames.ContainsKey(text2))
						{
							this.propertyNames.Add(text2, type);
						}
					}
				}
			}
		}

		private bool HasProfile(string userName)
		{
			return this._initialized && ProfileRepository.GetUserProperties(userName, this.propertyNames.Keys.ToArray<string>()).Any<KeyValuePair<string, object>>();
		}

		public override int DeleteInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
		{
			throw new NotImplementedException();
		}

		public override int DeleteProfiles(string[] usernames)
		{
			throw new NotImplementedException();
		}

		public override int DeleteProfiles(ProfileInfoCollection profiles)
		{
			throw new NotImplementedException();
		}

		public override ProfileInfoCollection FindInactiveProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			if (!this._initialized)
			{
				return new ProfileInfoCollection();
			}
			ProfileInfoCollection profileCollection = new ProfileInfoCollection();
			this.FindProfilesByUserName(authenticationOption, usernameToMatch, pageIndex, pageSize, out totalRecords).OfType<ProfileInfo>().ToList<ProfileInfo>().ForEach(delegate(ProfileInfo profile)
			{
				if (profile.LastActivityDate < userInactiveSinceDate)
				{
					profileCollection.Add(profile);
				}
			});
			return profileCollection;
		}

		public override ProfileInfoCollection FindProfilesByUserName(ProfileAuthenticationOption authenticationOption, string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			if (!this._initialized)
			{
				return new ProfileInfoCollection();
			}
			ProfileInfoCollection profileCollection = new ProfileInfoCollection();
			UserRepository.FindUsersByName(usernameToMatch, pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (this.HasProfile(usernameToMatch))
				{
					profileCollection.Add(new ProfileInfo(usernameToMatch, false, user.LastLoginDate, user.LastUpdatedDate, 0));
				}
			});
			return profileCollection;
		}

		public override ProfileInfoCollection GetAllInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			if (!this._initialized)
			{
				return new ProfileInfoCollection();
			}
			ProfileInfoCollection profileCollection = new ProfileInfoCollection();
			UserRepository.GetAllUsers(pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (this.HasProfile(user.Username) && user.LastLoginDate < userInactiveSinceDate)
				{
					profileCollection.Add(new ProfileInfo(user.Username, false, user.LastLoginDate, user.LastUpdatedDate, 0));
				}
			});
			return profileCollection;
		}

		public override ProfileInfoCollection GetAllProfiles(ProfileAuthenticationOption authenticationOption, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			if (!this._initialized)
			{
				return new ProfileInfoCollection();
			}
			ProfileInfoCollection profileCollection = new ProfileInfoCollection();
			UserRepository.GetAllUsers(pageIndex, pageSize, out totalRecords).ForEach(delegate(GigyaUser user)
			{
				if (this.HasProfile(user.Username))
				{
					profileCollection.Add(new ProfileInfo(user.Username, false, user.LastLoginDate, user.LastUpdatedDate, 0));
				}
			});
			return profileCollection;
		}

		public override int GetNumberOfInactiveProfiles(ProfileAuthenticationOption authenticationOption, DateTime userInactiveSinceDate)
		{
			int num = 0;
			if (!this._initialized)
			{
				return 0;
			}
			return this.GetAllInactiveProfiles(authenticationOption, userInactiveSinceDate, 1, 2147483647, out num).Count;
		}

		public override SettingsPropertyValueCollection GetPropertyValues(SettingsContext context, SettingsPropertyCollection collection)
		{
			if (!this._initialized)
			{
				return new SettingsPropertyValueCollection();
			}
			SettingsPropertyValueCollection settingsPropertyValueCollection = new SettingsPropertyValueCollection();
			string text = (string)context["UserName"];
			if (!string.IsNullOrEmpty(text) && !text.Contains("\\"))
			{
				List<string> list = new List<string>();
				SettingsPropertyCollection relevantProperties = this.GetRelevantProperties(collection);
				if (relevantProperties.Count == 0)
				{
					return settingsPropertyValueCollection;
				}
				list.AddRange(from SettingsProperty p in relevantProperties
				select (p as GigyaSettingsProperty).PropertyName);
				Dictionary<string, object> userProperties = ProfileRepository.GetUserProperties(text, list.ToArray());
				foreach (GigyaSettingsProperty gigyaSettingsProperty in relevantProperties)
				{
					if (collection[gigyaSettingsProperty.PropertyName] != null)
					{
						SettingsPropertyValue settingsPropertyValue = new SettingsPropertyValue(collection[gigyaSettingsProperty.PropertyName]);
						collection.Remove(gigyaSettingsProperty.PropertyName);
						settingsPropertyValue.IsDirty = false;
						settingsPropertyValue.PropertyValue = (userProperties.ContainsKey(gigyaSettingsProperty.PropertyName) ? userProperties[gigyaSettingsProperty.PropertyName] : string.Empty);
						settingsPropertyValueCollection.Add(settingsPropertyValue);
					}
				}
			}
			return settingsPropertyValueCollection;
		}

		public override void SetPropertyValues(SettingsContext context, SettingsPropertyValueCollection collection)
		{
			if (!this._initialized)
			{
				return;
			}
			string text = (string)context["UserName"];
			if (!string.IsNullOrEmpty(text) && !text.Contains("\\"))
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				foreach (SettingsPropertyValue settingsPropertyValue in collection)
				{
					string @string = StringUtil.GetString(settingsPropertyValue.PropertyValue, string.Empty);
					GigyaSettingsProperty gigyaSettingsProperty;
					if (settingsPropertyValue.IsDirty && !string.IsNullOrEmpty(@string) && this.IsGigyaProperty(settingsPropertyValue.Property) && !GigyaSettings.GigyaDynamicFields.Contains(settingsPropertyValue.Name.ToLowerInvariant()) && this.TryParseGigyaProperty(settingsPropertyValue.Property, out gigyaSettingsProperty))
					{
						dictionary.Add(gigyaSettingsProperty.PropertyName, settingsPropertyValue.PropertyValue);
					}
				}
				if (dictionary.Any<KeyValuePair<string, object>>() && !ProfileRepository.SetUserProperties(text, dictionary))
				{
					throw new Exception(Translate.Text("Could not update user profile on Gigya, contact your admin for support"));
				}
			}
		}

		protected virtual SettingsPropertyCollection GetRelevantProperties(SettingsPropertyCollection allProperties)
		{
			SettingsPropertyCollection settingsPropertyCollection = new SettingsPropertyCollection();
			foreach (SettingsProperty property in allProperties)
			{
				GigyaSettingsProperty property2;
				if (this.TryParseGigyaProperty(property, out property2))
				{
					settingsPropertyCollection.Add(property2);
				}
			}
			return settingsPropertyCollection;
		}

		private bool TryParseGigyaProperty(SettingsProperty property, out GigyaSettingsProperty gigyaProperty)
		{
			string customProviderData = (string)property.Attributes["CustomProviderData"];
			if (this.IsGigyaProperty(customProviderData))
			{
				string text;
				string text2;
				this.ParseCustomProviderData(customProviderData, out text, out text2);
				if (!string.IsNullOrEmpty(text) && !string.IsNullOrEmpty(text2))
				{
					gigyaProperty = new GigyaSettingsProperty(text, text2, property);
					return true;
				}
			}
			if (property.Name == "FullName")
			{
				gigyaProperty = new GigyaSettingsProperty("fullname", "String", property);
				return true;
			}
			if (property.Name == "SocialProviders")
			{
				gigyaProperty = new GigyaSettingsProperty("socialProviders", "String", property);
				return true;
			}
			if (property.Name == "Email")
			{
				gigyaProperty = new GigyaSettingsProperty("email", "String", property);
				return true;
			}
			gigyaProperty = null;
			return false;
		}

		private bool IsGigyaProperty(SettingsProperty property)
		{
			string customProviderData = (string)property.Attributes["CustomProviderData"];
			return this.IsGigyaProperty(customProviderData);
		}

		private bool IsGigyaProperty(string customProviderData)
		{
			return !string.IsNullOrEmpty(customProviderData) && customProviderData.StartsWith(string.Format("{0}|", GigyaSettings.GigyaUserDomainName));
		}

		private void ParseCustomProviderData(string customProviderData, out string propertyName, out string propertyType)
		{
			Assert.IsNotNullOrEmpty(customProviderData, "customProviderData can't be null or empty.");
			propertyName = string.Empty;
			propertyType = string.Empty;
			string[] array = customProviderData.Trim().Split(new char[]
			{
				'|'
			}, StringSplitOptions.RemoveEmptyEntries);
			if (array.Length >= 2 && array[0].Equals(GigyaSettings.GigyaUserDomainName, StringComparison.InvariantCultureIgnoreCase))
			{
				propertyName = array[1].Trim();
				if (!string.IsNullOrEmpty(propertyName))
				{
					propertyType = this.propertyNames[propertyName];
				}
			}
		}
	}
}
