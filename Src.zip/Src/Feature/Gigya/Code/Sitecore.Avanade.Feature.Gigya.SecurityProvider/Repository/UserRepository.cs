using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Caching;
using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore.Diagnostics;
using Sitecore.StringExtensions;
using System;
using System.Collections.Generic;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Repository
{
	internal class UserRepository
	{
		private static readonly GigyaCache _userCache;

		static UserRepository()
		{
			UserRepository._userCache = new GigyaCache(GigyaSettings.GigyaUserCacheName, GigyaSettings.GigyaUserCacheLength, GigyaSettings.GigyaUserCacheDuration);
		}

		public static bool ValidateUser(string username, string password)
		{
			return GigyaApiHelper.Login(username, password);
		}

		public static GigyaUser GetUser(string username, bool userIsOnline)
		{
			Assert.ArgumentNotNull(username, "userName");
			Log.Debug("GetUser({0}). Started.".FormatWith(new object[]
			{
				username
			}), new object());
			GigyaUser gigyaUser = (GigyaUser)UserRepository._userCache.Get(username);
			if (gigyaUser != null)
			{
				Log.Debug("GetUser({0}). Finished (retrieved user from cache).".FormatWith(new object[]
				{
					username
				}), new object());
				return gigyaUser;
			}
			GigyaUser arg_7B_0;
			if ((arg_7B_0 = GigyaApiHelper.GetUserByUID(username)) == null)
			{
				arg_7B_0 = (GigyaApiHelper.GetUserByName(username) ?? GigyaApiHelper.GetUserByEmail(username));
			}
			gigyaUser = arg_7B_0;
			if (gigyaUser != null)
			{
                Log.Debug("GetUser({0}). Retrieved user from Gigya.".FormatWith(new object[]
				{
					username
				}), new object());
				UserRepository.AddUserToCache(gigyaUser);
			}
			Log.Debug("GetUser({0}). Finished.".FormatWith(new object[]
			{
				username
			}), new object());
			return gigyaUser;
		}

		public static GigyaUser GetUserByUID(string uid)
		{
			Assert.ArgumentNotNull(uid, "uid");
			Log.Debug("GetUserByUID({0}). Started.".FormatWith(new object[]
			{
				uid
			}), new object());
			GigyaUser gigyaUser = (GigyaUser)UserRepository._userCache.Get(uid);
			if (gigyaUser != null)
			{
                Log.Debug("GetUserByUID({0}). Finished (retrieved user from cache).".FormatWith(new object[]
				{
					uid
				}), new object());
				return gigyaUser;
			}
			gigyaUser = GigyaApiHelper.GetUserByUID(uid);
			if (gigyaUser != null)
			{
                Log.Debug("GetUserByUID({0}). Retrieved user from Gigya.".FormatWith(new object[]
				{
					uid
				}), new object());
				UserRepository.AddUserToCache(gigyaUser);
			}
			Log.Debug("GetUserByUID({0}). Finished.".FormatWith(new object[]
			{
				uid
			}), new object());
			return gigyaUser;
		}

		public static string GetUserNameByEmail(string email)
		{
			Assert.ArgumentNotNull(email, "email");
			Log.Debug("GetUserNameByEmail({0}). Started.".FormatWith(new object[]
			{
				email
			}), new object());
			GigyaUser gigyaUser = (GigyaUser)UserRepository._userCache.Get(email);
			if (gigyaUser != null)
			{
				Log.Debug("GetUserNameByEmail({0}). Finished (retrieved user from cache).".FormatWith(new object[]
				{
					email
				}), new object());
				return gigyaUser.Username;
			}
			gigyaUser = GigyaApiHelper.GetUserByEmail(email);
			if (gigyaUser != null)
			{
				Log.Debug("GetUserNameByEmail({0}). Retrieved user from Gigya.".FormatWith(new object[]
				{
					email
				}), new object());
				UserRepository.AddUserToCache(gigyaUser);

                return gigyaUser.Username;

            }
			Log.Debug("GetUserNameByEmail({0}). Finished.".FormatWith(new object[]
			{
				email
			}), new object());
			return string.Empty;
		}

		public static GigyaUser GetUserByEmail(string email)
		{
			Assert.ArgumentNotNull(email, "userName");
			Log.Debug("GetUserByEmail({0}). Started.".FormatWith(new object[]
			{
				email
			}), new object());
			GigyaUser gigyaUser = (GigyaUser)UserRepository._userCache.Get(email);
			if (gigyaUser != null)
			{
                Log.Debug("GetUserByEmail({0}). Finished (retrieved user from cache).".FormatWith(new object[]
				{
					email
				}), new object());
				return gigyaUser;
			}
			gigyaUser = GigyaApiHelper.GetUserByEmail(email);
			if (gigyaUser != null)
			{
				Log.Debug("GetUserByEmail({0}). Retrieved user from Gigya.".FormatWith(new object[]
				{
					email
				}), new object());
				UserRepository.AddUserToCache(gigyaUser);
			}
            Log.Debug("GetUserByEmail({0}). Finished.".FormatWith(new object[]
			{
				email
			}), new object());
			return gigyaUser;
		}

		public static List<GigyaUser> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			Assert.ArgumentNotNull(usernameToMatch, "userName");
			Log.Debug("FindUsersByName({0}, {1}, {2}). Started.".FormatWith(new object[]
			{
				usernameToMatch,
				pageIndex,
				pageSize
			}), new object());
			List<GigyaUser> list = GigyaApiHelper.FindUsersByName(usernameToMatch, pageIndex, pageSize, out totalRecords);
			Log.Debug("FindUsersByName({0}, {1}, {2}). Retrieved {3} user(s) from Gigya.".FormatWith(new object[]
			{
				usernameToMatch,
				pageIndex,
				pageSize,
				list.Count
			}), new object());
			list.ForEach(delegate(GigyaUser user)
			{
				UserRepository.AddUserToCache(user);
			});
			Log.Debug("FindUsersByName({0}, {1}, {2}). Finished.".FormatWith(new object[]
			{
				usernameToMatch,
				pageIndex,
				pageSize
			}), new object());
			return list;
		}

		public static List<GigyaUser> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			Assert.ArgumentNotNull(emailToMatch, "userName");
			Log.Debug("FindUsersByEmail({0}, {1}, {2}). Started.".FormatWith(new object[]
			{
				emailToMatch,
				pageIndex,
				pageSize
			}), new object());
			List<GigyaUser> list = GigyaApiHelper.FindUsersByEmail(emailToMatch, pageIndex, pageSize, out totalRecords);
            Log.Debug("FindUsersByEmail({0}, {1}, {2}). Retrieved {3} user(s) from Gigya.".FormatWith(new object[]
			{
				emailToMatch,
				pageIndex,
				pageSize,
				list.Count
			}), new object());
			list.ForEach(delegate(GigyaUser user)
			{
				UserRepository.AddUserToCache(user);
			});
			Log.Debug("FindUsersByEmail({0}, {1}, {2}). Finished.".FormatWith(new object[]
			{
				emailToMatch,
				pageIndex,
				pageSize
			}), new object());
			return list;
		}

		public static List<GigyaUser> GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
		{
			Log.Debug("GetAllUsers({0}, {1}). Started.".FormatWith(new object[]
			{
				pageIndex,
				pageSize
			}), new object());
			List<GigyaUser> allUsers = GigyaApiHelper.GetAllUsers(pageIndex, pageSize, out totalRecords);
			Log.Debug("GetAllUsers({0}, {1}). Retrieved {2} user(s) from Gigya.".FormatWith(new object[]
			{
				pageIndex,
				pageSize,
				allUsers.Count
			}), new object());
			allUsers.ForEach(delegate(GigyaUser user)
			{
				UserRepository.AddUserToCache(user);
			});
            Log.Debug("GetAllUsers({0}, {1}). Finished.".FormatWith(new object[]
			{
				pageIndex,
				pageSize
			}), new object());
			return allUsers;
		}

		public static void RemoveUserFromCache(GigyaUser user)
		{
			if (!string.IsNullOrEmpty(user.Email))
			{
				UserRepository._userCache.Remove(user.Email);
			}
			if (!string.IsNullOrEmpty(user.Username))
			{
				UserRepository._userCache.Remove(user.Username);
			}
			if (!string.IsNullOrEmpty(user.UID))
			{
				UserRepository._userCache.Remove(user.UID);
			}
		}

		private static void AddUserToCache(GigyaUser user)
		{
			if (!string.IsNullOrEmpty(user.Email))
			{
				UserRepository._userCache.Add(user.Email, user);
			}
			if (!string.IsNullOrEmpty(user.Username))
			{
				UserRepository._userCache.Add(user.Username, user);
			}
			if (!string.IsNullOrEmpty(user.UID))
			{
				UserRepository._userCache.Add(user.UID, user);
			}
		}

		public static bool DeleteUser(string username, out string message)
		{
			GigyaUser user = UserRepository.GetUser(username, false);
			return GigyaApiHelper.DeleteUser(user, out message);
		}

		public static GigyaUser RegisterUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, out string message)
		{
			GigyaUser gigyaUser = GigyaApiHelper.RegisterUser(username, password, email, passwordQuestion, passwordAnswer, out message);
			if (gigyaUser == null)
			{
				return null;
			}
			UserRepository.AddUserToCache(gigyaUser);
			return gigyaUser;
		}
	}
}
