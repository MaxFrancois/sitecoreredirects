using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Repository
{
	internal class ProfileRepository
	{
		public static Dictionary<string, object> GetUserProperties(string username, string[] propertyNames)
		{
			Assert.ArgumentNotNull(username, "userName");
			Assert.ArgumentNotNull(propertyNames, "propertyNames");
			Log.Debug(string.Format("GetUserProperties({0}). Started.", username), new object());
			try
			{
				if (propertyNames.Any<string>())
				{
					GigyaUser user = UserRepository.GetUser(username, true);
					if (user != null)
					{
						return (from property in user.Profile
						where propertyNames.Contains(property.Key)
						select property).ToDictionary((KeyValuePair<string, object> p) => p.Key, (KeyValuePair<string, object> v) => v.Value);
					}
				}
			}
			catch (Exception ex)
			{
				Log.Error(string.Format("GetUserProperties({0}). failed.", username), ex, new object());
			}
			finally
			{
				Log.Debug(string.Format("GetUserProperties({0}). Finished.", username), new object());
			}
			return new Dictionary<string, object>();
		}

		public static object GetUserProperty(string username, string propertyName)
		{
			Assert.ArgumentNotNullOrEmpty(propertyName, "propertyName");
			return ProfileRepository.GetUserProperties(username, new string[]
			{
				propertyName
			}).FirstOrDefault<KeyValuePair<string, object>>();
		}

		public static bool SetUserProperty(string username, string propertyName, object propertyValue)
		{
			return ProfileRepository.SetUserProperties(username, new Dictionary<string, object>
			{
				{
					propertyName,
					propertyValue
				}
			});
		}

		public static bool SetUserProperties(string username, Dictionary<string, object> properties)
		{
			bool result = false;
			Assert.ArgumentNotNull(username, "userName");
			Assert.ArgumentNotNull(properties, "proprties");
			Log.Debug(string.Format("SetUserProperty({0}). Started.", username), new object());
			try
			{
				if (properties.Any<KeyValuePair<string, object>>())
				{
					GigyaUser user = UserRepository.GetUser(username, true);
					if (user == null)
					{
						throw new Exception("User not found");
					}
					if (!GigyaApiHelper.UpdateUserProfile(user.UID, properties))
					{
						throw new Exception("Could not update user profile on Gigya, contact your admin for support");
					}
					ProfileRepository.ReloadUserProfile(username);
				}
				result = true;
			}
			catch (Exception ex)
			{
				result = false;
				Log.Error(string.Format("SetUserProperty({0}). failed.", username), ex, new object());
			}
			finally
			{
				Log.Debug(string.Format("SetUserProperty({0}). Finished.", username), new object());
			}
			return result;
		}

		public static void ReloadUserProfile(string username)
		{
			Assert.ArgumentNotNull(username, "userName");
			Log.Debug(string.Format("ReloadUserProfile({0}). Started.", username), new object());
			try
			{
				GigyaUser user = UserRepository.GetUser(username, true);
				if (user != null)
				{
					UserRepository.RemoveUserFromCache(user);
				}
			}
			catch (Exception ex)
			{
				Log.Error(string.Format("ReloadUserProfile({0}). failed.", username), ex, new object());
			}
			finally
			{
				Log.Debug(string.Format("ReloadUserProfile({0}). Finished.", username), new object());
			}
		}
	}
}
