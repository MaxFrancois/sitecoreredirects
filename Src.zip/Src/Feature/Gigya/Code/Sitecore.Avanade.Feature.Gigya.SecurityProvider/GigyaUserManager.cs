using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Repository;
using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore.Security.Accounts;
using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	public class GigyaUserManager
	{
		public static void ReloadUserProfile(User sitecoreUser)
		{
			if (!sitecoreUser.IsAuthenticated)
			{
				return;
			}
			sitecoreUser.Profile.Reload();
			if (sitecoreUser.GetDomainName().Equals(GigyaSettings.GigyaUserDomainName, StringComparison.InvariantCultureIgnoreCase))
			{
				ProfileRepository.ReloadUserProfile(sitecoreUser.GetLocalName());
			}
		}
	}
}
