using Gigya.Socialize.SDK;
using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils
{
	public class GigyaHelper
	{
		public static bool IsValidSignature(string timestamp, string UID, string secretKey, string signature)
		{
            if (Utils.GigyaSettings.GigyaValidateSignature)
            {
                return SigUtils.ValidateUserSignature(UID, timestamp, secretKey, signature);
            }

            return true;
		}
	}
}
