using Gigya.Socialize.SDK;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.Globalization;
using Sitecore.StringExtensions;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils
{
	internal class GigyaApiHelper
	{
		private static readonly ConcurrentDictionary<string, object> _processes = new ConcurrentDictionary<string, object>();

		private static readonly object _dictionaryLock = new object();

		public static List<GigyaUser> GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
			{
				new GigyaApiParameter("query", "select * from accounts limit {0} start {1}".FormatWith(new object[]
				{
					pageSize,
					GigyaApiHelper.GetStrartRowIndex(pageSize, pageIndex)
				})),
				new GigyaApiParameter("include", "loginIDs"),
				new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
			});
			if (gSResponse != null)
			{
				List<GigyaUser> list = GigyaApiHelper.ConvertToGigyaUserList(gSResponse);
				if (list.Any<GigyaUser>())
				{
					totalRecords = GigyaApiHelper.GetAllUsersCount();
				}
				return list;
			}
			totalRecords = 0;
			return new List<GigyaUser>(0);
		}

		public static int GetAllUsersCount()
		{
			try
			{
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
				{
					new GigyaApiParameter("query", "select count(*) from accounts"),
					new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
				});
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					JToken jToken = jObject["results"].Children().FirstOrDefault((JToken child) => child["count(*)"] != null);
					return MainUtil.GetInt(jToken["count(*)"].ToString(), 0);
				}
			}
			catch (Exception ex)
			{
				Log.Error("Gigya Count Exception", ex, new object());
			}
			return 0;
		}

		public static List<GigyaUser> FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
			{
				new GigyaApiParameter("query", "select * from accounts where profile.email=\"{0}\" and profile.email is not null limit {1} start {2}".FormatWith(new object[]
				{
					emailToMatch,
					pageSize,
					GigyaApiHelper.GetStrartRowIndex(pageSize, pageIndex)
				})),
				new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
			});
			if (gSResponse != null)
			{
				List<GigyaUser> list = GigyaApiHelper.ConvertToGigyaUserList(gSResponse);
				if (list.Any<GigyaUser>())
				{
					totalRecords = GigyaApiHelper.FindUsersByEmailCount(emailToMatch);
				}
				return list;
			}
			return new List<GigyaUser>(0);
		}

		public static GigyaUser GetUserByEmail(string email)
		{
			try
			{
				int num = 0;
				Assert.IsNotNullOrEmpty(email, "email can not be null");
				List<GigyaUser> source = GigyaApiHelper.FindUsersByEmail(email, 0, 1, out num);
				return source.FirstOrDefault<GigyaUser>();
			}
			catch (Exception ex)
			{
				Log.Error("could not find users", ex, new object());
			}
			return null;
		}

		public static int FindUsersByEmailCount(string emailToMatch)
		{
			try
			{
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
				{
					new GigyaApiParameter("query", "select count(*) from accounts where profile.email=\"{0}\" and profile.email is not null".FormatWith(new object[]
					{
						emailToMatch
					})),
					new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
				});
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					JToken jToken = jObject["results"].Children().FirstOrDefault((JToken child) => child["count(*)"] != null);
					return MainUtil.GetInt(jToken["count(*)"].ToString(), 0);
				}
			}
			catch (Exception ex)
			{
				Log.Error("Gigya FindUsersByEmailCount Exception", ex, new object());
			}
			return 0;
		}

		public static List<GigyaUser> FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
			{
				new GigyaApiParameter("query", "select * from accounts where profile.username=\"{0}\" and profile.email is not null limit {1} start {2}".FormatWith(new object[]
				{
					usernameToMatch,
					pageSize,
					GigyaApiHelper.GetStrartRowIndex(pageSize, pageIndex)
				})),
				new GigyaApiParameter("include", "loginIDs"),
				new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
			});
			if (gSResponse != null)
			{
				List<GigyaUser> list = GigyaApiHelper.ConvertToGigyaUserList(gSResponse);
				if (list.Any<GigyaUser>())
				{
					totalRecords = GigyaApiHelper.FindUsersByNameCount(usernameToMatch);
				}
				return list;
			}
			return new List<GigyaUser>(0);
		}

		public static GigyaUser GetUserByName(string username)
		{
			try
			{
				int num = 0;
				Assert.IsNotNullOrEmpty(username, "username can not be null");
				List<GigyaUser> source = GigyaApiHelper.FindUsersByName(username, 0, 1, out num);
				return source.FirstOrDefault<GigyaUser>();
			}
			catch (Exception ex)
			{
				Log.Error("could not find users", ex, new object());
			}
			return null;
		}

		public static int FindUsersByNameCount(string usernameToMatch)
		{
			try
			{
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
				{
					new GigyaApiParameter("query", "select count(*) from accounts where profile.username=\"{0}\" and profile.username is not null".FormatWith(new object[]
					{
						usernameToMatch
					})),
					new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
				});
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					JToken jToken = jObject["results"].Children().FirstOrDefault((JToken child) => child["count(*)"] != null);
					return MainUtil.GetInt(jToken["count(*)"].ToString(), 0);
				}
			}
			catch (Exception ex)
			{
				Log.Error("Gigya FindUsersByNameCount Exception", ex, new object());
			}
			return 0;
		}

		public static List<GigyaUser> FindUsersByUID(string uidToMatch, int pageIndex, int pageSize, out int totalRecords)
		{
			totalRecords = 0;
			GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
			{
				new GigyaApiParameter("query", "select * from accounts where UID=\"{0}\" and UID is not null limit {1} start {2}".FormatWith(new object[]
				{
					uidToMatch,
					pageSize,
					GigyaApiHelper.GetStrartRowIndex(pageSize, pageIndex)
				})),
				new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
			});
			if (gSResponse != null)
			{
				List<GigyaUser> list = GigyaApiHelper.ConvertToGigyaUserList(gSResponse);
				if (list.Any<GigyaUser>())
				{
					totalRecords = GigyaApiHelper.FindUsersByUIDCount(uidToMatch);
				}
				return list;
			}
			return new List<GigyaUser>(0);
		}

		public static GigyaUser GetUserByUID(string uid)
		{
			try
			{
				Assert.IsNotNull(uid, "uid can not be null");
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.getAccountInfo", new GigyaApiParameter[]
				{
					new GigyaApiParameter("UID", uid)
				});
				if (gSResponse != null)
				{
					return GigyaApiHelper.ConvertToGigyaUserList(gSResponse).FirstOrDefault<GigyaUser>();
				}
			}
			catch (Exception ex)
			{
				Log.Error("Error parsing file", ex, new object());
			}
			return null;
		}

		public static int FindUsersByUIDCount(string uidToMatch)
		{
			try
			{
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
				{
					new GigyaApiParameter("query", "select count(*) from accounts where UID=\"{0}\" and UID is not null".FormatWith(new object[]
					{
						uidToMatch
					})),
					new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
				});
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					JToken jToken = jObject["results"].Children().FirstOrDefault((JToken child) => child["count(*)"] != null);
					return MainUtil.GetInt(jToken["count(*)"].ToString(), 0);
				}
			}
			catch (Exception ex)
			{
				Log.Error("Gigya FindUsersByUIDCount Exception", ex, new object());
			}
			return 0;
		}

		public static string GetUserNameByEmail(string email)
		{
			try
			{
				Assert.IsNotNullOrEmpty(email, "email can not be null");
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.search", new GigyaApiParameter[]
				{
					new GigyaApiParameter("query", "select * from accounts where profile.email=\"{0}\" and profile.email is not null ".FormatWith(new object[]
					{
						email
					})),
					new GigyaApiParameter("include", "loginIDs"),
					new GigyaApiParameter("timeout", GigyaSettings.GigyaSearchTimeoutMilliSeconds)
				});
				if (gSResponse != null)
				{
					List<GigyaUser> source = GigyaApiHelper.ConvertToGigyaUserList(gSResponse);
					if (source.Any<GigyaUser>())
					{
						GigyaUser gigyaUser = source.FirstOrDefault<GigyaUser>();
						return StringUtil.GetString(new string[]
						{
							gigyaUser.Username,
							gigyaUser.Email,
							gigyaUser.UID
						});
					}
				}
			}
			catch (Exception ex)
			{
				Log.Error("Error parsing file", ex, new object());
			}
			return null;
		}

		public static bool Login(string username, string password)
		{
			GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.login", new GigyaApiParameter[]
			{
				new GigyaApiParameter("loginID", username),
				new GigyaApiParameter("password", password)
			});
			return gSResponse != null;
		}

		public static void Logout(string uid)
		{
			GigyaApiHelper.ExecuteGigyaRequest("accounts.logout", new GigyaApiParameter[]
			{
				new GigyaApiParameter("UID", uid)
			});
		}

		public static GigyaUser RegisterUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, out string message)
		{
			message = "";
			try
			{
				Log.Debug("Gigya: RegisterUser({0}), requesting for token".FormatWith(new object[]
				{
					username
				}), new object());
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.initRegistration", new GigyaApiParameter[0]);
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					JToken jToken = jObject["regToken"];
					string value = jToken.Value<string>();
					if (!string.IsNullOrEmpty(value))
					{
						Log.Debug("Gigya: RegisterUser({0}), registering account".FormatWith(new object[]
						{
							username
						}), new object());
						if (GigyaApiHelper.GetObjectSize(username) > 16384)
						{
							throw new Exception(string.Format("Username {0} contains value more than allowed constraint of 16 KB.", username));
						}
						if (GigyaApiHelper.GetObjectSize(email) > 16384)
						{
							throw new Exception(string.Format("Email {0} contains value more than allowed constraint of 16 KB.", email));
						}
						if (GigyaApiHelper.GetObjectSize(password) > 16384)
						{
							throw new Exception(string.Format("Password {0} contains value more than allowed constraint of 16 KB.", password));
						}
						GSObject gSObject = null;
						string text = ConfigurationManager.AppSettings["GigyaCreateUserRequiredFields"];
						if (text != null)
						{
							string[] array = text.Split(new string[]
							{
								"|"
							}, StringSplitOptions.RemoveEmptyEntries);
							gSObject = new GSObject();
							string[] array2 = array;
							for (int i = 0; i < array2.Length; i++)
							{
								string text2 = array2[i];
								string[] array3 = text2.Split(new string[]
								{
									":"
								}, StringSplitOptions.RemoveEmptyEntries);
								if (array3[1] == "boolean")
								{
									gSObject.Put(array3[0], bool.Parse(array3[2]));
								}
								else if (array3[1] == "int")
								{
									gSObject.Put(array3[0], int.Parse(array3[2]));
								}
								else if (array3[1] == "long")
								{
									gSObject.Put(array3[0], long.Parse(array3[2]));
								}
								else if (array3[1] == "string")
								{
									gSObject.Put(array3[0], array3[2]);
								}
							}
						}
						GigyaApiParameter[] array4 = new GigyaApiParameter[]
						{
							new GigyaApiParameter("username", username),
							new GigyaApiParameter("email", email),
							new GigyaApiParameter("password", password),
							new GigyaApiParameter("regToken", value)
						};
						GigyaApiParameter[] array5 = new GigyaApiParameter[]
						{
							new GigyaApiParameter("email", email),
							new GigyaApiParameter("password", password),
							new GigyaApiParameter("regToken", value),
							new GigyaApiParameter("finalizeRegistration", true)
						};
						if (gSObject != null)
						{
							Log.Info("$$$$$$$$$$$$$$$$$$ data.ToJsonString() = " + gSObject.ToJsonString(), new object());
							array4 = array4.Concat(new GigyaApiParameter[]
							{
								new GigyaApiParameter("data", gSObject.ToJsonString())
							}).ToArray<GigyaApiParameter>();
							array5 = array5.Concat(new GigyaApiParameter[]
							{
								new GigyaApiParameter("data", gSObject.ToJsonString())
							}).ToArray<GigyaApiParameter>();
						}
						GSResponse gSResponse2 = GigyaApiHelper.ExecuteGigyaRegisterRequest("accounts.register", array4, array5);
						if (gSResponse2 != null)
						{
							List<GigyaUser> source = GigyaApiHelper.ConvertToGigyaUserList(gSResponse2);
							if (source.Any<GigyaUser>())
							{
								message = Translate.Text("success");
								GigyaUser gigyaUser = source.FirstOrDefault<GigyaUser>();
								gigyaUser.Username = username;
								return gigyaUser;
							}
						}
						else
						{
							Log.Debug("Gigya: RegisterUser({0}): could not create account".FormatWith(new object[]
							{
								username
							}), new object());
						}
					}
					throw new System.Security.Authentication.AuthenticationException("Gigya: RegisterUser({0}): did not receive token".FormatWith(new object[]
					{
						username
					}));
				}
				Log.Debug("Gigya: RegisterUser({0}): did not receive token".FormatWith(new object[]
				{
					email
				}), new object());
			}
			catch (Exception ex)
			{
				Log.Error("Gigya: Gigya RegisterUser({0}) Exception".FormatWith(new object[]
				{
					email
				}), ex, new object());
				message = string.Format("{0}: Error message: {1}", Translate.Text("Could not create gigya user"), ex.Message);
			}
			return null;
		}

		public static bool DeleteUser(GigyaUser gigyaUser, out string message)
		{
			message = "";
			try
			{
				string uID = gigyaUser.UID;
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.deleteAccount", new GigyaApiParameter[]
				{
					new GigyaApiParameter("UID", uID)
				});
				if (gSResponse != null)
				{
					message = Translate.Text(gSResponse.GetResponseText());
					return true;
				}
				Log.Debug("Gigya: DeleteUser({0}): could not delete account".FormatWith(new object[]
				{
					gigyaUser.Username
				}), new object());
			}
			catch (Exception ex)
			{
				Log.Error("Gigya: Gigya DeleteUser({0}) Exception".FormatWith(new object[]
				{
					gigyaUser.Username
				}), ex, new object());
				message = string.Format("{0}: Error message: {1}", Translate.Text("Could not delete gigya user"), ex.Message);
			}
			return false;
		}

		private static int GetObjectSize(object ob)
		{
			try
			{
				if (ob is string)
				{
					int result = ob.ToString().Length;
					return result;
				}
				if (ob is int)
				{
					int result = 4;
					return result;
				}
				if (ob is long)
				{
					int result = 8;
					return result;
				}
				if (ob is double)
				{
					int result = 8;
					return result;
				}
				if (ob is float)
				{
					int result = 4;
					return result;
				}
				if (ob is bool)
				{
					int result = 1;
					return result;
				}
			}
            catch (System.InvalidCastException iex)
            {
                Log.Error("Gigya: Get Object Size Error", iex);
            }
			catch (Exception ex)
			{
                Log.Error("Gigya: Get Object Size Error", ex);
            }
			return 0;
		}

		private static bool _UpdateUserProfile(string uid, Dictionary<string, object> profileObjects)
		{
			Log.Debug("Gigya: UpdateUserProfile({0}), initiated for".FormatWith(new object[]
			{
				uid
			}), new object());
			try
			{
				foreach (KeyValuePair<string, object> current in profileObjects)
				{
					int objectSize = GigyaApiHelper.GetObjectSize(current.Value);
					if (objectSize > 16384)
					{
						throw new System.Security.Authentication.AuthenticationException(string.Format("Profile key {0} for user id {1} contains value more than allowed constraint of 16 KB.", current.Key, uid));
					}
				}
				Dictionary<string, object> dictionary = (from kvp in profileObjects
				where kvp.Key.StartsWith(GigyaSettings.CustomPropertyNamePrefix)
				select kvp).ToDictionary((KeyValuePair<string, object> kvp) => kvp.Key.Replace(GigyaSettings.CustomPropertyNamePrefix, string.Empty).Trim(), (KeyValuePair<string, object> kvp1) => kvp1.Value);
				Dictionary<string, object> dictionary2 = profileObjects.Except(dictionary).ToDictionary((KeyValuePair<string, object> kvp) => kvp.Key, (KeyValuePair<string, object> kvp1) => kvp1.Value);
				string value = JsonConvert.SerializeObject(dictionary2, Formatting.Indented);
                string value2 = JsonConvert.SerializeObject(dictionary, Formatting.Indented);
				Log.Debug("Gigya: UpdateUserProfile({0}), updating account".FormatWith(new object[]
				{
					uid
				}), new object());
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRequest("accounts.setAccountInfo", new GigyaApiParameter[]
				{
					new GigyaApiParameter("uid", uid),
					new GigyaApiParameter("profile", value),
					new GigyaApiParameter("data", value2)
				});
				if (gSResponse != null)
				{
					JObject jObject = JObject.Parse(gSResponse.GetData().ToJsonString());
					if (jObject["errorCode"] != null && jObject["errorCode"].ToString() == "0")
					{
						return true;
					}
				}
				else
				{
					Log.Debug("Gigya: UpdateUserProfile({0}), updating account failed {1}".FormatWith(new object[]
					{
						uid,
						gSResponse
					}), new object());
				}
			}
			catch (Exception ex)
			{
				Log.Error("Gigya: Gigya UpdateUserProfile({0}) Exception".FormatWith(new object[]
				{
					uid
				}), ex, new object());
			}
			Log.Debug("Gigya: UpdateUserProfile({0}), executed for".FormatWith(new object[]
			{
				uid
			}), new object());
			return false;
		}

		public static bool UpdateUserProfile(string uid, Dictionary<string, object> profileObjects)
		{
			Assert.IsNotNullOrEmpty(uid, "uid can not be null");
			Assert.IsNotNull(profileObjects, "profile objects can not be null");
			object obj = null;
			bool flag = false;
			bool result = false;
			lock (GigyaApiHelper._dictionaryLock)
			{
				if (!GigyaApiHelper._processes.TryGetValue(uid, out obj))
				{
					flag = true;
					obj = new object();
					GigyaApiHelper._processes.TryAdd(uid, obj);
				}
			}
			object obj2 = null;
			lock (obj)
			{
				if (flag)
				{
					result = GigyaApiHelper._UpdateUserProfile(uid, profileObjects);
					GigyaApiHelper._processes.TryRemove(uid, out obj2);
				}
			}
			return result;
		}

		public static List<GigyaUser> ConvertToGigyaUserList(GSResponse gigyaResponse)
		{
			return GigyaApiHelper.ConvertToGigyaUserList(gigyaResponse.GetData());
		}

		public static List<GigyaUser> ConvertToGigyaUserList(GSObject gigyaObject)
		{
			return GigyaApiHelper.ConvertToGigyaUserList(gigyaObject.ToJsonString());
		}

		public static List<GigyaUser> ConvertToGigyaUserList(string jsonString)
		{
			try
			{
				JObject jObject = JObject.Parse(jsonString);
				List<GigyaUser> result;
				if (jObject["results"] != null)
				{
					string arg_32_0 = jObject["results"].ToString();
					JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings();
					jsonSerializerSettings.TypeNameHandling = TypeNameHandling.All;
					List<UserJsonObject> source = JsonConvert.DeserializeObject<List<UserJsonObject>>(arg_32_0, jsonSerializerSettings);
					result = (from user in source
					select new GigyaUser(user.UID, user.UIDDignature, user.SocialProviders, user.LastLoginDate, user.OldestDataUpdated, user.LastUpdatedDate, user.CreatedDate, user.Profile, user.CustomProfileProperties)).ToList<GigyaUser>();
					return result;
				}
				string arg_7E_0 = jObject.ToString();
				JsonSerializerSettings jsonSerializerSettings2 = new JsonSerializerSettings();
				jsonSerializerSettings2.TypeNameHandling = TypeNameHandling.All;
				UserJsonObject userJsonObject = JsonConvert.DeserializeObject<UserJsonObject>(arg_7E_0, jsonSerializerSettings2);
				result = new List<GigyaUser>
				{
					new GigyaUser(userJsonObject.UID, userJsonObject.UIDDignature, userJsonObject.SocialProviders, userJsonObject.LastLoginDate, userJsonObject.OldestDataUpdated, userJsonObject.LastUpdatedDate, userJsonObject.CreatedDate, userJsonObject.Profile, userJsonObject.CustomProfileProperties)
				};
				return result;
			}
			catch (Exception ex)
			{
				Log.Error("Gigya: ", ex, new object());
			}
			return new List<GigyaUser>(0);
		}

		private static int GetStrartRowIndex(int pageSize, int pageIndex)
		{
			return pageSize * pageIndex;
		}

		private static GSResponse ExecuteGigyaRequest(string methodName, params GigyaApiParameter[] parameters)
		{
            try
            {
                string gigyaApiKeyForSite = GigyaSettings.GetGigyaApiKeyForSite();
                GSRequest gSRequest = new GSRequest(gigyaApiKeyForSite, GigyaSettings.SecretKey, methodName, GigyaSettings.GigyaHttps);
                gSRequest.APIDomain = GigyaSettings.GigyaDataCenter;
                Log.Debug("Gigya Connector Start Request, api key: {0}, secret key: {1}, method name: {2}, site name: {3}".FormatWith(new object[]
                {
                    gigyaApiKeyForSite,
                    GigyaSettings.SecretKey,
                    methodName,
                    Context.GetSiteName()
                }), new object());
                if (parameters.Any<GigyaApiParameter>())
                {
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        GigyaApiParameter gigyaApiParameter = parameters[i];
                        if (!gigyaApiParameter.Name.Equals("password", StringComparison.InvariantCultureIgnoreCase))
                        {
                            Log.Debug("Gigya Connector, API parameter name {0}, parameter value {1}".FormatWith(new object[]
                            {
                                gigyaApiParameter.Name,
                                gigyaApiParameter.Value
                            }), new object());
                        }
                        if (gigyaApiParameter.Value is string)
                        {
                            gSRequest.SetParam(gigyaApiParameter.Name, gigyaApiParameter.Value.ToString());
                        }
                        else if (gigyaApiParameter.Value is bool)
                        {
                            gSRequest.SetParam(gigyaApiParameter.Name, (bool)gigyaApiParameter.Value);
                        }
                        else
                        {
                            gSRequest.SetParam(gigyaApiParameter.Name, (int)gigyaApiParameter.Value);
                        }
                    }
                }
                Log.Debug("Gigya Connector End Request", new object());
                GSResponse gSResponse = gSRequest.Send();
                if (gSResponse != null && gSResponse.GetErrorCode() == 0)
                {
                    Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
                    {
                        gSResponse.GetResponseText()
                    }));
                    return gSResponse;
                }

                if (gSResponse != null)
                {
                    throw new System.Security.Authentication.AuthenticationException($"Error Message: {gSResponse.GetErrorMessage()}, Method Name: {methodName}, Error Code: {gSResponse.GetErrorCode()}");
                }
                else
                {
                    throw new System.Security.Authentication.AuthenticationException($"Error Message: gsResponse is null, Method Name: {methodName}, Error Code: gsResponse is null");
                }
			}
			catch (Exception ex)
            {
                Log.Error("Gigya method : {0} Exception. Response error code help http://developers.gigya.com/037_API_reference/zz_Response_Codes_and_Errors ".FormatWith(new object[]
				{
					methodName
				}), ex, new object());
			}
			return null;
		}

		private static GSResponse ExecuteGigyaRegisterRequest(string methodName, GigyaApiParameter[] originalParameters, params GigyaApiParameter[] parameters)
		{
			try
			{
				string gigyaApiKeyForSite = GigyaSettings.GetGigyaApiKeyForSite();
				GSRequest gSRequest = new GSRequest(gigyaApiKeyForSite, GigyaSettings.SecretKey, methodName, true);
				gSRequest.APIDomain = GigyaSettings.GigyaDataCenter;
				Log.Debug("Gigya Connector Start Request, api key: {0}, secret key: {1}, method name: {2}, site name: {3}".FormatWith(new object[]
				{
					gigyaApiKeyForSite,
					GigyaSettings.SecretKey,
					methodName,
					Context.GetSiteName()
				}), new object());
				if (parameters.Any<GigyaApiParameter>())
				{
					for (int j = 0; j < parameters.Length; j++)
					{
						GigyaApiParameter gigyaApiParameter = parameters[j];
						if (!gigyaApiParameter.Name.Equals("password", StringComparison.InvariantCultureIgnoreCase))
						{
                            Log.Debug("Gigya Connector, API parameter name {0}, parameter value {1}".FormatWith(new object[]
							{
								gigyaApiParameter.Name,
								gigyaApiParameter.Value
							}), new object());
						}
						if (gigyaApiParameter.Value is string)
						{
							gSRequest.SetParam(gigyaApiParameter.Name, gigyaApiParameter.Value.ToString());
						}
						else if (gigyaApiParameter.Value is bool)
						{
							gSRequest.SetParam(gigyaApiParameter.Name, (bool)gigyaApiParameter.Value);
						}
						else
						{
							gSRequest.SetParam(gigyaApiParameter.Name, (int)gigyaApiParameter.Value);
						}
					}
				}
				Log.Debug("Gigya Connector End Request", new object());
				GSResponse gSResponse = gSRequest.Send();
				if (gSResponse != null && gSResponse.GetErrorCode() == 0)
				{
					Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
					{
						gSResponse.GetResponseText()
					}));
					GSResponse result = gSResponse;
					return result;
				}
				if (gSResponse != null && gSResponse.GetErrorCode() == 400009 && methodName.Equals("accounts.register"))
				{
					if (parameters.Count((GigyaApiParameter i) => i.Name.Equals("username")) != 0
                        && parameters.Count((GigyaApiParameter i) => i.Name.Equals("email")) != 0)
					{
                        throw new System.Security.Authentication.AuthenticationException("Error Message: {0}, Method Name: {1}, Error Code: {2}".FormatWith(new object[]
						{
							gSResponse.GetErrorMessage(),
							methodName,
							gSResponse.GetErrorCode()
						}));
					}
					if (parameters.Count((GigyaApiParameter i) => i.Name.Equals("username")) != 0
                        && parameters.Count((GigyaApiParameter i) => i.Name.Equals("email")) == 0)
					{
						gSResponse = GigyaApiHelper.ReExecuteGigyaRegisterRequest(gigyaApiKeyForSite, "accounts.register", "", originalParameters);
						if (gSResponse != null && gSResponse.GetErrorCode() == 0)
						{
                            Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
							{
								gSResponse.GetResponseText()
							}));
							GSResponse result = gSResponse;
							return result;
						}
					}
					if (parameters.Count((GigyaApiParameter i) => i.Name.Equals("username")) != 0)
					{
						gSResponse = GigyaApiHelper.ReExecuteGigyaRegisterRequest(gigyaApiKeyForSite, "accounts.register", "username", originalParameters);
						if (gSResponse != null && gSResponse.GetErrorCode() == 0)
						{
                            Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
							{
								gSResponse.GetResponseText()
							}));
							GSResponse result = gSResponse;
							return result;
						}
					}
					if (parameters.Count((GigyaApiParameter i) => i.Name.Equals("email")) != 0)
					{
						gSResponse = GigyaApiHelper.ReExecuteGigyaRegisterRequest(gigyaApiKeyForSite, "accounts.register", "email", originalParameters);
						if (gSResponse != null && gSResponse.GetErrorCode() == 0)
						{
                            Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
							{
								gSResponse.GetResponseText()
							}));
							GSResponse result = gSResponse;
							return result;
						}
					}
				}

                if (gSResponse != null)
                {
                    throw new System.Security.Authentication.AuthenticationException("Error Message: {0}, Method Name: {1}, Error Code: {2}".FormatWith(new object[]
                    {
                        gSResponse.GetErrorMessage(),
                        methodName,
                        gSResponse.GetErrorCode()
                    }));
                }
			}
			catch (Exception ex)
			{
                Log.Error("Gigya method : {0} Exception. Response error code help http://developers.gigya.com/037_API_reference/zz_Response_Codes_and_Errors ".FormatWith(new object[]
				{
					methodName
				}), ex, new object());
			}
			return null;
		}

		private static GSResponse ReExecuteGigyaRegisterRequest(string apiKey, string methodName, string skipName, GigyaApiParameter[] originalParameters)
		{
			GSRequest gSRequest = new GSRequest(apiKey, GigyaSettings.SecretKey, methodName, true);
			gSRequest.APIDomain = GigyaSettings.GigyaDataCenter;
			if (string.IsNullOrEmpty(skipName) || originalParameters.Count((GigyaApiParameter i) => i.Name.Equals(skipName)) != 0)
			{
				List<GigyaApiParameter> list = new List<GigyaApiParameter>();
				for (int j = 0; j < originalParameters.Length; j++)
				{
					GigyaApiParameter gigyaApiParameter = originalParameters[j];
					if (string.IsNullOrEmpty(skipName) || !gigyaApiParameter.Name.Equals(skipName))
					{
						list.Add(new GigyaApiParameter(gigyaApiParameter.Name, gigyaApiParameter.Value.ToString()));
					}
				}
				GSResponse gSResponse = GigyaApiHelper.ExecuteGigyaRegisterRequest(methodName, originalParameters, list.ToArray());
				if (gSResponse != null && gSResponse.GetErrorCode() == 0)
				{
                    Log.Debug("Gigya Connector: receiving response from Gigya API. Response text: {0} ".FormatWith(new object[]
					{
						gSResponse.GetResponseText()
					}));
					return gSResponse;
				}
			}
			return null;
		}
	}
}
