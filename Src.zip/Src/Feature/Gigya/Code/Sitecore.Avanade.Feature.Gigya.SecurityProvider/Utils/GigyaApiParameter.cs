using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils
{
	internal class GigyaApiParameter
	{
		private string _name;

		private object _paramValue;

		public string Name
		{
			get
			{
				return this._name;
			}
		}

		public object Value
		{
			get
			{
				return this._paramValue;
			}
		}

		public GigyaApiParameter(string name, object value)
		{
			this._paramValue = value;
			this._name = name;
		}
	}
}
