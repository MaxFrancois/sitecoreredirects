using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils
{
	internal class UserJsonObject
	{
		[JsonProperty(PropertyName = "UID")]
		public string UID
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "UIDDignature")]
		public string UIDDignature
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "signatureTimestamp")]
		public string SignatureTimestamp
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "loginProvider")]
		public string LoginProvider
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "isRegistered")]
		public bool IsRegistered
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "isActive")]
		public bool IsActive
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "isVerified")]
		public bool IsVerified
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "iRank")]
		public long IRank
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "lastLoginTimestamp")]
		public long LastLoginTimestamp
		{
			get;
			set;
		}

		[JsonConverter(typeof(IsoDateTimeConverter)), JsonProperty(PropertyName = "lastLogin")]
		public DateTime LastLoginDate
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "oldestDataUpdatedTimestamp")]
		public long OldestDataUpdatedTimestamp
		{
			get;
			set;
		}

		[JsonConverter(typeof(IsoDateTimeConverter)), JsonProperty(PropertyName = "oldestDataUpdated")]
		public DateTime OldestDataUpdated
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "lastUpdatedTimestamp")]
		public long LastUpdatedTimestamp
		{
			get;
			set;
		}

		[JsonConverter(typeof(IsoDateTimeConverter)), JsonProperty(PropertyName = "lastUpdated")]
		public DateTime LastUpdatedDate
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "createdTimestamp")]
		public long CreatedTimestamp
		{
			get;
			set;
		}

		[JsonConverter(typeof(IsoDateTimeConverter)), JsonProperty(PropertyName = "created")]
		public DateTime CreatedDate
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "socialProviders")]
		public string SocialProviders
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "profile")]
		public Dictionary<string, object> Profile
		{
			get;
			set;
		}

		[JsonProperty(PropertyName = "data")]
		public Dictionary<string, object> CustomProfileProperties
		{
			get;
			set;
		}
	}
}
