using System;

namespace Sitecore.Avanade.Feature.Gigya.SecurityProvider
{
	internal class GigyaRoleProvider
	{
	}
}
