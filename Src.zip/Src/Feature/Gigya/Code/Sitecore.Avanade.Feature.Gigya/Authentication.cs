/*
****************************************************************************
Copyright 2000-2017 Accenture Interactive Australia Pty Ltd

This file is licensed under the Accenture Interactive Internal Business
Operations License (AIIBOL), Version [1.0] (the "License").
You may not use this file except in compliance with the License.
You may obtain a copy of the License from Accenture/Accenture Interactive
email address at DSO.Legal.Requests@accenture.com
 
Except to the extent specified in the License and unless required by
applicable law or agreed to in writing, software distributed under the
License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************
*/

using Sitecore.Avanade.Feature.Gigya.SecurityProvider.Utils;
using Sitecore;
using Sitecore.Diagnostics;
using Sitecore.Globalization;
using Sitecore.Security.Accounts;
using Sitecore.Security.Authentication;
using Sitecore.StringExtensions;
using System;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Gigya
{
    /// <summary>
    /// Authentication mechanisums to assist with login into Sitecore and Gigya
    /// </summary>
    public static class Authentication
    {
        #region Login
        /// <summary>
        /// Login Context
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="sgn"></param>
        /// <param name="stm"></param>
        /// <param name="lgn"></param>
        /// <param name="redirectUrl"></param>
        public static Sitecore.Avanade.Feature.Gigya.AuthenticaitonResponse Login(string uid, string sgn, string stm, string lgn, string redirectUrl)
		{
            // is the user already authenitcated
            if (Sitecore.Context.User.IsAuthenticated)
            {
                Log.Audit("Gigya Connector - User already logged in.".FormatWith(new object[]
				{
					uid
				}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
                return new Feature.Gigya.AuthenticaitonResponse
                {
                    Success = Context.User.IsAuthenticated,
                    ErrorMessage = (Context.User.IsAuthenticated ? string.Empty : Translate.Text("Unable to login to Gigya+Sitecore")),
                    RedirectUrl = redirectUrl
                };
            }

			if (!GigyaHelper.IsValidSignature(stm, uid, GigyaSettings.SecretKey, sgn))
			{
                Log.Audit("Gigya Connector - Signature for uid: {0} is not valid.".FormatWith(new object[]
				{
					uid
				}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
                return new Feature.Gigya.AuthenticaitonResponse
				{
					Success = Context.User.IsAuthenticated,
                    ErrorMessage = (Context.User.IsAuthenticated ? string.Empty : Translate.Text("Unable to login to Gigya+Sitecore")),
					RedirectUrl = redirectUrl
				};
			}
			bool @bool = MainUtil.GetBool(lgn, true);
			string text = GigyaSettings.GigyaUserDomainName + "\\" + uid;
			if (string.IsNullOrEmpty(uid) || !@bool)
			{
                return new Feature.Gigya.AuthenticaitonResponse
				{
					Success = false,
					ErrorMessage = ((!@bool) ? Translate.Text("Invalid login request") : Translate.Text("Invalid UID")),
					RedirectUrl = redirectUrl
				};
			}
			if (Sitecore.Security.Accounts.User.Exists(text))
			{
				Log.Audit("Gigya Connector - user found for uid = {0}".FormatWith(new object[]
				{
					text
				}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
				if (AuthenticationManager.Login(text, true))
				{
					Log.Audit("Gigya Connector - sucessfully authenticated uid = {0}".FormatWith(new object[]
					{
						text
					}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
				}
				else
				{
					Log.Audit("Gigya Connector - could not authenticate uid = {0}".FormatWith(new object[]
					{
						text
					}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
					AuthenticationManager.Logout();
				}
			}
			else
			{
				Log.Audit("Gigya Connector - could not find user for uid = {0}".FormatWith(new object[]
				{
					text
				}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
				AuthenticationManager.Logout();
			}
            return new Feature.Gigya.AuthenticaitonResponse
			{
                Success = Context.User.IsAuthenticated,
                ErrorMessage = (Context.User.IsAuthenticated ? string.Empty : Translate.Text("Unable to login")),
				RedirectUrl = redirectUrl
			};
		}
        #endregion

        #region Logout
        public static Sitecore.Avanade.Feature.Gigya.AuthenticaitonResponse Logout(string lgout, string redirectUrl)
		{
			if (!MainUtil.GetBool(lgout, true))
			{
				return new Feature.Gigya.AuthenticaitonResponse
				{
					Success = false,
					ErrorMessage = Translate.Text("Invalid logout request"),
					RedirectUrl = redirectUrl
				};
			}
            Log.Audit("Gigya Connector - logging out user {0}".FormatWith(new object[]
			{
				Context.User.Name
			}), typeof(Sitecore.Avanade.Feature.Gigya.Authentication));
			AuthenticationManager.Logout();
			return new Feature.Gigya.AuthenticaitonResponse
			{
				Success = true,
				ErrorMessage = string.Empty,
				RedirectUrl = redirectUrl
			};
        }
        #endregion
    }
}
