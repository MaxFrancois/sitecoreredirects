﻿/*
****************************************************************************
Copyright 2000-2017 Accenture Interactive Australia Pty Ltd

This file is licensed under the Accenture Interactive Internal Business
Operations License (AIIBOL), Version [1.0] (the "License").
You may not use this file except in compliance with the License.
You may obtain a copy of the License from Accenture/Accenture Interactive
email address at DSO.Legal.Requests@accenture.com
 
Except to the extent specified in the License and unless required by
applicable law or agreed to in writing, software distributed under the
License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.Avanade.Feature.Gigya
{
    public class AuthenticaitonResponse
    {
        /// <summary>
        /// Was the login attempt Successful
        /// </summary>
        public bool Success { get; internal set; }

        /// <summary>
        /// The error message if login failed
        /// </summary>
        public string ErrorMessage { get; internal set; }

        /// <summary>
        /// The location we need to redirect the user
        /// </summary>
        public string RedirectUrl { get; internal set; }
    }
}
