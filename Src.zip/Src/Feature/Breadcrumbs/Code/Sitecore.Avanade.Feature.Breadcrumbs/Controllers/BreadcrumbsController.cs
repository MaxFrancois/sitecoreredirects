﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Mvc;

namespace Sitecore.Avanade.Feature.Breadcrumbs.Controllers
{
    public class BreadcrumbsController : SitecoreController
    {
        protected Item PageContext { get; } = RenderingContext.Current.PageContext.Item;

        /// <summary>
        /// Returns a collection containing filtered Sitecore <see cref="Item"/>'s using the
        /// supplied predicate for use when building a breadcrumb navigation rendering.
        /// </summary>
        /// <remarks>
        /// This method starts at the specified <paramref name="item"/> and walks up the content tree using the
        /// parent items until the start item for the website is reached. The items are returned with the start
        /// item first in the collection minus any filtered items.
        /// </remarks>
        public ActionResult Display()
        {
            if (PageContext == null)
            {
                //PageContext cannot be found or not initialised.
                Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Breadcrumb]: PageContext is null for rendering Breadcrumb", this);
                return new EmptyResult();
            }

            var pages = PageContext.Axes.GetAncestors(true);
            Debug.Assert(pages != null);

            var list = new List<Item>();
            foreach (var itm in pages)
            {
                if (itm.HasField(Constants.Breadcrumb.EnabledField) && itm.Fields[Constants.Breadcrumb.EnabledField].IsChecked())
                    list.Add(itm);
            }

            return PartialView("~/Views/Navigation/Breadcrumbs.cshtml", list);
        }
    }
}