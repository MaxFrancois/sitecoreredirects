﻿namespace Sitecore.Avanade.Feature.Breadcrumbs
{
    public static class Constants
    {
        public static class Breadcrumb
        {
            public const string EnabledField = "ShowInBreadcrumbs";
            public const string TitleField = "BreadcrumbTitle";
        }
    }
}