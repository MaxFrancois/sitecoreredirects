﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Shell.Applications.WebEdit.Commands;
using Sitecore.Shell.Framework.Commands;
using Sitecore.Web.UI.Sheer;

namespace Sitecore.Avanade.Foundation.Analytics.Commands
{
    public class InsertAiAnalyticsWebEdit : WebEditCommand
    {
        public override void Execute(CommandContext context)
        {
            Context.ClientPage.Start(this, "Run", context.Parameters);
        }

        protected static void Run(ClientPipelineArgs args)
        {
            if(args.IsPostBack)
            {
                if(args.HasResult)
                {
                    var decodedResults = args.Result.UnescapeJavascriptString();
                    var selectedValues = decodedResults.Split(new char[] { ',' }, StringSplitOptions.None);
                    var goal = selectedValues[0] != null ? selectedValues[0] : string.Empty; //We'll make sure the first element is a selected goal
                    var pageEvent = selectedValues[1] != null ? selectedValues[1] : string.Empty; //and the second element is the selected event
                    //The response to the javascript
                    SheerResponse.Eval("window.parent.Sitecore.PageModes.ChromeManager.handleMessage('chrome:field:aianalyticsinserted',{{ {0}: '{1}', {2}: '{3}' }})", new object[] { Constants.DialogAttributes.Goal, goal, Constants.DialogAttributes.Event, pageEvent }); //goal:<value>,event:<value>
                }
            }
            else
            {
                //run the dialog
                var urlStr = Resources.ResourceUri.Parse("control:RichText.InsertAiAnalytics").ToUrlString();
                urlStr.Add("mo", "webedit");
                urlStr.Add("la", args.Parameters["language"]);
                if(args.Parameters[Constants.DialogAttributes.Goal] != null)
                {
                    urlStr.Add(Constants.DialogAttributes.Goal, args.Parameters[Constants.DialogAttributes.Goal]);
                }
                
                if(args.Parameters[Constants.DialogAttributes.Event] != null)
                {
                    urlStr.Add(Constants.DialogAttributes.Event, args.Parameters[Constants.DialogAttributes.Event]);
                }

                SheerResponse.ShowModalDialog(urlStr.ToString(), true);
                args.WaitForPostBack();
            }
        }
    }

    public static class JavascriptStringExtensions
    {
        public static string UnescapeJavascriptString(this String strValue)
        {
            if (String.IsNullOrEmpty(strValue))
            {
                return strValue;
            }

            return new System.Text.StringBuilder(strValue).Replace("\\\\", "\\").Replace("\\'", "'").Replace("\\\"", "\"").Replace("\"", "").Replace("\\<", "<").Replace("\\>", ">").ToString();
        }
    }
}