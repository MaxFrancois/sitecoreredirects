﻿var callback = function () {
    var scTrackingAttr = "data-sctracking";
    var scGoalAttr = "data-scgoal";
    var scEventAttr = "data-scevent";

    var nodeList = document.querySelectorAll("[" + scTrackingAttr + "]", "[" + scGoalAttr + "]", "[" + scEventAttr + "]");
    var clickable = Array.prototype.slice.apply(nodeList);
    if (clickable != null && clickable !== undefined) {
        clickable.forEach(function (item) {
            item.addEventListener("click", function RegisterTracking(data) {
                //Get the element
                var element = data.srcElement;

                var tracking = element.attributes[scTrackingAttr];
                var goal = element.attributes[scGoalAttr];
                var event = element.attributes[scEventAttr];

                //Get all the attribute values if they exist on this element
                var postObj = {
                    "Tracking": tracking === undefined ? "" : tracking.value,
                    "Goal": goal === undefined ? "" : goal.value,
                    "Event": event === undefined ? "" : event.value
                };

                //turn into JSON to log and send
                var json = JSON.stringify(postObj);

                //log in console so we can see whats going on
                console.log("Attempting to register the following json:\n" + json);

                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function () {

                    if (this.readyState == 4 && this.status == 200) {
                        console.log("Tracking field registered successfully.");
                        console.log(this.responseText);
                    }

                    if (this.readyState == 4 && this.status != 200) {
                        console.log(this.responseText);
                    }
                };
                //open the channel
                xhttp.open("POST", "sitecore/api/analyticsapi/RegisterSitecoreAnalyticsAsync", true);

                //set the header
                xhttp.setRequestHeader("Content-type", "application/json");
                xhttp.send(json);
            });
        });
    }
};

if(document.readyState === "complete" || 
    (document.readyState !== "loading" && !document.documentElement.doScroll)) {
    callback();
} else {
    document.addEventListener("DOMContentLoaded", callback);
}