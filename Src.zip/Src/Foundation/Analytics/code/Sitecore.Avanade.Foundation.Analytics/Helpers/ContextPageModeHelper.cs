﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Helpers
{
    public static class ContextPageModeHelper
    {
        /// <summary>
        /// Checks that Sitecore is in the correct mode to run feature
        /// Current condition is:
        /// IsExperienceEditor OR IsPreview OR (IsDebugging AND IsProfiling) OR IsSimulatedDevicePreviewing
        /// </summary>
        /// <returns>Boolean</returns>
        public static bool IsSitecoreNOTInCorrectMode()
        {
            return Context.PageMode.IsExperienceEditor ||
                Context.PageMode.IsPreview ||
                (Context.PageMode.IsDebugging && Context.PageMode.IsProfiling) ||
                Context.PageMode.IsSimulatedDevicePreviewing;
        }
    }
}