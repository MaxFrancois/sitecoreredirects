﻿using Sitecore.Web;
using System;
using System.Linq;
using Sitecore.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace Sitecore.Avanade.Foundation.Analytics.Helpers
{
    public static class DialogDropDownHelper
    {
        public static string GoalXmlAttributeName
        {
            get
            {
                return Constants.XmlAttributes.Goal;
            }
        }

        public static string GetSetValueFromXml(string name = "")
        {
            name = string.IsNullOrEmpty(name) ? GoalXmlAttributeName : name;

            //Check the query string for the handle
            var queryString = WebUtil.GetQueryString("hdl");
            if (String.IsNullOrEmpty(queryString))
            {
                return string.Empty;
            }

            //retrieve the xml text from the handle
            var text = UrlHandle.Get()["va"];
            if (String.IsNullOrEmpty(text))
            {
                return string.Empty;
            }

            //convert to xml element which will be what was stored in the Link field
            var xmlElement = XElement.Parse(text);
            if (xmlElement == null || !xmlElement.HasAttributes)
            {
                return string.Empty;
            }

            //Get the value of the previously stored ID of the goal that was selected
            var selectedValue = GetXmlAttributeValue(xmlElement, name);
            if (String.IsNullOrEmpty(selectedValue))
            {
                return string.Empty;
            }

            return selectedValue;
        }

        /// <summary>
        /// Gets a value from an XML attribute of the parsed in XML element
        /// </summary>
        /// <param name="xml">The XML element to read the attribute from.</param>
        /// <param name="attName">The attributes name</param>
        /// <returns>Value of the attribute</returns>
        public static string GetXmlAttributeValue(XElement xml, string attName)
        {
            if (xml.Attribute(attName) == null)
            {
                return string.Empty;
            }
            return xml.Attribute(attName).Value;
        }

        /// <summary>
        /// Shared function to initialise the combo box of goal and event items on Sheer dialogs
        /// </summary>
        /// <param name="combobox"></param>
        public static void InitializeCombobox(Combobox combobox, Data.Items.Item rootItem, string defaultItemText)
        {
            var items = rootItem?.Children;
            if (items.Any() && combobox != null)
            {
                foreach (var i in items.Select(x => new ListItem { Header = x.DisplayName, Value = x.ID.ToString(), Selected = false }))
                {
                    combobox.Controls.Add(i);
                }

                //Set the initial list item
                combobox.Controls.AddAt(0, new ListItem { Header = defaultItemText, Value = "", Selected = true });
            }
        }

        /// <summary>
        /// Shared function to set the selected value of a combo box after it has been initialised on Sheer dialogs.
        /// </summary>
        /// <param name="combobox"></param>
        /// <param name="selectedGoal"></param>
        public static void SetComboBoxSelectedValue(Combobox combobox, string selectedValue)
        {
            if (String.IsNullOrEmpty(selectedValue))
            {
                return;
            }

            foreach (var listItemControl in combobox.Controls)
            {
                var listItem = listItemControl as ListItem;
                listItem.Selected = listItem.Value.Equals(selectedValue);
            }
        }
    }
}