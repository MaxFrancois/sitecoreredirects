﻿define([], function () {
  var action = function (context, args) {
    var targetDisplayTextID = context.app[args.targetDisplayTextID],
      targetAnchorID = context.app[args.targetAnchorID],
      targetAltTextID = context.app[args.targetAltTextID],
      targetStyleID = context.app[args.targetStyleID],
      targetWindowID = context.app[args.targetWindowID],
	  targetGoalID = context.app[args.targetGoalID],
      targetEventID = context.app[args.targetEventID],
      template = '<link text="<%=text%>" linktype="anchor" url="<%=anchor%>" anchor="<%=anchor%>" title="<%=alternateText %>" class="<%=style%>" goal="<%=goal%>" event="<%=event%>" />',
      targetWindowValue, hyperLink,
      emptyOptionID = "{A3C9DB39-1D1B-4AA1-8C68-7B9674D055EE}",
      goalItemID = "{0CB97A9F-CAFB-42A0-8BE1-89AB9AE32BD9}",
      eventItemID = "{633273C1-02A5-4EBC-9B82-BD1A7C684FEA}",
      htmlEncode = function (str) {
        return str.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      };

    var selectedGoalID = targetGoalID.get("selectedValue");
    if (selectedGoalID === goalItemID) {
        selectedGoalID = "";
    }

    var selectedEventID = targetEventID.get("selectedValue");
    if (selectedEventID === eventItemID) {
        selectedEventID = "";
    }

    hyperLink = _.template(template, {
      text: htmlEncode(targetDisplayTextID.get("text")),
      style: htmlEncode(targetStyleID.get("text")),
      alternateText: htmlEncode(targetAltTextID.get("text")),
      anchor: htmlEncode(targetAnchorID.get("text")),
      url: targetAnchorID.get("text"),
      goal: selectedGoalID,
      event: selectedEventID
    });

    context.app.closeDialog(hyperLink);
  };  

  return action;
});
