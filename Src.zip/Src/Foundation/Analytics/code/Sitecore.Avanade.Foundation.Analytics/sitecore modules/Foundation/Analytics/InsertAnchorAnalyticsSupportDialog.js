﻿define(["sitecore"], function(Sitecore) {
    var InsertAnchorDialog = Sitecore.Definitions.App.extend({
        initialized: function () {

            this.updateOkButton();

            this.Text.on("change", function () {
                this.updateOkButton();
            }, this);

            //Initializes the drop down to a previously selected value if there was one.
            this.GoalsDataSource.on("change:items", function () {
                var selectedGoal = this.GoalsLoadedValue.get("text");
                if (selectedGoal !== "") {
                    this.Goals.set("selectedValue", selectedGoal);
                }
            }, this);

            //Initializes the drop down to a previously selected value if there was one.
            this.EventsDataSource.on("change:items", function () {
                var selectedEvent = this.EventsLoadedValue.get("text");
                if (selectedEvent !== "") {
                    this.Events.set("selectedValue", selectedEvent);
                }
            }, this);
        },

        updateOkButton: function () {

            var text = this.Text.get("text");

            if (text)
                this.InsetAnchor.set("isEnabled", true);
            else
                this.InsetAnchor.set("isEnabled", false);
        }

    });

    return InsertAnchorDialog;
});