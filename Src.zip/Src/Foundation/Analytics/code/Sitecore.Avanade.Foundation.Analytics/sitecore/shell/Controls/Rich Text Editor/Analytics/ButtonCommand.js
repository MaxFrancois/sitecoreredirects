﻿var scEditor = null;
var html = null;

Telerik.Web.UI.Editor.CommandList["InsertAiAnalytics"] = function (commandName, editor, args) {
    var d = Telerik.Web.UI.Editor.CommandList._getLinkArgument(editor);
    Telerik.Web.UI.Editor.CommandList._getDialogArguments(d, "A", editor, "DocumentManager");

    //selected text
    html = editor.getSelectionHtml();
    //the editor object, for later use
    scEditor = editor;

    //make sure we have a link element
    var aTagRegEx = new RegExp('<\s*a[^>]*>(.*?)<\s*/\s*a>');
    var match = aTagRegEx.exec(html);
    if (!match || match.length < 1) {
        alert('Invalid selection. Please try again.');
        return;
    }

    //Detect an existing goal selection in the link
    var goalDataAttr = new RegExp('data-scgoal=\\"(.+?)\\"');
    var match = goalDataAttr.exec(html);
    var selectedGoal = "";
    if (match && match.length > 1 && match[1]) {
        selectedGoal = match[1];
    }

    //Detect an existing event selection in the link
    var eventDataAttr = new RegExp('data-scevent=\\"(.+?)\\"');
    var match = eventDataAttr.exec(html);
    var selectedEvent = "";
    if (match && match.length > 1 && match[1]) {
        selectedEvent = match[1];
    }

    //show dialog if invalid selection
    //Open up the dialog
    editor.showExternalDialog(
        "/sitecore/shell/default.aspx?xmlcontrol=RichText.InsertAiAnalytics&la=" + scLanguage + (scDatabase ? "&databasename=" + scDatabase : "") + "&curr=" + scItemID + (selectedGoal != "" ? "&goal=" + encodeURI(selectedGoal) : "") + (selectedEvent != "" ? "&event=" + encodeURI(selectedEvent) : ""),
        null, //argument
        600,
        600,
        scInsertAnalyticsAttributes, //callback
        null, // callback args
        "Insert Analytics",
        true, //modal
        Telerik.Web.UI.WindowBehaviors.Close, // behaviors
        false, //showStatusBar
        false //showTitleBar
    );
};

function scInsertAnalyticsAttributes(sender, returnValue) {
    if (!returnValue | !html) {
        return;
    }

    var indexOfChar = html.indexOf(">")
    var firstPart = html.substr(0, indexOfChar);
    var secondPart = html.substr(indexOfChar);


    scEditor.pasteHtml(firstPart + (returnValue.goal !== "" ? " data-scgoal=\"" + returnValue.goal + "\"": "") + (returnValue.event !== "" ? " data-scevent=\"" + returnValue.event + "\"": "") + secondPart, "DocumentManager");
};