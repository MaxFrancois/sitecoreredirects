﻿function GetDialogArguments() {
    return getRadWindow().ClientParameters;
}

function getRadWindow() {
    if (window.radWindow) {
        return window.radWindow;
    }

    if (window.frameElement && window.frameElement.radWindow) {
        return window.frameElement.radWindow;
    }

    return null;
}

var isRadWindow = true;

var radWindow = getRadWindow();

if (radWindow) {
    if (window.dialogArguments) {
        radWindow.Window = window;
    }
}

function scClose(goals, events) {
    var returnValue = {
        goal: goals,
        event: events
    };

    getRadWindow().close(returnValue);

}

function scCancel() {
    getRadWindow().close();
}

/* Used when dialog launched from experience editor */
function scCloseWebEdit(result) {
    window.returnValue = result;
    window.close();
}

if (window.focus && Prototype.Browser.Gecko) {
    window.focus();
}