﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines.RenderField;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Extensions
{
    public static class RenderFieldArgumentExtensions
    {
        public static void CheckArguements(this RenderFieldArgs args)
        {
            Assert.ArgumentNotNull(args, "Arguments cannot be null.");
            Assert.ArgumentNotNull(args.Item, "Item in render field arguements is null.");
            Assert.ArgumentNotNull(Context.Item, "Context item not initialised.");
            Assert.ArgumentCondition(args.Aborted != true, "args.Aborted", "The pipeline has been aborted.");
        }

        public static bool IsRenderingEnabled(this RenderFieldArgs args)
        {
            var CurrentRendering = Mvc.Presentation.RenderingContext.CurrentOrNull;
            if(CurrentRendering != null)
            {
                var parameters = CurrentRendering.Rendering.Parameters;
                return !(parameters != null && parameters.Contains(Constants.SitecoreFields.DisableAnalyticsOnRendering));                
            }
            return true;
        }
    }
}