﻿using Sitecore.Data.Items;
using Sitecore.Mvc.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Extensions
{
    public static class FieldHtmlHelper
    {
        public static HtmlString Field(this SitecoreHelper helper, string fieldName, object parameters)
        {
            return helper.Field(fieldName, parameters);
        }

        public static HtmlString Field(this SitecoreHelper helper, string fieldName, Item item, object parameters)
        {
            return helper.Field(fieldName, item, parameters);
        }
    }
}