﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics
{
    public static class Settings
    {
        #region Private Variables
        private static bool? _isEnabled;
        private static string[] _allowedFields;
        #endregion

        #region Public variables
        public static bool IsEnabled
        {
            get
            {
                if(_isEnabled == null)
                {
                    _isEnabled = Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Analytics.AnalyticsTrigger.Enabled", true);
                }

                return _isEnabled.Value;
            }
        }

        public static string[] AllowedFields
        {
            get
            {
                if(_allowedFields == null)
                {
                    var setting = Configuration.Settings.GetSetting("AI.Foundation.Analytics.AnalyticsTrigger.Fieldlist", string.Empty);
                    _allowedFields = setting.ToLower().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                }

                return _allowedFields;
            }
        }

        #endregion
    }
}