﻿using Sitecore.Diagnostics;
using Sitecore.Utils;
using Sitecore.Web.UI.HtmlControls;
using Sitecore.Web.UI.Sheer;
using Sitecore.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Sheer.GeneralLink
{
    public class GeneralLinkFormWithAnalytics : Shell.Applications.Dialogs.GeneralLink.GeneralLinkForm
    {
        /// <summary>
        /// The goals combo box
        /// </summary>
        protected Combobox Goals;

        /// <summary>
        /// The event combo box
        /// </summary>
        protected Combobox Events;

        /// <summary>
        /// Gets or sets CurrentMode.
        /// </summary>
        /// <value>The current mode.</value>
        private string CurrentMode
        {
            get
            {
                string text = base.ServerProperties["current_mode"] as string;
                if (!string.IsNullOrEmpty(text))
                {
                    return text;
                }
                return "internal";
            }
            set
            {
                Assert.ArgumentNotNull(value, "value");
                base.ServerProperties["current_mode"] = value;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            Assert.ArgumentNotNull(e, "e");
            base.OnLoad(e);
            if (!Context.ClientPage.IsEvent)
            {
                CurrentMode = (base.LinkType ?? string.Empty);
                InitializeAnalyticsCombobox();
                SetAnalyticsComboboxSelectedValue();
            }
        }

        protected override void ParseLink(string link)
        {
            base.ParseLink(link);
            if (LinkAttributes != null)
            {
                var xmlDocument = XmlUtil.LoadXml(link);
                if (xmlDocument != null)
                {
                    var xmlNode = xmlDocument.SelectSingleNode("/link");
                    if (xmlNode != null)
                    {
                        //The goal attribute
                        LinkAttributes[Constants.XmlAttributes.Goal] = XmlUtil.GetAttribute(Constants.XmlAttributes.Goal, xmlNode);
                        //The event attribute
                        LinkAttributes[Constants.XmlAttributes.Event] = XmlUtil.GetAttribute(Constants.XmlAttributes.Event, xmlNode);
                    }
                }
            }
        }

        protected override void OnOK(object sender, EventArgs args)
        {
            Assert.ArgumentNotNull(sender, "sender");
            Assert.ArgumentNotNull(args, "args");

            Packet packet = new Packet("link", new string[0]);
            SetAttribute(packet, "linktype", this.CurrentMode);
            SetAttribute(packet, "text", this.Text);
            SetAttribute(packet, "title", this.Title);
            SetAttribute(packet, "class", this.Class);

            SetAttribute(packet, Constants.XmlAttributes.Goal, Goals.SelectedItem.Value);
            SetAttribute(packet, Constants.XmlAttributes.Event, Events.SelectedItem.Value);

            var currentMode = this.CurrentMode;
            bool flag = false;

            switch (currentMode)
            {
                case "internal":
                    flag = SetInternalLinkAttributes(packet);
                    break;
                case "media":
                    flag = SetMediaLinkAttributes(packet);
                    break;
                case "external":
                    flag = SetExternalLinkAttributes(packet);
                    break;
                case "mailto":
                    flag = SetMailToLinkAttributes(packet);
                    break;
                case "anchor":
                    flag = SetAnchorLinkAttributes(packet);
                    break;
                case "javascript":
                    flag = SetJavascriptLinkAttributes(packet);
                    break;
                default:
                    throw new ArgumentException($"Unsupported mode: {currentMode}");
            }

            if(flag)
            {
                SheerResponse.SetDialogValue(packet.OuterXml);
                SheerResponse.CloseWindow();
            }
        }

        /// <summary>
        /// The set anchor link attributes.
        /// </summary>
        /// <param name="packet">The packet.</param>
        /// <returns>The set anchor link attributes.</returns>
        private bool SetAnchorLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            string text = this.LinkAnchor.Value;
            if (text.Length > 0 && text.StartsWith("#", StringComparison.InvariantCulture))
            {
                text = text.Substring(1);
            }
            SetAttribute(packet, "url", text);
            SetAttribute(packet, "anchor", text);
            return true;
        }

        /// <summary>
		/// The set javascript link attributes.
		/// </summary>
		/// <param name="packet">The packet.</param>
		/// <returns>The set javascript link attributes.</returns>
		protected bool SetJavascriptLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            string text = this.JavascriptCode.Value;
            if (text.Length > 0 && text.IndexOf("javascript:", StringComparison.InvariantCulture) < 0)
            {
                text = "javascript:" + text;
            }
            SetAttribute(packet, "url", text);
            SetAttribute(packet, "anchor", string.Empty);
            return true;
        }

        /// <summary>
        /// The set mail to link attributes.
        /// </summary>
        /// <param name="packet">The packet.</param>
        /// <returns>The set mail to link attributes.</returns>
        protected bool SetMailToLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            string text = this.MailToLink.Value;
            text = StringUtil.GetLastPart(text, ':', text);
            if (!EmailUtility.IsValidEmailAddress(text))
            {
                SheerResponse.Alert("The e-mail address is invalid.", new string[0]);
                return false;
            }
            if (!string.IsNullOrEmpty(text))
            {
                text = "mailto:" + text;
            }
            SetAttribute(packet, "url", text ?? string.Empty);
            SetAttribute(packet, "anchor", string.Empty);
            return true;
        }

        /// <summary>
        /// The set media link attributes.
        /// </summary>
        /// <param name="packet">The packet.</param>
        /// <returns>The set media link attributes.</returns>
        protected bool SetMediaLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            var selectionItem = this.MediaLinkTreeview.GetSelectionItem();
            if (selectionItem == null)
            {
                Context.ClientPage.ClientResponse.Alert("Select a media item.");
                return false;
            }
            string linkTargetAttributeFromValue = GetLinkTargetAttributeFromValue(this.Target.Value, this.CustomTarget.Value);
            SetAttribute(packet, "target", linkTargetAttributeFromValue);
            SetAttribute(packet, "id", selectionItem.ID.ToString());
            return true;
        }

        /// <summary>
        /// The set internal link attributes.
        /// </summary>
        /// <param name="packet">The packet.</param>
        /// <returns>The set internal link attributes.</returns>
        protected bool SetInternalLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            var selectionItem = this.InternalLinkTreeview.GetSelectionItem();
            if (selectionItem == null)
            {
                Context.ClientPage.ClientResponse.Alert("Select an item.");
                return false;
            }
            string linkTargetAttributeFromValue = GetLinkTargetAttributeFromValue(this.Target.Value, this.CustomTarget.Value);
            string text = this.Querystring.Value;
            if (text.StartsWith("?", StringComparison.InvariantCulture))
            {
                text = text.Substring(1);
            }
            SetAttribute(packet, "anchor", this.LinkAnchor);
            SetAttribute(packet, "querystring", text);
            SetAttribute(packet, "target", linkTargetAttributeFromValue);
            SetAttribute(packet, "id", selectionItem.ID.ToString());
            return true;
        }

        /// <summary>
        /// The set external link attributes.
        /// </summary>
        /// <param name="packet">The packet.</param>
        /// <returns>The set external link attributes.</returns>
        protected bool SetExternalLinkAttributes(Packet packet)
        {
            Assert.ArgumentNotNull(packet, "packet");
            string text = this.Url.Value;
            if (text.Length > 0 && text.IndexOf("://", StringComparison.InvariantCulture) < 0 && !text.StartsWith("/", StringComparison.InvariantCulture))
            {
                text = "http://" + text;
            }
            string linkTargetAttributeFromValue = GetLinkTargetAttributeFromValue(this.Target.Value, this.CustomTarget.Value);
            SetAttribute(packet, "url", text);
            SetAttribute(packet, "anchor", string.Empty);
            SetAttribute(packet, "target", linkTargetAttributeFromValue);
            return true;
        }

        private void InitializeAnalyticsCombobox()
        {
            Helpers.DialogDropDownHelper.InitializeCombobox(Goals, Constants.Items.Goals, Globalization.Translate.Text("default-goal-selection"));
            Helpers.DialogDropDownHelper.InitializeCombobox(Events, Constants.Items.Events, Globalization.Translate.Text("default-event-selection"));
        }

        private void SetAnalyticsComboboxSelectedValue()
        {
            //The goal selected value
            var selectedGoal = LinkAttributes.Get(Constants.XmlAttributes.Goal);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Goals, selectedGoal);

            //The event selected value
            var selectedEvent = LinkAttributes.Get(Constants.XmlAttributes.Event);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Events, selectedEvent);
        }
    }
}