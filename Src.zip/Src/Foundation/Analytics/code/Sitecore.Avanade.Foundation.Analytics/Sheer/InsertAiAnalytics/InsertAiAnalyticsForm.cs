﻿using Sitecore.Diagnostics;
using Sitecore.Web;
using Sitecore.Web.UI.HtmlControls;
using Sitecore.Web.UI.Pages;
using Sitecore.Web.UI.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Sheer.InsertAiAnalytics
{
    public class InsertAiAnalyticsForm : DialogForm
    {
        /// <summary>
        /// The insert analytics form panel
        /// </summary>
        protected GridPanel AiAnalyticsForm;

        /// <summary>
        /// The goals combo box
        /// </summary>
        protected Combobox Goals;

        /// <summary>
        /// The events combo box
        /// </summary>
        protected Combobox Events;

        /// <summary>
        /// The current link label, 
        /// to display the link chosen 
        /// to add analytics to.
        /// </summary>
        protected Label CurrentSelection;

        /// <summary>
        /// Gets or sets the mode
        /// </summary>
        protected string Mode
        {
            get
            {
                string str = StringUtil.GetString(base.ServerProperties["Mode"]);
                if(String.IsNullOrEmpty(str))
                {
                    return "shell";
                }
                return str;
            }
            set
            {
                Assert.ArgumentNotNull(value, "value");
                base.ServerProperties["Mode"] = value;
            }
        }

        protected override void OnCancel(object sender, EventArgs args)
        {
            Assert.ArgumentNotNull(sender, "sender");
            Assert.ArgumentNotNull(args, "args");
            if(this.Mode.Equals("webedit"))
            {
                base.OnCancel(sender, args);
                return;
            }
            Web.UI.Sheer.SheerResponse.Eval("scCancel()");
        }

        protected override void OnLoad(EventArgs e)
        {
            Assert.ArgumentNotNull(e, "e");
            base.OnLoad(e);
            if(Context.ClientPage.IsEvent)
            {
                //Dont load anything while in postback / event
                return;
            }

            Mode = WebUtil.GetQueryString("mo");
            var scgoal = WebUtil.GetQueryString(Constants.DialogAttributes.Goal);
            var scevent = WebUtil.GetQueryString(Constants.DialogAttributes.Event);

            //Set the current selected values in label for users convienance
            CurrentSelection.Value = $"Goal: {scgoal}\n Event: {scevent}";

            Helpers.DialogDropDownHelper.InitializeCombobox(Goals, Constants.Items.Goals, Globalization.Translate.Text("default-goal-selection"));
            Helpers.DialogDropDownHelper.InitializeCombobox(Events, Constants.Items.Events, Globalization.Translate.Text("default-event-selection"));

            if(!String.IsNullOrEmpty(scgoal))
            {
                Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Goals, scgoal);
            }

            if(!String.IsNullOrEmpty(scevent))
            {
                Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Events, scevent);
            }
        }

        protected override void OnOK(object sender, EventArgs args)
        {
            Assert.ArgumentNotNull(sender, "sender");
            Assert.ArgumentNotNull(args, "args");

            //Get the seletced values from the combo boxes
            string goal = Goals.SelectedItem.Value;
            string events = Events.SelectedItem.Value;

            if (Mode.Equals("webedit"))
            {
                var result = $"{goal},{events}";
                Web.UI.Sheer.SheerResponse.SetDialogValue(StringUtil.EscapeJavascriptString(result));
                base.OnOK(sender, args);
            }
            else
            {
                var callText = $"scClose({StringUtil.EscapeJavascriptString(goal)}, {StringUtil.EscapeJavascriptString(events)})";
                Web.UI.Sheer.SheerResponse.Eval(callText);
            }
        }
    }
}