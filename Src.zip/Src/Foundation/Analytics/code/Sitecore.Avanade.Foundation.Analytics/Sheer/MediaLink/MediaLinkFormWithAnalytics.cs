﻿using Sitecore.Diagnostics;
using Sitecore.Web.UI.HtmlControls;
using Sitecore.Web.UI.Sheer;
using Sitecore.Xml;
using System;

namespace Sitecore.Avanade.Foundation.Analytics.Sheer.MediaLink
{
    public class MediaLinkFormWithAnalytics : Shell.Applications.Dialogs.MediaLink.MediaLinkForm
    {
        /// <summary>
        /// The goals combo box
        /// </summary>
        protected Combobox Goals;

        /// <summary>
        /// The event combo box
        /// </summary>
        protected Combobox Events;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (!Context.ClientPage.IsEvent)
            {
                InitializeAnalyticsCombobox();
                SetAnalyticsComboboxSelectedValue();
            }
        }

        protected override void OnOK(object sender, EventArgs args)
        {
            /* The following is extracted from Sitecore.Shell.Applications.Dialogs.MediaLink.MediaLinkForm */
            Assert.ArgumentNotNull(sender, "sender");
            Assert.ArgumentNotNull(args, "args");
            var selectedItem = MediaLinkTreeview.GetSelectionItem();
            if(selectedItem == null)
            {
                Context.ClientPage.ClientResponse.Alert("Select a media item.");
                return;
            }

            var linkTargetAttributeFromValue = GetLinkTargetAttributeFromValue(Target.Value, CustomTarget.Value);
            var packet = new Packet("link", new string[0]);
            SetAttribute(packet, "text", Text);
            SetAttribute(packet, "linktype", "media");
            SetAttribute(packet, "title", Title);
            SetAttribute(packet, "class", Class);
            SetAttribute(packet, "target", linkTargetAttributeFromValue);
            SetAttribute(packet, "id", selectedItem.ID.ToString());
            /* end extraction */
            SetAttribute(packet, Constants.XmlAttributes.Goal, Goals.SelectedItem.Value);
            SetAttribute(packet, Constants.XmlAttributes.Event, Events.SelectedItem.Value);

            /* continue extraction */
            SheerResponse.SetDialogValue(packet.OuterXml);
            SheerResponse.CloseWindow();
            /* end extraction */
        }

        protected override void ParseLink(string link)
        {
            base.ParseLink(link);
            if(LinkAttributes != null)
            {
                var xmlDocument = XmlUtil.LoadXml(link);
                if(xmlDocument != null)
                {
                    var xmlNode = xmlDocument.SelectSingleNode("/link");
                    if(xmlNode != null)
                    {
                        //The goal attribute
                        LinkAttributes[Constants.XmlAttributes.Goal] = XmlUtil.GetAttribute(Constants.XmlAttributes.Goal, xmlNode);
                        //The event attribute
                        LinkAttributes[Constants.XmlAttributes.Event] = XmlUtil.GetAttribute(Constants.XmlAttributes.Event, xmlNode);
                    }
                }
            }
        }

        private void InitializeAnalyticsCombobox()
        {
            Helpers.DialogDropDownHelper.InitializeCombobox(Goals, Constants.Items.Goals, Globalization.Translate.Text("default-goal-selection"));
            Helpers.DialogDropDownHelper.InitializeCombobox(Events, Constants.Items.Events, Globalization.Translate.Text("default-event-selection"));
        }

        private void SetAnalyticsComboboxSelectedValue()
        {
            //The goal selected value
            var selectedGoal = LinkAttributes.Get(Constants.XmlAttributes.Goal);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Goals, selectedGoal);

            //The event selected value
            var selectedEvent = LinkAttributes.Get(Constants.XmlAttributes.Event);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Events, selectedEvent);
        }
    }
}