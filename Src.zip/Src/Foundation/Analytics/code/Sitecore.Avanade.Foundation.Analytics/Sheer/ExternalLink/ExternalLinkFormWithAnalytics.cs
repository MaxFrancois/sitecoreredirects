﻿using Sitecore.Diagnostics;
using Sitecore.Xml;
using System;
using Sitecore.Web.UI.HtmlControls;
using Sitecore.Web.UI.Sheer;

namespace Sitecore.Avanade.Foundation.Analytics.Sheer.ExternalLink
{
    public class ExternalLinkFormWithAnalytics : Shell.Applications.Dialogs.ExternalLink.ExternalLinkForm
    {
        /// <summary>
        /// The goals combo box
        /// </summary>
        protected Combobox Goals;

        /// <summary>
        /// The events combo box
        /// </summary>
        protected Combobox Events;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (!Context.ClientPage.IsEvent)
            {
                InitialiseAnalyticsComboBox();
                SetAnalyticsComboBoxSelectedValue();
            }
        }

        protected override void OnOK(object sender, EventArgs args)
        {
            Assert.ArgumentNotNull(sender, "sender");
            Assert.ArgumentNotNull(args, "args");
            /*The following is taken from Sitecore.Shell.Applications.Dialog.ExternalLink */
            var path = GetPath();
            var linkTargetAttributeFromValue = GetLinkTargetAttributeFromValue(Target.Value, CustomTarget.Value);
            var packet = new Packet("link", new string[0]);
            SetAttribute(packet, "text", Text);
            SetAttribute(packet, "linktype", "external");
            SetAttribute(packet, "url", path);
            SetAttribute(packet, "anchor", string.Empty);
            SetAttribute(packet, "title", Title);
            SetAttribute(packet, "class", Class);
            SetAttribute(packet, "target", linkTargetAttributeFromValue);
            /*End Extraction*/

            SetAttribute(packet, Constants.XmlAttributes.Goal, Goals.SelectedItem.Value);
            SetAttribute(packet, Constants.XmlAttributes.Event, Events.SelectedItem.Value);

            /*Begin extraction*/
            SheerResponse.SetDialogValue(packet.OuterXml);
            SheerResponse.CloseWindow();
            /*End Extraction*/
        }

        protected override void ParseLink(string link)
        {
            base.ParseLink(link);
            if(LinkAttributes != null)
            {
                var xmlDocument = XmlUtil.LoadXml(link);
                if(xmlDocument != null)
                {
                    var xmlNode = xmlDocument.SelectSingleNode("/link");
                    if(xmlNode != null)
                    {
                        //The goal attribute
                        LinkAttributes[Constants.XmlAttributes.Goal] = XmlUtil.GetAttribute(Constants.XmlAttributes.Goal, xmlNode);
                        //The event attribute
                        LinkAttributes[Constants.XmlAttributes.Event] = XmlUtil.GetAttribute(Constants.XmlAttributes.Event, xmlNode);
                    }
                }
            }
        }

        private void InitialiseAnalyticsComboBox()
        {
            Helpers.DialogDropDownHelper.InitializeCombobox(Goals, Constants.Items.Goals, Globalization.Translate.Text("Please select a goal"));
            Helpers.DialogDropDownHelper.InitializeCombobox(Events, Constants.Items.Events, Globalization.Translate.Text("Please select an event"));
        }

        private void SetAnalyticsComboBoxSelectedValue()
        {
            //The selected goal
            var selectedGoal = LinkAttributes.Get(Constants.XmlAttributes.Goal);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Goals, selectedGoal);

            //The selected event
            var selectedEvent = LinkAttributes.Get(Constants.XmlAttributes.Event);
            Helpers.DialogDropDownHelper.SetComboBoxSelectedValue(Events, selectedEvent);
        }

        public virtual string GetPath()
        {
            var text = this.Url.Value;
            if(text.Length > 0 && text.IndexOf("://", StringComparison.InvariantCulture) < 0 && !text.StartsWith("/", StringComparison.InvariantCulture))
            {
                text = "http://" + text;
            }
            return text;
        }
    }
}