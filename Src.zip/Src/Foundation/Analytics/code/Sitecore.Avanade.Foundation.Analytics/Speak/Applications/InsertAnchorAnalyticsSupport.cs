﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics.Speak.Applications
{
    public class InsertAnchorAnalyticsSupport : Sitecore.Speak.Applications.InsertAnchor
    {
        /// <summary>
        /// The goals selected value rendering
        /// </summary>
        public Mvc.Presentation.Rendering GoalsLoadedValue { get; set; }

        /// <summary>
        /// The events selected value rendering
        /// </summary>
        public Mvc.Presentation.Rendering EventsLoadedValue { get; set; }

        public override void Initialize()
        {
            base.Initialize();
            
            //Initialize the goals drop down after checking that we have the control
            if(GoalsLoadedValue == null)
            {
                return;
            }
            GoalsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml();

            //Initialize the events drop down after checking that we have the control
            if(EventsLoadedValue == null)
            {
                return;
            }
            EventsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml(Constants.XmlAttributes.Event);
        }
    }
}