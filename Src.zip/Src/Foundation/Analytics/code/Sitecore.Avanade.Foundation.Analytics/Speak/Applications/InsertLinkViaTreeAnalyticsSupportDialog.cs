﻿using Sitecore.Mvc.Presentation;

namespace Sitecore.Avanade.Foundation.Analytics.Speak.Applications
{
    public class InsertLinkViaTreeAnalyticsSupportDialog : Sitecore.Speak.Applications.InsertLinkDialogTree
    {
        /// <summary>
        /// The Goals Loaded Value rendering. This holds the currently selected value
        /// to populate the combo box on load.
        /// </summary>
        public Rendering GoalsLoadedValue { get; set; }

        /// <summary>
        /// The Events Loaded Value rendering. This hold the currently selected value
        /// to populate the combo box on load.
        /// </summary>
        public Rendering EventsLoadedValue { get; set; }

        public override void Initialize()
        {
            //Run the original initialise method to get everything else setup
            base.Initialize();

            //Initialise the new goals drop down after checking that we have the control
            if (GoalsLoadedValue == null)
            {
                return;
            }

            //Assign the selected value
            GoalsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml();

            //Initialise the new events drop down after checking that we have the control
            if(EventsLoadedValue == null)
            {
                return;
            }

            //Assign the selected value
            EventsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml(Constants.XmlAttributes.Event);
        }
    }
}