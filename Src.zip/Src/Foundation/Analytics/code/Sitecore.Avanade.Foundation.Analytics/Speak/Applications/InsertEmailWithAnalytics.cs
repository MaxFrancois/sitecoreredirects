﻿

namespace Sitecore.Avanade.Foundation.Analytics.Speak.Applications
{
    public class InsertEmailWithAnalytics : Sitecore.Speak.Applications.InsertEmail
    {
        /// <summary>
        /// The Goals selected value rendering
        /// </summary>
        public Mvc.Presentation.Rendering GoalsLoadedValue { get; set; }

        /// <summary>
        /// The Events selected value rendering
        /// </summary>
        public Mvc.Presentation.Rendering EventsLoadedValue { get; set; }

        public override void Initialize()
        {
            base.Initialize();
            
            if(GoalsLoadedValue == null)
            {
                return;
            }
            GoalsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml();

            if(EventsLoadedValue == null)
            {
                return;
            }
            EventsLoadedValue.Parameters["Text"] = Helpers.DialogDropDownHelper.GetSetValueFromXml(Constants.XmlAttributes.Event);
        }
    }
}