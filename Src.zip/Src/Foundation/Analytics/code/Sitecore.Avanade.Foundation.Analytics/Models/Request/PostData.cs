﻿
namespace Sitecore.Avanade.Foundation.Analytics.Models.Request
{
    public class PostData
    {
        public string Tracking { get; set; }
        public string Goal { get; set; }
        public string Event { get; set; }
    }
}