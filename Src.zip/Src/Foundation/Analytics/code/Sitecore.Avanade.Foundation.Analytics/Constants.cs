﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Analytics
{
    public static class Constants
    {
        public static class SitecoreFields
        {
            public const string Tracking = "__Tracking";
            public const string DisableAnalyticsOnRendering = "DisableAIAnalyticsForThisRendering";
            public const string RichTextFieldTypeName = "rich text";
        }

        public static class XmlAttributes
        {
            public const string Goal = "goal";
            public const string Event = "event";
        }

        public static class DialogAttributes
        {
            public const string Goal = "goal";
            public const string Event = "event";
        }

        public static class DataAttributes
        {
            public const string Tracking = "data-sctracking";
            public const string Goal = "data-scgoal";
            public const string Event = "data-scevent";
        }

        public static class IDs
        {
            public static readonly string MarketingItem = "{33CFB9CA-F565-4D5B-B88A-7CDFE29A6D71}";
            public static readonly string Goals = "{0CB97A9F-CAFB-42A0-8BE1-89AB9AE32BD9}";
            public static readonly string Events = "{633273C1-02A5-4EBC-9B82-BD1A7C684FEA}";
        }

        public static class TemplateIDs
        {
            public static readonly string PageEvent = "{059CFBDF-49FC-4F14-A4E5-B63E1E1AFB1E}";
            public static readonly string Goal = "{475E9026-333F-432D-A4DC-52E03B75CB6B}";
        }

        public static class Items
        {
            private static Data.Items.Item _goals;
            public static Data.Items.Item Goals
            {
                get
                {
                    if(_goals == null)
                    {
                        _goals = Context.ContentDatabase.GetItem(IDs.Goals);
                    }
                    return _goals;
                }
            }

            private static Data.Items.Item _events;
            public static Data.Items.Item Events
            {
                get
                {
                    if(_events == null)
                    {
                        _events = Context.ContentDatabase.GetItem(IDs.Events);
                    }
                    return _events;
                }
            }
        }
    }
}