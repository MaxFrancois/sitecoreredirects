﻿using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Sitecore.Avanade.Foundation.Analytics.Attributes
{
    public class EnsureAnalyticsTrackerAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (!Sitecore.Analytics.Tracker.IsActive)
            {
                Sitecore.Analytics.Tracker.StartTracking();
            }
            base.OnActionExecuting(actionContext);
        }
    }
}