﻿using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Sitecore.Avanade.Foundation.Analytics.Attributes
{
    public class StopAnalyticsTrackingAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Cancels the tracking of the current request. This is generally used for WebAPI calls.
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (Sitecore.Analytics.Tracker.IsActive)
            {
                Sitecore.Analytics.Tracker.Current?.CurrentPage.Cancel();
            }

            base.OnActionExecuting(actionContext);
        }
    }
}