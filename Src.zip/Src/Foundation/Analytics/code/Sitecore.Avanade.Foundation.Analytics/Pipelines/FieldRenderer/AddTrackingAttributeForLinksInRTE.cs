﻿using Sitecore.Pipelines.RenderField;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;
using HtmlAgilityPack;
using Sitecore.Avanade.Foundation.Analytics.Extensions;

namespace Sitecore.Avanade.Foundation.Analytics.Pipelines.FieldRenderer
{
    public class AddTrackingAttributeForLinksInRte
    {
        public void Process(RenderFieldArgs args)
        {
            // filter down the results to ensure we only run this in a valid state
            if (Helpers.ContextPageModeHelper.IsSitecoreNOTInCorrectMode()
                || !Settings.IsEnabled
                || args?.Item == null
                || args.Aborted
                || args.Result.IsEmpty
                || string.IsNullOrEmpty(args.FieldValue)
                || !args.FieldTypeKey.Equals(Constants.SitecoreFields.RichTextFieldTypeName)
                || Sitecore.Context.Item == null
                || args.Item.ID.Equals(Sitecore.Context.Item.ID)
                || !args.IsRenderingEnabled()
                || !args.Item.Fields[Constants.SitecoreFields.Tracking].HasNoEmptyValue())
            {
                return;
            }

            var rteContent = new HtmlDocument();
            rteContent.LoadHtml(args.Result.FirstPart);
            var links = rteContent.DocumentNode.SelectNodes("//a");

            if (links != null && links.Any())
            {
                foreach (var link in links)
                {
                    link.SetAttributeValue(Constants.DataAttributes.Tracking, args.Item.ID.ToString());
                }
            }

            //Output once all links have the tracking data attribute
            args.Result.FirstPart = rteContent.DocumentNode.OuterHtml;
        }
    }
}