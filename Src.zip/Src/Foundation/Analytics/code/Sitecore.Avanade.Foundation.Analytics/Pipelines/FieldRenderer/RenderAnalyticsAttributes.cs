﻿using Sitecore.Pipelines.RenderField;
using Sitecore.Avanade.Foundation.Analytics.Extensions;

namespace Sitecore.Avanade.Foundation.Analytics.Pipelines.FieldRenderer
{
    public class RenderAnalyticsAttributes
    {
        public void Process(RenderFieldArgs args)
        {
            // filter down the results to ensure we only run this in a valid state
            if (Helpers.ContextPageModeHelper.IsSitecoreNOTInCorrectMode()
                || !Settings.IsEnabled
                || args?.Item == null
                || args.Aborted
                || args.Result.IsEmpty
                || string.IsNullOrEmpty(args.FieldValue)
                || args.FieldTypeKey.Equals(Constants.SitecoreFields.RichTextFieldTypeName)
                || !args.IsRenderingEnabled())
            {
                return;
            }

            //Kick off the analytics attributes field rendering pipeline
            Sitecore.Pipelines.CorePipeline.Run("ai.foundation.analytics.renderField", args);
        }
    }
}