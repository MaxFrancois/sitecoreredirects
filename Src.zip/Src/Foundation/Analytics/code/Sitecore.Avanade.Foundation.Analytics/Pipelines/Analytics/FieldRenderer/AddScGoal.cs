﻿using HtmlAgilityPack;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Analytics.Extensions;
using Sitecore.Pipelines.RenderField;
using Sitecore.Xml;
using System;

namespace Sitecore.Avanade.Foundation.Analytics.Pipelines.Analytics.FieldRenderer
{
    public class AddScGoal
    {
        public void Process(RenderFieldArgs args)
        {
            if (!args.Aborted
                && !string.IsNullOrEmpty(args.FieldValue)
                && args.FieldValue.Contains(Constants.XmlAttributes.Goal)
                && !args.Result.IsEmpty)
            {
                var xmlDocument = XmlUtil.LoadXml(args.FieldValue);
                if(xmlDocument != null)
                {
                    var xmlNode = xmlDocument.SelectSingleNode("/link");
                    if(xmlNode != null)
                    {
                        var goalAttr = XmlUtil.GetAttribute(Constants.XmlAttributes.Goal, xmlNode);
                        if (!String.IsNullOrEmpty(goalAttr))
                        {
                            var goalAttrAsShortID = new Data.ID(goalAttr).ToShortID().ToString();
                            var analyticsItem = Context.Items.Get(goalAttrAsShortID, () => Context.Database.GetItem(goalAttr));
                            if (analyticsItem != null)
                            {
                                var htmlNode = HtmlNode.CreateNode(args.Result.FirstPart);
                                if (htmlNode != null)
                                {
                                    htmlNode.SetAttributeValue(Constants.DataAttributes.Goal, goalAttr);
                                    args.Result.FirstPart = htmlNode.OuterHtml.Replace(args.Result.LastPart, "");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}