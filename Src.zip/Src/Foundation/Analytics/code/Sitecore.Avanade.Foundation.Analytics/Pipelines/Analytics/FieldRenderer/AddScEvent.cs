﻿using Sitecore.Pipelines.RenderField;
using Sitecore.Avanade.Foundation.Analytics.Extensions;
using System;
using Sitecore.Xml;
using Sitecore.Avanade.Foundation.Extensions;
using HtmlAgilityPack;

namespace Sitecore.Avanade.Foundation.Analytics.Pipelines.Analytics.FieldRenderer
{
    public class AddScEvent
    {
        public void Process(RenderFieldArgs args)
        {
            if (!args.Aborted
                && !string.IsNullOrEmpty(args.FieldValue)
                && args.FieldValue.Contains(Constants.XmlAttributes.Event)
                && !args.Result.IsEmpty)
            {
                var xmlDocument = XmlUtil.LoadXml(args.FieldValue);
                if (xmlDocument != null)
                {
                    var xmlNode = xmlDocument.SelectSingleNode("/link");
                    if (xmlNode != null)
                    {
                        var eventAttr = XmlUtil.GetAttribute(Constants.XmlAttributes.Event, xmlNode);
                        if (!String.IsNullOrEmpty(eventAttr))
                        {
                            var eventAttrAsShortID = new Data.ID(eventAttr).ToShortID().ToString();
                            var analyticsItem = Context.Items.Get(eventAttrAsShortID, () => Context.Database.GetItem(eventAttr));
                            if (analyticsItem != null)
                            {
                                var htmlNode = HtmlNode.CreateNode(args.Result.FirstPart);
                                if (htmlNode != null)
                                {
                                    htmlNode.SetAttributeValue(Constants.DataAttributes.Event, eventAttr);
                                    args.Result.FirstPart = htmlNode.OuterHtml.Replace(args.Result.LastPart, "");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}