﻿using HtmlAgilityPack;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Analytics.Extensions;
using Sitecore.Pipelines.RenderField;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Analytics.Pipelines.Analytics.FieldRenderer
{
    public class AddScTracking
    {
        public void Process(RenderFieldArgs args)
        {
            //Need to make sure that we want to only apply the event handler on datasource items only.
            //Context items will be handled by Sitecore natively.
            if (!args.Aborted
                && !args.Item.ID.Equals(Sitecore.Context.Item.ID))
            {
                //this isn't the context item, this is the selected datasource item, which may also be a child of the selected data source item
                //lets check the __Tracking field to see if anything is set. Child item overrides parent so we'll perform necessary checks
                //and check that an override parameter wasn't set in the Html helper function
                var item = args.Item;

                //This will be the selected data source in the current rendering
                var selectedDS = Mvc.Presentation.RenderingContext.CurrentOrNull?.Rendering.DataSource;


                if (!string.IsNullOrEmpty(selectedDS) &&
                    item.Paths.LongID.Contains(selectedDS) && //the parent of this item is the selected data source item for this rendering
                    item.HasField(Constants.SitecoreFields.Tracking) && //this item has a tracking field
                    !item.Fields[Constants.SitecoreFields.Tracking].HasNoEmptyValue() //this item hasn't any tracking set within its Tracking field
                    )
                {
                    item = Sitecore.Context.Database.GetItem(Data.ID.Parse(selectedDS));
                }

                if (item.HasField(Constants.SitecoreFields.Tracking) &&
                    item.Fields[Constants.SitecoreFields.Tracking].HasNoEmptyValue() &&
                    Settings.AllowedFields.Contains(args.FieldTypeKey) &&
                    !args.Result.IsEmpty)
                {
                    var htmlNode = HtmlNode.CreateNode($"{args.Result.FirstPart}");
                    if (htmlNode != null)
                    {
                        htmlNode.SetAttributeValue(Constants.DataAttributes.Tracking, args.Item.ID.ToString());

                        //The replace using the 'LastPart' is very hacky but I can't figure out another way....for the moment.
                        args.Result.FirstPart = htmlNode.OuterHtml.Replace(args.Result.LastPart, "");
                    }
                }
            }
        }
    }
}