﻿using Sitecore.Avanade.Foundation.Analytics.Attributes;
using Sitecore.Analytics;
using Sitecore.Analytics.Data;
using Sitecore.Analytics.Data.Items;
using Sitecore.Analytics.Tracking;
using Sitecore.Diagnostics;
using Sitecore.Services.Infrastructure.Web.Http;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Analytics.Controllers
{
    public class AnalyticsApiController : ServicesApiController
    {
        //POST: RegisterSitecoreAnalyticsAsync
        /// <summary>
        /// Triggers all analytics items associated on a front end element
        /// </summary>
        /// <param name="data"></param>
        /// <returns>A HttpResponseMessage contains a message for all resgiatrations.</returns>
        [EnsureAnalyticsTracker]
        [StopAnalyticsTracking]
        [HttpPost]
        public async Task<HttpResponseMessage> RegisterSitecoreAnalyticsAsync([System.Web.Http.FromBody]Models.Request.PostData data)
        {
            if(data == null)
            {
                return new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
            }

            //We need some bits to operate as we lose these when the new thread is started
            var CurrentSession = Tracker.Current.Session;
            var pageContext = CurrentSession.Interaction.PreviousPage;
            var CurrentInteractions = CurrentSession.Interaction;
            var db = Context.Database;

            var result = await Task.Run(() => ProcessAll(CurrentSession, pageContext, CurrentInteractions, db, data));
            return result;
        }

        #region Private methods
        private HttpResponseMessage ProcessCampaigns(IPageContext page, TrackingField field, Data.Database db)
        {
            //Get all the campains set in the field
            var list = field.CampaignIds;
            foreach(var current in list)
            {
                var id = new Data.ID(current);
                var campaignItem = db.GetItem(id);
                if(campaignItem != null)
                {
                    page.TriggerCampaign(new CampaignItem(campaignItem));
                }
                else
                {
                    Log.Error($"[AI.Analytics]: Campaign with ID {id} not found.", this);
                }
            }

            return new HttpResponseMessage(System.Net.HttpStatusCode.OK);
        }

        private HttpResponseMessage ProcessEvents(IPageContext page, TrackingField field)
        {
            //get all the events set on this tracking field
            var events = field.Events;

            //cycle through and register events
            foreach (TrackingField.PageEventData current in events)
            {
                var name = current.Name;
                var guid = current.PageEventDefinitionId;
                var data = current.Data;
                Assert.IsNotNull(name, "Page event name is not defined");
                Assert.IsNotNull(data, "Page event data is not defined");
                try
                {
                    var pageData = new PageEventData(name, guid)
                    {
                        ItemId = page.Item.Id,
                        Data = data,
                        DataKey = page.Url.Path
                    };
                    page.Register(pageData);
                }
                catch (Exception e)
                {
                    Log.Error($"[AI.Analytics]: Failed to trigger event from tracking field. Event name '{name}'", e, this);
                }
            }

            return new HttpResponseMessage(System.Net.HttpStatusCode.OK);
        }
        
        private HttpResponseMessage ProcessEvent(Data.Items.Item eventItem, IPageContext page, CurrentInteraction interaction)
        {
            Assert.IsNotNull(eventItem, "The Event Item is null");

            //register the page event item with the page
            var eventData = page.Register(new PageEventItem(eventItem));
            //Assign details
            eventData.Data = eventItem["Description"];
            eventData.ItemId = eventItem.ID.Guid;
            eventData.DataKey = page.Url.Path;

            //Register the modifications
            interaction.AcceptModifications();
            return new HttpResponseMessage(System.Net.HttpStatusCode.OK);
        }

        private HttpResponseMessage ProcessProfiles(CurrentInteraction interaction, TrackingField field)
        {
            //get all the profiles set in the tracking field
            var profiles = field.Profiles;
            foreach(var profileItem in profiles)
            {
                //make sure the profile is in the field
                if(profileItem.IsSavedInField)
                {
                    //need the key
                    var key = profileItem.Key;
                    if(!String.IsNullOrEmpty(key))
                    {
                        //based on the key, get the saved profile
                        var profile = interaction.Profiles[key];

                        //implement the score for the profile
                        profile.Score(profileItem);
                    }
                }
            }

            return new HttpResponseMessage(System.Net.HttpStatusCode.OK);
        }

        private HttpResponseMessage ProcessAll(Session session, IPageContext pageContext, CurrentInteraction interaction, Data.Database db, Models.Request.PostData data)
        {
            Assert.ArgumentNotNull(session, "The current session is null");
            Assert.ArgumentNotNull(pageContext, "The page context is null");
            Assert.ArgumentNotNull(interaction, "The current interactions is null");
            Assert.ArgumentNotNull(db, "The database is null");
            Assert.ArgumentNotNull(data, "Data posted data object is null");

            //first we'll process the tracking field of the datasource item
            var trackingResult = new HttpResponseMessage();
            var goalResult = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            var eventResult = new HttpResponseMessage(System.Net.HttpStatusCode.OK);

            #region Tracking Field
            if (!String.IsNullOrEmpty(data.Tracking))
            {
                var datasourceID = data.Tracking;
                var datasourceItem = db.GetItem(datasourceID);
                var trackingField = new TrackingField(datasourceItem.Fields[Constants.SitecoreFields.Tracking]);

                var campaignsResult = ProcessCampaigns(pageContext, trackingField, db);
                var eventsResult = ProcessEvents(pageContext, trackingField);
                var profilesResult = ProcessProfiles(interaction, trackingField);

                trackingResult.StatusCode = campaignsResult.StatusCode == System.Net.HttpStatusCode.OK && eventsResult.StatusCode == System.Net.HttpStatusCode.OK && profilesResult.StatusCode == System.Net.HttpStatusCode.OK
                                            ? System.Net.HttpStatusCode.OK
                                            : System.Net.HttpStatusCode.InternalServerError;
            }

            #endregion

            #region Goals
            if(!String.IsNullOrEmpty(data.Goal))
            {
                var goalItem = db.GetItem(new Data.ID(data.Goal));
                if (goalItem != null)
                {
                    goalResult = ProcessEvent(goalItem, pageContext, interaction);
                }
            }
            #endregion

            #region Events
            if(!String.IsNullOrEmpty(data.Event))
            {
                var eventItem = db.GetItem(new Data.ID(data.Event));
                if(eventItem != null)
                {
                    eventResult = ProcessEvent(eventItem, pageContext, interaction);
                }
            }
            #endregion

            var result = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
            result.Content = new StringContent($"Tracking: {trackingResult} - Goal: {goalResult} - Event: {eventResult}");
            return result;
        }
        #endregion
    }
}