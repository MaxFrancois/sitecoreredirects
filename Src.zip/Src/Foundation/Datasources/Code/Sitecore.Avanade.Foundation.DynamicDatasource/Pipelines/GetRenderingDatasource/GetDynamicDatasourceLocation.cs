﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Data.Items;
using Sitecore.Pipelines.GetRenderingDatasource;
using Sitecore.SecurityModel;

namespace Sitecore.Avanade.Foundation.DynamicDatasource.Pipelines.GetRenderingDatasource
{
    public class GetDynamicDatasourceLocation
    {
        /// <summary>
        /// RAllows for dynamic datasources to be created for each page or in a shared locatieon
        /// </summary>
        /// <param name="args">The arguments.</param>
        public void Process(GetRenderingDatasourceArgs args)
        {
            // if not enabled exit
            if(!Settings.IsEnabled
                || args == null)
            {
                return;
            }
                 
            // get the datasource and template data
            string dataSource = args.RenderingItem.Fields[Constants.Templates.Rendering.Fields.DatasourceLocationField].ValueSafe(useStandardValue: true);
            string template = args.RenderingItem.Fields[Constants.Templates.Rendering.Fields.DatasourceTemplateField].ValueSafe(useStandardValue: true);

            if (string.IsNullOrEmpty(dataSource) && // if datasource location is not set - add it dynamically
                !string.IsNullOrEmpty(template) &&  // and there is a datasource template assigned to it
                !string.IsNullOrEmpty(args.ContextItemPath))
            {
                // get start & contextItem
                Item contextItem = args.ContentDatabase.GetItem(args.ContextItemPath);
                Item templateItem = args.ContentDatabase.GetItem(template);
                
                // get your site instance
                var site = Sitecore.Context.Site.GetValidSiteContext(contextItem);

                // make sure we find the correct path, if not stop, we need to have the root and start item
                if (site != null
                    && (
                        contextItem.IsDescendantOfItem(site.GetHomeItem(contextItem))
                        || (Settings.IsTemplatesEnabled && contextItem.IsStandardValue())
                        )
                    )
                {
                    // get the references folder for the site
                    var siteSettingsReference = site.GetSettings(contextItem, xPath: $"./*[@@templateid='{Constants.Templates.References.Id}']");

                    // do we have any site settings setup
                    if (siteSettingsReference != null)
                    {
                        // set the site references
                        SiteReferences(args, siteSettingsReference, templateItem);

                        // set the page reference
                        PageReferences(args, siteSettingsReference, templateItem, contextItem);
                    }

                    // global references
                    GlobalReferences(args, templateItem);
                }
            }
        }

        #region TemplateReferenceItem
        /// <summary>
        /// Create or find the References required
        /// </summary>
        /// <param name="args"></param>
        /// <param name="parentItem"></param>
        /// <param name="templateItem"></param>
        /// <param name="displayName"></param>
        /// <returns>Return the Item</returns>
        private Item TemplateReferenceItem(GetRenderingDatasourceArgs args, Item parentItem, Item templateItem, string displayName)
        {
            // get out a valid ids
            string validTemplateId = templateItem.ID.ToLuceneID("N");

            // do we have the item
            var validSiteRefItem = parentItem.Axes.SelectSingleItem(validTemplateId);

            // get the valid site reference
            if (validSiteRefItem == null)
            {
                // set the user so we can track this
                using (new Sitecore.Security.Accounts.UserSwitcher("sitecore\\dyanmicdatasource", false))
                {
                    // make sure we disable security just in case
                    using (new SecurityDisabler())
                    {
                        // add the page referene (this is a folder)
                        validSiteRefItem = parentItem.Add(validTemplateId, (Sitecore.Data.Items.TemplateItem)args.ContentDatabase.GetItem(Constants.Templates.Bucket.Id));

                        // make sure we have a reference
                        if (validSiteRefItem != null)
                        {
                            // edit
                            validSiteRefItem.Editing.BeginEdit();

                            try
                            {
                                //We want to keep the display name same as what the user intended but correct the item name to reflect the right format
                                validSiteRefItem.Appearance.DisplayName = $"{displayName}: ('{templateItem.Name}')";
                            }
                            finally
                            {
                                // finish editing
                                validSiteRefItem.Editing.EndEdit();
                            }
                        }
                    }
                }

            }

            return validSiteRefItem;
        }
        #endregion

        #region Site References
        /// <summary>
        /// Get the Site references for the Component
        /// </summary>
        /// <param name="args"></param>
        /// <param name="siteSettingsReference"></param>
        /// <param name="templateItem"></param>
        private void SiteReferences(GetRenderingDatasourceArgs args, Item siteSettingsReference, Item templateItem)
        {
            // get the shared reference
            var siteReference = siteSettingsReference.Axes.SelectSingleItem($"./*[@@templateid='{Constants.Templates.SiteReferences.Id}']");

            // make sure we have our shared reference
            if (siteReference != null)
            {
                // create or find the reference
                Item validSiteRefItem = TemplateReferenceItem(args, siteReference, templateItem, "Site Reference");

                if (validSiteRefItem != null)
                {
                    args.DatasourceRoots.Add(validSiteRefItem);
                }
            }
        }
        #endregion

        #region Page References
        /// <summary>
        /// The Page References which is designed to find 'COMPONENT / PAGE'
        /// </summary>
        /// <param name="args"></param>
        /// <param name="siteSettingsReference"></param>
        /// <param name="templateItem"></param>
        /// <param name="contextItem"></param>
        private void PageReferences(GetRenderingDatasourceArgs args, Item siteSettingsReference, Item templateItem, Item contextItem)
        {
            // get the shared reference
            var pageReference = siteSettingsReference.Axes.SelectSingleItem($"./*[@@templateid='{Constants.Templates.PageReferences.Id}']");

            // make sure we have our shared reference
            if (pageReference != null)
            {
                // get out a valid ids
                string validTemplateId = templateItem.ID.ToLuceneID("N");
                string validContextId = contextItem.ID.ToLuceneID("N");

                // do we have the full reference
                var validPageReference = pageReference.Axes.SelectSingleItem(validTemplateId + "/" + validContextId);

                if (validPageReference == null)
                {
                    // we have to create the template bucket
                    var bucketTemplateReferenceItem = TemplateReferenceItem(args, pageReference, templateItem, "Page Reference");

                    if (bucketTemplateReferenceItem != null)
                    {
                        // we have to create the context reference
                        validPageReference = TemplateReferenceItem(args, bucketTemplateReferenceItem, contextItem, "Page Reference");
                    }
                }

                if (validPageReference != null)
                {
                    args.DatasourceRoots.Add(validPageReference);
                }
            }

        }
        #endregion

        #region Global References
        /// <summary>
        /// Global References which is found below the Foundation Settings Item
        /// </summary>
        /// <param name="args"></param>
        /// <param name="templateItem"></param>
        private void GlobalReferences(GetRenderingDatasourceArgs args, Item templateItem)
        {
            // get the shared reference
            var globalReference = Sitecore.Avanade.Foundation.Site.Helpers.Bedrock.FindFoundationItem(null, Constants.Templates.GlobalReferences.Id);

            // make sure we have our shared reference
            if (globalReference != null)
            {
                // get the template or create the template
                Item globalReferenceTemplate = TemplateReferenceItem(args, globalReference, templateItem, "Global Reference");

                // we have to double check
                if (globalReferenceTemplate != null)
                {
                    args.DatasourceRoots.Add(globalReferenceTemplate);
                }
            }
        }
        #endregion
    }
}
