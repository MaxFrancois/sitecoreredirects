﻿namespace Sitecore.Avanade.Foundation.DynamicDatasource
{
    public static class Settings
    {
        #region Private Variables
        private static bool? _isEnabled;
        private static bool? _isTemplatesEnabled;
        private static string _defaultPageReferencePath;
        private static string _defaultSiteReferencePath;
        private static string _globalReferencePath;
        #endregion

        #region Public Properties
        /// <summary>
        /// Enable the datasource module
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Configuration.Settings.GetBoolSetting("AI.Foundation.DynamicDatasource.Enabled", false);

                return _isEnabled.Value;
            }
        }

        // <summary>
        /// Enabling Templates
        /// </summary>
        public static bool IsTemplatesEnabled
        {
            get
            {
                _isTemplatesEnabled = _isTemplatesEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.DynamicDatasource.Templates.Enabled", false);

                return _isTemplatesEnabled.Value;

            }
        }

        /// <summary>
        /// The item path for the page references storage folder
        /// </summary>
        public static string DefaultPageReferencePath
        {
            get
            {
                if (string.IsNullOrEmpty(_defaultPageReferencePath))
                {
                    _defaultPageReferencePath = Configuration.Settings.GetSetting("AI.Foundation.DynamicDatasource.DefaultPageReferencePath", "Page Reference");
                }

                return _defaultPageReferencePath;

            }
        }

        /// <summary>
        /// The item path for the shared references storage folder
        /// </summary>
        public static string DefaultSiteReferencePath
        {
            get
            {
                if (string.IsNullOrEmpty(_defaultSiteReferencePath))
                {
                    _defaultSiteReferencePath = Configuration.Settings.GetSetting("AI.Foundation.DynamicDatasource.DefaultSiteReferencePath", "Site Reference");
                }

                return _defaultSiteReferencePath;

            }
        }

        /// <summary>
        /// The global reference path
        /// </summary>
        public static string GlobalReferencePath
        {
            get
            {
                if (string.IsNullOrEmpty(_globalReferencePath))
                {
                    _globalReferencePath = Configuration.Settings.GetSetting("AI.Foundation.DynamicDatasource.GlobalReferencePath", "/sitecore/system/Settings/Foundation/Dynamic Datasources");
                }

                return _globalReferencePath;

            }
        }

        #endregion

    }
}