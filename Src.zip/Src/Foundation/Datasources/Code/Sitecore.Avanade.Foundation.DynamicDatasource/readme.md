﻿Dynamic Data Source Module

What this does
===========================================================

This module adds a feature to allow creation of datasource content in two locations. Both under the settings node but one in the shared reference folder or page specific folder.
This page specific folder is created using the item:created pipleline. But restricted to when a content page item creation for certain sites that have this feature turned on. 
This is feature is turned on/off using the enableDynamicDataSource - true/false setting on each sitedefinition nodes (<sitecore><sites><site..></site>)
 

How to use it
===========================================================

Just ensure the
1. Sitecore.Avanade.Foundation.DynamicDataSource.config file gets pulled into the app_config/include folder
2. Create page/shared reference items from the tds project


