﻿namespace Sitecore.Avanade.Foundation.DynamicDatasource
{
    public static class Constants
    {
        public static class Templates
        {
            public static class Bucket
            {
                public const string Id = "{ADB6CA4F-03EF-4F47-B9AC-9CE2BA53FF97}";

                public const string Name = "Bucket";
            }

            public static class Rendering
            {
                public static class Fields
                {
                    public const string DatasourceLocationField = "Datasource Location";
                    public const string DatasourceTemplateField = "Datasource Template";
                }
            }

            public static class GlobalReferences
            {
                public const string Id = "{C60A2C49-36F2-4E4C-8599-A46F41C2B38C}";
            }

            public static class References
            {
                public const string Id = "{7A896659-025A-4086-BC1A-40D14ADD7B20}";
            }

            public static class PageReferences
            {
                public const string Id = "{923BD4B3-7C8E-4D3E-892C-8269ED4C68CF}";
            }

            public static class SiteReferences
            {
                public const string Id = "{53551A27-D668-4744-89D5-CCB6D242C854}";
            }
        }
    }
}