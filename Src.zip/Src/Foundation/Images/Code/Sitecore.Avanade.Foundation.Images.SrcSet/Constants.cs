﻿namespace Sitecore.Avanade.Foundation.Images.SrcSet
{
    public static class Constants
    {
        public const string FieldRichText = "rich text";

        public static class SrcSetSetting
        {
            public static class Template
            {
                public const string ID = "{ABFF7995-15AB-4670-A4E4-37743C7E65B4}";
                public static class Fields
                {
                    public const string Enabled = "Enabled";
                    public const string DefaultSizes = "DefaultSizes";
                    public const string RemoveAttributes = "RemoveAttributes";
                    public const string ExcludePaths = "ExcludePaths";
                    public const string FindMediaPatternRegex = "FindMediaPatternRegex";
                    public const string EnableRichTextParsing = "EnableRichTextParsing";

                }
            }
        }

        public static class Caches
        {
            public const string GlobalSettingItemCacheKey = "global-srcset-settingitem";
            public const string SiteSettingItemCacheKey = "site-srcset-settingitem";
            public const string SrcSetSettingCacheKey = "site-srcset-setting";
            public const string srcSetContextSettingKey = "site-srcset-context";

        }
    }
}