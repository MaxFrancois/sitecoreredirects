﻿using System;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Images.SrcSet
{
    public static class Settings
    {

        #region Find Media Pattern Regex
        /// <summary>
        /// Find the Media Pattern Regex
        /// </summary>
        public static string FindMediaPatternRegex
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting("AI.Foundation.Images.SrcSet.FindMediaPatternRegex", "%2F(%5BA-Fa-f0-9%5D%7B32%2C32%7D)%5C.ashx",
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.FindMediaPatternRegex, domainListFilter: true, processingData: (x) =>
                    {
                        if (!x.IsNullOrEmpty())
                        {
                            return System.Web.HttpUtility.HtmlDecode(x);
                        }

                        return string.Empty;
                    });
            }
        }
        #endregion

        #region Exclude Path
        /// <summary>
        /// Find the Media Pattern Regex
        /// </summary>
        public static string[] ExcludePath
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting<string[]>("AI.Foundation.Images.SrcSet.Exclude.Path", string.Empty,
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.ExcludePaths, domainListFilter: true, processingData: (x) =>
                    {
                        if (!x.IsNullOrEmpty())
                        {
                            // set the collection
                            return x.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        }

                        return new string[] { };
                    });
            }
        }
        #endregion

        #region Exclude Style
        /// <summary>
        /// Find the Media Pattern Regex
        /// </summary>
        public static string[] RemoveAttribute
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting<string[]>("AI.Foundation.Images.SrcSet.Remove.Attribute", string.Empty,
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.RemoveAttributes, domainListFilter: true, processingData: (x) =>
                    {
                        if (x.IsNullOrEmpty())
                        {
                            // set the collection
                            return x.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        }

                        return new string[] { };
                    });
            }
        }
        #endregion

        #region Src Set Values
        /// <summary>
        /// The default Source Set Values
        /// </summary>
        public static string[] SrcSetValues
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting<string[]>("AI.Foundation.Images.SrcSet.Values", string.Empty,
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.DefaultSizes, domainListFilter: true, processingData: (x) =>
                    {
                        if (x.IsNullOrEmpty())
                        {
                            // set the collection
                            return x.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        }

                        return new string[] { };
                    });
            }
        }
        #endregion

        #region Enabled
        /// <summary>
        /// Is the Src Set Enabled
        /// </summary>
        public static bool Enabled
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.Images.SrcSet.Enabled", false,
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.Enabled, domainListFilter: true);
            }
        }
        #endregion

        #region EnableRichTextParsing
        /// <summary>
        /// Are we enabling Rich Text Parsing
        /// </summary>
        public static bool EnableRichTextParsing
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.Images.SrcSet.RichText.Enabled", false,
                    Constants.SrcSetSetting.Template.ID, Constants.SrcSetSetting.Template.Fields.EnableRichTextParsing, domainListFilter: true);
            }
        }
        #endregion
        
    }
}