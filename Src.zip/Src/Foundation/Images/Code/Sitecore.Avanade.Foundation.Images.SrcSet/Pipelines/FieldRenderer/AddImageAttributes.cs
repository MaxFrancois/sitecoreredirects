﻿using System;
using System.Text.RegularExpressions;
using System.Web;
using System.Linq;

using HtmlAgilityPack;
using Sitecore.Data;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.RenderField;
using Sitecore.Resources.Media;

using Sitecore.Avanade.Foundation.Extensions;


namespace Sitecore.Avanade.Foundation.Images.SrcSet.Pipelines.FieldRenderer
{
    public class AddImageAttributes
    {
        #region Processing Method
        public void Process(RenderFieldArgs args)
        {
            //Check that we have an arguments object
            Assert.ArgumentNotNull(args, "args");

            //Check that we dont have a null for the field type key currently being processed
            Assert.ArgumentNotNull(args.FieldTypeKey, "args.FieldTypeKey");
            
            //Check that we are on a RTE before doing anything, return if we are not on a RTE field
            if (!Settings.Enabled
                || args.FieldTypeKey != Constants.FieldRichText
                || String.IsNullOrEmpty(args.FieldValue)
                || Sitecore.Context.PageMode.IsExperienceEditor
                || string.IsNullOrEmpty(Sitecore.Context.RawUrl)
                || (Settings.ExcludePath.Any(s => (s.IsNullOrEmpty() ? false : (Sitecore.Context.RawUrl.StartsWith(s)))))
                )
            {
                return;
            }

            //Process the image tags if any
            args.Result.FirstPart = ProcessImageTags(args);
        }
        #endregion

        #region Process Image Tags
        private string ProcessImageTags(RenderFieldArgs args)
        {
            //Construct a Html document with the field value
            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(args.FieldValue);

            //Find all the images in the field
            var imgs = htmlDocument.DocumentNode.SelectNodes("//img");

            //Check that we have some images to work with
            if (imgs == null || imgs.Count == 0)
                return args.Result.FirstPart;

            #region Process Image tags in current RTE field
            //Go over all the image elements and apply apply new attribute
            foreach (var img in imgs)
            {
                if (img == null) continue;
                
                //Setup a variable to hold the srcset attribute string
                var srcSetAttribute = new System.Text.StringBuilder();

                //Grab the source attribute
                var srcAtt = img.GetAttributeValue("src", string.Empty);
                if (String.IsNullOrEmpty(srcAtt)) continue;

                //find the media item id
                var mediaIdMatch = new Regex(Settings.FindMediaPatternRegex, RegexOptions.Compiled).Match(srcAtt);
                if (!mediaIdMatch.Success) continue;

                //Found the ID, construct an ID object from it
                var id = ID.Parse(mediaIdMatch.Groups[1].Value);
                if (id.IsNull) continue;

                //Now we can get the media item
                var mediaItem = Context.Database.GetItem(id);
                if (mediaItem == null) continue;

                //Counter so we dont append unwanted characters
                int counter = 0;

                #region Apply media URLs
                //Now we need to construct the full srcset attribute string by cycling through the set values
                foreach (var s in Settings.SrcSetValues)
                {
                    //Strip the width value and type
                    int dimValue;
                    string dimType = string.Empty;
                    Helper.SplitValues(s, out dimValue, out dimType);

                    //get the media url for this width
                    var mediaUrl = MediaManager.GetMediaUrl(mediaItem, Helper.GetMediaUrlOptions(dimType, dimValue));

                    //get the security hash
                    var securedMediaUrl = HashingUtils.ProtectAssetUrl(mediaUrl);

                    //Append string
                    srcSetAttribute.AppendFormat("{0} {1}", HttpUtility.UrlPathEncode(securedMediaUrl),
                        counter == (Settings.SrcSetValues.Length - 1)
                            ? s
                            : String.Concat(s, ", "));

                    //Increment the counter
                    counter++;
                }
                #endregion

                //Attach the attribute to the image element
                img.SetAttributeValue("srcset", srcSetAttribute.ToString());

                #region Remove Unwanted attributes
                //http://aceik.com.au/2015/06/02/resolve-rte-responsive-image-issue/
                // Describes an issue with RTE's adding in line styles when images have been edited within the RTE.
                // Outlines the need to strip thos attributes as follows

                // has auto null check
                Settings.RemoveAttribute.ForEach(x =>
                {
                    img.Attributes.Remove(x);
                });
                #endregion
            }
            #endregion

            //dump it out
            return htmlDocument.DocumentNode.OuterHtml;
        }
        #endregion
    }
}