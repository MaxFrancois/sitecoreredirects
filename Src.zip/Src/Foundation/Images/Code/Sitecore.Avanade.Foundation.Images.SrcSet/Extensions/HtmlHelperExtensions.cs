﻿using System;
using System.Text;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Mvc.Helpers;
using Sitecore.Resources.Media;
using System.Collections.Generic;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Images.SrcSet.Extensions
{
    public static class HtmlHelperExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="fieldname"></param>
        /// <param name="item"></param>
        /// <param name="srcset"></param>
        /// <param name="htmlAttributes"></param>
        /// <returns></returns>
        public static HtmlString Image(this SitecoreHelper helper, string fieldname, Item item, string[] srcset = null,
            object htmlAttributes = null, bool clearCache = false, string cacheBuster = "")
        {
            // make sure the image is valid
            if (string.IsNullOrEmpty(fieldname)
                || item == null
                || !item.HasField(fieldname))
            {
                return new HtmlString(string.Empty);
            }
            
            var mediaItem = item.Fields[fieldname].ConvertToMediaItem();
            return Image(helper, mediaItem, srcset ?? Settings.SrcSetValues, htmlAttributes, clearCache, cacheBuster);
        }

        public static HtmlString Image(this SitecoreHelper helper, MediaItem mediaItem, string[] srcset = null,
            object htmlAttributes = null, bool clearCache = false, string cacheBuster = "")
        {
            // add default, this causes issues if not passed in
            if (mediaItem == null)
            {
                return new HtmlString(string.Empty);
            }

            var sb = new StringBuilder();

            //Open the tag and add the src attribute
            sb.Append("<img src=\"");

            //new set of htmlAttributes for the tag
            Dictionary<string, object> newHtmlAttributes;

            //construct the media option object
            var options = GetMediaOptions(htmlAttributes, out newHtmlAttributes);

            //Are we busting the browser cache
            if (clearCache)
            {
                //Apply the source of the image, with a timestamp to clear the cache
                sb.Append(String.Concat(HttpUtility.UrlPathEncode(HashingUtils.ProtectAssetUrl(MediaManager.GetMediaUrl(mediaItem, options))), $"&t={(string.IsNullOrEmpty(cacheBuster) ? DateTime.Now.Ticks.ToString() : cacheBuster)}\" "));
            }
            else
            {
                //Apply the source of the image
                sb.Append(String.Concat(HttpUtility.UrlPathEncode(HashingUtils.ProtectAssetUrl(MediaManager.GetMediaUrl(mediaItem, options))), "\" "));
            }

            //Check the media item properties and apply the appropriate attributes
            //Alt
            object attValue = null;
            if (newHtmlAttributes.TryGetValue("alt", out attValue))
            {
                sb.AppendFormat("alt=\"{0}\" ", attValue);
                newHtmlAttributes.Remove("alt");
            }
            else if (!String.IsNullOrEmpty(mediaItem.Alt))
            {
                sb.AppendFormat("alt=\"{0}\" ", mediaItem.Alt);
            }

            //title
            object titleValue = null;
            if (newHtmlAttributes.TryGetValue("title", out titleValue))
            {
                sb.AppendFormat("title=\"{0}\"", titleValue);
                newHtmlAttributes.Remove("title");
            }
            else if (!String.IsNullOrEmpty(mediaItem.Title))
            {
                sb.AppendFormat("title=\"{0}\"", mediaItem.Title);
            }

            if (newHtmlAttributes.Any())
            {
                //cycle through the attributes
                foreach (var prop in newHtmlAttributes)
                {
                    sb.AppendFormat("{0}=\"{1}\" ", prop.Key, prop.Value);
                }
            }
            /* Any other tags that I've missed, add check and append here */

            //Close the tag
            sb.Append(" />");

            // if we have disabled Source set do not render
            if (Settings.Enabled && srcset != null)
            {
                return new HtmlString(ProcessMediaItem(sb.ToString(), srcset, mediaItem));
            }

            return new HtmlString(sb.ToString());
        }

        private static string ProcessMediaItem(string generatedTag, string[] srcset, MediaItem mediaItem = null, ImageField field = null)
        {
            if (srcset == null || !srcset.Any())
            {
                srcset = Settings.SrcSetValues;
            }

            //Initialise a string to hold it
            var srcsetValue = new System.Text.StringBuilder();

            //If we have passed a field into the function, then grab the mediaitem from it
            if (field != null)
            {
                mediaItem = field.MediaItem;
            }

            // make sure we can process
            if (mediaItem != null
                && srcset != null
                && srcset.Length > 0)
            {
                //We'll keep a count so we dont append unwanted characters in the loop
                int count = 0;

                //cycle through srcset values, generating media urls for them
                foreach (var s in srcset)
                {
                    int dimValue = 0; //this will hold the integer value
                    string dimName = string.Empty; //this will hold the dimension to change

                    Helper.SplitValues(s, out dimValue, out dimName);

                    //Generate the sitecore media url for this dimension
                    var sitecoreMediaUrl = MediaManager.GetMediaUrl(mediaItem, Helper.GetMediaUrlOptions(dimName, dimValue));

                    //Protect it
                    var protectedMediaUrl = HashingUtils.ProtectAssetUrl(sitecoreMediaUrl);

                    //make the string
                    srcsetValue.AppendFormat("{0} {1}", HttpUtility.UrlPathEncode(protectedMediaUrl), count == (srcset.Length - 1) ? s : String.Concat(s, ", "));

                    //increment count
                    count++;
                }

                //chop off the end of tag ('/>')
                generatedTag = generatedTag.Replace("/>", "");

                //Add the srcset attribute and close the tag
                generatedTag += String.Format("srcset=\"{0}\"//>", srcsetValue);
            }

            return generatedTag;
        }

        private static MediaUrlOptions GetMediaOptions(object htmlAttributes, out Dictionary<string, object> newHtmlAttributes)
        {
            if (htmlAttributes == null)
            {
                newHtmlAttributes = new Dictionary<string, object>();
                return new MediaUrlOptions();
            }

            var options = new MediaUrlOptions();
            newHtmlAttributes = htmlAttributes.GetType().GetProperties().ToDictionary(x => x.Name, x => x.GetValue(htmlAttributes));

            //max width
            if (newHtmlAttributes.ContainsKey("mw"))
            {
                int maxWidth = 0;
                if (int.TryParse(newHtmlAttributes["mw"].ToString(), out maxWidth))
                    options.MaxWidth = maxWidth;

                newHtmlAttributes.Remove("mw");
            }

            //max height
            if (newHtmlAttributes.ContainsKey("mh"))
            {
                int maxHeight = 0;
                if (int.TryParse(newHtmlAttributes["mh"].ToString(), out maxHeight))
                    options.MaxHeight = maxHeight;

                newHtmlAttributes.Remove("mh");
            }

            //width
            if (newHtmlAttributes.ContainsKey("w"))
            {
                int width = 0;
                if (int.TryParse(newHtmlAttributes["w"].ToString(), out width))
                    options.Width = width;

                newHtmlAttributes.Remove("w");
            }

            //height
            if (newHtmlAttributes.ContainsKey("h"))
            {
                int height = 0;
                if (int.TryParse(newHtmlAttributes["h"].ToString(), out height))
                    options.Height = height;

                newHtmlAttributes.Remove("h");
            }

            //Allow Stretch
            if (newHtmlAttributes.ContainsKey("as"))
            {
                bool allowStretch = false;
                if (bool.TryParse(newHtmlAttributes["as"].ToString(), out allowStretch))
                    options.AllowStretch = allowStretch;

                newHtmlAttributes.Remove("as");
            }

            return options;
        }
    }
}