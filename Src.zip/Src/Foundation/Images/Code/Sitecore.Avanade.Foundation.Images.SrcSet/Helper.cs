﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Sitecore.Resources.Media;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Images.SrcSet
{ 
    internal static class Helper
    {
        #region SplitValues
        /// <summary>
        /// Split the 'srcset' attribute values to determine width value to set
        /// </summary>
        /// <param name="fullString">The full string of the value</param>
        /// <param name="dimValue">The integer value</param>
        /// <param name="dimName">Type value</param>
        internal static void SplitValues(string fullString, out int dimValue, out string dimName)
        {
            //Setup a regex to detect only integers in the string
            var regex = new Regex(@"\d+");

            //split them
            var match = regex.Split(fullString);

            //assign back values
            Int32.TryParse(fullString.Replace(match[1], ""), out dimValue);
            dimName = match[1];
        }
        #endregion

        #region GetMediaUrlOptions
        /// <summary>
        /// Gets the media url options object based on the setsrc values parsed. Only w (Width) and h (Height) are accepted at the moment
        /// </summary>
        /// <param name="dimName"></param>
        /// <param name="dimValue"></param>
        /// <returns></returns>
        internal static MediaUrlOptions GetMediaUrlOptions(string dimName, int dimValue)
        {
            var mediaUrlOptions = new MediaUrlOptions();

            switch (dimName)
            {
                case "w":
                    mediaUrlOptions.MaxWidth = dimValue;
                    break;
                case "h":
                    mediaUrlOptions.MaxHeight = dimValue;
                    break;
                default:
                    break;
            }

            mediaUrlOptions.AllowStretch = false;

            return mediaUrlOptions;
        }
        #endregion
    }
}