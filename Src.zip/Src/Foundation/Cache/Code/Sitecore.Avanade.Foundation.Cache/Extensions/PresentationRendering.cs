﻿using System;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Cache.Extensions
{
    /// <summary>
    /// The Presentation Rendering Extension methods
    /// </summary>
    public static class PresentationRendering
    {
        #region ClearOnIndexUpdate
        /// <summary>
        /// Returns if the rendering needs to be cleared when an index is updated
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static bool ClearOnIndexUpdate(this Sitecore.Mvc.Presentation.Rendering render)
        {
            return render.RenderingItem.Caching.ClearOnIndexUpdate;
        }
        #endregion

        #region VaryByContextItem
        /// <summary>
        /// Returns if the rendering needs to vary by the Context Item
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static bool VaryByContextItem(this Sitecore.Mvc.Presentation.Rendering render)
        {
            return render.RenderingField("VaryByContext").IsChecked();
        }
        #endregion

        #region VaryByTimeout
        /// <summary>
        /// Returns if the rendering needs to vary by the timeout period.
        /// This is set in Sitecore as "00:00:00", with the following;
        /// First 00 = hours
        /// Second 00 = minutes
        /// Thrid 00 = seconds
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static TimeSpan VaryByTimout(this Sitecore.Mvc.Presentation.Rendering render)
        {
            string timeSpan = render.RenderingField("VaryByTimeout").ValueSafe();

            // make sure it's not set to nothing
            if (!timeSpan.IsNullOrEmpty() && !timeSpan.Equals("00:00:00"))
            {
                // get the base timeout as our default
                TimeSpan defaultTimeSpan = render.Caching.Timeout;

                // set the cache time span
                return Sitecore.DateUtil.ParseTimeSpan(timeSpan, defaultTimeSpan);
            }

            return render.Caching.Timeout;
        }
        #endregion

        #region VaryByCookie
        /// <summary>
        /// Returns if the rendering needs to vary by the Cookie
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static bool VaryByCookie(this Sitecore.Mvc.Presentation.Rendering render)
        {
            return render.RenderingField("VaryByCookie").IsChecked();
        }

        /// <summary>
        /// Returns if the rendering needs to vary by the Cookie
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static string VaryByCookieKey(this Sitecore.Mvc.Presentation.Rendering render)
        {
            return render.RenderingField("VaryByCookieKey").ValueSafe();
        }

        /// <summary>
        /// Returns if the rendering needs to vary by the Cookie Value
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static bool VaryByCookieValue(this Sitecore.Mvc.Presentation.Rendering render)
        {
            return render.RenderingField("VaryByCookieValue").IsChecked();
        }
        #endregion
    }
}
