﻿/********************************************************************************************** 
* Product:  Sitecore Ignition - Sitecore Core
* Author:   Christopher Giddings (http://www.christophergiddings.com)
* Details:  For sitecore version conditional compilcation symbols
*               - Sitecore 8.2-: Sitecore81 (Have to include old approach)
*               - Sitecore 8.2+: Sitecore82 (Have updated to include new ICache approach)
**********************************************************************************************/

using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;


namespace Sitecore.Avanade.Foundation.Cache
{
    /// <summary>
    /// Exposes various basic caching type
    /// </summary>
    public static class Cache
    {
        #region Private Constant
        /// <summary>
        /// Non publish key
        /// </summary>
        private const string NonPublishKey = "DontPublish-{0}";

        /// <summary>
        /// The base sitekey
        /// </summary>
        private const string SiteKey = "{0}-{1}-{2}-IgnitionCache";

        /// <summary>
        /// The global key
        /// </summary>
        private const string GlobalKey = "Global";
        #endregion

        #region Private Variables
        /// <summary>
        /// The caching collection singleton to hold the caching references
        /// </summary>
        private static ConcurrentDictionary<string, Sitecore.Caching.ICache> _cacheCollection = new ConcurrentDictionary<string, Sitecore.Caching.ICache>();
        #endregion

        #region GetBaseKey
        /// <summary>
        /// Gets the base key used for the both sitecore caching and the HttpRuntime cache
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="isGlobal">if set to <c>true</c> [is global].</param>
        /// <param name="siteName">Name of the site.</param>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="languageName">Name of the language</param>
        /// <returns></returns>
        private static string GetBaseKey(string key, bool isGlobal = false, string siteName = "", string databaseName = "", string languageName = "")
        {
            // the defaults
            string cacheKey = "";

            // the site name can be overridden
            if (string.IsNullOrEmpty(siteName))
            {
                if (Sitecore.Context.Site == null)
                {
                    siteName = Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.NoSiteName;
                    if (Foundation.Extensions.Diagnostics.Log.IsWarnEnabled && Settings.Caching.Util.LogsEnabled)
                    {
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Cache]: Sitecore: Error generating cache key can not find site name and it is not manually set for key:{key}", typeof(Cache));
                    }
                }
                else
                {
                    siteName = Sitecore.Context.Site.Name;
                }
            }

            // the database can be overridden
            if (string.IsNullOrEmpty(databaseName))
            {
                if (Sitecore.Context.Database == null)
                {
                    databaseName = Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.NoDBName;
                    if (Foundation.Extensions.Diagnostics.Log.IsWarnEnabled && Settings.Caching.Util.LogsEnabled)
                    {
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Cache]: Sitecore: Error generating cache key can not find database name and it is not manually set for key:{key}", typeof(Cache));
                    }
                }
                else
                {
                    databaseName = Sitecore.Context.Database.Name;
                }
            }

            // the language can be overridden
            if (string.IsNullOrEmpty(languageName))
            {
                if (Sitecore.Context.Language == null)
                {
                    languageName = Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.NoLangName;
                    if (Foundation.Extensions.Diagnostics.Log.IsWarnEnabled && Settings.Caching.Util.LogsEnabled)
                    {
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Cache]: Sitecore: Error generating cache key can not find language name and it is not manually set for key:{key}", typeof(Cache));
                    }
                }
                else
                {
                    languageName = Sitecore.Context.Language.Name;
                }
            }

            // are we on the global cache
            if (isGlobal)
            {
                // set the global cache key
                cacheKey = string.Format(SiteKey, GlobalKey, databaseName, languageName);
            }
            else
            {
                // get the site root site
                cacheKey = string.Format(SiteKey, siteName, databaseName, languageName);
            }

            return cacheKey;
        }
        #endregion

        #region SitecoreCache
        /// <summary>
        /// The easy way to fetch the cache in a locked way
        /// </summary>
        /// <param name="key">The unique key</param>
        /// <param name="isGlobal">Is the</param>
        /// <param name="siteName">Name of the site.</param>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="languageName">Name of the language</param>
        /// <returns>Returns the sitecore cache instance</returns>
        /// 
        private static Sitecore.Caching.ICache SitecoreCache(string key, bool isGlobal = false, string siteName = "", string databaseName = "", string languageName = "")
        {
            // sets the default cache key
            string cacheKey = GetBaseKey(key, isGlobal, siteName, databaseName, languageName);

            // caching reference
            Sitecore.Caching.ICache cache = null;

            if (!_cacheCollection.IsEmpty && _cacheCollection.ContainsKey(cacheKey))
            {
                // fetch the cache from the collection
                cache = _cacheCollection[cacheKey];
            }

            // was there data
            if (cache == null)
            {
                // make sure we have not created this within the time period
                if (!_cacheCollection.ContainsKey(cacheKey))
                {
                    // we need to lock the cache due to multi threaded features
                    // fetches from the settings, but has a default size
                    cache = Sitecore.Caching.CacheManager.GetNamedInstance(cacheKey, Settings.Caching.Util.DefaultCacheSize, true);

                    // add new reference to the singleton
                    _cacheCollection.TryAdd(cacheKey, cache);
                }
                else
                {
                    // fetch the cache from the collection
                    cache = _cacheCollection[cacheKey];
                }
            }

            // return our object
            return cache;
        }
        #endregion

        #region HasCachedItem
        /// <summary>
        /// Is the cached item found in the list
        /// </summary>
        /// <param name="cacheKey">The cache key we are looking for</param>
        /// <param name="useSitecoreCache">Do you want to use Sitecore cache or the HttpRuntime cache object</param>
        /// <param name="globalCache">Do we use the global cache</param>
        /// <param name="siteName">The sitename</param>
        /// <param name="databaseName">The database name</param>
        /// <param name="languageName">The language name</param>
        /// <returns>Returns the cached data or null</returns>
        public static bool Has(string cacheKey,
            bool useSitecoreCache = true,
            bool globalCache = false,
            string siteName = "",
            string databaseName = "",
            string languageName = "")
        {
            // default
            bool isCachedItemFound = false;

            // no key so return error
            if (!Settings.Caching.IsEnabled
                || !Settings.Caching.Util.Enabled
                || string.IsNullOrEmpty(cacheKey)
                || (Sitecore.Configuration.State.Previewing
                            || Sitecore.Configuration.State.WebEditing
                            || Sitecore.Configuration.State.DebugMode))
            {
                return isCachedItemFound;
            }

            // produce the valid key we want to use
            string key = cacheKey.ToLower();

            // what type of cache are we using
            if (useSitecoreCache)
            {
                // get the cache we are looking for
                Sitecore.Caching.ICache cache = SitecoreCache(cacheKey, globalCache, siteName, databaseName, languageName);

                if (cache != null)
                {
                    // use the sitecore cache
                    if (cache.ContainsKey(key))
                    {
                        isCachedItemFound = true;
                    }
                    else
                    {
                        // the item might be a non publish key
                        key = string.Format(NonPublishKey, key).ToLower();

                        // get the data if found
                        if (cache.ContainsKey(key))
                        {
                            isCachedItemFound = true;
                        }
                    }
                }
            }
            else
            {
                // set the cache key
                string globalBaseKey = GetBaseKey(cacheKey, globalCache, siteName, databaseName, languageName);
                string cacheStartKey = globalBaseKey + key;

                // get the cache item from the http runtime
                object cachedItem = System.Web.HttpRuntime.Cache.Get(cacheStartKey.ToLower());

                // is empty try a non-published item
                if (cachedItem == null)
                {
                    // the item might be a non publish key
                    cacheStartKey = (globalBaseKey + string.Format(NonPublishKey, key)).ToLower();

                    // get the non publish clearing item
                    cachedItem = System.Web.HttpRuntime.Cache.Get(cacheStartKey);
                }

                if (cachedItem != null)
                {
                    isCachedItemFound = true;
                }
            }

            // return the data or null
            return isCachedItemFound;
        }
        #endregion

        #region GetCachedItem
        /// <summary>
        /// Loads the cache from the page caching
        /// </summary>
        /// <typeparam name="T">The type of parameter to cast the list to</typeparam>
        /// <param name="cacheKey">The cache key we are looking for</param>
        /// <param name="useSitecoreCache">Do you want to use Sitecore cache or the HttpRuntime cache object</param>
        /// <param name="globalCache">Do we use the global cache</param>
        /// <param name="siteName">The sitename</param>
        /// <param name="databaseName">The database name</param>
        /// <param name="languageName">Language name</param>
        /// <returns>Returns the cached data or null</returns>
        public static T Get<T>(string cacheKey,
            bool useSitecoreCache = true,
            bool globalCache = false,
            string siteName = "",
            string databaseName = "",
            string languageName = "")
        {
            // no key so return error
            if (!Settings.Caching.IsEnabled
                || !Settings.Caching.Util.Enabled
                || string.IsNullOrEmpty(cacheKey)
                || (Sitecore.Configuration.State.Previewing
                            || Sitecore.Configuration.State.WebEditing
                            || Sitecore.Configuration.State.DebugMode))
            {
                return default(T);
            }

            // setup the default object we will use
            T cachedItem = default(T);

            // produce the valid key we want to use
            string key = cacheKey.ToLower();

            // what type of cache are we using
            if (useSitecoreCache)
            {
                // get the cache we are looking for
                Sitecore.Caching.ICache cache = SitecoreCache(cacheKey, globalCache, siteName, databaseName, languageName);

                if (cache != null)
                {
                    // make ure the system has the key before doing anything
                    if (cache.ContainsKey(key))
                    {
                        // get the data from the sitecore cache
                        cachedItem = (T)cache[key];
                    }
                    else
                    {
                        // the item might be a non publish key
                        key = string.Format(NonPublishKey, key).ToLower();

                        // get the data if found
                        if (cache.ContainsKey(key))
                        {
                            // get the data from the sitecore cache
                            cachedItem = (T)cache[key];
                        }
                    }
                }
            }
            else
            {
                // set the cache key
                string globalBaseKey = GetBaseKey(cacheKey, globalCache, siteName, databaseName, languageName);
                string cacheStartKey = globalBaseKey + key;

                // get the cache item from the http runtime
                cachedItem = (T)System.Web.HttpRuntime.Cache.Get(cacheStartKey.ToLower());

                // is empty try a non-published item
                if (cachedItem == null)
                {
                    // the item might be a non publish key
                    cacheStartKey = (globalBaseKey + string.Format(NonPublishKey, key)).ToLower();

                    // get the non publish clearing item
                    cachedItem = (T)System.Web.HttpRuntime.Cache.Get(cacheStartKey);
                }
            }

            // return the data or null
            return cachedItem;
        }

        /// <summary>
        /// Loads the cache from the page caching.
        /// This method requires a function delegate to be passed, to create the cache entry, in case it is non-existent.
        /// </summary>
        /// <typeparam name="T">The type of parameter to cast the list to</typeparam>
        /// <param name="cacheKey">The cache key we are looking for</param>
        /// <param name="InsertObjectsToCache">The function to call, to perform the object retrieval, if the specified cache entry is non-existent</param>
        /// <param name="useSitecoreCache">Do you want to use Sitecore cache or the HttpRuntime cache object</param>
        /// <param name="globalCache">Do we use the global cache</param>
        /// <param name="siteName">The sitename</param>
        /// <param name="databaseName">The database name</param>
        /// <param name="languageName">Language name</param>
        /// <returns>Returns the cached data or null</returns>
        public static T Get<T>(string cacheKey,
            Func<T> InsertObjectsToCache,
            object cacheTimer = null,
            bool isNoSlidingExpiration = true,
            bool useSitecoreCache = true,
            bool globalCache = false,
            bool removeOnPublish = true,
            string siteName = "",
            string databaseName = "",
            string languageName = "",
            System.Web.Caching.CacheDependency cacheDep = null,
            System.Web.Caching.CacheItemPriority priority = System.Web.Caching.CacheItemPriority.Normal,
            System.Web.Caching.CacheItemRemovedCallback callback = null)
        {
            // set default data just incase
            T returnData;

            // do we have the item
            if (Has(cacheKey, useSitecoreCache, globalCache, siteName, databaseName, languageName))
            {
                // get the item
                returnData = Get<T>(cacheKey,
                                useSitecoreCache,
                                globalCache,
                                siteName,
                                databaseName,
                                languageName);
            }
            else
            {
                // execute the function
                returnData = InsertObjectsToCache();

                // get the returning data
                if (returnData != null)
                {
                    // add the data to the items
                    Add(cacheKey,
                        returnData,
                        cacheTimer,
                        isNoSlidingExpiration,
                        useSitecoreCache,
                        globalCache,
                        removeOnPublish,
                        siteName,
                        databaseName,
                        languageName,
                        cacheDep,
                        priority,
                        callback);
                }
            }

            return returnData != null ? returnData : default(T);
        }

        #endregion

        #region SaveCachedItem
        /// <summary>
        /// Saves the list to the cache
        /// </summary>
        /// <typeparam name="T">The type of parameter that will be saved</typeparam>
        /// <param name="cacheKey">The unique key to save</param>
        /// <param name="cachingData">The data to cache</param>
        /// <param name="cacheTimer">The time we want to cache this data</param>
        /// <param name="isNoSlidingExpiration">Is the cacheTimer an Absolute Expiration (default) or a sliding expiration</param>
        /// <param name="useSitecoreCache">Do you want to use Sitecore cache or the HttpRuntime cache object</param>
        /// <param name="globalCache">Is the data to be stored in the global cache or site specific cache</param>
        /// <param name="removeOnPublish">Remove the contents on a publish, this is defaulted as true</param>
        /// <param name="siteName">Force set the site name, if this is run from a scheduled task this should be set</param>
        /// <param name="databaseName">Force the database if this is run from a scheduled tasks, this should be set</param>
        /// <param name="languageName">Sets the language name, this is not mandatory</param>
        /// <param name="cacheDep">Any caching dependencies for the cache. NOTE: Not valid for Sitecore Caching</param>
        /// <param name="priority">The priority of the cache. NOTE: Not valid for Sitecore Caching</param>
        /// <param name="callback">The call-back function of the cache. NOTE: Not valid for Sitecore Caching</param>
        public static void Add(string cacheKey, object cachingData,
            object cacheTimer = null,
            bool isNoSlidingExpiration = true,
            bool useSitecoreCache = true,
            bool globalCache = false,
            bool removeOnPublish = true,
            string siteName = "",
            string databaseName = "",
            string languageName = "",
            System.Web.Caching.CacheDependency cacheDep = null,
            System.Web.Caching.CacheItemPriority priority = System.Web.Caching.CacheItemPriority.Normal,
            System.Web.Caching.CacheItemRemovedCallback callback = null)
        {
            // make sure we have data
            if (Settings.Caching.IsEnabled && Settings.Caching.Util.Enabled
                && !string.IsNullOrEmpty(cacheKey)
                && cachingData != null
                && !(Sitecore.Configuration.State.Previewing
                            || Sitecore.Configuration.State.WebEditing
                            || Sitecore.Configuration.State.DebugMode))
            {
                // set the key so we can override it
                string key = cacheKey.ToLower();

                if (!removeOnPublish)
                {
                    key = string.Format(NonPublishKey, key).ToLower();
                }

                // setup defaults for caching types
                TimeSpan slidingCache = System.Web.Caching.Cache.NoSlidingExpiration;
                DateTime absoluteCache = System.Web.Caching.Cache.NoAbsoluteExpiration;

                if (cacheTimer != null)
                {
                    // set the cache type
                    if (isNoSlidingExpiration)
                    {
                        if (cacheTimer.GetType().Equals(typeof(DateTime)))
                        {
                            absoluteCache = (DateTime)cacheTimer;
                        }
                        else
                        {
                            // we have an issue fix up
                            TimeSpan timeSpanCheck = (TimeSpan)cacheTimer;
                            absoluteCache = DateTime.Now.Add(timeSpanCheck);
                        }

                        // Sitecore Caches via UTC have to make sure we use this instead of local
                        if (absoluteCache.Kind != DateTimeKind.Utc)
                        {
                            // convert to UTC
                            absoluteCache = absoluteCache.ToUniversalTime();
                        }
                    }
                    else
                    {
                        // make sure it's right
                        if (cacheTimer.GetType().Equals(typeof(TimeSpan)))
                        {
                            slidingCache = (TimeSpan)cacheTimer;
                        }
                        else
                        {
                            // we have an issue fix up
                            DateTime dateCheck = (DateTime)cacheTimer;
                            slidingCache = dateCheck.Subtract(DateTime.Now);
                        }
                    }
                }

                // what type of cache are we using
                if (useSitecoreCache)
                {
                    #region Sitecore Cache
                    // get the cache key
                    Sitecore.Caching.ICache cache = SitecoreCache(cacheKey, globalCache, siteName, databaseName, languageName);

                    // quickly perfom a check
                    if (cache.ContainsKey(key))
                    {
                        // use the sitecore cache
                        cache.Remove(key);
                    }

                    // use the sitecore cache
                    cache.Add(key.ToLower(), cachingData, slidingCache, absoluteCache);

                    #endregion
                }
                else
                {
                    #region HttpRuntime Cache
                    // set the cache key
                    string cacheStartKey = GetBaseKey(cacheKey, globalCache, siteName, databaseName, languageName) + key;

                    // do we have something to call back when removing
                    if (callback == null)
                    {
                        System.Web.HttpRuntime.Cache.Insert(cacheStartKey.ToLower(), cachingData, cacheDep, absoluteCache, slidingCache);
                    }
                    else
                    {
                        System.Web.HttpRuntime.Cache.Insert(cacheStartKey.ToLower(), cachingData, cacheDep, absoluteCache, slidingCache, priority, callback);
                    }
                    #endregion
                }
            }
        }
        #endregion

        #region RemoveCacheItem
        /// <summary>
        /// Removes the required item from the cache
        /// </summary>
        /// <typeparam name="T">The type of object to retrun from the cache</typeparam>
        /// <param name="cacheKey">The cache key</param>
        /// <param name="useSitecoreCache">Do we want to use the cache</param>
        /// <param name="globalCache">Are we using the global cache</param>
        /// <param name="siteName">The sitename</param>
        /// <param name="databaseName">The database name</param>
        /// <param name="languageName">The language name</param>
        /// <returns>Returns true if the data was removed from the cache or false if it wasnt or there was an error</returns>
        public static bool Remove(string cacheKey,
            bool useSitecoreCache = true,
            bool globalCache = false,
            string siteName = "",
            string databaseName = "",
            string languageName = "")
        {

            // is caching disabled
            if (!Settings.Caching.IsEnabled || !Settings.Caching.Util.Enabled)
            {
                return true;
            }

            // no key so return error
            if (string.IsNullOrEmpty(cacheKey))
            {
                return false;
            }

            // produce the valid key we want to use
            string key = cacheKey.ToLower();

            // what type of cache are we using
            if (useSitecoreCache)
            {
                // get the cache we are looking for
                Sitecore.Caching.ICache cache = SitecoreCache(cacheKey, globalCache, siteName, databaseName, languageName);

                // kill
                if (cache == null)
                {
                    return true;
                }

                // data is not found
                bool isFound = false;

                // use the sitecore cache
                if (cache.ContainsKey(key))
                {
                    isFound = true;
                }
                else
                {
                    // the item might be a non publish key
                    key = string.Format(NonPublishKey, key).ToLower();

                    // get the data if found
                    if (cache.ContainsKey(key))
                    {
                        isFound = true;
                    }
                }

                // is the data found
                if (isFound
                    && cache.ContainsKey(key))
                {
                    // use the sitecore cache
                    cache.Remove(key);
                }
            }
            else
            {
                // set the cache key
                string globalBaseKey = GetBaseKey(cacheKey, globalCache, siteName, databaseName, languageName);
                string cacheStartKey = globalBaseKey + key;

                // removes the cache key
                System.Web.HttpRuntime.Cache.Remove(cacheStartKey.ToLower());

                // remove the non publish key
                System.Web.HttpRuntime.Cache.Remove((globalBaseKey + string.Format(NonPublishKey, key)).ToLower());
            }

            // data removed
            return true;
        }
        #endregion


        #region SearchRemove
        /// <summary>
        /// Searches the cache item and removes
        /// </summary>
        /// <typeparam name="T">The type of object to retrun from the cache</typeparam>
        /// <param name="cacheKeyLookup">The cache key to lookup</param>
        /// <param name="useSitecoreCache">Do we want to use the cache</param>
        /// <param name="globalCache">Are we using the global cache</param>
        /// <param name="siteName">The sitename</param>
        /// <param name="databaseName">The database name</param>
        /// <param name="languageName">The language name</param>
        /// <returns>Returns true if the data was removed from the cache or false if it wasnt or there was an error</returns>
        public static bool SearchRemove(string cacheKeyLookup,
            bool useSitecoreCache = true,
            bool globalCache = false,
            string siteName = "",
            string databaseName = "",
            string languageName = "")
        {

            // is caching disabled
            if (!Settings.Caching.IsEnabled || !Settings.Caching.Util.Enabled)
            {
                return true;
            }

            // no key so return error
            if (string.IsNullOrEmpty(cacheKeyLookup))
            {
                return false;
            }

            // produce the valid key we want to use
            string key = cacheKeyLookup.ToLower();

            // what type of cache are we using
            if (useSitecoreCache)
            {
                // get the cache we are looking for\
                Sitecore.Caching.ICache cache = SitecoreCache(key, globalCache, siteName, databaseName, languageName);

                // kill
                if (cache == null)
                {
                    return true;
                }

                // use the sitecore cache
                cache.RemoveKeysContaining(cacheKeyLookup);
            }
            else
            {
                return false;
            }

            // data removed
            return true;
        }
        #endregion


        #region ClearCache
        /// <summary>
        /// Clears the cache based on the details provided
        /// </summary>
        /// <param name="siteName">The name of the site to clear it's cached data</param>
        /// <param name="useSitecoreCache">Clear the cache from sitecore or the httpruntime</param>
        /// <param name="globalCache">Clear the global cache as well</param>
        /// <param name="removeOnPublish">Remove the data which was indicated as not to be cleared when publishing</param>
        public static void ClearCache(
            string siteName = "",
            string databaseName = "",
            string languageName = "",
            bool useSitecoreCache = true,
            bool globalCache = false,
            bool removeOnPublish = false)
        {
            // is caching disabled
            if (!Settings.Caching.IsEnabled || !Settings.Caching.Util.Enabled)
            {
                return;
            }

            // what type of caching are we dealing with
            if (useSitecoreCache)
            {
                #region Sitecore Cache
                // get the cache from sitecore
                Sitecore.Caching.ICache cache = SitecoreCache("", globalCache, siteName, databaseName, languageName);

                // make sure we have the data
                if (cache != null)
                {
                    // process the keys
                    foreach (object key in cache.GetCacheKeys())
                    {
                        // can we remove the item
                        if (removeOnPublish || !((string)key).Contains("DontPublish-"))
                        {
                            // remove the key
                            cache.Remove(key.ToString());
                        }
                    }
                }
                #endregion
            }
        }
        #endregion
    }
}