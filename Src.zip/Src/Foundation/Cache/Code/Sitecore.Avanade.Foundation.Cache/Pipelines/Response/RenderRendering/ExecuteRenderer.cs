﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Cache.Extensions;

namespace Sitecore.Avanade.Foundation.Cache.Pipelines.Response.RenderRendering
{
    /// <summary>
    /// Overrides the Sitecore Execute Renderer to capture issues with custom renderings
    /// </summary>
    public class ExecuteRenderer : Sitecore.Mvc.Pipelines.Response.RenderRendering.ExecuteRenderer
    {
        /// <summary>
        /// Overriding the Sitecore Rendering, to including options to capture and display errors based on settings.
        /// </summary>
        /// <param name="renderer"></param>
        /// <param name="writer"></param>
        /// <param name="args"></param>
        /// <returns>Returns true if the rendering has succesfully executed. You can however also get true if a error was run but captured.</returns>
        protected override bool Render(Sitecore.Mvc.Presentation.Renderer renderer, System.IO.TextWriter writer, Sitecore.Mvc.Pipelines.Response.RenderRendering.RenderRenderingArgs args)
        {
            // is the error module allowed to execute
            if (Data.Settings.Mvc.Renderings.Errors.IsEnabled
                || (Data.Settings.Mvc.Renderings.Errors.PageEditor.IsEnabled
                    && Sitecore.Configuration.State.WebEditing))
            {
                // we are in our custom errors or are we not
                if (Sitecore.Configuration.State.WebEditing)
                {
                    // should we throw the error
                    if (Data.Settings.Mvc.Renderings.Errors.PageEditor.Throw)
                    {
                        // we are going to throw the error if it occurs
                        return base.Render(renderer, writer, args);
                    }
                    else
                    {
                        // define default
                        bool isValid = true;

                        try
                        {
                            // execute the rendering, do not reutnr in a try / catch for memory
                            isValid = base.Render(renderer, writer, args);
                        }
                        catch (System.Exception ex)
                        {
                            // log the error
                            Sitecore.Diagnostics.Log.Error("AI Exception", ex, typeof(ExecuteRenderer));

                            // are we showing the issue
                            if (Data.Settings.Mvc.Renderings.Errors.PageEditor.Show)
                            {
                                // output the .NET http exception page and format
                                writer.Write("Error loading modules'{0}', {1}".Fmt(args.Rendering.RenderingItem.Name, CleanHttpExceptionFormatting(((System.Web.HttpException)ex).GetHtmlErrorMessage())));
                            }

                            // default output
                            isValid = true;
                        }

                        return isValid;
                    }
                }
                else
                {
                    // are we throwing the error on the front end
                    if (Data.Settings.Mvc.Renderings.Errors.Throw)
                    {
                        return base.Render(renderer, writer, args);
                    }
                    else
                    {
                        // default value
                        bool isValid = true;

                        try
                        {
                            // set the data because return causes memory issues
                            isValid = base.Render(renderer, writer, args);
                        }
                        catch (System.Exception ex)
                        {
                            // log the issue
                            Sitecore.Diagnostics.Log.Error("Reactive Exception", ex, typeof(ExecuteRenderer));

                            // are we allowed to show the error
                            if (Data.Settings.Mvc.Renderings.Errors.Show)
                            {
                                // show the error and format with Http Exception Formatter
                                writer.Write("Error loading modules'{0}', {1}".Fmt(args.Rendering.RenderingItem.Name, CleanHttpExceptionFormatting(((System.Web.HttpException)ex).GetHtmlErrorMessage())));

                            }

                            // ensure we have an out
                            isValid = true;
                        }

                        return isValid;
                    }
                }
            
            }

            // pure default
            return base.Render(renderer, writer, args);    
        }

        /// <summary>
        /// Cleans the formatted HTML Error exception.
        /// This is required due to certain changes it tries to make that causes
        /// issues with formatting.
        /// </summary>
        /// <param name="exceptionFormatted"></param>
        /// <returns></returns>
        private string CleanHttpExceptionFormatting(string exceptionFormatted)
        {


            return exceptionFormatted;
        }
    }
}