﻿using System.Web;

using Sitecore.Diagnostics;
using Sitecore.Mvc.Pipelines.Response.RenderRendering;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Cache.Pipelines.Response.RenderRendering
{
    /// <summary>
    /// Determines if the caching rules has to be enabled
    /// </summary>
    public class CachingRules : RenderRenderingProcessor
    {
        #region Private Variables
        /// <summary>
        /// The query key used to identify if all caching should be disabled
        /// </summary>
        private static string _cacheKeyAll = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Cache.MVC.Query.KeyAll", "cache_mvc");

        /// <summary>
        /// The query key used to identify the rendering to look for
        /// </summary>
        private static string _cacheKeyRendering = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Cache.MVC.Query.KeyRendering", "cache_rendering");

        /// <summary>
        /// Is the query enabled
        /// </summary>
        private static bool _cacheQueryEnabled = Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Cache.MVC.Query.Enabled", false);

        /// <summary>
        /// Is the MVC caching enabled
        /// </summary>
        private static bool _cacheEnabled = Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Cache.MVC.EnableCaching", true);
        #endregion

        #region Process
        /// <summary>
        /// Overrides the rendering processess just to check it's caching options
        /// </summary>
        /// <param name="args"></param>
        public override void Process(RenderRenderingArgs args)
        {
            // ensure we have the data required
            Assert.ArgumentNotNull(args, "args");

            // just stop if the system is not cachable already
            if (args.Rendered
                || HttpContext.Current == null
                || (!args.Cacheable)
                //|| string.IsNullOrWhiteSpace(args.CacheKey) // Does not exist at this point
                || args.Rendering.RenderingItem == null)
            {
                return;
            }

            // is the caching disable globally for MVC
            if (!_cacheEnabled)
            {
                // disable the cache
                args.Cacheable = false;
            }

            // check if the query data is valid
            CacheByQueryString(args);
        }
        #endregion

        #region CacheByQueryString
        /// <summary>
        /// Overrides the cache based on Querystring data
        /// </summary>
        /// <param name="args"></param>
        private void CacheByQueryString(RenderRenderingArgs args)
        {
            // have we enabled the query string checks
            if (_cacheQueryEnabled
                && (!_cacheKeyAll.IsNullOrEmpty() || !_cacheKeyRendering.IsNullOrEmpty())
                && System.Web.HttpContext.Current != null)
            {
                // set the query context
                var _queryContext = System.Web.HttpContext.Current.Request.QueryString;

                // make sure wehave data
                if (_queryContext != null && _queryContext.Count > 0)
                {
                    // are we stopping all renderings
                    if (!_cacheKeyAll.IsNullOrEmpty()
                        && Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(_queryContext[_cacheKeyAll], false))
                    {
                        // disable the cache
                        args.Cacheable = false;
                        return;
                    }

                    // ensure we have a unique rendering to stop caching
                    if (!_cacheKeyRendering.IsNullOrEmpty()
                        && !string.IsNullOrEmpty(_queryContext[_cacheKeyRendering])
                        && args.Rendering.RenderingItem.ID.EqualsTo(_queryContext[_cacheKeyRendering]))
                    {
                        // disable the cache
                        args.Cacheable = false;
                    }
                }
            }
        }
        #endregion
    }
}