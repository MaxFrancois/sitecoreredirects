﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Cache.Extensions;
using Sitecore.Mvc.Pipelines.Response.RenderRendering;
using Sitecore.Diagnostics;


namespace Sitecore.Avanade.Foundation.Cache.Pipelines.Response.RenderRendering
{
    /// <summary>
    /// Override the Generate Cache key to include custom cache options
    /// </summary>
    public class ExtendCacheKey : RenderRenderingProcessor
    {
        /// <summary>
        /// Cache Clear on Index
        /// </summary>
        /// <param name="args"></param>
        private void CacheClearOnIndex(RenderRenderingArgs args)
        {
            // are we performing varification on the context item cacheoption
            // adding due to not being implemented
            // http://stackoverflow.com/questions/28987033/sitecore-7-clear-on-index-update-not-working
            if (Sitecore.Context.Item != null
                && args.Rendering.ClearOnIndexUpdate()
                && !args.CacheKey.Contains("_#index")
                )
            {
                // append the key
                args.CacheKey += "_#index";
            }
        }
        
        /// <summary>
        /// Cache Vary by Context
        /// </summary>
        /// <param name="args"></param>
        private void CacheVaryByContext(RenderRenderingArgs args)
        {
            // are we performing varification on the context item cache option
            if (args.Rendering.VaryByContextItem()
                && Sitecore.Context.Item != null)
            {
                // append the key
                args.CacheKey += string.Format("_#context:{0}", Sitecore.Context.Item.ID.ToString());
            }
        }

        #region CacheVaryByCookie
        /// <summary>
        /// Cache Vary by Cookie
        /// </summary>
        /// <param name="args"></param>
        private void CacheVaryByCookie(RenderRenderingArgs args)
        {
            // are we caching based on a cookie being set
            if (args.Rendering.VaryByCookie())
            {
                // get the cookie
                System.Web.HttpCookie cacheCookieKey = System.Web.HttpContext.Current.Request.Cookies[args.Rendering.VaryByCookieKey()];

                // ensure we have data
                if (cacheCookieKey != null)
                {
                    if (args.Rendering.VaryByCookieValue())
                    {
                        // append the key
                        if (cacheCookieKey.Value.IsNullOrEmpty())
                        {
                            // append the key
                            args.CacheKey += string.Format("_#cookiekey:{0}", args.Rendering.VaryByCookieKey());
                        }
                        else
                        {
                            args.CacheKey += string.Format("_#cookiekey:{0}_#cookievalue:{1}", args.Rendering.VaryByCookieKey(), cacheCookieKey.Value);
                        }
                    }
                    else
                    {
                        // append the key
                        args.CacheKey += string.Format("_#cookiekey:{0}", args.Rendering.VaryByCookieKey());
                    }

                }
            }
        }
        #endregion

        #region Override GenerateKey
        /// <summary>
        /// Override the GenerateKey to include new caching options
        /// </summary>
        /// <param name="rendering"></param>
        /// <param name="args"></param>
        /// <returns>Returns the Cache key for the module being run</returns>
        public override void Process(RenderRenderingArgs args)
        {
            Assert.ArgumentNotNull(args, "args");

            if (args.Rendered || !args.Cacheable || args.CacheKey.IsNullOrEmpty())
            {
                return;
            }

            // set the caching timeout or use default if not set
            args.Rendering.Caching.Timeout = args.Rendering.VaryByTimout();

            // set clear on index just in case
            CacheClearOnIndex(args);

            // vary by context
            CacheVaryByContext(args);

            // vary by cookie
            CacheVaryByCookie(args);
        }
        #endregion
    }
}