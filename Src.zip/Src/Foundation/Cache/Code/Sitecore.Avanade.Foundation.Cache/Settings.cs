﻿namespace Sitecore.Avanade.Foundation.Cache
{ 
    public static class Settings
    {
        #region Caching
        /// <summary>
        /// Caching class
        /// </summary>
        public static class Caching
        {
            #region Private Variables
            /// <summary>
            /// Is caching enabled
            /// </summary>
            private static bool? _isEnabled;

            /// <summary>
            /// is the sublayout caching enabled
            /// </summary>
            private static bool? _sublayoutEnabled;

            /// <summary>
            /// Is the rendering caching enabled
            /// </summary>
            private static bool? _renderingEnabled;
            #endregion

            #region Public Properties
            /// <summary>
            /// Is caching enabled
            /// </summary>
            public static bool IsEnabled
            {
                get
                {
                    // set data just incase
                    _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Caching.Enabled", false);

                    // return
                    return _isEnabled.Value;
                }
            }

            /// <summary>
            /// Is sublayout caching enabled
            /// </summary>
            public static bool SublayoutEnabled
            {
                get
                {
                    _sublayoutEnabled = _sublayoutEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Caching.Sublayouts.Enabled", false);

                    return _sublayoutEnabled.Value;

                }
            }

            /// <summary>
            /// Is rendering caching enabled
            /// </summary>
            public static bool RenderingEnabled
            {
                get
                {
                    _renderingEnabled = _renderingEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Caching.Renderings.Enabled", false);

                    return _renderingEnabled.Value;

                }
            }

            #endregion

            #region Caching Util
            /// <summary>
            /// The Caching Util
            /// </summary>
            public static class Util
            {
                #region Private Variables
                /// <summary>
                /// Is caching enabled
                /// </summary>
                private static bool? _utilIsEnabled;

                /// <summary>
                /// Are caching logs enabled
                /// </summary>
                private static bool? _isLogsEnabled;

                /// <summary>
                /// Is the default caching size configured
                /// </summary>
                private static long? _defaultCachingSize;
                #endregion

                #region Public Properties
                /// <summary>
                /// Is the Caching Util enabled
                /// </summary>
                public static bool Enabled
                {
                    get
                    {
                        _utilIsEnabled = _utilIsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Caching.Util.Enabled", false);

                        return _utilIsEnabled.Value;
                    }
                }

                /// <summary>
                /// Are the caching logs enabled
                /// </summary>
                public static bool LogsEnabled
                {
                    get
                    {
                        _isLogsEnabled = _isLogsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Caching.Util.Logs.Enabled", false);

                        return _isLogsEnabled.Value;

                    }
                }

                /// <summary>
                /// The Default caching size
                /// </summary>
                public static long DefaultCacheSize
                {
                    get
                    {
                        _defaultCachingSize = _defaultCachingSize ?? Sitecore.StringUtil.ParseSizeString(Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Caching.Util.CacheSize.Default", "10MB"));
                        return _defaultCachingSize.Value;
                    }
                }
                #endregion
            }
            #endregion
        }
        #endregion
    }
}
