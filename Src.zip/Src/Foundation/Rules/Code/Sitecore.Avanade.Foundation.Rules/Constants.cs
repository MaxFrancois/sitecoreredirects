﻿namespace Sitecore.Avanade.Foundation.Rules
{
    public static class Constants
    {
        public static class InsertRuleItem
        {
            public const string InsertRuleTemplateId = "{664E5035-EB8C-4BA1-9731-A098FCC9127A}";
        }
    }
}
