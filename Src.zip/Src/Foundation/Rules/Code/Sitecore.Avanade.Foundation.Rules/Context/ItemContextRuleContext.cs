﻿using Sitecore.Rules;
using Sitecore.Shell.Framework.Commands;

namespace Sitecore.Avanade.Foundation.Rules.Context
{
    public class ItemContextRuleContext : RuleContext
    {
        public CommandState CommandState { get; set; }

        public string Name { get; set; }
    }
}