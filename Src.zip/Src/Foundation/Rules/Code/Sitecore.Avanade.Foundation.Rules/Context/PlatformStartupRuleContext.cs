﻿using Sitecore.Data;
using Sitecore.Rules;
using Sitecore.Shell.Framework.Commands;

namespace Sitecore.Avanade.Foundation.Rules.Context
{
    public class PlatformStartupRuleContext : RuleContext
    {
        public Database ContentDatabase { get; set; }
    }
}