﻿using System.Collections.Generic;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Rules.Actions;
using Sitecore.Avanade.Foundation.Rules.Context;
using System.ComponentModel;
using Sitecore.SecurityModel;

namespace Sitecore.Avanade.Foundation.Rules.Actions.PlatformStartup
{
    /// <summary>
    /// The options available to authors
    /// </summary>
    public enum Option
    {
        /// <summary>
        /// Add a new base template to the required template
        /// </summary>
        [Description("{60446DE3-EBA3-4E21-BDB3-E3DC2AF4E81E}")]
        Add,

        /// <summary>
        /// Remove a base template from the required template
        /// </summary>
        [Description("{9D837B08-2115-4136-B2C9-1A629C4DBA38}")]
        Remove
    }

    /// <summary>
    /// Adds or removes a template from the base template list of a template item
    /// </summary>
    public class AddRemoveBaseTemplate<T> : RuleAction<T> where T : PlatformStartupRuleContext
    {
        /// <summary>
        /// Setup default to add
        /// </summary>
        private Option Option = Option.Add;

        /// <summary>
        /// The Base Template Field Name
        /// </summary>
        private const string BaseTemplateFieldName = "__base template";

        /// <summary>
        /// The option id
        /// </summary>
        public string OptionId
        {
            get
            {
                return Option.Description();
            }
            set
            {
                if (new ID(value).EqualsTo(Option.Add.Description()))
                {
                    Option = Option.Add;
                }
                else
                {
                    Option = Option.Remove;
                }
                    
            }
        }

        /// <summary>
        /// The template Id that we want to add to the base template
        /// </summary>
        public string TemplateId { get; set; }

        /// <summary>
        /// Apply the rule if it meets the internal requirements
        /// </summary>
        /// <param name="ruleContext"></param>
        public override void Apply(T ruleContext)
        {
            // make sure we have the require data first
            if (ruleContext?.Item != null
                && !TemplateId.IsNullOrEmpty()
                && !ruleContext.Item.ID.EqualsTo(TemplateId))
            {
                // set the correct user
                using (new Sitecore.Security.Accounts.UserSwitcher("sitecore\\platformstartuprule", false))
                {
                    // kill security so we can run the process
                    using (new SecurityDisabler())
                    {
                        // get the item for easier access
                        Item itm = ruleContext.Item;

                        // get out the template list but safely
                        string baseTemplateList = itm.Fields[BaseTemplateFieldName].ValueSafe();

                        // get the base list
                        var baseTemplateIdList = baseTemplateList.SplitString('|').ToList();

                        // what is the users option
                        if (Option == Option.Add)
                        {
                            // add the template
                            baseTemplateIdList.Add(TemplateId);

                            // output the list
                            baseTemplateList = baseTemplateIdList.ToString("|");

                        }
                        else if (Option == Option.Remove)
                        {
                            // cycle over and remove the template id
                            baseTemplateList = baseTemplateIdList.Where(x => !x.Equals(TemplateId, System.StringComparison.OrdinalIgnoreCase)).ToString("|");
                        }
                    
                        // we don't do versions as templates don't have versions
                        // edit the item
                        itm.Editing.BeginEdit();

                        // we need to make sure we try catch just in case of  issues
                        try
                        {
                            // set the value
                            itm.Fields[BaseTemplateFieldName].SetValue(baseTemplateList, true);
                        }
                        catch (System.Exception ex)
                        {
                            // log the error so we can resolve
                            Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Rules]: Unable to set base template id: '{TemplateId}' onto the template id: '{itm.ID.ToString()}'", ex, typeof(AddRemoveBaseTemplate<T>));
                        }
                        finally
                        {
                            // finish editing
                            itm.Editing.EndEdit();
                        }
                    }
                }
            }

            // have to be careful
            if (ruleContext?.Item != null)
            {
                // reset to null just in case
                ruleContext.Item = null;
            }
        }
    }
}