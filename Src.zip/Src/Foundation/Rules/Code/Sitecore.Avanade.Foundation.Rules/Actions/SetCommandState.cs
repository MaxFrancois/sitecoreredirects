﻿using Sitecore.Diagnostics;
using Sitecore.Rules.Actions;
using Sitecore.Shell.Framework.Commands;
using System;
using Sitecore.Avanade.Foundation.Rules.Context;

namespace Sitecore.Avanade.Foundation.Rules.Actions
{
    public class SetCommandState<T> : RuleAction<T> where T : ItemContextRuleContext
    {
        public string CommandName { get; set; }

        public override void Apply(T ruleContext)
        {
            //Check that we have a rule context
            Assert.ArgumentNotNull(ruleContext, "ruleContext");


            //Make sure the command name has been parsed
            if (String.IsNullOrEmpty(CommandName))
                return;

            //Is this the command selected in the rule, if so, complete action
            if (ruleContext.Name.Equals(CommandName))
            {
                //Now we can query the commands state, then disable it
                ruleContext.CommandState = CommandState.Disabled;
            }
        }
    }
}