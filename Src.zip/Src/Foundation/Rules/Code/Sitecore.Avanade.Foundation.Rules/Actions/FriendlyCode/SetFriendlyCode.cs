﻿using System.Collections.Generic;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Rules.Actions;
using System.ComponentModel;
using Sitecore.SecurityModel;
using Sitecore.Rules;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.ContentSearch.Linq;

namespace Sitecore.Avanade.Foundation.Rules.Actions.FriendlyCode
{
    /// <summary>
    /// Sets the friendly code
    /// </summary>
    public class SetFriendlyCode<T> : RuleAction<T> where T : RuleContext
    {
        /// <summary>
        /// The Field to create the friendly code within
        /// </summary>
        public string FieldId { get; set; }

        /// <summary>
        /// The starting value to use
        /// </summary>
        public string StartingValue { get; set; }

        /// <summary>
        /// Apply the rule if it meets the internal requirements
        /// </summary>
        /// <param name="ruleContext"></param>
        public override void Apply(T ruleContext)
        {
            // make sure we have the require data first
            if (ruleContext?.Item != null
                && !FieldId.IsNullOrEmpty()
                && !StartingValue.IsNullOrEmpty()
                && ruleContext.Item.HasField(FieldId))
            {
                // get the item for easier access
                Item itm = ruleContext.Item;

                var field = itm.Database.GetItem(Sitecore.Data.ID.Parse(FieldId));
                string fieldName = field.Name;

                // make sure we do not have a blank field
                if (itm.Fields[fieldName].HasValue
                    && !itm.Fields[fieldName].ValueSafe().IsNullOrEmpty())
                {
                    return;
                }

                Sitecore.Diagnostics.Log.Info($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Rules]: SetFriendlyCode: Save Event for Item-ID: '{itm.ID.ToString()}', Path: '{itm.Paths.Path.ToString()}'", typeof(SetFriendlyCode<T>));

                // kill security so we can run the process
                using (new SecurityDisabler())
                {
                    // make sure we re-get it without security enabled
                    itm = ruleContext.Item;

                    // default in case
                    if (StartingValue.IsNullOrEmpty())
                    {
                        StartingValue = "10000";
                    }

                    var friendlyCode = System.Convert.ToInt32(StartingValue);

                    // edit the item
                    itm.Editing.BeginEdit();

                    // we need to make sure we try catch just in case of  issues
                    try
                    {
                        ISearchIndex index = ContentSearchManager.GetIndex($"sitecore_{itm.Database.Name.ToLower()}_index");

                        using (IProviderSearchContext context = index.CreateSearchContext())
                        {
                            var query = context.GetQueryable<SearchResultItem>()
                                                .Filter(x => x.Path.Contains(Sitecore.Constants.ContentPath)) // for to only be in the home
                                                .Where(x => x[fieldName] != "") // look for the specific type of field
                                                .OrderByDescending(x => x[fieldName]) // make sure it is ordered in the right way
                                                ;

                            if (query != null && query.Count() > 0)
                            {
                                // get out the results
                                var results = query.GetResults();

                                // get the results
                                if (results != null && results.TotalSearchResults >= 1)
                                {
                                    
                                    // find the correct code
                                    friendlyCode = System.Convert.ToInt32(results.Hits.FirstOrDefault().Document.GetField(FieldId).ValueSafe());
                                }
                            }
                        }

                        // increment the number
                        friendlyCode++;

                        // set the value
                        itm.Fields[FieldId].SetValue(friendlyCode.ToString(), true);
                    }
                    catch (System.Exception ex)
                    {
                        // log the error so we can resolve
                        Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Rules]: Unable to produce friendly id for Item-ID: '{itm.ID.ToString()}', Path: '{itm.Paths.Path.ToString()}'", ex, typeof(SetFriendlyCode<T>));
                    }
                    finally
                    {
                        // finish editing
                        itm.Editing.EndEdit();
                    }
                }
            }

            // have to be careful
            if (ruleContext?.Item != null)
            {
                // reset to null just in case
                ruleContext.Item = null;
            }
        }
    }
}

