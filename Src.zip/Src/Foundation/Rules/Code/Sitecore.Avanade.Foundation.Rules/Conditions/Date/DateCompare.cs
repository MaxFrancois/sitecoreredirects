﻿using Sitecore.Diagnostics;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System.ComponentModel;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.Date
{
    /// <summary>
    /// Compares two dates set within the rule
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DateCompare<T> : OperatorCondition<T> where T : RuleContext
    {
        /// <summary>
        /// The first date field to compare
        /// </summary>
        [TypeConverter(typeof(DateTimeConverter))]
        public System.DateTime DateFieldOne { get; set; }

        /// <summary>
        /// The second date field to compare
        /// </summary>
        [TypeConverter(typeof(DateTimeConverter))]
        public System.DateTime DateFieldTwo { get; set; }

        /// <summary>
        /// Executes the rule context
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            Assert.ArgumentNotNull((object)ruleContext, "ruleContext");

            // make sure we have dates
            if (DateFieldOne <= System.DateTime.MinValue
                && DateFieldTwo <= System.DateTime.MinValue)
            {
                return false;
            }
            
            // compare the dates but make sure they are not in UTC so convert
            return DateComparer(DateUtil.ToServerTime(DateFieldOne), DateUtil.ToServerTime(DateFieldTwo), base.GetOperator());
        }

        /// <summary>
        /// Compare the dates
        /// </summary>
        /// <param name="date1">The first date</param>
        /// <param name="date2">The second date</param>
        /// <param name="conditionOperator">The operator we are comparing</param>
        /// <returns>Returns bool indicating if the dates meet the operator</returns>
        private bool DateComparer(System.DateTime date1, System.DateTime date2, ConditionOperator conditionOperator)
        {
            switch (conditionOperator)
            {
                case ConditionOperator.Equal:
                    return date1.Equals(date2);
                case ConditionOperator.LessThan:
                    return date1 < date2;
                case ConditionOperator.LessThanOrEqual:
                    return date1 <= date2;
                case ConditionOperator.GreaterThan:
                    return date1 > date2;
                case ConditionOperator.GreaterThanOrEqual:
                    return date1 >= date2;
                case ConditionOperator.NotEqual:
                    return !date1.Equals(date2);
                default:
                    return false;
            }

        }

    }
}