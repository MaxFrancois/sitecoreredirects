﻿using System;
using Sitecore.Avanade.Foundation.Extensions;
using System.ComponentModel;
using Sitecore.Rules.Conditions;
using Sitecore.Diagnostics;
using Sitecore.Rules;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.Date
{
    /// <summary>
    /// Time of Day Condition
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class TimeOfDayCondition<T> : OperatorCondition<T> where T : RuleContext
    {
        /// <summary>
        /// Get the Time Field
        /// </summary>
        public string TimeField { get; set; }

        /// <summary>
        /// Execute the Time of Day Rule
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure we have valid data
            Assert.ArgumentNotNull((object)ruleContext, "ruleContext");
            Assert.ArgumentNotNull(TimeField, "TimeField");

            TimeSpan time = DateTime.Parse(TimeField).TimeOfDay;


            // return our comparer
            return TimeSpanComparer(DateTime.Now.SitecoreDateTime().TimeOfDay, time, base.GetOperator());
        }

        /// <summary>
        /// Compares the Time Spans based on the conditional Operator
        /// </summary>
        /// <param name="timeSpan1">The current datetime</param>
        /// <param name="timeSpan2">The sepected date time</param>
        /// <param name="conditionOperator">The operation that was leveraged</param>
        /// <returns>Returns true if the comparison is valid</returns>
        private bool TimeSpanComparer(TimeSpan timeSpan1, TimeSpan timeSpan2, ConditionOperator conditionOperator)
        {
            // what operation are we running
            switch (conditionOperator)
            {
                case ConditionOperator.Equal:
                    return timeSpan1.Equals(timeSpan2);
                case ConditionOperator.LessThan:
                    return timeSpan1 < timeSpan2;
                case ConditionOperator.LessThanOrEqual:
                    return timeSpan1 <= timeSpan2;
                case ConditionOperator.GreaterThan:
                    return timeSpan1 > timeSpan2;
                case ConditionOperator.GreaterThanOrEqual:
                    return timeSpan1 >= timeSpan2;
                case ConditionOperator.NotEqual:
                    return !timeSpan1.Equals(timeSpan2);
                default:
                    return false;
            }

        }

    }
}