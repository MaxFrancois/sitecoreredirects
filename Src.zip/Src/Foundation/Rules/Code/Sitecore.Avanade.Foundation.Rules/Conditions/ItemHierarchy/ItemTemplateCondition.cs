﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.ItemHierarchy
{
    /// <summary>
    /// Determines if the item is from an inherited template
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ItemTemplateCondition<T> : WhenCondition<T> where T : RuleContext
    {
        /// <summary>
        /// The template to check
        /// </summary>
        public ID TemplateId { get; set; }

        /// <summary>
        /// Can we process this request rule
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valid
            Assert.ArgumentNotNull(ruleContext, "ruleContext");

            // get the item
            Item item = ruleContext.Item;

            // we have the data required
            if (item == null || TemplateId == ID.Null)
            {
                return false;
            }

            // is the item inherited from the base template
            return item.HasBaseTemplate(TemplateId);
        }
    }
}
