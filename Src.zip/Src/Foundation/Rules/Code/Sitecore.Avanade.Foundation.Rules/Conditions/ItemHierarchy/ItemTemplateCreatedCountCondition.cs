﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Rules;
using Sitecore.Rules.Conditions;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.ItemHierarchy
{
    /// <summary>
    /// Determines if the template has been created a number of times (child)
    /// This can also process the item for it's inherited templates if required
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ItemTemplateCreatedCountCondition<T> : WhenCondition<T> where T : RuleContext
    {
        /// <summary>
        /// The Template ID to condition
        /// </summary>
        public ID CurrentTemplateId { get; set; }

        /// <summary>
        /// The Template ID that will  be set
        /// </summary>
        public ID SetTemplateId { get; set; }

        /// <summary>
        /// The maximum amount of items
        /// </summary>
        public int MaxCount { get; set; }

        protected override bool Execute(T ruleContext)
        {
            // ensure we have data
            Assert.ArgumentNotNull(ruleContext, "ruleContext");

            // get the item out
            Item item = ruleContext.Item;

            // have we got valid data
            if (item == null || CurrentTemplateId == ID.Null || SetTemplateId == ID.Null || MaxCount == 0)
            {
                return false;
            }
            
            // are we allowed to run
            return item.HasBaseTemplate(CurrentTemplateId) ? (item.Children.Count(x => x.HasBaseTemplate(SetTemplateId)) < MaxCount) : false;
        }
    }
}
