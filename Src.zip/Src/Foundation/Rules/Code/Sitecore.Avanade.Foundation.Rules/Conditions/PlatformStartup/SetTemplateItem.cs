﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Rules;
using Sitecore.Avanade.Foundation.Rules.Context;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.PlatformStartup
{
    public class SetTemplateItem<T> : WhenCondition<T> where T : PlatformStartupRuleContext
    {
        /// <summary>
        /// The Template Id
        /// </summary>
        public string TemplateId { get; set; }

        /// <summary>
        /// Executes to make sure the template has the required base template
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valie
            if (ruleContext != null
                && ruleContext.Item == null
                && !TemplateId.IsNullOrEmpty()
                && ruleContext.ContentDatabase != null)
            {
                // get the item and set in the context of the rule
                ruleContext.Item = ruleContext.ContentDatabase.GetItem(TemplateId);
            }

            // perform null check
            return (ruleContext?.Item != null);
        }

    }
}