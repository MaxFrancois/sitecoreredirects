﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Rules;
using Sitecore.Avanade.Foundation.Rules.Context;

namespace Sitecore.Avanade.Foundation.Rules.Conditions.PlatformStartup
{
    public class HasBaseTemplate<T> : StringOperatorCondition<T> where T : PlatformStartupRuleContext
    {
        /// <summary>
        /// The Template Id
        /// </summary>
        public string TemplateId { get; set; }

        /// <summary>
        /// Executes to make sure the template has the required base template
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valie
            if (ruleContext != null
                && ruleContext.Item != null
                && !TemplateId.IsNullOrEmpty())
            {
                string baseTemplateList = string.Empty;

                if (ruleContext.Item.IsTemplate())
                {
                    baseTemplateList = ruleContext.Item.Fields["__Base template"].ValueSafe();
                }

                // get the data
                if (!baseTemplateList.IsNullOrEmpty())
                {
                    // compare the values
                    return base.Compare(baseTemplateList, TemplateId);
                }
            }

            return false;
        }

    }
}