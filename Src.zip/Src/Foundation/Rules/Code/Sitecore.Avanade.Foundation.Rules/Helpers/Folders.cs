﻿using Sitecore.Data;
using Sitecore.Data.Items;
using System.Collections.Generic;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.SecurityModel;

namespace Sitecore.Avanade.Foundation.Rules.Helpers
{
    public static class Folders
    {
        /// <summary>
        /// Get the listing of Rules based on the folders list supplied
        /// </summary>
        /// <param name="db">The database to call</param>
        /// <param name="Folders">The listing of folders</param>
        /// <param name="templateId">The template id to fetch</param>
        /// <returns>Returns listing of Items based on the folders and template</returns>
        public static List<Item> GetRules(Database db, List<string> Folders, string templateId)
        {
            // set our insert options list
            return Cache.Cache.Get<List<Item>>($"{templateId}-{Folders.ToString("|")}", () =>
            {
                // the data we will return
                var list = new List<Item>();

                // make sure we disable security for this
                using (new SecurityDisabler())
                {
                    // cycle over the rules
                    Folders.ForEach(x =>
                    {
                        // get the item
                        var itm = db.GetItem(x);

                        // make sure it is valid
                        if (itm != null)
                        {
                            // fetch all InsertRuleItems no matter the depth
                            var itms = itm.Axes.SelectItems($".//*[@@templateid='{templateId}']");

                            // ensure we have data
                            if (itms != null && itms.Length > 0)
                            {
                                // increase our list
                                list.AddRange(itms);
                            }
                        }
                    });
                }

                return list;
            }, System.DateTime.Now.AddMinutes(2));
        }
    }
}