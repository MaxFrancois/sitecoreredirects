﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects
{
    public static class Settings
    {
        #region Private Variables
        /// <summary>
        /// Are the redirections enabled
        /// </summary>
        private static bool? _isEnabled;

        /// <summary>
        /// The formatter for the indexer
        /// </summary>
        private static string _indexFormatter = string.Empty;
        #endregion

        #region Public Properties
        /// <summary>
        /// Are the redirections enabled
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redirection.Enabled", false);

                return _isEnabled.Value;

            }
        }

        /// <summary>
        /// THe index formatter, it will need to replace {0} with the database name
        /// </summary>
        /// <example>
        /// String.Format(IndexFormatter, Sitecore.Context.Database.Name);
        /// </example>
        public static string IndexFormatter
        {
            get
            {
                if (String.IsNullOrEmpty(_indexFormatter))
                {
                    _indexFormatter = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Redirection.IndexFormatter", "sitecore_redirection_{0}");
                }

                    
                return _indexFormatter;
            }
        }
        #endregion

        public static class Media
        {
            #region Private Variables
            /// <summary>
            /// Are the redirections enabled
            /// </summary>
            private static bool? _mediaIsEnabled;


            #endregion

            #region Public Properties
            /// <summary>
            /// Are the redirections enabled
            /// </summary>
            public static bool MediaIsEnabled
            {
                get
                {
                    _mediaIsEnabled = _mediaIsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redirection.Media.Enabled", false);

                    return _mediaIsEnabled.Value;

                }
            }
            #endregion
        }

        public static class Logs
        {
            #region Private Variables
            /// <summary>
            /// Are the redirections enabled
            /// </summary>
            private static bool? _logsIsEnabled;

            /// <summary>
            /// Do we log if there are multiple results
            /// </summary>
            private static bool? _multipleResults;
            #endregion

            #region Public Properties
            /// <summary>
            /// Are the redirections enabled
            /// </summary>
            public static bool LogsIsEnabled
            {
                get
                {
                    _logsIsEnabled = _logsIsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redirection.Logs.Enabled", false);

                    return _logsIsEnabled.Value;

                }
            }

            /// <summary>
            /// Do we log when we find multiple results
            /// </summary>
            public static bool MultipleResults
            {
                get
                {
                    _multipleResults = _multipleResults ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redirection.Logs.MultipleResults", false);

                    return _multipleResults.Value;

                }
            }
            #endregion
        }

        public static class Ignorelist
        {
            #region Private Variables
            /// <summary>
            /// Are we performing an initial check on the ignore list
            /// </summary>
            private static bool? _isInitialCheckEnabled;


            #endregion

            #region Public Properties
            /// <summary>
            /// Are we performing an initial check on the ignore list
            /// </summary>
            public static bool IsInitialCheckEnabled
            {
                get
                {
                    _isInitialCheckEnabled = _isInitialCheckEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redireciton.Ignorelist.IsInitialCheckEnabled", false);

                    return _isInitialCheckEnabled.Value;

                }
            }
            #endregion
        }

        public static class Global
        {
            #region Private Variables
            /// <summary>
            /// Are the redirections enabled
            /// </summary>
            private static bool? _globalIsEnabled;

            /// <summary>
            /// The global redirects path
            /// </summary>
            private static string _globalRedirectsPath = string.Empty;
            #endregion

            #region Public Properties
            /// <summary>
            /// Are the global redirects enabled
            /// </summary>
            public static bool GlobalIsEnabled
            {
                get
                {
                    _globalIsEnabled = _globalIsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Redirection.GlobalRedirects.Enabled", false);
                
                    return _globalIsEnabled.Value;

                }
            }

            /// <summary>
            /// The global redirects path
            /// </summary>
            public static string Path
            {
                get
                {
                    if (String.IsNullOrEmpty(_globalRedirectsPath))
                    {
                        _globalRedirectsPath = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Redireciton.GlobalRedirects.Path", "/sitecore/content/global-redirects");
                    }


                    return _globalRedirectsPath;
                }
            }
            #endregion
        }

    }
}