﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects
{
    public static class Constants
    {
        public static class Templates
        {
            public static class RedirectionFolder
            {
                public const string TemplateId = "{D250065A-D19E-476F-AE6D-4A915F4B0B2D}";

                public static class Fields
                {
                    public const string SiteOfflineEnabled = "SiteOfflineEnabled";

                    public const string SiteOfflinePage = "SiteOfflinePage";
                }
            }

            public static class Redirection
            {
                public const string Name = "Redirection";
                public static class Fields
                {
                    public const string RequestedUrl = "requestedurl";
                    
                    public const string IsRegex = "isregex";
                    
                    public const string RedirectToItem = "redirecttoitem";

                    public const string RedirectToUrl = "redirecttourl";

                    public const string ExcludeQueryString = "excludequerystring";

                    public const string ItemDeleted = "itemdeleted";

                    public const string RedirectionTemporary = "redirecttemporary";
                }
            }
        }

        public static class Cache
        {
            public const string WarningMarker = "redirection-notifiation-{0}";
        }
    }
}