﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects.Models
{
    /// <summary>
    /// Custom Response Headers
    /// </summary>
    public class StatusResponse
    {
        /// <summary>
        /// The status that is outputted in the response header, defaults to 301 Moved Permmanently
        /// </summary>
        public string Status { get; internal set; } 

        /// <summary>
        /// The Status Code to output to the response header, default is 301
        /// </summary>
        public int StatusCode { get; internal set; }


        /// <summary>
        /// Initialise the Status Response
        /// </summary>
        /// <param name="status"></param>
        /// <param name="statusCode"></param>
        public StatusResponse(string status = "301 Moved Permanently", int statusCode = 301)
        {
            this.Status = status;
            this.StatusCode = statusCode;
        }
    }
}