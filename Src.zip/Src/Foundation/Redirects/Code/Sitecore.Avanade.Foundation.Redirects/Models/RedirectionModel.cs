﻿using Sitecore.Data.Items;
using Sitecore.Links;
using Sitecore.Resources.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Redirects.Models
{
    /// <summary>
    /// Redirection Model used to contain all redirection information
    /// </summary>
    [Serializable]
    public class RedirectionModel
    {
        #region Private Variables
        /// <summary>
        /// The redirect Item
        /// </summary>
        [NonSerialized()]
        private Item _redirectionItem;

        /// <summary>
        /// Redirection ID: The item ID, used in serializing back from a serialized object
        /// </summary>
        private Sitecore.Data.ID _redirectionItemId;

        /// <summary>
        /// The Item we are redirecting too
        /// </summary>
        [NonSerialized()]
        private Item _redirectToItem;

        /// <summary>
        /// Redirect too ID: The item ID, used in serializing back from a serialized object
        /// </summary>
        private Sitecore.Data.ID _idToItem;
        #endregion

        #region Public Properties
        /// <summary>
        /// The response status code used for the redirection
        /// </summary>
        public Models.StatusResponse ResponseStatus { get; set; }

        /// <summary>
        /// The redirection to URL
        /// </summary>
        public string RedirectToURL { get; set; }

        /// <summary>
        /// The querystring used for the redirection
        /// </summary>
        public string QueryString { get; set; }

        /// <summary>
        /// The redireciton Id used for outputting
        /// </summary>
        public string RedirectionId { get;set; }

        /// <summary>
        /// The redirection Item
        /// </summary>
        [XmlIgnore()]
        public Item RedirectionItem
        {
            get
            {
                if (this._redirectionItem == null
                    && _redirectionItemId.IsNull
                    && !string.IsNullOrEmpty(RedirectionId)
                    && !Sitecore.Data.ID.TryParse(RedirectionId, out _redirectionItemId))
                {
                    return null;
                }

                // fetch the item if it doesn't exist
                if (this._redirectionItem == null
                    && !_redirectionItemId.IsNull)
                {
                    this._redirectionItem = Sitecore.Context.Database.GetItem(this._redirectionItemId);
                }

                return this._redirectionItem;
            }
            set
            {
                this._redirectionItem = value;

                // set the id
                this._redirectionItemId = value.ID;
                this.RedirectionId = value.ID.ToString();
            }
        }

        /// <summary>
        /// The redirect to Item
        /// </summary>
        [XmlIgnore()]
        public Item RedirectToItem
        {
            get
            {
                // fetch the item if it doesn't exist
                if (this._redirectToItem == null
                    && !_idToItem.IsNull)
                {
                    this._redirectToItem = Sitecore.Context.Database.GetItem(_idToItem);
                }

                return this._redirectToItem;
            }
            set
            {
                this._redirectToItem = value;

                if (this._redirectToItem.Paths.Path.StartsWith(Sitecore.Constants.MediaLibraryPath))
                {
                    var mediaItem = (MediaItem)this._redirectToItem;
                    var mediaUrl = MediaManager.GetMediaUrl(mediaItem);

                    // set the redirection URL
                    RedirectToURL = StringUtil.EnsurePrefix('/', mediaUrl);
                }
                else
                {
                    RedirectToURL = LinkManager.GetItemUrl(this._redirectToItem);
                }

                // set the id
                this._idToItem = value.ID;
            }
        }

        /// <summary>
        /// Has the redirection model been processed previously
        /// </summary>
        public bool PreProcessed { get; set; }
        #endregion
    }
}