using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using Sitecore.Data;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Redirects.Models
{
    /// <summary>
    /// Extends the SearchResultItem to match the required fields for the search
    /// </summary>
    public class RedirectSearchResultItem : SearchResultItem
    {
        /// <summary>
        /// The Requested URL
        /// </summary>
        [IndexField(Constants.Templates.Redirection.Fields.RequestedUrl)]
        public string RequestedUrl { get; set; }

        /// <summary>
        /// Is the path a regex expression
        /// </summary>
        [IndexField(Constants.Templates.Redirection.Fields.IsRegex)]
        public bool IsRegex { get; set; }

        /// <summary>
        /// Are we exlcuding the querystring
        /// </summary>
        [IndexField(Constants.Templates.Redirection.Fields.ExcludeQueryString)]
        public bool ExcludeQueryString { get; set; }

        /// <summary>
        /// Are we redirecting to an item
        /// </summary>
        [IndexField(Constants.Templates.Redirection.Fields.RedirectToItem)]
        public string RedirectToItem { get; set; }

        /// <summary>
        /// Are we redirecting to a new URL
        /// </summary>
        [IndexField(Constants.Templates.Redirection.Fields.RedirectToUrl)]
        public string RedirectToUrl { get; set; }
    }
}