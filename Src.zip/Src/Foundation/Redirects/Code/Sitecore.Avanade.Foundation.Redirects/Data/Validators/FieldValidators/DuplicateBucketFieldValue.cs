﻿using Sitecore.Data.Validators;
using System;
using System.Runtime.Serialization;
using Sitecore.Avanade.Foundation.Extensions;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Redirects.Data.Validators.FieldValidators
{
    /// <summary>
    /// The duplicate incoming path
    /// </summary>
    [Serializable]
    public class DuplicateBucketFieldValue : StandardValidator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:Sitecore.Avanade.Foundation.Redirects.Data.Validators.FieldValidators.DuplicateIncomingPath" /> class. 
        /// </summary>
        public DuplicateBucketFieldValue()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Sitecore.Avanade.Foundation.Redirects.Data.Validators.FieldValidators.DuplicateIncomingPath" /> class. 
        /// </summary>
        /// <param name="info">
        /// The serialization info.
        /// </param>
        /// <param name="context">
        /// The context.
        /// </param>
        public DuplicateBucketFieldValue(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The validator name.</value>
        public override string Name
        {
            get
            {
                return "Duplicate Bucket Field Value";
            }
        }

        /// <summary>
        /// When overridden in a derived class, this method contains the code to determine whether the value in the input control is valid.
        /// </summary>
        /// <returns>
        /// The result of the evaluation.
        /// </returns>
        protected override ValidatorResult Evaluate()
        {
            var field = base.GetField();

            if (string.IsNullOrEmpty(inputFieldName))
            {
                return ValidatorResult.Valid;
            }

            // make sure we have some form of text from the field
            string text = this.ControlValidationValue;
            if (string.IsNullOrEmpty(text))
            {
                return ValidatorResult.Valid;
            }

            // get the parent bucket so we can perform a search
            var itemBucket = base.GetItem().GetParentBucketItemOrParent();

            if (itemBucket == null)
            {
                return ValidatorResult.Valid;
            }

            var items = itemBucket.Axes.GetDescendants().Where(x => x.Fields[inputFieldName].ValueSafe().Equals(text, StringComparison.OrdinalIgnoreCase));

            if (items == null
                || (items.Count() == 1 && items.First().ID.EqualsTo(base.GetItem().ID.ToString())))
            {
                return ValidatorResult.Valid;
            }

            base.Text = this.GetText("The field \"{0}\" is a duplicate already present with the value '{1}'.", new string[]
            {
                base.GetFieldDisplayName(),
                text
            });
            return base.GetFailedResult(ValidatorResult.Error);
        }

        /// <summary>
        /// Gets the max validator result.
        /// </summary>
        /// <remarks>
        /// This is used when saving and the validator uses a thread. If the Max Validator Result
        /// is Error or below, the validator does not have to be evaluated before saving.
        /// If the Max Validator Result is CriticalError or FatalError, the validator must have
        /// been evaluated before saving.
        /// </remarks>
        /// <returns>
        /// The max validator result.
        /// </returns>
        // Token: 0x060056A7 RID: 22183 RVA: 0x001326DF File Offset: 0x001308DF
        protected override ValidatorResult GetMaxValidatorResult()
        {
            return base.GetFailedResult(ValidatorResult.Error);
        }
    }
}
