﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Events;
using Sitecore.SecurityModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Events
{
    /// <summary>
    /// Monitors any changes in the redirection items and fixes any references
    /// </summary>
    public class ItemEventHandler
    {
        #region OnItemAdded
        /// <summary>
        /// Called when the item has been added.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="T:System.EventArgs" /> instance containing the event data.</param>
        public void OnItemProccessed(object sender, System.EventArgs e)
        {
            // make sure we have data
            if (e == null)
            {
                return;
            }

            // get the item
            Item item = Event.ExtractParameter<Item>(e, 0);

            // have we got an item
            if (item != null)
            {
                ClearCacheItem(item);
            }
        }
        #endregion
        

        #region OnItemSaved
        /// <summary>
        /// Called when the item has been saved.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="args">
        /// The arguments.
        /// </param>
        internal void OnItemSaved(object sender, System.EventArgs e)
        {
            // make sure we have data
            if (e == null)
            {
                return;
            }

            // get the item
            Item item = Event.ExtractParameter<Item>(e, 0);

            // make sure we have our template
            if (item != null && item.TemplateName.Equals(Constants.Templates.Redirection.Name, StringComparison.CurrentCultureIgnoreCase))
            {
                // get out the ID of the calling page
                string redirectionId = item.Fields[Constants.Templates.Redirection.Fields.RedirectToItem].ValueSafe();

                // get the changes listing
                ItemChanges itmChanged = Event.ExtractParameter(e, 1) as ItemChanges;

                ID fieldID = item.Fields[Constants.Templates.Redirection.Fields.RedirectToItem].ID;

                // has the field changed
                if (itmChanged != null && itmChanged.IsFieldModified(fieldID))
                {
                    // get the field changed
                    FieldChange fieldChange = itmChanged.FieldChanges[fieldID];

                    // has the field value changed for empty
                    if (!fieldChange.OriginalValue.IsNullOrEmpty())
                    {
                        // remove the existing cache instance to remove the instance
                        Cache.Cache.Remove(Constants.Cache.WarningMarker.Fmt(fieldChange.OriginalValue));
                    }
                }

                // do we have a calling Item
                if (!redirectionId.IsNullOrEmpty())
                {
                    // clear the id that is being called
                    Cache.Cache.Remove(Constants.Cache.WarningMarker.Fmt(redirectionId));
                }
            }
        }
        #endregion
        
        #region Clear Cache Item
        /// <summary>
        /// Clears the cache maker for the warnings
        /// </summary>
        /// <param name="itm"></param>
        private void ClearCacheItem(Item itm)
        {
            // make sure we have our template
            if (itm.TemplateName.Equals(Constants.Templates.Redirection.Name, StringComparison.CurrentCultureIgnoreCase))
            {
                // get out the ID of the calling page
                string redirectionId = itm.Fields[Constants.Templates.Redirection.Fields.RedirectToItem].ValueSafe();

                // do we have a calling Item
                if (!redirectionId.IsNullOrEmpty())
                {
                    // clear the id that is being called
                    Cache.Cache.Remove(Constants.Cache.WarningMarker.Fmt(redirectionId));
                }
            }
        }
        #endregion
    }
}