﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects
{
    public static class Collections
    {
        /// <summary>
        /// The collection of URLS that need to be redirected
        /// </summary>
        private static ConcurrentDictionary<string, Models.RedirectionModel> _redirectCollection = new ConcurrentDictionary<string, Models.RedirectionModel>();

        /// <summary>
        /// The collection of urls to be ignored
        /// </summary>
        private static ConcurrentDictionary<string, string> _ignoreCollection = new ConcurrentDictionary<string, string>();

        /// <summary>
        /// Collection of redirections that have already been processed
        /// </summary>
        /// <returns></returns>
        public static ConcurrentDictionary<string, Models.RedirectionModel> RedirectionCollection()
        {
            return _redirectCollection;
        }

        /// <summary>
        /// Collection of URLs to ignore
        /// </summary>
        /// <returns></returns>
        public static ConcurrentDictionary<string, string> IgnoreCollection()
        {
            return _ignoreCollection;
        }
    }
}