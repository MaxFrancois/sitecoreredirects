﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines.HttpRequest;
using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Extensions;
using System;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.HttpRequest
{
    /// <summary>
    /// Resolver for Redirections
    /// </summary>
    public class RedirectResolver : HttpRequestProcessor
    {
        private static string _mediaLinkPrefix = string.Format("/{0}", Sitecore.Configuration.Settings.Media.MediaLinkPrefix);

        /// <summary>/
        /// Run the Redirect Pipeline
        /// </summary>
        public override void Process(HttpRequestArgs args)
        {
            #region Validation Check
            // This processer is added to the pipeline after the Sitecore Item Resolver.  We want to
            // skip everything if the item resolved successfully. Also, skip processing for the
            // visitor identification items related to DMS.
            Assert.ArgumentNotNull(args, "args");

            // stop execution as quickly as possible
            if (!Settings.IsEnabled
                ||Sitecore.Configuration.State.Previewing
                || Sitecore.Configuration.State.WebEditing
                || Sitecore.Configuration.State.DebugMode
                || args.Aborted
                || Sitecore.Context.Site == null
                || Sitecore.Context.Database == null
                || args.LocalPath == null
                || args.LocalPath.StartsWith(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.VisitorIdentification)
                || args.Context.Request.Path.StartsWith(Sitecore.Constants.SitecorePath + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.TempFolderPath + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.DataFolder + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.MediaFolder + "/")
                || (!Settings.Media.MediaIsEnabled && args.LocalPath.StartsWith(_mediaLinkPrefix, StringComparison.OrdinalIgnoreCase))
                || Sitecore.Configuration.Factory.GetCustomHandlers().Exists(e => args.Context.Request.Path.StartsWith(string.Format("/{0}", e.Trigger), StringComparison.OrdinalIgnoreCase))
                )
            {
                // error so just stop
                return;
            }
            #endregion

            // has logging been enabled
            if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled
                && Settings.Logs.LogsIsEnabled)
            {
                Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Redirection]: Pipeline: Redirection Processing", this);
            }

            var redirectArgs = new RedirectionRequest.RedirectionArgs(args);

            #region Check if in ignore list
            // do we want to ignore the url
            if (Settings.Ignorelist.IsInitialCheckEnabled
                && redirectArgs.IgnoreCollection != null
                && !redirectArgs.IgnoreCollection.IsEmpty
                && redirectArgs.IgnoreCollection.Keys.Contains(redirectArgs.AbsoluteURL))
            {
                // has logging been enabled
                if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled
                    && Settings.Logs.LogsIsEnabled)
                {
                    Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Redirection]: Pipeline: Redirection Processing - Aborted as URL is in Ignore Collection", this);
                }

                return;
            }
            #endregion

            // execute the pipeline for the redirection
            CorePipeline.Run("redirection", redirectArgs, false);
        }
    }
}

