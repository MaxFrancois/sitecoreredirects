﻿using Sitecore.Globalization;
using System;
using System.Linq;
using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionGetContentEditorWarnings;
using Sitecore.Pipelines.GetPageEditorNotifications;
using System.Text;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Sites;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.GetPageEditorNotifications
{

    public class RedirectionNotification
    {
        public void Process([NotNull] GetPageEditorNotificationsArgs args)
        {
            // make sure the dtata is valid
            Sitecore.Diagnostics.Assert.IsNotNull(args, "args");
            Sitecore.Diagnostics.Assert.IsNotNull(args.ContextItem, "args.ContextItem");
            
            // make sure we have data to validate
            if (args.ContextItem != null
                && args.ContextItem.Paths.Path.StartsWith(Sitecore.Constants.ContentPath)
                && !args.ContextItem.TemplateName.Equals(Constants.Templates.Redirection.Name, StringComparison.OrdinalIgnoreCase))
            {
                // get the cache marker
                string markerCache = Constants.Cache.WarningMarker.Fmt(args.ContextItem.ID.ToString());

                // get out the data to see if this has already been processed
                PageEditorNotification pageEditorNotification = Foundation.Cache.Cache.Get<PageEditorNotification>(markerCache, () =>
                {
                    PageEditorNotification information = new PageEditorNotification("", PageEditorNotificationType.Information);

                    // get the database name
                    string databaseName = args.ContextItem.Database != null
                                        ? args.ContextItem.Database.Name
                                        : Extensions.Constants.SitecoreConstants.MasterDBName;

                    // the index name
                    string indexName = Settings.IndexFormatter.Fmt(databaseName);

                    // we have to create our args
                    RedirectionGetContentEditorWarningsArgs redirectArgsInternal = new RedirectionGetContentEditorWarningsArgs(args.ContextItem)
                    {
                        HasSections = false,
                        ProcessorItem = args.ProcessorItem,
                        ShowInputBoxes = false,
                        DatabaseName = databaseName,
                        IndexName = indexName,
                        IndexValid = Sitecore.ContentSearch.ContentSearchManager.Indexes.Any(x => x.Name.Equals(indexName, StringComparison.OrdinalIgnoreCase))
                    };

                    // execute the pipeline for the redirection
                    CorePipeline.Run("redirectionGetContentEditorWarnings", redirectArgsInternal, false);

                    // do we have any data
                    if (redirectArgsInternal.Items != null
                        && redirectArgsInternal.Items.Any())
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.AppendFormat(Translate.Text("[Redirections]: '{0}'."), redirectArgsInternal.Items.Count.ToString());

                        // we only want to show a maximum of 10 results
                        if (redirectArgsInternal.Items.Count > 5)
                        {
                            sb.Append(Translate.Text(" NOTE: Maximum of 5 redirects shown."));
                        }

                        // we have to cast as the description field is readonly
                        information = new PageEditorNotification(sb.ToString(), PageEditorNotificationType.Information);
                        information.Icon = "/sitecore/shell/themes/standard/Images/warning_yellow.png";

                        // cycle the list
                        redirectArgsInternal.Items.Take(5).ForEach(i =>
                        {
                            // get the item
                            var redirectitem = redirectArgsInternal.Item.Database.GetItem(i);

                            // just make sure
                            if (redirectitem != null)
                            { 
                                // get the site
                                SiteContext site = redirectitem.GetSite();

                                // get the name
                                string siteName = site == null ? "Foundation" : site.Name;

                                // add the option
                                information.Options.Add(new PageEditorNotificationOption(Translate.Text("'{0}' - Site: '{1}'").Fmt(redirectitem.Fields[Constants.Templates.Redirection.Fields.RequestedUrl].ValueSafe(), siteName),
                                    "item:load(id={0}, language={1}, version={2})".Fmt(redirectitem.ID, redirectitem.Language, redirectitem.Version)));
                            }
                        });
                        
                    }

                    return information;
                }, System.DateTime.Now.AddMinutes(5));

                args.Notifications.Add(pageEditorNotification);
            }
        }
    }
}