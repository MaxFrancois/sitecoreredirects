﻿using Sitecore.Pipelines.GetContentEditorWarnings;
using Sitecore.Globalization;
using System;
using System.Linq;
using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionGetContentEditorWarnings;
using static Sitecore.Pipelines.GetContentEditorWarnings.GetContentEditorWarningsArgs;
using Sitecore.Sites;
using Sitecore.Avanade.Foundation.Site.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.GetContentEditorWarnings
{

    public class RedirectionNotification
    {
        public void Process([NotNull] GetContentEditorWarningsArgs args)
        {
            // make sure the dtata is valid
            Sitecore.Diagnostics.Assert.IsNotNull(args, "args");
            Sitecore.Diagnostics.Assert.IsNotNull(args.Item, "args.Item");

            // make sure we have data to validate
            if (args.Item != null
                && args.Item.Paths.Path.StartsWith(Sitecore.Constants.ContentPath)
                && !args.Item.TemplateName.Equals(Constants.Templates.Redirection.Name, StringComparison.OrdinalIgnoreCase))
            {
                // get the cache marker
                string markerCache = Constants.Cache.WarningMarker.Fmt(args.Item.ID.ToString());

                // get out the data to see if this has already been processe
                ContentEditorWarning contentEditorWarning = Foundation.Cache.Cache.Get<ContentEditorWarning>(markerCache, () =>
                {
                    ContentEditorWarning contentEditorWarningInternal = new ContentEditorWarning();

                    // get the database name
                    string databaseName = args.Item.Database != null
                                        ? args.Item.Database.Name
                                        : Extensions.Constants.SitecoreConstants.MasterDBName;

                    // the index name
                    string indexName = Settings.IndexFormatter.Fmt(databaseName);

                    // we have to create our args
                    RedirectionGetContentEditorWarningsArgs redirectArgsInternal = new RedirectionGetContentEditorWarningsArgs(args.Item)
                    {
                        HasSections = args.HasSections,
                        ProcessorItem = args.ProcessorItem,
                        ShowInputBoxes = args.ShowInputBoxes,
                        DatabaseName = databaseName,
                        IndexName = indexName,
                        IndexValid = Sitecore.ContentSearch.ContentSearchManager.Indexes.Any(x=>x.Name.Equals(indexName, StringComparison.OrdinalIgnoreCase))
                    };
                
                    // execute the pipeline for the redirection
                    CorePipeline.Run("redirectionGetContentEditorWarnings", redirectArgsInternal, false);

                    // do we have any data
                    if (redirectArgsInternal.Items != null
                        && redirectArgsInternal.Items.Any())
                    {
                        // create the new visual display
                        contentEditorWarningInternal.Title = Translate.Text("[Redirections]");
                        contentEditorWarningInternal.IsExclusive = false;
                        contentEditorWarningInternal.Icon = "/sitecore/shell/themes/standard/Images/warning_yellow.png";
                        contentEditorWarningInternal.Text = String.Format(Translate.Text("Redirections identified - '{0}'."), redirectArgsInternal.Items.Count.ToString());

                        // we only want to show a maximum of 10 results
                        if (redirectArgsInternal.Items.Count > 10)
                        {
                            contentEditorWarningInternal.Text += Translate.Text("<br/>NOTE: Maximum of 10 redirects shown.");
                        }

                        // cycle the list
                        redirectArgsInternal.Items.Take(10).ForEach(i =>
                        {
                            // get the item
                            var redirectitem = args.Item.Database.GetItem(i);

                            // just make sure
                            if (redirectitem != null)
                            {
                                // get the site
                                SiteContext site = redirectitem.GetSite();

                                // get the name
                                string siteName = site == null ? "Foundation" : site.Name;

                                contentEditorWarningInternal.AddOption(Translate.Text("Redirection: '{0}' - Actioning site: '{1}'").Fmt(redirectitem.Fields[Constants.Templates.Redirection.Fields.RequestedUrl].ValueSafe(), siteName),
                                    "item:load(id={0}, language={1}, version={2})".Fmt(redirectitem.ID, redirectitem.Language, redirectitem.Version));
                            }
                        });
                    }

                    return contentEditorWarningInternal;
                }, System.DateTime.Now.AddMinutes(5));

                // make sure we have data to process
                if (contentEditorWarning != null && !contentEditorWarning.Title.IsNullOrEmpty())
                {
                    args.Warnings.Add(contentEditorWarning);
                }
            }
        }
    }
}