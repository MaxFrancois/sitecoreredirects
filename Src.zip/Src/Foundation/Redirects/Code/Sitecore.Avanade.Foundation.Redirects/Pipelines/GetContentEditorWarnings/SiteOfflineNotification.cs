﻿using Sitecore.Pipelines.GetContentEditorWarnings;
using Sitecore.Globalization;
using System;
using Sitecore.Avanade.Foundation.Extensions;
using static Sitecore.Pipelines.GetContentEditorWarnings.GetContentEditorWarningsArgs;
using Sitecore.Sites;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.GetContentEditorWarnings
{

    public class SiteOfflineNotification
    {
        public void Process([NotNull] GetContentEditorWarningsArgs args)
        {
            // make sure we have data to validate
            if (args?.Item != null
                && args.Item.Paths.Path.StartsWith(Sitecore.Constants.ContentPath)
                && !args.Item.TemplateName.Equals(Constants.Templates.Redirection.Name, StringComparison.OrdinalIgnoreCase))
            {
                // get the setting item
                Item settingItem = Sitecore.Avanade.Foundation.Site.Helpers.Bedrock.FindFoundationItem(args.Item, Constants.Templates.RedirectionFolder.TemplateId);

                // for the site is this offline
                if (settingItem != null
                    && settingItem.Fields[Constants.Templates.RedirectionFolder.Fields.SiteOfflineEnabled].IsChecked())
                {
                    // get the page editor
                    ContentEditorWarning information = new ContentEditorWarning();
                    information.Title = "[Redirections] - Site Offline";
                    information.IsExclusive = false;
                    information.Icon = "/sitecore/shell/themes/standard/Images/error.png";
                    
                    // get the site
                    SiteContext site = args.Item.GetSite();

                    // get the name
                    string siteName = site == null ? "Foundation" : site.Name;

                    // add the option
                    information.AddOption(Translate.Text("Offline Set in site: '{0}'").Fmt(siteName),
                        "item:load(id={0}, language={1}, version={2})".Fmt(settingItem.ID, settingItem.Language, settingItem.Version));

                    args.Warnings.Add(information);
                }
            }
        }
    }
}