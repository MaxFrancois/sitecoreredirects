﻿using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Permissions;


namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionGetContentEditorWarnings
{
    [Serializable]
#pragma warning disable S3925 // "ISerializable" should be implemented correctly
    public class RedirectionGetContentEditorWarningsArgs : Sitecore.Pipelines.GetContentEditorWarnings.GetContentEditorWarningsArgs
#pragma warning restore S3925 // "ISerializable" should be implemented correctly
    {
        /// <summary>
        /// Collection of Items, can be ID, paths etc
        /// </summary>
        public List<string> Items { get; set; } = new List<string>();

        /// <summary>
        /// The Index Name
        /// </summary>
        public string IndexName { get; set; }

        /// <summary>
        /// Is the index valid
        /// </summary>
        public bool IndexValid { get; set; }

        /// <summary>
        /// The Database name
        /// </summary>
        public string DatabaseName { get; set; }

        /// <summary>
        /// The Settings Item
        /// </summary>
        public Item SettingItem { get; set; }


        protected RedirectionGetContentEditorWarningsArgs(SerializationInfo info, StreamingContext context) : base(info, context)
        { }

        public RedirectionGetContentEditorWarningsArgs(Item itm) : base(itm)
        {
            // set the setting item based on the supplied item
            SettingItem = Sitecore.Avanade.Foundation.Site.Helpers.Bedrock.FindFoundationItem(itm, Constants.Templates.RedirectionFolder.TemplateId);
        }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }
            base.GetObjectData(info, context);
        }
    }
}