﻿using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionGetContentEditorWarnings
{
    /// <summary>
    /// Adds the items which are of exact match
    /// </summary>
    public class ExactMatchResult
    {
        public void Process([NotNull] RedirectionGetContentEditorWarningsArgs args)
        {
            // no index get out
            if (!args.IndexValid)
            {
                return;
            }

            // set the search results listing
            IQueryable<Models.RedirectSearchResultItem> searchResults = null;

            // engadge the search manager
            using (var searchContext = Sitecore.ContentSearch.ContentSearchManager.GetIndex(args.IndexName).CreateSearchContext())
            {
                // set the lucene id to search for, need to use the N formatter
                string luceneId = args.Item.ID.ToLuceneID("N");

                // search for the query we want
                searchResults = searchContext.GetQueryable<Models.RedirectSearchResultItem>().Where(i =>
                    i.TemplateName == Constants.Templates.Redirection.Name
                    && (i.Path.StartsWith(Sitecore.Constants.ContentPath) || i.Path.StartsWith(Sitecore.Avanade.Foundation.Bedrock.Settings.FoundationSettingsPath))
                    && !i.IsRegex
                    && i.RedirectToItem.Equals(luceneId)
                    //&& (Settings.Global.IsEnabled && i.Path.StartsWith(Settings.Global.Path))
                    );
            
                // do we have any search results
                if (searchResults != null
                    && searchResults.Count() > 0)
                {
                    // add the list
                    searchResults.ForEach(i => {
                        args.Items.Add(i.ItemId.ToString());
                    });
                }
            }
        }
    }
}