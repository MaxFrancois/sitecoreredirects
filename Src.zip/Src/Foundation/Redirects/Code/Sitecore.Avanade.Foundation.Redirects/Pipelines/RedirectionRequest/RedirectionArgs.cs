﻿using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Links;
using System;
using System.Collections.Concurrent;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Web;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    [Serializable]
#pragma warning disable S3925 // "ISerializable" should be implemented correctly
    public class RedirectionArgs: Sitecore.Pipelines.PipelineArgs
#pragma warning restore S3925 // "ISerializable" should be implemented correctly
    {
        /// <summary>
        /// THe redirection model
        /// </summary>
        public Models.RedirectionModel RedirectionModel { get; set; }
        
        /// <summary>
        /// Returns the HttpRequestArgs supplied
        /// </summary>
        [XmlIgnore]
        public Sitecore.Pipelines.HttpRequest.HttpRequestArgs HttpRequestArgs { get; internal set; }

        [XmlIgnore]
        public System.Uri RequestUrl
        {
            get
            {
                return HttpContext.Current.Request.Url;
            }
        }
        
        public string AbsoluteURL { get; internal set; }
        
        public bool RedirectionFound
        {
            get
            {
                return (this.RedirectionModel != null && !String.IsNullOrEmpty(this.RedirectionModel.RedirectToURL));
            }
        }


        public ConcurrentDictionary<string, Models.RedirectionModel> RedirectionCollection
        {
            get
            {
                return Collections.RedirectionCollection();
            }
        }


        public ConcurrentDictionary<string, string> IgnoreCollection
        {
            get
            {
                return Collections.IgnoreCollection();
            }
        }

        /// <summary>
        /// Extends the HttpRequestArgs for the Redireciton pipeline
        /// </summary>
        /// <param name="args">The HttpRequestArgs supplied in the pipeline for the HttpRequest Pipeline</param>
        public RedirectionArgs(Sitecore.Pipelines.HttpRequest.HttpRequestArgs args)
        {
            // make sure we have our data
            Assert.ArgumentNotNull(args, "args");

           this.HttpRequestArgs = args;
            
            this.AbsoluteURL = HttpContext.Current.Request.Url.AbsoluteUri.ToLower();
            
            // setup the redireciton model, may be changed from cache
            this.RedirectionModel = new Models.RedirectionModel();
        }

        public RedirectionArgs()
        {
        }

        protected RedirectionArgs(SerializationInfo info, StreamingContext context) : base(info, context)
        { }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }

            base.GetObjectData(info, context);
        }
    }
}