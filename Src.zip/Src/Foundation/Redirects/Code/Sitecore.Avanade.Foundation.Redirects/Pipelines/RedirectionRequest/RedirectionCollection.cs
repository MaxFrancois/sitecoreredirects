﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class RedirectionCollection
    {
        public void Process(RedirectionArgs args)
        {
            // do we have our cached instance     
            #region redirecting from cached lists
            // has this already been executed
            if (args.RedirectionCollection != null
                && !args.RedirectionCollection.IsEmpty
                && args.RedirectionCollection.ContainsKey(args.AbsoluteURL))
            {
                Models.RedirectionModel redirectUrlCheck = null;

                // gets out the key
                args.RedirectionCollection.TryGetValue(args.AbsoluteURL, out redirectUrlCheck);

                // make sure we have data
                if (redirectUrlCheck != null)
                {
                    // set the redirection requirements
                    args.RedirectionModel = redirectUrlCheck;
                }
            }
            #endregion
        }
    }
}