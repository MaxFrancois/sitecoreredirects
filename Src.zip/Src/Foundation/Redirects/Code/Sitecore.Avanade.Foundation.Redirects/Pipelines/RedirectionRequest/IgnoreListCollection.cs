﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class IgnoreListCollection
    {
        public void Process(RedirectionArgs args)
        {
            // do we want to ignore the url
            if (!Settings.Ignorelist.IsInitialCheckEnabled
                && args.IgnoreCollection != null
                && !args.IgnoreCollection.IsEmpty
                && args.IgnoreCollection.Keys.Contains(args.AbsoluteURL))
            {
                args.AbortPipeline();
                return;
            }
        }
    }
}