﻿using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Diagnostics;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class ExactMatchResult
    {
        /// <summary>
        /// Performs a search on any exact match results
        /// </summary>
        /// <param name="args"></param>
        public void Process(RedirectionArgs args)
        {
            // if the redirection has been processed skip this
            if (args.RedirectionFound)
            {
                return;
            }

            // set the search results listing
            IQueryable<Models.RedirectSearchResultItem> searchResults = null;

            // TODO: Fix up if the index is not found
            // engadge the search manager
            using (var searchContext = Sitecore.ContentSearch.ContentSearchManager.GetIndex(Settings.IndexFormatter.Fmt(Sitecore.Context.Database.Name)).CreateSearchContext())
            {
                // remove the schema: eg: //domain.com/test/something?query=22 (includes query)
                var schemalessAbsoluteURL = args.AbsoluteURL.TrimStart(args.RequestUrl.Scheme.Fmt("{0}:").ToCharArray());

                // eg: /path/something.aspx (no query)
                var absolutePath = args.RequestUrl.AbsolutePath;

                // eg: /path/something?query=dd
                var absolutePathQuery = args.RequestUrl.PathAndQuery;

                // eg: http://domian.com/test/something
                var fullAbsolutePath = "{0}://{1}{2}".Fmt(args.RequestUrl.Scheme, args.RequestUrl.Host, args.RequestUrl.AbsolutePath);

                // search for the query we want
                searchResults = searchContext.GetQueryable<Models.RedirectSearchResultItem>().Where(i =>
                    i.TemplateName == Constants.Templates.Redirection.Name
                    && (i.Path.StartsWith(Sitecore.Constants.ContentPath) || i.Path.StartsWith(Sitecore.Avanade.Foundation.Bedrock.Settings.FoundationSettingsPath))
                    && !i.IsRegex
                    && (i.RequestedUrl == args.AbsoluteURL // includes query
                        || i.RequestedUrl == schemalessAbsoluteURL // includes query
                        || i.RequestedUrl == absolutePathQuery // includes query
                        || (i.ExcludeQueryString && (i.RequestedUrl == absolutePath || i.RequestedUrl == fullAbsolutePath))
                        )
                );
            

                // do we have any search results
                if (searchResults != null
                    && searchResults.Count() > 0)
                {
                    // get the first item
                    Models.RedirectSearchResultItem resultItem = searchResults.First();

                    #region Debug Logging for more information More Results than expected
                    // do we have more than one result to indicate to the user that this needs to be fixed
                    if (searchResults.Count() > 1
                        && Settings.Logs.LogsIsEnabled
                        && Settings.Logs.MultipleResults)
                    {
                        if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsInfoEnabled)
                        {
                            Log.Info($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Redirection]: Exact Match Result - Found more then 1 result found: '{0}'. Enable Debug logging for more information".Fmt(args.AbsoluteURL), this);
                        }

                        // are we in info mode to output more information
                        if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                        {
                            // cycle over the results but we will only use the first one
                            searchResults.ForEach(i => {
                                Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Redirection]: Exact Match Result - '{0}' found Item: {1}".Fmt(args.AbsoluteURL, i.Path), this);
                            });
                        }
                    }
                    #endregion

                    // are we redirecting to an item or a URL
                    if (!resultItem.RedirectToItem.IsNullOrEmpty())
                    {
                        args.RedirectionModel.RedirectToItem = Extensions.Helpers.ItemHelper.GetItemFromLuceneId(resultItem.RedirectToItem);
                    }
                    else
                    {
                        args.RedirectionModel.RedirectToURL = resultItem.RedirectToUrl;
                    }

                    // The Sitecore Item ID of the redirect
                    args.RedirectionModel.RedirectionId = resultItem.ItemId.ToString();
                }
            }
        }
    }
}