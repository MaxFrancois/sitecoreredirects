﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class RegexMatchResult
    {
        public void Process(RedirectionArgs args)
        {
            // if the redirection has been processed skip this
            if (args.RedirectionFound)
            {
                return;
            }

            
            
#pragma warning disable S125 // Sections of code should not be "commented out"
/*
            // Loop through the pattern match items to find a match
            foreach (var possibleRedirectPattern in GetRedirects(db, Constants.Templates.RedirectPattern, Constants.Templates.VersionedRedirectPattern, Sitecore.Configuration.Settings.GetSetting(Constants.Settings.QueryExactMatch)))
            {
                var redirectPath = string.Empty;
                if (Regex.IsMatch(requestedUrl, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedUrl, possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                    possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                else if (Regex.IsMatch(requestedUrlWithoutScheme, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedUrlWithoutScheme, possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                    possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                else if (Regex.IsMatch(requestedPathAndQuery, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedPathAndQuery,
                                                    possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                    possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                if (string.IsNullOrEmpty(redirectPath)) continue;
                    
                SendResponse(redirectPath, "", args, possibleRedirectPattern.ID.ToString());
            }*/
        }
#pragma warning restore S125 // Sections of code should not be "commented out"
    }
}