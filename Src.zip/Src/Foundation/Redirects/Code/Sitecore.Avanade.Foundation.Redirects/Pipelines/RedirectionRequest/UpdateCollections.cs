﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class UpdateCollections
    {
        /// <summary>
        /// Updates the Redirection Collection and the Ignore Collections
        /// </summary>
        /// <param name="args"></param>
        public void Process(RedirectionArgs args)
        {
            // make sure we do a redirect if not add to ignore list
            if (args.RedirectionFound)
            {
                // add the redirect to the redirect collection
                if (args.RedirectionCollection != null
                    && !args.RedirectionCollection.Keys.Contains(args.AbsoluteURL))
                {
                    args.RedirectionCollection.TryAdd(args.AbsoluteURL, args.RedirectionModel);
                }

            }
            else
            {
                // Add Url to ignore list to reduce execution of redirection pipeline code
                if (args.IgnoreCollection != null
                    && !args.IgnoreCollection.Keys.Contains(args.AbsoluteURL))
                {
                    args.IgnoreCollection.TryAdd(args.AbsoluteURL, string.Empty);
                }
            }
        }
    }
}