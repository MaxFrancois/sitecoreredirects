﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class SchemalessResolve
    {
        /// <summary>
        /// The path we want to look out for
        /// </summary>
        private readonly string _startsWith = "//";

        /// <summary>
        /// The final format URL we want to ensure is set
        /// </summary>
        private readonly string _requestURLFormat = "{0}:{1}";

        /// <summary>
        /// Processor to ensure the schemaless redirection obsorbs the
        /// requesting URL schema
        /// </summary>
        /// <param name="args"></param>
        public void Process(RedirectionArgs args)
        {
            // make sure we do a redirect if not add to ignore list
            if (args.RedirectionFound
                && !args.RedirectionModel.PreProcessed
                && args.RedirectionModel.RedirectToURL.StartsWith(this._startsWith))
            {
                //Set the right url scheme
                args.RedirectionModel.RedirectToURL = args.RequestUrl.Scheme.Fmt(this._requestURLFormat, args.RedirectionModel.RedirectToURL);
            }
        }
    }
}