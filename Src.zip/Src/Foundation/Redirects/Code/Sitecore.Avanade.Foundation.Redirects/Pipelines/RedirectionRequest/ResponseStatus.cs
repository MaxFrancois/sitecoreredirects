﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class ResponseStatus
    {
        public void Process(RedirectionArgs args)
        {
            // make sure we do a redirect if not add to ignore list
            if (args.RedirectionFound
                && !args.RedirectionModel.PreProcessed)
            {
                // are we dealing with a temporary redirect
                if (args.RedirectionModel.RedirectionItem.Fields[Constants.Templates.Redirection.Fields.RedirectionTemporary].IsChecked())
                {
                    // set the status code we want to return
                    args.RedirectionModel.ResponseStatus = new Models.StatusResponse("302 Temporary Movied", 302);
                }
                // are we dealing with a deleted item
                else if (args.RedirectionModel.RedirectionItem.Fields[Constants.Templates.Redirection.Fields.ItemDeleted].IsChecked())
                {
                    // set the status code we want to return
                    args.RedirectionModel.ResponseStatus = new Models.StatusResponse("410 Content Deleted", 410);
                }
            }
        }
    }
}