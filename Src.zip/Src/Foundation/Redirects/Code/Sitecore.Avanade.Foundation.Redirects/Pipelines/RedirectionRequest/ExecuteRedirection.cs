﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class ExecuteRedirection
    {
        public void Process(RedirectionArgs args)
        {
            // make sure we do a redirect if not add to ignore list
            if (args.RedirectionFound)
            {
                // add the redirect to the redirect collection
                if (args.RedirectionCollection != null
                    && !args.RedirectionCollection.Keys.Contains(args.AbsoluteURL))
                {
                    args.RedirectionCollection.TryAdd(args.AbsoluteURL, args.RedirectionModel);
                }

                // update the response headers and status
                args.HttpRequestArgs.Context.Response.Status = args.RedirectionModel.ResponseStatus.Status;
                args.HttpRequestArgs.Context.Response.StatusCode = args.RedirectionModel.ResponseStatus.StatusCode;
                args.HttpRequestArgs.Context.Response.AddHeader("Location", args.RedirectionModel.RedirectToURL + args.RedirectionModel.QueryString);

                // make sure we have an ID to send back for our checks
                if (!args.RedirectionModel.RedirectionId.IsNullOrEmpty())
                {
                    args.HttpRequestArgs.Context.Response.AddHeader("SID", args.RedirectionModel.RedirectionId);
                }

                // update the response and redirect
                args.HttpRequestArgs.Context.Response.End();
            }
            else
            {
                // Add Url to ignore list to reduce execution of redirection pipeline code
                if (args.IgnoreCollection != null && !args.IgnoreCollection.Keys.Contains(args.AbsoluteURL))
                {
                    args.IgnoreCollection.TryAdd(args.AbsoluteURL, string.Empty);
                }
            }
        }
    }
}