﻿using System.Collections.Concurrent;
using System.Web;
using System.Xml.Serialization;
using Sitecore;
using Sitecore.Data;
using System;
using Sitecore.Data.Items;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
using Sitecore.Links;
using Sitecore.Pipelines.HttpRequest;
using Sitecore.Diagnostics;
using Sitecore.Resources.Media;

using Sitecore.Avanade.Foundation.Extensions;


namespace Sitecore.AIOLD.Foundation.Redirects.Pipelines.RedirectionRequest
{
    internal class Something
    {
        public static ConcurrentDictionary<string, string[]> _redirectCollection = new ConcurrentDictionary<string, string[]>();
    }

    /// <summary>
    /// Handles the Redirects managed via the CMS using the
    /// open source Shared Source Redirects Module for it's Sitecore
    /// Items, templates only. This code is heavily modified and upgraded to work with Sitecore 8
    /// Moreinfo: https://marketplace.sitecore.net/Modules/301_Redirect_module.aspx?sc_lang=en
    /// </summary>
    public class RedirectResolverDeddd : HttpRequestProcessor
    {
        /// <summary>
        /// The collection of URLS that need to be redirected
        /// </summary>
        private static ConcurrentDictionary<string, string[]> _redirectCollection = new ConcurrentDictionary<string, string[]>();

        /// <summary>
        /// The collection of urls to be ignored
        /// </summary>
        private static ConcurrentDictionary<string, string> _ignoreCollection = new ConcurrentDictionary<string, string>();

        /// <summary>
        /// The cache key for the redirect URLS
        /// </summary>
        private const string _cacheKey = "Reactive.Redirect.RedirectURLs";

        /// <summary>
        /// The cache key for the redirect items
        /// </summary>
        private const string _cacheKeyItems = "Redirect.RedirectItems.{0}";

        /// <summary>
        /// Make sure we get the correct media link
        /// </summary>
        private static string _mediaLinkPrefix = string.Format("/{0}", Sitecore.Configuration.Settings.Media.MediaLinkPrefix);

        /// <summary>
        /// Unique ID
        /// </summary>
        private static ID _redirectPageTemplateId = ID.Parse("{4CCF2C29-D20F-4373-8DA0-A13349F2DECC}");

        /// <summary>
        ///  The main method for the processor.  It simply overrides the Process method.
        /// </summary>
        public override void Process(HttpRequestArgs args)
        {
            #region Validation Check
            // This processer is added to the pipeline after the Sitecore Item Resolver.  We want to
            // skip everything if the item resolved successfully. Also, skip processing for the
            // visitor identification items related to DMS.
            Assert.ArgumentNotNull(args, "args");

            // stop execution as quickly as possible
            if (Sitecore.Configuration.State.Previewing
                || Sitecore.Configuration.State.WebEditing
                || Sitecore.Configuration.State.DebugMode
                || args.Aborted
                || Sitecore.Context.Site == null
                || Sitecore.Context.Database == null
                || args.LocalPath == null
                || args.LocalPath.StartsWith(Constants.Paths.VisitorIdentification)
                || args.Context.Request.Path.StartsWith(Sitecore.Constants.SitecorePath + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.TempFolderPath + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.DataFolder + "/")
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.MediaFolder + "/")
                || args.LocalPath.StartsWith(_mediaLinkPrefix, StringComparison.OrdinalIgnoreCase)
                || Sitecore.Configuration.Factory.GetCustomHandlers().Exists(e => args.Context.Request.Path.StartsWith(string.Format("/{0}", e.Trigger), StringComparison.OrdinalIgnoreCase))
                )
            {
                // error so just stop
                return;
            }
            #endregion

            // get the current URL
            var url = HttpContext.Current.Request.Url.AbsoluteUri.ToLower();

            // do we have our cached instance
            #region Clear Instance
            // do we have our cached instance
            bool? isRedirectCached = Sitecore.Avanade.Foundation.Cache.Cache.Get<bool>(_cacheKey);

            // confirm we do not have to clear the redirects
            if (isRedirectCached == null || !isRedirectCached.HasValue || !isRedirectCached.Value)
            {
                // we need to clear the instance
                _redirectCollection.Clear();
                _ignoreCollection.Clear();

                // set the data so it's always valid
                Sitecore.Avanade.Foundation.Cache.Cache.Add(_cacheKey, true, System.DateTime.Now.AddHours(1));
            }
            #endregion

            #region Check Ignore Lists
            // do we want to ignore the url
            if (_ignoreCollection != null
                && !_ignoreCollection.IsEmpty
                && _ignoreCollection.Keys.Contains(url))
            {
                return;
            }
            #endregion

            #region redirecting from cached lists
            // has this already been executed
            if (_redirectCollection != null
                && !_redirectCollection.IsEmpty
                && _redirectCollection.ContainsKey(url))
            {
                string[] redirectUrlCheck = null;

                // gets out the key
                _redirectCollection.TryGetValue(url, out redirectUrlCheck);

                if (redirectUrlCheck.Length > 1 && !string.IsNullOrEmpty(redirectUrlCheck[0]))
                {
                    //SendResponse(redirectUrl, HttpContext.Current.Request.Url.Query, args);
                    SendResponse(redirectUrlCheck[0], "", args, redirectUrlCheck[1]);
                }
            }

            #endregion

            ProcessRedirect(args, url);
        }

        /// <summary>
        /// Do the redirect
        /// </summary>
        /// <param name="args"></param>
        /// <param name="url"></param>
        private static void ProcessRedirect(HttpRequestArgs args, string url)
        {
            // determine if the redirect is allowed
            //HotFix: Hookup RedirecPage Template
            if (Context.Item != null && Context.Item.TemplateID == _redirectPageTemplateId)
            {
                var redirectToUrl = Context.Item.Fields["RedirectLink"].ConvertToLinkField().GetValidRedirectURL();
                SendResponse(redirectToUrl, HttpContext.Current.Request.Url.Query, args);
            }

            if ((Context.Item == null || AllowRedirectsOnFoundItem(Context.Database)))
            {
                // Grab the actual requested path for use in both the item and pattern match sections.
                var requestedUrl = HttpContext.Current.Request.Url.ToString();
                var urlScheme = HttpContext.Current.Request.Url.Scheme + ":";
                var requestedUrlWithoutScheme = requestedUrl.TrimStart(urlScheme.ToCharArray());
                var db = Context.Database;

                // First, we check for exact matches because those take priority over pattern matches.
                if (Sitecore.Configuration.Settings.GetBoolSetting(Constants.Settings.RedirExactMatch, true))
                {
                    var requestedPath = HttpContext.Current.Request.Url.AbsolutePath;

                    FindExactMatch(args, db, requestedUrl, requestedUrlWithoutScheme, requestedPath);
                }

                // Finally, we check for pattern matches because we didn't hit on an exact match.
                if (Sitecore.Configuration.Settings.GetBoolSetting(Constants.Settings.RedirPatternMatch, true))
                {
                    var requestedPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;

                    FindPatternMatch(args, db, requestedUrl, requestedUrlWithoutScheme, requestedPathAndQuery);
                }
            }

            // Add Url to ignore list so that it will not be looped through redirect items next time
            if (_ignoreCollection != null && !_ignoreCollection.Keys.Contains(url))
                _ignoreCollection.TryAdd(url, string.Empty);
        }

        /// <summary>
        /// Find the exact match of the requested url
        /// </summary>
        /// <param name="args"></param>
        /// <param name="db"></param>
        /// <param name="requestedUrl"></param>
        /// <param name="requestedUrlWithoutScheme"></param>
        /// <param name="requestedPath"></param>
        private static void FindExactMatch(HttpRequestArgs args, Database db, string requestedUrl, string requestedUrlWithoutScheme, string requestedPath)
        {
            var possibleRedirects = GetRedirects(db, Constants.Templates.RedirectUrl, Constants.Templates.VersionedRedirectUrl,
                Sitecore.Configuration.Settings.GetSetting(Constants.Settings.QueryExactMatch));

            // The purpose of this is to eliminate the possible mistake when in the string comparison
            var requestedUrlWithoutSlashes = requestedUrl.ToLower().Replace(@"/", "");
            var requestedUrlWithoutSchemeWithoutSlashes = requestedUrlWithoutScheme.ToLower().Replace(@"/", "");
            var requestedPathWithoutSlashes = requestedPath.ToLower().Replace(@"/", "");

            // Loop through the exact match entries to look for a match.
            foreach (var possibleRedirect in possibleRedirects)
            {
                var possibleRedirectUrlWithoutSlashes = possibleRedirect[Constants.Fields.RequestedUrl].ToLower().Replace(@"/", "");

                if (requestedUrlWithoutSlashes.Equals(possibleRedirectUrlWithoutSlashes, StringComparison.InvariantCultureIgnoreCase) ||
                     requestedUrlWithoutSchemeWithoutSlashes.Equals(possibleRedirectUrlWithoutSlashes, StringComparison.InvariantCultureIgnoreCase) ||
                     requestedPathWithoutSlashes.Equals(possibleRedirectUrlWithoutSlashes, StringComparison.InvariantCultureIgnoreCase))
                {

                    var redirectToItemId = possibleRedirect.Fields[Constants.Fields.RedirectToItem];
                    var redirectToUrl = possibleRedirect.Fields[Constants.Fields.RedirectToUrl];

                    if (redirectToItemId.HasValue && !string.IsNullOrEmpty(redirectToItemId.ToString()))
                    {
                        var redirectToItem = db.GetItem(ID.Parse(redirectToItemId));
                        if (redirectToItem != null)
                        {
                            SendResponse(redirectToItem, "", args, possibleRedirect.ID.ToString());
                            //SendResponse(redirectToItem, HttpContext.Current.Request.Url.Query, args, possibleRedirect.ID.ToString());
                        }
                    }
                    else if (redirectToUrl.HasValue && !string.IsNullOrEmpty(redirectToUrl.ToString()))
                    {
                        SendResponse(redirectToUrl.Value, "", args, possibleRedirect.ID.ToString());
                        //SendResponse(redirectToUrl.Value, HttpContext.Current.Request.Url.Query, args, possibleRedirect.ID.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// Find the pattern that matches the requested url
        /// </summary>
        /// <param name="args"></param>
        /// <param name="db"></param>
        /// <param name="requestedUrl"></param>
        /// <param name="requestedUrlWithoutScheme"></param>
        /// <param name="requestedPathAndQuery"></param>
        private static void FindPatternMatch(HttpRequestArgs args, Database db, string requestedUrl, string requestedUrlWithoutScheme, string requestedPathAndQuery)
        {
            // Loop through the pattern match items to find a match
            foreach (var possibleRedirectPattern in GetRedirects(db, Constants.Templates.RedirectPattern, Constants.Templates.VersionedRedirectPattern, Sitecore.Configuration.Settings.GetSetting(Constants.Settings.QueryExactMatch)))
            {
                var redirectPath = string.Empty;
                if (Regex.IsMatch(requestedUrl, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedUrl, possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                 possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                else if (Regex.IsMatch(requestedUrlWithoutScheme, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedUrlWithoutScheme, possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                 possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                else if (Regex.IsMatch(requestedPathAndQuery, possibleRedirectPattern[Constants.Fields.RequestedExpression], RegexOptions.IgnoreCase))
                {
                    redirectPath = Regex.Replace(requestedPathAndQuery,
                                                 possibleRedirectPattern[Constants.Fields.RequestedExpression],
                                                 possibleRedirectPattern[Constants.Fields.SourceItem], RegexOptions.IgnoreCase);
                }
                if (string.IsNullOrEmpty(redirectPath)) continue;

                // Query portion gets in the way of getting the sitecore item.
                /*var pathAndQuery = redirectPath.Split('?');
                var path = pathAndQuery[0];
                if (LinkManager.Provider != null &&
                    LinkManager.Provider.GetDefaultUrlOptions() != null &&
                    LinkManager.Provider.GetDefaultUrlOptions().EncodeNames)
                {
                    path = MainUtil.DecodeName(path);
                }
                var redirectToItem = db.GetItem(path);
                if (redirectToItem != null)
                {
                    var query = pathAndQuery.Length > 1 ? "?" + pathAndQuery[1] : "";
                    SendResponse(redirectToItem, query, args);
                }
                else
                {
                    // we have changed the query to a full path so fix up
                    if (path.StartsWith("http"))
                    {
                        var query = pathAndQuery.Length > 1 ? "?" + pathAndQuery[1] : "";
                        SendResponse(path, query, args);
                    }
                }*/
                SendResponse(redirectPath, "", args, possibleRedirectPattern.ID.ToString());
            }
        }

        private static bool AllowRedirectsOnFoundItem(Database db)
        {
            if (db == null)
                return false;

            var redirectRoot = Sitecore.Configuration.Settings.GetSetting(Constants.Settings.RedirectRootNode);
            var redirectFolderRoot = redirectRoot != null ? db.SelectSingleItem(redirectRoot) : null;
            
            if (redirectFolderRoot == null)
                return false;

            var allowRedirectsOnItemIDs = redirectFolderRoot[Constants.Fields.ItemProcessRedirects];
            
            return allowRedirectsOnItemIDs != null && Context.Item != null &&
                      allowRedirectsOnItemIDs.Contains(Context.Item.ID.ToString());
        }

        /// <summary>
        ///  This method return all of the possible matches for either the exact matches or the pattern matches
        ///  Note: Because Fast Query does not guarantee to return items in the current language context
        ///  (e.g. while in US/English, results may include other language items as well, even if the 
        ///  US/EN language has no active versions), an additional LINQ query has to be run to filter for language.
        ///  Choose your query type appropriately.
        /// </summary>
        private static IEnumerable<Item> GetRedirects(Database db, string templateName, string versionedTemplateName, string queryType)
        {
            // get collection from cache
            var items = Sitecore.Avanade.Foundation.Cache.Cache.Get<IEnumerable<Item>>(_cacheKeyItems.Fmt(templateName));
            if (items != null) return items;

            // Based off the config file, we can run different types of queries. 
            IEnumerable<Item> ret = null;
            var redirectRoot = Sitecore.Configuration.Settings.GetSetting(Constants.Settings.RedirectRootNode);
            switch (queryType)
            {
                case "fast": // fast query
                    {
                        //process shared template items
                        ret = db.SelectItems(String.Format("fast:{0}//*[@@templatename='{1}']", redirectRoot, templateName));

                        //because fast query requires to check for active versions in the current language
                        //run a separate query for versioned items to see if this is even necessary.
                        //if only shared templates exist in System/Modules, this step is extraneous and unnecessary.
                        IEnumerable<Item> versionedItems = db.SelectItems(String.Format("fast:{0}//*[@@templatename='{1}']", redirectRoot, versionedTemplateName));

                        //if active versions of items in the current context exist, union the two IEnumerable lists together.
                        ret = versionedItems.Any(i => i.Versions.Count > 0)
                            ? ret.Union(versionedItems.Where(i => i.Versions.Count > 0))
                            : ret;


                        break;
                    }
                case "query": // Sitecore query
                    {
                        ret = db.SelectItems(String.Format("{0}//*[@@templatename='{1}' or @@templatename='{2}']", redirectRoot, templateName, versionedTemplateName));
                        break;
                    }
                default: // API LINQ
                    {
                        Item redirectFolderRoot = db.SelectSingleItem(redirectRoot);
                        if (redirectFolderRoot != null)
                            ret = redirectFolderRoot.Axes.GetDescendants().Where(i => i.TemplateName == templateName || i.TemplateName == versionedTemplateName);
                        break;
                    }
            }

            Sitecore.Avanade.Foundation.Cache.Cache.Add(_cacheKeyItems.Fmt(templateName), ret, DateTime.Now.AddHours(1));

            // make sure to return an empty list instead of null
            return ret ?? new Item[0];
        }

        /// <summary>
        ///  Once a match is found and we have a Sitecore Item, we can send the 301 response.
        /// </summary>
        private static void SendResponse(Item redirectToItem, string queryString, HttpRequestArgs args, string id = null)
        {
            var redirectToUrl = GetRedirectToUrl(redirectToItem);
            SendResponse(redirectToUrl, queryString, args, id);
        }

        private static void SendResponse(string redirectToUrl, string queryString, HttpRequestArgs args, string id = null)
        {
            // add to collection
            var requestedUrl = HttpContext.Current.Request.Url.AbsoluteUri.ToLower();
            //var requestedUrl = HttpContext.Current.Request.Url.ToString();
            if (redirectToUrl.StartsWith("//"))
            {
                //Set the right url scheme
                redirectToUrl = string.Format("{0}:{1}", HttpContext.Current.Request.Url.Scheme, redirectToUrl);
            }
            if (_redirectCollection != null && !_redirectCollection.Keys.Contains(requestedUrl))
            {
                _redirectCollection.TryAdd(requestedUrl, new string[] { redirectToUrl + queryString, id });
            }

            args.Context.Response.Status = "301 Moved Permanently";
            args.Context.Response.StatusCode = 301;
            args.Context.Response.AddHeader("Location", redirectToUrl + queryString);

            if (!id.IsNullOrEmpty())
            {
                args.Context.Response.AddHeader("SID", id.ToString());
            }

            args.Context.Response.End();
        }

        private static string GetRedirectToUrl(Item redirectToItem)
        {
            if (redirectToItem.Paths.Path.StartsWith(Constants.Paths.MediaLibrary))
            {
                var mediaItem = (MediaItem)redirectToItem;
                var mediaUrl = MediaManager.GetMediaUrl(mediaItem);
                var redirectToUrl = StringUtil.EnsurePrefix('/', mediaUrl);
                return redirectToUrl;
            }

            return LinkManager.GetItemUrl(redirectToItem);
        }
    }

    public static class Constants
    {
        public static class Paths
        {
            public static string VisitorIdentification = "/layouts/system/visitoridentification";
            public static string MediaLibrary = "/sitecore/media library/";
        }

        public static class Settings
        {
            public static string RedirExactMatch = "RedirectModule.RedirectionType.ExactMatch";
            public static string RedirPatternMatch = "RedirectModule.RedirectionType.Pattern";
            public static string QueryExactMatch = "RedirectModule.QueryType.ExactMatch";
            public static string QueryPatternMatch = "RedirectModule.QueryType.PatternMatch";
            public static string RedirectRootNode = "RedirectModule.RedirectRootNode";

        }
        public static class Templates
        {
            public static string RedirectUrl = "Redirect Url";
            public static string VersionedRedirectUrl = "Versioned Redirect Url";
            public static string RedirectPattern = "Redirect Pattern";
            public static string VersionedRedirectPattern = "Versioned Redirect Pattern";
        }
        public static class Fields
        {
            public static string RequestedUrl = "Requested Url";
            public static string RedirectToItem = "redirect to item";
            public static string RedirectToUrl = "redirect to url";
            public static string RequestedExpression = "requested expression";
            public static string SourceItem = "source item";
            public static string ItemProcessRedirects = "Items Which Always Process Redirects";
        }

    }
}

