﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Redirects.Pipelines.RedirectionRequest
{
    public class InitializeRedirection
    {
        /// <summary>
        /// The cache key used for the collections
        /// </summary>
        private const string RedirectionCacheKey = "AI.Foundation.Redirection";

        public void Process(RedirectionArgs args)
        {
            // do we have our cached instance
            #region Clear Instance
            // do we have our cached instance
            Sitecore.Avanade.Foundation.Cache.Cache.Get<bool>(RedirectionCacheKey, () =>
            {
                // we need to clear the instance
                args.RedirectionCollection.Clear();
                args.IgnoreCollection.Clear();

                return true;
            });
            #endregion
        }
    }
}