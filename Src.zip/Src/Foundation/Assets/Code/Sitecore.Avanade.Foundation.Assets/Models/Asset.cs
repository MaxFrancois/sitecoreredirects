﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Assets.Models
{
    public class Asset
    {
        public string File { get; set; }
        public AssetLocation Location { get; set; }
        public AssetType Type { get; set; }
        public string AddOnceToken { get; set; }
        public string Inline { get; set; }

        public Asset(string File, AssetType Type, AssetLocation Location = AssetLocation.body, string AddOnceToken = "", string Inline = "")
        {
            this.File = File;
            this.Type = Type;
            this.Location = Location;
            this.AddOnceToken = AddOnceToken;
            this.Inline = Inline;
        }

        public long GetDataLength()
        {
            var total = 0L;

            if(!String.IsNullOrEmpty(File))
            {
                total += File.Length;
            }

            if(!String.IsNullOrEmpty(Inline))
            {
                total += Inline.Length;
            }

            if(!String.IsNullOrEmpty(AddOnceToken))
            {
                total += AddOnceToken.Length;
            }

            return total;
        }
    }
}