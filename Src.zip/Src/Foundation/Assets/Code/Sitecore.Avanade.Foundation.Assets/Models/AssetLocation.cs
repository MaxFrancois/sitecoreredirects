﻿
namespace Sitecore.Avanade.Foundation.Assets.Models
{
    public enum AssetLocation
    {
        head_upper,
        head,
        head_lower,
        body
    }
}