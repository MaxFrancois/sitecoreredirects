﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Assets.Models
{
    public enum AssetType
    {
        CSS,
        JS,
        Raw
    }
}