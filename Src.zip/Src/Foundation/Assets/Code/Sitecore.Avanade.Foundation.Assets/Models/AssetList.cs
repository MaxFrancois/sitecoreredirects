﻿using Sitecore.Caching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace Sitecore.Avanade.Foundation.Assets.Models
{
    internal class AssetList : ICacheable, IEnumerable<Asset>
    {
        private readonly List<Asset> _items = new List<Asset>();

        public bool Cacheable { get; set; } = true;

        public bool Immutable { get { return true; } }

        public event DataLengthChangedDelegate DataLengthChanged
        {
            add
#pragma warning disable S108 // Nested blocks of code should not be left empty
            {
            }
            remove
            {
            }
#pragma warning restore S108 // Nested blocks of code should not be left empty
        }

        public long GetDataLength()
        {
            return _items.Sum(i => i.GetDataLength());
        }

        public IEnumerator<Asset> GetEnumerator()
        {
            return _items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public void Add(Asset asset)
        {
            _items.Add(asset);
        }
    }
}