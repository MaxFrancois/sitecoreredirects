﻿using Sitecore.Caching;

namespace Sitecore.Avanade.Foundation.Assets.Models
{
    internal class AssetCache : CustomCache
    {
        public AssetCache(long maxSize) : base("AI.Foundation.Assets", maxSize) { }

        public AssetList Get(string Cachekey) => (AssetList)GetObject(Cachekey);

        public void Set(string Cachekey, AssetList Assetlist) => SetObject(Cachekey, Assetlist);
    }
}