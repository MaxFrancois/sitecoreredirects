﻿/*
****************************************************************************
Copyright 2000-2017 Accenture Interactive Australia Pty Ltd

This file is licensed under the Accenture Interactive Internal Business
Operations License (AIIBOL), Version [1.0] (the "License").
You may not use this file except in compliance with the License.
You may obtain a copy of the License from Accenture/Accenture Interactive
email address at DSO.Legal.Requests@accenture.com
 
Except to the extent specified in the License and unless required by
applicable law or agreed to in writing, software distributed under the
License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
****************************************************************************
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Theme.Extensions
{
    public static class ScriptBlockExtensions
    {
        #region ScriptBlock
        /// <summary>
        /// Register the script block that we want to use to register scripts
        /// </summary>
        private class ScriptBlock : IDisposable
        {
            #region Private Variables
            /// <summary>
            /// The Script formatter
            /// </summary>
            private static string ScriptKeyFormatter = "scripts-{0}{1}";

            /// <summary>
            /// The unique script key
            /// </summary>
            private string scriptsKey = ScriptKeyFormatter;

            /// <summary>
            /// The cache key
            /// </summary>
            private string scriptCacheKey = "";

            /// <summary>
            /// The script location
            /// </summary>
            private ScriptLocation scriptLocation;

            /// <summary>
            /// Is the scripts cachable
            /// </summary>
            private bool cachable = true;
            #endregion

            /// <summary>
            /// The listing of scripts to load
            /// </summary>
            private List<string> PageScripts
            {
                get
                {
                    // do we need to create the new colleciton
                    if (HttpContext.Current.Items[scriptsKey] == null)
                    {
                        HttpContext.Current.Items[scriptsKey] = new List<string>();
                    }

                    return (List<string>)HttpContext.Current.Items[scriptsKey];
                }
            }

            public static List<string> FilterPageScripts(ScriptLocation location, string customString = "")
            {
                string scriptKey = ScriptKeyFormatter.Fmt(Enum.GetName(typeof(ScriptLocation), location), customString);

                // do we need to create the new colleciton
                if (HttpContext.Current.Items[scriptKey] == null)
                {
                    HttpContext.Current.Items[scriptKey] = new List<string>();
                }

                return (List<string>)HttpContext.Current.Items[scriptKey];
            }

            // default web view page base
            WebViewPage webPageBase;

            /// <summary>
            /// 
            /// </summary>
            /// <param name="webPageBase"></param>
            /// <param name="location"></param>
            /// <param name="customString"></param>
            /// <param name="cacheKey"></param>
            /// <param name="cache"></param>
            public ScriptBlock(WebViewPage webPageBase, ScriptLocation location, string customString, string cacheKey, bool cache)
            {
                // get the unique key
                this.scriptsKey = scriptsKey.Fmt(Enum.GetName(typeof(ScriptLocation), location), customString);
                this.scriptCacheKey = cacheKey;
                this.cachable = cache;
                this.scriptLocation = location;
                this.webPageBase = webPageBase;
                this.webPageBase.OutputStack.Push(new StringWriter());
            }

            /// <summary>
            /// Close the objects
            /// </summary>
            public void Dispose()
            {
                // create the scripts
                List<string> scripts = new List<string>();
                scripts.Add(((StringWriter)this.webPageBase.OutputStack.Pop()).ToString());

                // append the scripts to the writer to output last
                PageScripts.AddRange(scripts);

                // do we want to cache
                if (cachable)
                {
                    // append to cache for next time
                    Cache.Cache.Add(this.scriptCacheKey, scripts, System.DateTime.Now.AddMonths(1));
                }
            }
        }
        #endregion

        #region ScriptLocation
        public enum ScriptLocation
        {
            HeaderUpper = 1,
            HeaderMiddle = 2,
            HeaderLower = 3,
            FooterUpper = 4,
            FooterMiddle = 5,
            FooterLower = 6,
            Custom = 7
        }
        #endregion

        #region RegisterScripts
        /// <summary>
        /// Exposable scripts to allow developers to register their scripts
        /// </summary>
        /// <param name="helper">The view to add</param>
        /// <param name="location">The enum location to put the scripts</param>
        /// <param name="customString">A custom name if flexibility is required</param>
        /// <param name="cache">Is caching enabled, default is true</param>
        /// <returns></returns>
        public static IDisposable RegisterScripts(this HtmlHelper helper, ScriptLocation location, string customString = "", bool cache = true)
        {
            // set the view page container
            var webViewPage = (WebViewPage)helper.ViewDataContainer;

            //There are situation like mvc ajax postback where the renderingContext is not initialised correctly
            var renderingContext = Sitecore.Mvc.Presentation.RenderingContext.CurrentOrNull;
            string renderingItemPath = (renderingContext != null && renderingContext.Rendering != null)
                ? renderingContext.Rendering.RenderingItemPath
                : string.Empty;

            // set the cache key for us to use
            string cacheKey = "{0}{1}-view-script: {2}".Fmt(Enum.GetName(typeof(ScriptLocation), location), customString, renderingItemPath);

            return new ScriptBlock(webViewPage, location, customString, cacheKey, cache);
        }
        #endregion

        #region PageScripts
        /// <summary>
        /// Outputs the scripts defined for the page
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="location"></param>
        /// <param name="customString"></param>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static MvcHtmlString PageScripts(this HtmlHelper helper, ScriptLocation location, string customString = "", bool cache = true)
        {
            string locationName = Enum.GetName(typeof(ScriptLocation), location);

            // set the cache key
            string cacheKey = "{0}{1}-page-script:{2}".Fmt(locationName, customString, helper.ViewContext.HttpContext.Request.Url.LocalPath);

            // get the cached instance
            MvcHtmlString scriptHtmlString = Cache.Cache.Get<MvcHtmlString>(cacheKey);

            // make sure we have some data
            if (scriptHtmlString == null)
            {
                // make sure we have some renderings
                if (Sitecore.Mvc.Presentation.PageContext.Current.PageDefinition.Renderings.Any())
                {
                    foreach (var rendering in Sitecore.Mvc.Presentation.PageContext.Current.PageDefinition.Renderings)
                    {
                        // get the key and check
                        string renderingKey = "{0}{1}-view-script: {2}".Fmt(locationName, customString, rendering.RenderingItemPath);

                        // get the cached scripts out
                        List<string> scripts = Cache.Cache.Get<List<string>>(renderingKey);

                        // do we have data
                        if (scripts != null && scripts.Count > 0)
                        {
                            // append the scripts
                            ScriptBlock.FilterPageScripts(location, customString).AddRange(scripts);
                        }

                    }
                }

                // get the script data
                scriptHtmlString = MvcHtmlString.Create(string.Join(Environment.NewLine, ScriptBlock.FilterPageScripts(location, customString).Select(s => s.ToString()).Distinct()));

                // are we allowed to cache the output
                if (cache)
                {
                    // add the cached item
                    Cache.Cache.Add(cacheKey, scriptHtmlString, System.DateTime.Now.AddMonths(1));
                }
            }

            // output our data
            return scriptHtmlString;
        }
        #endregion
    }
}
