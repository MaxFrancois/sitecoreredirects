﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Forms.TypeConverters
{
    public class DataAttributesConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            Dictionary<string, object> Items = new Dictionary<string, object>();

            string text = value as string;
            if (string.IsNullOrEmpty(text))
            {
                return null;
            }

            // make sure we have our wrapper
            text = $"<wrapper>{text}</wrapper>";

            //Mark whats been selected by default
            var serializerForSV = new XmlSerializer(typeof(DataAttributesXmlConverter.Wrapper));

            
            try
            {
                DataAttributesXmlConverter.Wrapper wrapper;

                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(text)))
                {
                    wrapper = (DataAttributesXmlConverter.Wrapper)serializerForSV.Deserialize(stream);
                }

                // add the data to the dictionary
                wrapper.Item.ForEach(x =>
                {
                    Items.Add(x.Attri, x.Value);
                });

            }
            catch (Exception e)
            {
                Diagnostics.Log.Error($"Error trying to deserialize SelectedValue XML.\nXML Value:{text}", e, this);
            }

            return Items;
        }
    }

    public class DataAttributesXmlConverter
    {
        [XmlRoot(ElementName = "item")]
        public class Item
        {
            [XmlElement(ElementName = "attri")]
            public string Attri { get; set; }
            [XmlElement(ElementName = "value")]
            public string Value { get; set; }
        }

        [XmlRoot(ElementName = "wrapper")]
        public class Wrapper
        {
            [XmlElement(ElementName = "item")]
            public List<Item> Item { get; set; }
        }
    }
}