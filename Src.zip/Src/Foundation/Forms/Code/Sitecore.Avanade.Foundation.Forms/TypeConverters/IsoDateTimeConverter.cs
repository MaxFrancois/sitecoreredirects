﻿using System.ComponentModel;
using System.Globalization;
namespace Sitecore.Avanade.Foundation.Forms.TypeConverters
{
    public class IsoDateTimeConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                Sitecore.Diagnostics.Assert.ArgumentNotNull(value, "value");
                return Sitecore.DateUtil.IsoDateToDateTime(value as string);
            }

            return base.ConvertFrom(context, culture, value);
        }
    }
}