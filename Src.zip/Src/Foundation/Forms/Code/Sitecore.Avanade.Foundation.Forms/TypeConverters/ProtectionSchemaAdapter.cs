﻿using System.ComponentModel;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.Forms.TypeConverters
{
    public class ProtectionSchemaAdapter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                return value as string;
            }
            return value;
        }
    }
}