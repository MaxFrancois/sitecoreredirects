﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Forms.TypeConverters
{
    /// <summary>
    /// Processes the List Items to get the data
    /// </summary>
    internal class ListItemsConverterProcess
    {
        /// <summary>
        /// Return the listing of items
        /// </summary>
        public List<string> Items { get; set; } = new List<string>();

        /// <summary>
        /// Converts the items
        /// </summary>
        /// <param name="value"></param>
        public ListItemsConverterProcess(object value)
        {
            string text = value as string;
            
            // get out
            if (text.IsNullOrEmpty())
            {
                return;
            }

            // make sure we have our wrapper
            text = $"<wrapper>{text}</wrapper>";

            //Mark whats been selected by default
            var serializerForSV = new XmlSerializer(typeof(ListItemsXmlConverter.Wrapper));


            try
            {
                ListItemsXmlConverter.Wrapper selectedValue;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(text)))
                {
                    selectedValue = (ListItemsXmlConverter.Wrapper)serializerForSV.Deserialize(stream);
                }

                if (selectedValue?.Item != null)
                {
                    // reset
                    Items = selectedValue.Item;
                }
            }
            catch (Exception e)
            {
                Diagnostics.Log.Error($"Error trying to deserialize SelectedValue XML.\nXML Value:{text}", e, this);
            }
        }
    }


    public class FirstListItemsConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            return new ListItemsConverterProcess(value)?.Items?.FirstOrDefault();
        }
    }

    public class ListItemsConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            return new ListItemsConverterProcess(value)?.Items;
        }
    }

    public class ListItemsXmlConverter
    {
        [XmlRoot(ElementName = "wrapper")]
        public class Wrapper
        {
            [XmlElement(ElementName = "item")]
            public List<string> Item { get; set; }
        }
    }
}