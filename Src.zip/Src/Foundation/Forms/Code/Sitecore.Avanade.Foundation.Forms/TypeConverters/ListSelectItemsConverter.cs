﻿using Sitecore.Avanade.Foundation.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Forms.TypeConverters
{
    public class ListSelectItemsConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            List<SelectListItem> Items = new List<SelectListItem>();

            string text = value as string;
            if (string.IsNullOrEmpty(text))
            {
                return null;
            }

            // build the xml we need
            string itemsXML = string.Concat("<items>",
                text
                    .Replace($"<{Sitecore.Context.Language.CultureInfo.TwoLetterISOLanguageName}>", "<lang>")
                    .Replace($"</{Sitecore.Context.Language.CultureInfo.TwoLetterISOLanguageName}>", "</lang>"),
                "</items>");

            var serializer = new XmlSerializer(typeof(ListSelectItemsXmlConverter.Items));

            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(itemsXML)))
            {
                ListSelectItemsXmlConverter.Items queryItems = (ListSelectItemsXmlConverter.Items)serializer.Deserialize(stream);

                if (queryItems != null)
                {
                    queryItems.Query.ForEach(x =>
                    {
                        Sitecore.Data.Items.Item[] itemList = null;

                        if (x.t.Equals("default", StringComparison.OrdinalIgnoreCase))
                        {
                            // manually select items
                            // <query t="default"><value>Male</value><en>male</en></query>
                            Items.Add(new SelectListItem
                            {
                                Text = x.sov ? x.value.Raw : (string.IsNullOrEmpty(x.lang.Raw) ? x.value.Raw : x.lang.Raw),
                                Value = x.value.Raw
                            });
                        }
                        else if (x.t.Equals("sitecore", StringComparison.OrdinalIgnoreCase))
                        {
                            //<query t="sitecore"><value>/sitecore/content/*</value></query>
                            itemList = Sitecore.Context.Database.SelectItems(x.value.Raw);
                        }
                        else if (x.t.Equals("xpath", StringComparison.OrdinalIgnoreCase))
                        {
                            //<query t="sitecore"><value>/sitecore/content/*</value></query>
                            var rootItem = Sitecore.Context.Database.SelectItemsUsingXPath(x.value.Raw);

                            if (rootItem != null && rootItem.Count > 0)
                            {
                                itemList = rootItem.ToArray();
                            }
                        }
                        else if (x.t.Equals("root", StringComparison.OrdinalIgnoreCase))
                        {
                            // set root item: <query t="root" vf="__ID" tf="__Display name"><value>{F6BE8589-526A-40A6-890F-223C3FA4EBB0}</value></query>
                            var rootItem = Sitecore.Context.Database.GetItem(x.value.Raw);

                            if (rootItem != null)
                            {
                                itemList = rootItem.Children.ToArray();
                            }
                        }

                        if (itemList != null && itemList.Length > 0)
                        {
                            // fix the order as we have weird results in some of the fetches
                            itemList = itemList.SortBySitecore().ToArray();

                            // cycle over the list and set the correct data
                            itemList.ForEach(mx =>
                            {
                                var listItem = new SelectListItem();
                                // set the text and value
                                listItem.Text = mx.Name;
                                listItem.Value = mx.Name;

                                // double check has it been overridden
                                if (!x.vf.IsNullOrEmpty())
                                {
                                    if (mx.Fields[x.vf] == null
                                    && x.vf.Equals("__ID"))
                                    {   
                                        listItem.Value = mx.ID.ToString();
                                    }
                                    else
                                    {
                                        listItem.Value = mx.Fields[x.vf].ValueSafe(listItem.Value);
                                    }
                                }

                                if (!x.tf.IsNullOrEmpty())
                                {
                                    if (mx.Fields[x.tf] == null
                                        && x.tf.Equals("__ID"))
                                    {
                                        listItem.Text = mx.ID.ToString();
                                    }
                                    else
                                    {
                                        listItem.Text = mx.Fields[x.tf].ValueSafe(listItem.Text);
                                    }
                                }

                                Items.Add(listItem);
                            });
                        }
                    });
                }
            }

            return Items;
        }
    }

    public class ListSelectItemsXmlConverter
    {

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        [System.Xml.Serialization.XmlRootAttribute(ElementName = "items", Namespace = "", IsNullable = false)]
        public partial class Items
        {
            /// <remarks/>
            [System.Xml.Serialization.XmlElementAttribute("query")]
            public ItemsQuery[] Query { get; set; }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        [System.Xml.Serialization.XmlRootAttribute(ElementName = "itemQuery")]
        public partial class ItemsQuery
        {
            /// <remarks/>dfghe
            public RichText value { get; set; }

            /// <remarks/>
            public RichText lang { get; set; }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute("t")]
            public string t { get; set; }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute("sov")]
            public bool sov { get; set; }

            /// <remarks/>
            [System.Xml.Serialization.XmlIgnoreAttribute()]
            public bool sovSpecified { get; set; }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute("vf")]
            public string vf { get; set; }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute("tf")]
            public string tf { get; set; }
        }

        public class RichText : IXmlSerializable
        {
            public string Raw { get; set; }
            public XmlSchema GetSchema()
            {
                return null;
            }

            public void ReadXml(XmlReader reader)
            {
                Raw = reader.ReadInnerXml();
            }

            public void WriteXml(XmlWriter writer)
            {
                writer.WriteString(Raw);
            }
        }
    }

}