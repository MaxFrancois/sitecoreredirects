﻿using System;
using System.Web;
using System.Web.Mvc;

[assembly: PreApplicationStartMethod(typeof(Sitecore.Avanade.Foundation.Forms.Startup), "Start")]

namespace Sitecore.Avanade.Foundation.Forms
{
    public static class Startup
    {
        public static void Start()
        {
            // setup custom binders
            ModelBinders.Binders.Add(typeof(DateTime), new ModelBinder.IsoDateTimeBinder());
            ModelBinders.Binders.Add(typeof(DateTime?), new ModelBinder.NullableIsoDateTimeBinder());
        }
    }
}