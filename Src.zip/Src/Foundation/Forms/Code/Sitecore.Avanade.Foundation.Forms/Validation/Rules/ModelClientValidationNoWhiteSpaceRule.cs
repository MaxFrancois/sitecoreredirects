﻿using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Validation.Rules
{
    public class ModelClientValidationNoWhiteSpaceRule : ModelClientValidationRule
    {
        public ModelClientValidationNoWhiteSpaceRule(string errorMessage)
        {
            base.ErrorMessage = errorMessage;
            base.ValidationType = "nowhitespace";
        }
    }
}