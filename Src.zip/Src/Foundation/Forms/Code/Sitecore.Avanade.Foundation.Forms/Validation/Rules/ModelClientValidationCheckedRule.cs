﻿using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Validation.Rules
{
    public class ModelClientValidationCheckedRule : ModelClientValidationRule
    {
        public ModelClientValidationCheckedRule(string errorMessage)
        {
            base.ErrorMessage = errorMessage;
            base.ValidationType = "ischecked";
        }
    }
}