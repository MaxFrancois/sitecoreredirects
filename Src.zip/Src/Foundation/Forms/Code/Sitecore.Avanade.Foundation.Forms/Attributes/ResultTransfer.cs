﻿using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Attributes
{
    public abstract class ResultTransferAttribute : ActionFilterAttribute
    {
        protected static readonly string Key = typeof(ResultTransferAttribute).FullName;
        protected static readonly string OriginalRequestTypeKey = Key + "_OriginalRequestType";

        protected virtual string CreateResultKey(ControllerContext ctrlContext, string actionMethodName)
        {
            return Key + "_" + ctrlContext.Controller.GetType().Name + "_" + actionMethodName;
        }
    }
}