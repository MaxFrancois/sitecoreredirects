﻿using Sitecore.Mvc.Presentation;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Attributes
{
    public class ExportResultAttribute : ResultTransferAttribute
    {
        public string ImportMethodName { get; set; }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            //Don't Export if we are redirecting
            if ((filterContext.Result is RedirectResult) || (filterContext.Result is RedirectToRouteResult))
                return;

            if (!filterContext.HttpContext.Request.RequestType.Equals("POST", System.StringComparison.OrdinalIgnoreCase))
                return;

            // Keep the result from post method
            var resultKey = this.CreateResultKey(filterContext, string.IsNullOrWhiteSpace(ImportMethodName) ? filterContext.ActionDescriptor.ActionName : ImportMethodName);
            filterContext.HttpContext.Items[resultKey] = filterContext.Result;

            // Start the GET request for page
            filterContext.HttpContext.Items[OriginalRequestTypeKey] = filterContext.HttpContext.Request.RequestType;
            this.SetHttpMethod("GET");

            IView pageView = PageContext.Current.PageView;
            filterContext.Result = new ViewResult { View = pageView };

            base.OnActionExecuted(filterContext);
        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            // Restore the original request type
            var originalRequestType = filterContext.HttpContext.Items[OriginalRequestTypeKey] as string;
            if (!string.IsNullOrWhiteSpace(originalRequestType))
                this.SetHttpMethod(originalRequestType);

            base.OnResultExecuted(filterContext);
        }

        private void SetHttpMethod(string httpMethod)
        {
            var a = System.Web.HttpContext.Current.Request.GetType().GetField("_httpMethod", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            a.SetValue(System.Web.HttpContext.Current.Request, httpMethod);
            System.Web.HttpContext.Current.Request.RequestType = httpMethod;
        }
    }
}