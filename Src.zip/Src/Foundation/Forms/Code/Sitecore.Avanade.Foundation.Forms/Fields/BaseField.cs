﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System.Collections.Generic;
using Sitecore.Data.Items;
using System.ComponentModel;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;

namespace Sitecore.Avanade.Foundation.Forms.Fields
{
    public class BaseField: IBaseField, IHasIsRequired, IHasRegularExpression
    {
        public Item Item { get; set; }

        public bool IsRequired { get; set; }

        public string Key { get; set; }

        public IDictionary<string, string> Parameters { get; set; }

        public string RegexPattern { get; set; }

        public string Title { get; set; }

        public bool Visible { get; set; }

        public IDictionary<string, object> HtmlAttributes { get; set; } = new Dictionary<string, object>();

        public virtual string Mapping { get; set; }
        public virtual string FormId { get; set; }
        public virtual string Information { get; set; }

        [ParameterName("ContainerClass")]
        public virtual string FieldContainerClass { get; set; }

        [ParameterName("CssClass")]
        public virtual string CssClass { get; set; }

        [ParameterName("DataAttributes"), TypeConverter(typeof(DataAttributesConverter))]
        public virtual Dictionary<string, object> FieldDataAttributes { get; set; } = new Dictionary<string, object>();

        public string FieldItemId { get; set; }

        public BaseField()
        {
            this.Parameters = new Dictionary<string, string>();
        }

        public virtual void Initialize()
        {
        }
    }
}