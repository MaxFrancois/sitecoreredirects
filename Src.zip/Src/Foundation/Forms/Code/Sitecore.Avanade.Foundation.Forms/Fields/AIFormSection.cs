﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System.Collections.Generic;
using Sitecore.Data.Items;
using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using System.ComponentModel;

namespace Sitecore.Avanade.Foundation.Forms.Fields
{
    public class AIFormSection : IBaseField
    {
        public Item Item { get; set; }

        public string Key { get; set; }

        public IDictionary<string, string> Parameters { get; set; }

        public bool ShowTitle { get; set; } = false;
        public string Title { get; set; }

        public bool Visible { get; set; }

        public List<BaseField> Fields { get; set; }

        public bool ShowInformation { get; set; } = false;
        public string Information { get; set; }
        public string Mapping { get; set; }


        [ParameterName("ContainerClass")]
        public virtual string FieldContainerClass { get; set; }

        [ParameterName("DataAttributes"), TypeConverter(typeof(DataAttributesConverter))]
        public virtual Dictionary<string, object> FieldDataAttributes { get; set; } = new Dictionary<string, object>();

        public AIFormSection()
        {
            this.Fields = new List<BaseField>();
            this.Parameters = new Dictionary<string, string>();
        }
    }
}