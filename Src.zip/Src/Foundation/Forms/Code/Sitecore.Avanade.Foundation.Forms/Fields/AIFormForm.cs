﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System.Collections.Generic;
using Sitecore.Data.Items;
using Sitecore.Forms.Core.Data;

namespace Sitecore.Avanade.Foundation.Forms.Fields
{
    public class AIFormForm : IBaseField
    {
        public Item Item
        {
            get; set;
        }

        public string Key
        {
            get; set;
        }

        public IDictionary<string, string> Parameters
        {
            get; set;
        }

        public IDictionary<string, object> FormAttributes { get; set; } = new Dictionary<string, object>();

        public bool ShowTitle { get; set; }
        public string Title { get; set; }


        public bool ShowIntroduction { get; set; }
        public string Introduction { get; set; }

        public bool ShowFooter { get; set; }
        public string Footer { get; set; }

        public bool Visible { get; set; }

        public bool ShowInformation { get; set; }
        public string Information { get; set; }

        public string Mapping { get; set;}

        public List<AIFormSection> Sections
        {
            get;
            set;
        }

        public string SubmitName { get; set; }

        public bool CancelEnabled { get; set; }
        public string CancelName { get; set; }
        public string CancelPage { get; set; }

        public SuccessMode SuccessMode { get; set; }
        public string SuccessMessage { get; set; }
        public string SuccessPage { get; set; }
        public string SaveActionFailedMessage { get;set; }

        
        public FormItem SitecoreFormItem { get; set; }


        public AIFormForm()
        {
            this.Sections = new List<AIFormSection>();
            this.Parameters = new Dictionary<string,string>();
        }
    }

    public enum SuccessMode
    {
        //
        Redirection,
        ShowMessage,
        Other
    }
}