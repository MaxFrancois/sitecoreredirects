﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormTelephoneField: AIFormSingleLineTextField
    {
        [DynamicRegularExpression("^\\+?\\s{0,}\\d{0,}\\s{0,}(\\(\\s{0,}\\d{1,}\\s{0,}\\)\\s{0,}|\\d{0,}\\s{0,}-?\\s{0,})\\d{2,}\\s{0,}-?\\s{0,}\\d{2,}\\s{0,}(-?\\s{0,}\\d{2,}|\\s{0,})\\s{0,}$", null, ErrorMessage = "The {0} field contains an invalid telephone number."), DataType(DataType.PhoneNumber)]
        public override string Value { get; set; }
    }
}