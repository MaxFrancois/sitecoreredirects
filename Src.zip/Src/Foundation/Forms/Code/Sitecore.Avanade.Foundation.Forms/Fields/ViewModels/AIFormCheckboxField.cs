﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Sitecore.Avanade.Foundation.Extensions.Converters;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormCheckboxField : FormField<bool>
    {
        [TypeConverter(typeof(Sitecore.Avanade.Foundation.Extensions.Converters.BooleanConverter))]
        public override bool Value { get; set; }

        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null)
            {
                // changed to AI Helper to make sure data is valid
                this.Value = Sitecore.Avanade.Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(valueFromQuery, false);
            }
        }

        public override void Initialize()
        {
            if (base.Parameters.ContainsKey("Checked"))
            {
                this.Value = Sitecore.Avanade.Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(base.Parameters["Checked"], false);
            }
        }
    }
}