﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.Validators;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class FormField<TValue> : BaseField
    {
        [ParameterName("Text"), DynamicRequiredAttribute(ErrorMessage = "The {0} field is required."), MultiRegularExpression(null, "RegexPattern", ErrorMessage = "The value of the {0} field is not valid.")]
        public virtual TValue Value { get; set; }

        public virtual void SetValueFromQuery(object valueFromQuery)
        {
            this.Value = valueFromQuery != null ? (TValue)System.Convert.ChangeType(valueFromQuery, typeof(TValue)) : default(TValue);
        }
    }
}