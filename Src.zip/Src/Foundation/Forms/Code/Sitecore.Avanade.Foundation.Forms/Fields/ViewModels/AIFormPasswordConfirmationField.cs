﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormPasswordConfirmationField: AIFormPasswordField
    {
        [DynamicCompare("Value", "Password", "PasswordTitle", "ConfirmationTitle", ErrorMessage = "The {0} and {1} fields must be the same."), DataType(DataType.Password)]
        public string Confirmation { get; set; }

        public string ConfirmationHelp { get; set; }

        public string PasswordHelp { get; set; }

        public string PasswordTitle { get; set; }

        public string ConfirmationTitle { get; set; }

        public AIFormPasswordConfirmationField()
        {
            this.PasswordTitle = "Password";
            this.ConfirmationTitle = "Confirmation";
        }

        /// <summary>
        /// Initialize and set the confirmation password
        /// </summary>
        public override void Initialize()
        {
            // get the confirmation mapping
            string confirmationPassword = $"{Mapping}_Confirmation";

            // do we have this in the form request
            if (!String.IsNullOrEmpty(System.Web.HttpContext.Current.Request[confirmationPassword]))
            {
                Confirmation = System.Web.HttpContext.Current.Request[confirmationPassword];
            }

            base.Initialize();
        }
    }
}