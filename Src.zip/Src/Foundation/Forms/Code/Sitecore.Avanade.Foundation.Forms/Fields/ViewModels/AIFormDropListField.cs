﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormDropListField : AIFormRadioListField
    {
        public AIFormDropListField()
        {
            this.Items = new List<SelectListItem>();
        }

        public override void Initialize()
        {
            bool emptyChoice = true;

            if (base.Parameters.ContainsKey("EmptyChoice"))
            {
                emptyChoice = Sitecore.Avanade.Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(base.Parameters["EmptyChoice"]);
            }

            if (base.Items == null)
            {
                base.Items = new List<SelectListItem>();
            }

            if (emptyChoice)
            {
                base.Items.Insert(0, new SelectListItem
                {
                    Text = string.Empty,
                    Value = string.Empty
                });
            }
            base.Initialize();
        }
    }
}
