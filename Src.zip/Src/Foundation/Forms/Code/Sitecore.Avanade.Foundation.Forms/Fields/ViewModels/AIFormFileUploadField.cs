﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormFileUploadField : FormField<HttpPostedFileBase>
    {
        [DefaultValue("/sitecore/media library")]
        public string UploadTo { get; set; } = "/sitecore/media library";

        [DataType(DataType.Upload)]
        public override HttpPostedFileBase Value { get; set; }
        
        public AIFormFileUploadField()
        {
            // extend the type to file to make sure it works as expected
            HtmlAttributes.Add("type", "file");
        }
    }
}