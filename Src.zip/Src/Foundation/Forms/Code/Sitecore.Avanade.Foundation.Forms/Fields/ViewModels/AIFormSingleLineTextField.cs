﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormSingleLineTextField : FormField<string>
    {
        [DefaultValue(256)]
        public int MaxLength { get; set; }

        [DefaultValue(0)]
        public int MinLength { get; set; }

        [DynamicStringLength("MinLength", "MaxLength", ErrorMessage = "The {0} field must be a string with a minimum length of {1} and a maximum length of {2}."), DynamicNoWhiteSpaceAttribute(ErrorMessage = "The {0} field can not be whitespace."), DataType(DataType.Text)]
        public override string Value { get; set; }

        /// <summary>
        /// Initilize the max length just in case
        /// </summary>
        public override void Initialize()
        {
            if (this.MaxLength == 0)
            {
                this.MaxLength = 256;
            }
        }
    }
}