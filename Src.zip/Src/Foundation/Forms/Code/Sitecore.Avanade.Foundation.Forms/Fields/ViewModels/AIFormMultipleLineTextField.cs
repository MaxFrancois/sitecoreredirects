﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormMultipleLineTextField: AIFormSingleLineTextField
    {
        [DataType(DataType.MultilineText)]
        public override string Value { get; set; }

        public int Rows { get; set; } = 4;

        public int Columns { get; set; } = 1;
    }
}