﻿using System;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormHiddenTextField : FormField<string>
    {
        public override string Value { get; set; }

        // Force date formatting to isodate
        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null && valueFromQuery is DateTime)
            {
                DateTime? dt = valueFromQuery as DateTime?;

                if (dt != null)
                {
                    Value = DateUtil.ToIsoDate(dt.Value);
                }
            }
            else
            {
                // call the base
                base.SetValueFromQuery(valueFromQuery);
            }
        }
    }
}
