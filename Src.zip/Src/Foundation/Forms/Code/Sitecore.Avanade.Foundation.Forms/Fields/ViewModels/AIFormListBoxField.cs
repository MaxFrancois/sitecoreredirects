﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormListBoxField: AIFormCheckboxListField
    {
        [DefaultValue(4)]
        public int Rows { get; set; } = 4;

        public string SelectionMode { get; set; } = "Single";

        public override void Initialize()
        {
            if (!HtmlAttributes.ContainsKey("size"))
            {
                // add the size
                HtmlAttributes.Add("size", Rows);
            }

            base.Initialize();
        }

    }
}