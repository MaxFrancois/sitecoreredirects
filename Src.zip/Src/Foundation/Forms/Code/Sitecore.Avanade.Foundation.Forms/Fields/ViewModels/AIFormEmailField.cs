﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormEmailField: AIFormSingleLineTextField
    {
        [DynamicEmail("EmailRegularExpression"), DataType(DataType.EmailAddress)]
        public override string Value { get; set; }
    }
}