﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormRadioListField : FormField<string>, Interfaces.ISelectList
    {
        [TypeConverter(typeof(ListSelectItemsConverter))]
        public List<SelectListItem> Items { get; set; }

        [ParameterName("SelectedValue"), TypeConverter(typeof(FirstListItemsConverter))]
        public override string Value { get; set; }


        public AIFormRadioListField()
        {
            this.Items = new List<SelectListItem>();
        }

        public override void Initialize()
        {

            if (this.Items == null)
            {
                this.Items = new List<SelectListItem>();
            }

            if (!string.IsNullOrEmpty(this.Value))
            {
                this.Items.ForEach(delegate (SelectListItem x)
                {
                    x.Selected = x.Value.Equals(this.Value);
                });
            }
        }

        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null)
            {
                if (valueFromQuery.GetType().IsArray)
                {
                    string[] valueArray = valueFromQuery as string[];

                    if (valueArray != null && valueArray.Any())
                    {
                        this.Value = valueArray[0];
                    }
                }
                else
                {
                    base.SetValueFromQuery(valueFromQuery);
                }

                Initialize();
            }
        }
    }
}
