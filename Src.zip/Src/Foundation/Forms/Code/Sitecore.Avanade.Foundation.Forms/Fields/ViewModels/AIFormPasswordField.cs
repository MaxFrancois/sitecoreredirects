﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormPasswordField: AIFormSingleLineTextField
    {
        [DataType(DataType.Password)]
        public override string Value { get; set; }
    }
}