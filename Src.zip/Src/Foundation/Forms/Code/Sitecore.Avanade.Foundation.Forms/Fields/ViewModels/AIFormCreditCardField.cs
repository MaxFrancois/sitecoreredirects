﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormCreditCardField: AIFormSingleLineTextField
    {
        [ParameterName("CardNumberHelp")]
        public override string Information { get; set; }

        [CreditCard]
        public override string Value { get; set; }

    }
}