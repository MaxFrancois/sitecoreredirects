﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormDateField : FormField<string>, IHasMinAge
    {
        [TypeConverter(typeof(IsoDateTimeConverter))]
        public DateTime StartDate { get; set; }
        [TypeConverter(typeof(IsoDateTimeConverter))]
        public DateTime EndDate { get; set; }

        public object Day { get; set; }
        public object Month { get; set; }
        public object Year { get; set; }

        public string DayTitle { get; set; }
        public string MonthTitle { get; set; }
        public string YearTitle { get; set; }

        public int MinAge { get; set; }


        [DefaultValue("yyyy-MMMM-dd")]
        public string DateFormat { get; set; } = "yyyy-MMMM-dd";

        //[DynamicTrippleDDLDateTime(ErrorMessage = "Please select a valid Date")]
        //[DynamicMinAge(ErrorMessage = "The MinAge of the field {0} is not valid.")]
        [ParameterName("SelectedDate")]
        public override string Value
        {
            get
            {
                return base.Value;
            }
            set
            {
                base.Value = value;
                this.OnValueUpdated();
            }
        }

        protected void OnValueUpdated()
        {
            if (!string.IsNullOrEmpty(this.Value))
            {
                DateTime dateTime = System.DateTime.Now.Date.ToLocalTime();
                if (!this.Value.Equals("ShowToday", StringComparison.OrdinalIgnoreCase))
                {
                    dateTime = Sitecore.DateUtil.IsoDateToDateTime(this.Value).Date;
                }
                else
                {
                    base.Value = Sitecore.DateUtil.ToIsoDate(dateTime);
                }

                this.Day = dateTime.Day;
                this.Month = dateTime.Month;
                this.Year = dateTime.Year;
            }
        }

        /// <summary>
        /// We want to make sure we convert the DateTime into the Sitecore format required
        /// </summary>
        /// <param name="valueFromQuery"></param>
        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null
                && valueFromQuery is DateTime)
            {
                DateTime? dt = valueFromQuery as DateTime?;

                if (dt != null)
                {
                    this.Value = Sitecore.DateUtil.ToIsoDate(dt.Value);
                }
            }
        }


        public override void Initialize()
        {
            if (string.IsNullOrEmpty(this.DateFormat))
            {
                this.DateFormat = "yyyy-MMMM-dd";
            }
            if (this.StartDate == DateTime.MinValue)
            {
                this.StartDate = Sitecore.DateUtil.IsoDateToDateTime("20000101T120000");
            }
            if (this.EndDate == DateTime.MinValue)
            {
                this.EndDate = DateTime.Now.AddYears(1).Date;
            }
            //this.Years
            //this.Months
            //this.Days

            DayTitle = Sitecore.Avanade.Foundation.Dictionary.Translate.Text("Day");
            MonthTitle = Sitecore.Avanade.Foundation.Dictionary.Translate.Text("Month");
            YearTitle = Sitecore.Avanade.Foundation.Dictionary.Translate.Text("Year");

            if (this.Years == null)
            {
                this.Years = new List<SelectListItem>();
            }
            if (this.Months == null)
            {
                this.Months = new List<SelectListItem>();
            }

            if (this.Days == null)
            {
                this.Days = new List<SelectListItem>();
            }
            

            this.InitItems();
        }

        public List<SelectListItem> Years { get; private set; }
        public List<SelectListItem> Months { get; private set; }
        public List<SelectListItem> Days { get; private set; }

        private void InitItems()
        {

            List<string> list = new List<string>(this.DateFormat.Split(new char[]
            {
                '-'
            }));
            list.Reverse();
            list.ForEach(new Action<string>(this.InitDate));
        }

        private void InitDate(string marker)
        {
            DateTime? current = string.IsNullOrEmpty(this.Value) ? null : new DateTime?(Sitecore.DateUtil.IsoDateToDateTime(this.Value));
            char c = marker.ToLower()[0];
            if (c == 'd')
            {
                this.InitDays(current);
                return;
            }
            if (c == 'm')
            {
                this.InitMonth(marker, current);
                return;
            }
            if (c != 'y')
            {
                return;
            }
            this.InitYears(marker, current);
        }

        private void InitYears(string marker, DateTime? current)
        {
            DateTime dateTime = new DateTime(this.StartDate.Year - 1, 1, 1);

            if (this.Years == null)
            {
                this.Years = new List<SelectListItem>();
            }
            
            if (!current.HasValue)
            {
                this.Years.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.YearTitle,
                    Value = string.Empty
                });
            }
            for (int i = this.StartDate.Year; i <= this.EndDate.Year; i++)
            {
                dateTime = dateTime.AddYears(1);
                SelectListItem item = new SelectListItem
                {
                    Text = string.Format("{0:" + marker + "}", dateTime),
                    Value = i.ToString(CultureInfo.InvariantCulture),
                    Selected = (current.HasValue && current.Value.Year == i)
                };
                this.Years.Add(item);
            }
        }

        private void InitDays(DateTime? current)
        {
            
            int num = current.HasValue ? DateTime.DaysInMonth(current.Value.Year, current.Value.Month) : 31;

            if (this.Days == null)
            {
                this.Days = new List<SelectListItem>();
            }
            if (!current.HasValue)
            {
                this.Days.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.DayTitle,
                    Value = string.Empty
                });
            }
            for (int i = 1; i <= 31; i++)
            {
                if (i <= num)
                {
                    this.Days.Add(new SelectListItem
                    {
                        Selected = (current.HasValue && current.Value.Day == i),
                        Text = i.ToString(CultureInfo.InvariantCulture),
                        Value = i.ToString(CultureInfo.InvariantCulture)
                    });
                }
            }
        }

        private void InitMonth(string marker, DateTime? current)
        {
            DateTime dateTime = default(DateTime);

            // make sure we have  data
            if (this.Months == null)
            {
                this.Months = new List<SelectListItem>();
            }
            
            if (!current.HasValue)
            {
                this.Months.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.MonthTitle,
                    Value = string.Empty
                });
            }
            for (int i = 1; i <= 12; i++)
            {
                this.Months.Add(new SelectListItem
                {
                    Selected = (current.HasValue && current.Value.Month == i),
                    Text = string.Format("{0:" + marker + "}", dateTime.AddMonths(i - 1)),
                    Value = i.ToString(CultureInfo.InvariantCulture)
                });
            }
        }
    }
}
