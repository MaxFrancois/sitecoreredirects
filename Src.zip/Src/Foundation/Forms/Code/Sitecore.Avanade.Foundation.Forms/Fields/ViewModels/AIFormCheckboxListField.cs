﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using Sitecore.Avanade.Foundation.Forms.Validators;
using Sitecore.Avanade.Foundation.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormCheckboxListField : FormField<List<string>>, Interfaces.ISelectList
    {
        [TypeConverter(typeof(ListSelectItemsConverter))]
        public List<SelectListItem> Items { get; set; }

        [ParameterName("SelectedValue"), TypeConverter(typeof(ListItemsConverter))]
        public override List<string> Value { get; set; }


        public AIFormCheckboxListField()
        {
            this.Items = new List<SelectListItem>();
        }

        public override void Initialize()
        {
            List<string> selectedValues = this.Value;
            if (this.Items == null)
            {
                this.Items = new List<SelectListItem>();
            }
            if (selectedValues != null)
            {
                this.Items.ForEach(delegate (SelectListItem x)
                {
                    x.Selected = selectedValues.Contains(x.Value);
                });
            }
        }

        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null
                && valueFromQuery.GetType().IsArray)
            {
                string[] valueArray = valueFromQuery as string[];
                
                if (valueArray != null && valueArray.Any())
                {
                    this.Value = valueArray.ToList();

                    // re-run the initialize to set the selected
                    Initialize();
                }
            }
        }
    }
}
