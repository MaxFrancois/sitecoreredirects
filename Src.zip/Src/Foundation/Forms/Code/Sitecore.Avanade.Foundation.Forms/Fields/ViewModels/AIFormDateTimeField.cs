﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using Sitecore.Avanade.Foundation.Forms.TypeConverters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormDateTimeField : FormField<string>, IHasMinAge
    {
        [TypeConverter(typeof(IsoDateTimeConverter))]
        public DateTime StartDate { get; set; }
        [TypeConverter(typeof(IsoDateTimeConverter))]
        public DateTime EndDate { get; set; }

        public object Day { get; set; }
        public object Month { get; set; }
        public object Year { get; set; }
        public object Hour { get; set; }
        public object Minute { get; set; }
        public object Meridiem { get; set; }

        public string DayTitle { get; set; }
        public string MonthTitle { get; set; }
        public string YearTitle { get; set; }
        public string HourTitle { get; set; }
        public string MinuteTitle { get; set; }
        public string MeridiemTitle { get; set; }

        public int MinAge { get; set; }
        
        [DefaultValue("yyyy-MMMM-dd hh:mm tt")]
        public string DateFormat { get; set; } = "yyyy-MMMM-dd hh:mm tt";

        //[DynamicTrippleDDLDateTime(ErrorMessage = "Please select a valid Date")]
        //[DynamicMinAge(ErrorMessage = "The MinAge of the field {0} is not valid.")]
        [ParameterName("SelectedDate")]
        public override string Value
        {
            get
            {
                return base.Value;
            }
            set
            {
                base.Value = value;
                this.OnValueUpdated();
            }
        }

        protected void OnValueUpdated()
        {
            if (!string.IsNullOrEmpty(this.Value))
            {
                DateTime dateTime = System.DateTime.Now.ToLocalTime();
                if (!this.Value.Equals("ShowToday", StringComparison.OrdinalIgnoreCase))
                {
                    dateTime = DateUtil.IsoDateToDateTime(this.Value);
                }
                else
                {
                    base.Value = DateUtil.ToIsoDate(dateTime);
                }

                this.Day = dateTime.Day;
                this.Month = dateTime.Month;
                this.Year = dateTime.Year;
                this.Hour = dateTime.Hour%12;
                this.Minute = dateTime.Minute;
                this.Meridiem = dateTime.ToString("tt", CultureInfo.InvariantCulture);
            }
        }

        /// <summary>
        /// We want to make sure we convert the DateTime into the Sitecore format required
        /// </summary>
        /// <param name="valueFromQuery"></param>
        public override void SetValueFromQuery(object valueFromQuery)
        {
            if (valueFromQuery != null
                && valueFromQuery is DateTime)
            {
                DateTime? dt = valueFromQuery as DateTime?;

                if (dt != null)
                {
                    this.Value = DateUtil.ToIsoDate(dt.Value);
                }
            }
        }

        public override void Initialize()
        {
            if (string.IsNullOrEmpty(this.DateFormat))
            {
                this.DateFormat = "yyyy-MMMM-dd hh:mm tt";
            }
            if (this.StartDate == DateTime.MinValue)
            {
                this.StartDate = DateUtil.IsoDateToDateTime("20000101T120000");
            }
            if (this.EndDate == DateTime.MinValue)
            {
                this.EndDate = DateTime.Now.AddYears(1).Date;
            }


            if (this.Years == null)
            {
                this.Years = new List<SelectListItem>();
            }
            if (this.Months == null)
            {
                this.Months = new List<SelectListItem>();
            }
            if (this.Days == null)
            {
                this.Days = new List<SelectListItem>();
            }
            if (this.Hours == null)
            {
                this.Hours = new List<SelectListItem>();
            }
            if (this.Minutes == null)
            {
                this.Minutes = new List<SelectListItem>();
            }
            if (this.Meridiems == null)
            {
                this.Meridiems = new List<SelectListItem>();
            }

            DayTitle = Dictionary.Translate.Text("Day");
            MonthTitle = Dictionary.Translate.Text("Month");
            YearTitle = Dictionary.Translate.Text("Year");
            HourTitle = Dictionary.Translate.Text("Hour");
            MinuteTitle = Dictionary.Translate.Text("Minute");
            MeridiemTitle = Dictionary.Translate.Text("Meridiem");

            this.InitItems();
        }

        public List<SelectListItem> Years { get; private set; }
        public List<SelectListItem> Months { get; private set; }
        public List<SelectListItem> Days { get; private set; }
        public List<SelectListItem> Hours { get; private set; }
        public List<SelectListItem> Minutes { get; private set; }
        public List<SelectListItem> Meridiems { get; private set; }

        private void InitItems()
        {
            List<string> list = new List<string>(this.DateFormat.Split(new char[]
            {
                '-',
                ' ',
                ':'
            }));
            list.Reverse();
            list.ForEach(new Action<string>(this.InitDate));
        }

        private void InitDate(string marker)
        {
            DateTime? current = string.IsNullOrEmpty(this.Value) ? null : new DateTime?(DateUtil.IsoDateToDateTime(this.Value));
            char c = marker[0];
            if (c == 'd')
            {
                this.InitDays(current);
                return;
            }
            if (c == 'M')
            {
                this.InitMonth(marker, current);
                return;
            }
            if (c == 'h')
            {
                this.InitHours(current);
                return;
            }
            if (c == 'm')
            {
                this.InitMinutes(current);
                return;
            }
            if (c == 't')
            {
                this.InitMeridiems(current);
                return;
            }
            if (c != 'y')
            {
                return;
            }
            this.InitYears(marker, current);
        }

        private void InitYears(string marker, DateTime? current)
        {
            DateTime dateTime = new DateTime(this.StartDate.Year - 1, 1, 1);

            if (this.Years == null)
            {
                this.Years = new List<SelectListItem>();
            }

            if (!current.HasValue)
            {
                this.Years.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.YearTitle,
                    Value = string.Empty
                });
            }
            for (int i = this.StartDate.Year; i <= this.EndDate.Year; i++)
            {
                dateTime = dateTime.AddYears(1);
                SelectListItem item = new SelectListItem
                {
                    Text = string.Format("{0:" + marker + "}", dateTime),
                    Value = i.ToString(CultureInfo.InvariantCulture),
                    Selected = (current.HasValue && current.Value.Year == i)
                };
                this.Years.Add(item);
            }
        }

        private void InitDays(DateTime? current)
        {
            int num = current.HasValue ? DateTime.DaysInMonth(current.Value.Year, current.Value.Month) : 31;

            if (this.Days == null)
            {
                this.Days = new List<SelectListItem>();
            }

            if (!current.HasValue)
            {
                this.Days.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.DayTitle,
                    Value = string.Empty
                });
            }
            for (int i = 1; i <= 31; i++)
            {
                if (i <= num)
                {
                    this.Days.Add(new SelectListItem
                    {
                        Selected = (current.HasValue && current.Value.Day == i),
                        Text = i.ToString(CultureInfo.InvariantCulture),
                        Value = i.ToString(CultureInfo.InvariantCulture)
                    });
                }
            }
        }

        private void InitMonth(string marker, DateTime? current)
        {
            DateTime dateTime = default(DateTime);


            if (this.Months == null)
            {
                this.Months = new List<SelectListItem>();
            }
            

            if (!current.HasValue)
            {
                this.Months.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.MonthTitle,
                    Value = string.Empty
                });
            }
            for (int i = 1; i <= 12; i++)
            {
                this.Months.Add(new SelectListItem
                {
                    Selected = (current.HasValue && current.Value.Month == i),
                    Text = string.Format("{0:" + marker + "}", dateTime.AddMonths(i - 1)),
                    Value = i.ToString(CultureInfo.InvariantCulture)
                });
            }
        }

        private void InitHours(DateTime? current)
        {
            if (this.Hours == null)
            {
                this.Hours = new List<SelectListItem>();
            }
            

            if (!current.HasValue)
            {
                this.Hours.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.HourTitle,
                    Value = string.Empty
                });
            }
            for (int i = 1; i <= 12; i++)
            {
                this.Hours.Add(new SelectListItem
                {
                    Selected = (current.HasValue && (current.Value.Hour%12) == i),
                    Text = i.ToString(CultureInfo.InvariantCulture),
                    Value = i.ToString(CultureInfo.InvariantCulture)
                });
            }
        }

        private void InitMinutes(DateTime? current)
        {
            if (this.Minutes == null)
            {
                this.Minutes = new List<SelectListItem>();
            }
            

            if (!current.HasValue)
            {
                this.Minutes.Add(new SelectListItem
                {
                    Selected = true,
                    Text = this.MinuteTitle,
                    Value = string.Empty
                });
            }
            for (int i = 0; i <= 59; i++)
            {
                this.Minutes.Add(new SelectListItem
                {
                    Selected = (current.HasValue && current.Value.Minute == i),
                    Text = i.ToString("00", CultureInfo.InvariantCulture),
                    Value = i.ToString(CultureInfo.InvariantCulture)
                });
            }
        }

        private void InitMeridiems(DateTime? current)
        {
            var dateTime = DateTime.Now.Date;

            if (this.Meridiems == null)
            {
                this.Meridiems = new List<SelectListItem>();
            }
            for (var i = 0; i < 2; i++)
            {
                this.Meridiems.Add(new SelectListItem
                {
                    Selected = (current.HasValue && current.Value.Hour < dateTime.Hour && current.Value.Hour < (dateTime.Hour + 12)),
                    Text = dateTime.ToString("tt", CultureInfo.InvariantCulture),
                    Value = dateTime.ToString("tt", CultureInfo.InvariantCulture)
                });
                dateTime = dateTime.AddHours(12);
            }
        }
    }
}
