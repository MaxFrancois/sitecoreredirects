﻿using Sitecore.Avanade.Foundation.Forms.Validators;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Forms.Fields.ViewModels
{
    public class AIFormSmsTelephoneField: AIFormSingleLineTextField
    {
        [DynamicRegularExpression("^\\+?\\d{3,}", null, ErrorMessage = "The {0} field contains an invalid sms/mms telephone number."), DataType(DataType.PhoneNumber)]
        public override string Value { get; set; }
    }
}