﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Forms.Fields;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Web.Mvc;

using Sitecore.Avanade.Foundation.Forms.Extensions;

namespace Sitecore.Avanade.Foundation.Forms.Factory
{
    public static class Manager
    {
        private static Regex regex = new Regex(
                                  "<(?<tag>\\w*)>(?<text>.*)</\\k<tag>>",
                                RegexOptions.IgnoreCase
                                | RegexOptions.CultureInvariant
                                | RegexOptions.IgnorePatternWhitespace
                                | RegexOptions.Compiled
                                );

        /// <summary>
        /// Get the AI Form, which uses the Sitecore WFFM
        /// </summary>
        /// <param name="itm">The WFFM Item</param>
        /// <param name="setData">The data to set</param>
        /// <param name="context">The controller context to help with IsValid</param>
        /// <returns>Returns the form</returns>
        public static AIFormForm GetForm(Item itm, object setData = null, System.Web.Mvc.Controller context = null)
        {
            // get the form
            AIFormForm form = null;

            // make sure we have data
            if (itm != null)
            {
                // set the cache key
                string cachekey = $"form-{itm.ID.ToString()}";

                // keep track of the performance
                using (new Sitecore.Diagnostics.ProfileSection($"[Sitecore AI]: Retrieve Form '{itm.Name}'."))
                {
                    // get the form from cache
                    AIFormForm formCache = Sitecore.Avanade.Foundation.Cache.Cache.Get<AIFormForm>(cachekey);
                    
                    // have we got the form
                    if (formCache == null)
                    {
                        // get the base bones form
                        formCache = BuildForm(itm);

                        // add to the cache
                        Sitecore.Avanade.Foundation.Cache.Cache.Add(cachekey, formCache);
                    }

                    // make sure we have our cached instance
                    if (formCache != null)
                    {
                        // capture how long it takes to process
                        using (new Sitecore.Diagnostics.ProfileSection($"[Sitecore AI]: Clone Form '{itm.Name}'."))
                        {
                            // clone so we do not have issues
                            form = formCache.Copy<AIFormForm>();
                        }

                        // have we got the form, now fix it
                        if (form != null)
                        {
                            using (new Sitecore.Diagnostics.ProfileSection($"[Sitecore AI]: Process  Form '{itm.Name}'."))
                            {
                                int sec = form.Sections.Count;

                                // fix the sections
                                form.Sections.ForEach(x =>
                                {
                                    // get te condition field
                                    var conSectionField = x.Item.Fields[new Sitecore.Data.ID("{E312BDFA-DDBA-4ACC-907A-89A0B59638D4}")].ValueSafe();

                                    // have we got actual rule to process
                                    if (!conSectionField.IsNullOrEmpty()
                                        && !conSectionField.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.EmptyRuleFieldValue, StringComparison.OrdinalIgnoreCase))
                                    {
                                    // run the rule against the section
                                    Sitecore.Forms.Mvc.Helpers.RulesManager.RunRules(conSectionField, x);
                                    }

                                    // have we been turned off
                                    if (!x.Visible)
                                    {
                                        // remove
                                        // count pushes it by 1
                                        form.Sections.RemoveAt(sec - 1);
                                    }
                                    else
                                    {
                                        int fild = x.Fields.Count;
                                        // now we have the section lets make sure we process the values
                                        x.Fields.ForEach(f =>
                                        {
                                            var conField = f.Item.Fields[new Sitecore.Data.ID("{E312BDFA-DDBA-4ACC-907A-89A0B59638D4}")].ValueSafe();

                                            if (!conField.IsNullOrEmpty()
                                                && !conField.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.EmptyRuleFieldValue, StringComparison.OrdinalIgnoreCase))
                                            {
                                                Sitecore.Forms.Mvc.Helpers.RulesManager.RunRules(conField, f);
                                            }

                                            // are we disabling the field
                                            if (!f.Visible)
                                            {
                                                // count pushes it by 1
                                                x.Fields.RemoveAt(fild - 1);
                                            }
                                            else
                                            {
                                                // initialize
                                                f.Initialize();

                                                // have we got a mapping to bind
                                                if (!f.Mapping.IsNullOrEmpty() && setData != null)
                                                {
                                                // we want to find our set value from query
                                                MethodInfo method = f.GetType().GetMethod("SetValueFromQuery");
                                                    if (method != null)
                                                    {
                                                    // action the set
                                                    method.Invoke(f, new object[]
                                                        {
                                                    // get the value so we can set it
                                                    GetPropValue(setData, f.Mapping)
                                                        });
                                                    }
                                                }
                                            }


                                        // increase
                                        fild--;
                                        }, false);
                                    }

                                // increase
                                sec--;
                                }, false);
                            }

                            using (new Sitecore.Diagnostics.ProfileSection($"[Sitecore AI]: Validation on Form '{itm.Name}'."))
                            {
                                // validate the model
                                if (context != null
                                && context.Request.HttpMethod == "POST")
                                {
                                    // validate the form
                                    TryValidateFormModel(form, context);
                                }
                            }
                        }
                    }
                }
            }

            return form;
        }

        private static AIFormForm BuildForm(Item itm)
        {
            AIFormForm frm = new AIFormForm();
            frm.Item = itm;

            frm.ShowTitle = itm.Fields["show title"].IsChecked();
            frm.Title = itm.Fields["title"].ValueSafe();

            frm.ShowIntroduction = itm.Fields["show introduction"].IsChecked();
            frm.Introduction = itm.Fields["introduction"].ValueSafe();

            frm.ShowFooter = itm.Fields["show footer"].IsChecked();
            frm.Footer = itm.Fields["footer"].ValueSafe();

            frm.SubmitName = itm.Fields["name"].ValueSafe();

            // TODO: This is just a simle approach need to extnd
            var itmMode = itm.Fields["Success mode"].ValueSafe();


            // Default is '{3B8369A0-CC1A-4E9A-A3DB-7B086379C53B}'
            switch (itmMode)
            {
                case "{F4D50806-6B89-4F2D-89FE-F77FC0A07D48}":
                    frm.SuccessMode = SuccessMode.Redirection;
                    break;
                default: 
                    frm.SuccessMode = SuccessMode.ShowMessage;
                    break;
            }

            frm.SuccessPage = itm.Fields["Success page"].TargetItem(true)?.GetValidURL();

            if (frm.SuccessPage.IsNullOrEmpty())
            {
                frm.SuccessPage = Sitecore.Context.Site.GetValidSiteContext().GetRootItem().GetValidURL();
            }

            frm.SuccessMessage = itm.Fields["Success Message"].ValueSafe();
            frm.SaveActionFailedMessage = itm.Fields["Save Action Failed Message"].ValueSafe();
            
            PopulateParameters(frm, itm, "parameters");

            frm.CancelEnabled = frm.Parameters.ContainsKey("CancelEnabled") ? Sitecore.Avanade.Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(frm.Parameters["CancelEnabled"], false) : false;
            frm.CancelName = frm.Parameters.ContainsKey("CancelText") ? frm.Parameters["CancelText"] : Sitecore.Avanade.Foundation.Dictionary.Translate.Text("Cancel");
            frm.CancelPage = frm.Parameters.ContainsKey("CancelPage") ? Sitecore.Context.Database.GetItem(frm.Parameters["CancelPage"]).GetValidURL() : Sitecore.Context.Site.GetValidSiteContext().GetRootItem().GetValidURL();

            if (frm.CancelPage.IsNullOrEmpty())
            {
                frm.CancelPage = Sitecore.Context.Site.GetValidSiteContext().GetRootItem().GetValidURL();
            }

            // hardcode the form data
            frm.FormAttributes.Add("enctype", "multipart/form-data");
            frm.FormAttributes.Add("role", "form");
            frm.FormAttributes.Add("data-wffm", frm.Item.ID);

            //See if there are any custom classes to append. We will hardcode the base class of 'scfForm'
            var formStyleClasses = "scfForm";
            var customformClasses = itm.Fields["Custom Css Class"].ValueSafe();
            if(!String.IsNullOrEmpty(customformClasses))
            {
                formStyleClasses += $" {customformClasses}";
            }
            frm.FormAttributes.Add("class", $"{formStyleClasses}");

            frm.Sections = (from x in GetSectionItems(itm)
                            select GetSectionView(x, frm) into x
                            where x != null
                            select x).ToList<AIFormSection>();

            //The sitecore form item, to expose WFFM stuff
            frm.SitecoreFormItem = Sitecore.Forms.Core.Data.FormItem.GetForm(itm.ID);

            return frm;
        }

        public static bool TryValidateFormModel(AIFormForm itmForm, System.Web.Mvc.Controller context)
        {
            if (itmForm == null)
            {
                throw new ArgumentNullException("itmForm");
            }

            itmForm.Sections.ForEach(s =>
            {
                s.Fields.ForEach(f =>
                {
                    ModelMetadata metadataForType = ModelMetadataProviders.Current.GetMetadataForType(() => f, f.GetType());
                    foreach (ModelValidationResult current in ModelValidator.GetModelValidator(metadataForType, context.ControllerContext).Validate(null))
                    {
                        context.ModelState.AddModelError(f.Mapping, current.Message);
                    }
                });
            });

            
            return context.ModelState.IsValid;
        }

        private static Sitecore.Data.Items.Item[] GetSectionItems(Item itm)
        {
            List<Sitecore.Data.Items.Item> list = new List<Sitecore.Data.Items.Item>();
            bool flag = true;
            foreach (Sitecore.Data.Items.Item item in itm.Children)
            {
                if (item.TemplateID.EqualsTo("{CF47DBAE-6E22-465A-B9B5-3EB6BCF9ECBF}"))
                {
                    list.Add(item);
                }
                else if (flag && item.TemplateID.EqualsTo("{C9E1BF85-800A-4247-A3A3-C3F5DFBFD6AA}"))
                {
                    list.Add(itm);
                    flag = false;
                }
            }
            return list.ToArray();
        }

        private static void PopulateParameters(AIFormForm frm, Data.Items.Item itm, string fieldName)
        {
            if (itm.HasValue(fieldName))
            {
                var parameters = itm.Fields[fieldName].ValueSafe();

                if (regex.IsMatch(parameters))
                {
                    foreach (Match m in regex.Matches(parameters))
                    {
                        // remove if already exists and override
                        if (frm.Parameters.ContainsKey(m.Groups["tag"].Value))
                        {
                            frm.Parameters.Remove(m.Groups["tag"].Value);
                        }

                        frm.Parameters.Add(m.Groups["tag"].Value,
                                        System.Web.HttpContext.Current.Server.UrlDecode(m.Groups["text"].Value));
                    }
                }
            }
        }

        public static AIFormSection GetSectionView(Item itm, AIFormForm frm)
        {
            AIFormSection section = new AIFormSection();
            section.Item = itm;
            section.Visible = true;

            string title = itm.Fields["title"].ValueSafe();

            // get the parameters from the supplied field (EG: Field)
            PopulateParameters(section, itm, "parameters");
            PopulateParameters(section, itm, "localized parameters");

            // make sure this section template is used and the title exists
            if (itm.TemplateID.EqualsTo("{CF47DBAE-6E22-465A-B9B5-3EB6BCF9ECBF}")
                && !string.IsNullOrEmpty(title))
            {
                section.ShowInformation = true;
                section.Title = (title ?? string.Empty);
                section.ShowTitle = section.Parameters.ContainsKey("ShowLegend") ? Sitecore.Avanade.Foundation.Extensions.Helpers.BooleanHelper.ConvertToBoolean(section.Parameters["ShowLegend"], true) : true;
                Reflection.ReflectionUtil.SetXmlProperties(section, section.Parameters);
            }

            section.Fields = (from x in GetFields(itm)
                              select GetFieldView(x, frm) into x
                            where x != null
                            select x).ToList<BaseField>();

            return section;
        }

        public static Sitecore.Data.Items.Item[] GetFields(Item itm)
        {
            List<Sitecore.Data.Items.Item> list = new List<Sitecore.Data.Items.Item>();
            foreach (Sitecore.Data.Items.Item item in itm.Children)
            {
                if (item.TemplateID.EqualsTo("{C9E1BF85-800A-4247-A3A3-C3F5DFBFD6AA}"))
                {
                    list.Add(item);
                }
            }
            return list.ToArray();
        }

        public static BaseField GetFieldView(Item itm, AIFormForm frm)
        {
            Item fieldItm = itm.Fields["field link"].TargetItem();

            if (fieldItm == null)
            {
                return null;
            }

            // mvc type field
            string mvcClass = ReplaceFormType(fieldItm.Fields[Data.ID.Parse("{C117FA3E-2A0C-45EC-894D-2D5A2A8AFD1F}")].ValueSafe());

            Type type = Type.GetType(mvcClass);
            if (type == null)
            {
                return null;
            }

            object obj = Activator.CreateInstance(type);
            BaseField formField = obj as BaseField;

            if (formField == null)
            {
                Sitecore.Diagnostics.Log.Warn(string.Format("[AI Forms]Unable to create instance of type {0}", mvcClass), typeof(Manager));
                return null;
            }
            formField.Item = itm;
            formField.Title = itm.Fields["title"].ValueSafe();
            formField.Visible = true;
            formField.FormId = frm.Item.ID.ToString();
            formField.FieldItemId = itm.ID.ToString();
            formField.IsRequired = itm.Fields["required"].IsChecked();

            // get the parameters from the field base item (EG: Settings for field)
            PopulateParameters(formField, fieldItm, "parameters");
            PopulateParameters(formField, fieldItm, "localized parameters");

            // get the parameters from the supplied field (EG: Field)
            PopulateParameters(formField, itm, "parameters");
            PopulateParameters(formField, itm, "localized parameters");

            Reflection.ReflectionUtil.SetXmlProperties(formField, formField.Parameters);

            if (formField.Mapping.IsNullOrEmpty())
            {
                formField.Mapping = itm.Name;
            }

            formField.HtmlAttributes.Add("Name", formField.Mapping);
            formField.HtmlAttributes.Add("id", TagBuilder.CreateSanitizedId(formField.Mapping));
            formField.HtmlAttributes.Add("data-tracking", "false");

            return formField;
        }

        public static Object GetPropValue(Object obj, String name)
        {
            foreach (String part in name.Split('.'))
            {
                if (obj == null) { return null; }

                Type type = obj.GetType();
                PropertyInfo info = type.GetProperty(part);
                if (info == null) { return null; }

                obj = info.GetValue(obj, null);
            }
            return obj;
        }

        public static T GetPropValue<T>(Object obj, String name)
        {
            Object retval = GetPropValue(obj, name);
            if (retval == null) { return default(T); }

            // throws InvalidCastException if types are incompatible
            return (T)retval;
        }

        private static string ReplaceFormType(string type)
        {
            // more simple replace type
            type = type.Replace(" ","").Replace("Sitecore.Forms.Mvc.ViewModels.Fields.", "Sitecore.Avanade.Foundation.Forms.Fields.ViewModels.AIForm")
                .Replace(",Sitecore.Forms.Mvc", ",Sitecore.Avanade.Foundation.Forms")
                .Replace("Sitecore.Avanade.Foundation.WFFM.Fields.CustomDateField,Sitecore.Avanade.Foundation.WFFM", "Sitecore.Avanade.Foundation.Forms.Fields.ViewModels.AIFormDateField,Sitecore.Avanade.Foundation.Forms");
            
            return type;
        }

        private static void PopulateParameters(AIFormSection frm, Data.Items.Item itm, string fieldName)
        {
            if (itm.HasValue(fieldName))
            {
                var parameters = itm.Fields[fieldName].ValueSafe();

                if (regex.IsMatch(parameters))
                {
                    foreach (Match m in regex.Matches(parameters))
                    {
                        // remove if already exists and override
                        if (frm.Parameters.ContainsKey(m.Groups["tag"].Value))
                        {
                            frm.Parameters.Remove(m.Groups["tag"].Value);
                        }

                        frm.Parameters.Add(m.Groups["tag"].Value,
                                        System.Web.HttpContext.Current.Server.UrlDecode(m.Groups["text"].Value));
                    }
                }
            }
        }

        private static void PopulateParameters(BaseField formField, Data.Items.Item itm, string fieldName)
        {
            if (itm.HasValue(fieldName))
            {
                var parameters = itm.Fields[fieldName].ValueSafe();

                if (regex.IsMatch(parameters))
                {
                    foreach (Match m in regex.Matches(parameters))
                    {
                        // remove if already exists and override
                        if (formField.Parameters.ContainsKey(m.Groups["tag"].Value))
                        {
                            formField.Parameters.Remove(m.Groups["tag"].Value);
                        }

                        formField.Parameters.Add(m.Groups["tag"].Value,
                                        System.Web.HttpContext.Current.Server.UrlDecode(m.Groups["text"].Value));
                    }
                }
            }
        }

    }
}