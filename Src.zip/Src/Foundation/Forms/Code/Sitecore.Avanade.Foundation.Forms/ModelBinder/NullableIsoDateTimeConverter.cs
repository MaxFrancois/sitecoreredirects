﻿using System;
using System.Globalization;
using System.Threading;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.ModelBinder
{
    public class NullableIsoDateTimeBinder : IModelBinder
    {
        /// <summary>
        /// Nullable Datetime object from ISO Datetime to Datetime
        /// </summary>
        /// <param name="controllerContext"></param>
        /// <param name="bindingContext"></param>
        /// <returns>Returns the datetime of the ISO or datetime or worse null</returns>
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        { 
            // get out the value
            var value = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);

            // as this is nullable it can return false
            if (string.IsNullOrWhiteSpace(value.AttemptedValue))
            {
                return null;
            }

            // set our base
            DateTime dateTime;

            // check are we looking at an iso datetime
            if (Sitecore.DateUtil.IsIsoDate(value.AttemptedValue))
            {
                // set the datetime
                dateTime = Sitecore.DateUtil.IsoDateToDateTime(value.AttemptedValue);
            }
            else
            {
                // we are in a normal date time so convert
                var isDate = DateTime.TryParse(value.AttemptedValue, Thread.CurrentThread.CurrentUICulture, DateTimeStyles.None, out dateTime);

                if (!isDate)
                {
                    bindingContext.ModelState.AddModelError(bindingContext.ModelName, "Unable to convert to DateTime");
                    dateTime = DateTime.UtcNow;
                }
            }

            // rturn our data
            return dateTime;
        }
    }
}