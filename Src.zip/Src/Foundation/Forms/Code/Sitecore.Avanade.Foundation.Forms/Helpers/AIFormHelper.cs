﻿using Sitecore.Forms.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using Sitecore.WFFM.Abstractions.Actions;
using Sitecore.Form.Core.Data;

namespace Sitecore.Avanade.Foundation.Forms.Helpers
{
    public static class AIFormHelper
    {
        public static bool ProcessFormSaveActions(FormItem Form, ControlResult[] results)
        {
            var result = true;

            var ActionList = Form.ActionsDefinition;

            var actionDefintions = new List<IActionDefinition>();
            actionDefintions.AddRange(ActionList.Groups.SelectMany(x => x.ListItems)
                                                .Select(li => new ActionDefinition(li.ItemID, li.Parameters)
                                                { UniqueKey = li.Unicid }));

            //Submit Action Manager
            var submitActionManager = WFFM.Abstractions.Dependencies.DependenciesManager.ActionExecutor;

            try
            {
                submitActionManager.ExecuteSystemAction(Form.ID, results);
            }
            catch(Exception e)
            {
                Sitecore.Diagnostics.Log.Error($"Error running save actions for form : {Form.ID}", e, typeof(AIFormHelper));
                result = false;
            }

            return result;
        }
    }
}