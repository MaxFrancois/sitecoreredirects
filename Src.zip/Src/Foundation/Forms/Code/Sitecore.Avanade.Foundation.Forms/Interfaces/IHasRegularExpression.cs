﻿namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface IHasRegularExpression
    {
        string RegexPattern
        {
            get;
            set;
        }
    }
}