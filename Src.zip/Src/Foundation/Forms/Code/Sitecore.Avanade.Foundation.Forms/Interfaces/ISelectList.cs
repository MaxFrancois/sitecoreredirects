﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface ISelectList
    {
        List<SelectListItem> Items
        {
            get;
            set;
        }
    }
}