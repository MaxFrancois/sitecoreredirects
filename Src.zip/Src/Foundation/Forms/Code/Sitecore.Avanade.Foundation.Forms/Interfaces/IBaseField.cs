﻿using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface IBaseField
    {
        IDictionary<string, string> Parameters { get; set; }
        Data.Items.Item Item { get; set; }
        string Key { get; set; }
        string Title { get; set; }
        bool Visible { get; set; }
        string Information { get; set; }
        string Mapping { get; set; }
    }
}