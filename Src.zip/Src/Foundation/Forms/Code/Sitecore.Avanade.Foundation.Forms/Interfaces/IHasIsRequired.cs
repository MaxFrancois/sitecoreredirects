﻿namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface IHasIsRequired
    {
        bool IsRequired
        {
            get;
            set;
        }
    }
}