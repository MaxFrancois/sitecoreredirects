﻿namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface IHasMinAge
    {
        int MinAge
        {
            get;
            set;
        }
    }
}