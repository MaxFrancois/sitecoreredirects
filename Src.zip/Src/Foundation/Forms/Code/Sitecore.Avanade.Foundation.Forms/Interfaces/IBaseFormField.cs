﻿using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.Forms.Interfaces
{
    public interface IBaseFormField
    {
        IDictionary<string, string> Parameters { get; set; }
        Data.Items.Item FieldItem { get; set; }
        string Key { get; set; }
        bool IsRequired { get; set; }
        string Title { get; set; }
        System.Web.Mvc.ModelMetadata ModelMetaData { get; set; }
        IDictionary<string, object> HtmlAttributes { get; set; }
        bool IsModelValid { get; set; }
        string Information { get; set; }
        bool Visible { get; set; }
        string FieldContainerClass { get; set; }
        string FieldDataAttributes { get; set; }
    }
}