﻿using Sitecore.Avanade.Foundation.Forms.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace Sitecore.Avanade.Foundation.Forms.Reflection
{
    public static class ReflectionUtil
    {
        public static void SetXmlProperties(object obj, IDictionary<string, string> parameters)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(obj, "obj");
            if (parameters == null || parameters.Count == 0)
            {
                return;
            }
            foreach (KeyValuePair<string, string> current in parameters)
            {
                PropertyInfo propertyInfo = Sitecore.Reflection.ReflectionUtil.GetPropertyInfo(obj, current.Key);
                if (propertyInfo?.GetSetMethod(false) != null)
                {
                    ReflectionUtil.SetProperty(obj, propertyInfo.Name, current.Value);
                }
            }
            var enumerable = from property in obj.GetType().GetProperties()
                             let attr = property.GetCustomAttributes(typeof(ParameterNameAttribute)).SingleOrDefault<Attribute>() as ParameterNameAttribute
                             where attr != null
                             select new
                             {
                                 property,
                                 attr
                             };
            foreach (var current2 in enumerable)
            {
                string key = current2.attr.Name;
                if (parameters.ContainsKey(key))
                {
                    ReflectionUtil.SetProperty(obj, current2.property.Name, parameters[key]);
                }
            }
        }

        public static bool SetProperty(object obj, string name, object value)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(obj, "obj");
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(name, "name");
            bool result = true;
            try
            {
                PropertyInfo propertyInfo = Sitecore.Reflection.ReflectionUtil.GetPropertyInfo(obj, name);
                if (propertyInfo == null)
                {
                    return false;
                }
                ReflectionUtil.SetProperty(obj, propertyInfo, value);
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error("Reflection Error", ex, typeof(ReflectionUtil));
                result = false;
            }
            return result;
        }

        private static void SetProperty(object obj, PropertyInfo property, object value)
        {
            Sitecore.Diagnostics.Error.AssertObject(obj, "obj");
            Sitecore.Diagnostics.Error.AssertObject(property, "property");
            Sitecore.Diagnostics.Assert.IsTrue((property.CanWrite ? 1 : 0) != 0, "Attempt to write to read-only property: {0}. Declaring type: {1}", new object[]
            {
                property.Name,
                property.DeclaringType
            });
            if (value == null)
            {
                property.SetValue(obj, null, null);
                return;
            }
            value = ReflectionUtil.ConvertPropertyValue(property, value);
            property.SetValue(obj, value, null);
        }

        private static object ConvertPropertyValue(PropertyInfo property, object value)
        {
            if (property.PropertyType.IsEnum && value is string)
            {
                return Enum.Parse(property.PropertyType, value as string, true);
            }
            object[] customAttributes = property.GetCustomAttributes(typeof(TypeConverterAttribute), true);
            if (customAttributes != null && customAttributes.Length > 0)
            {
                TypeConverterAttribute typeConverterAttribute = customAttributes[0] as TypeConverterAttribute;
                if (typeConverterAttribute != null)
                {
                    Type type = Type.GetType(typeConverterAttribute.ConverterTypeName, false);
                    if (type != null)
                    {
                        TypeConverter typeConverter = Sitecore.Reflection.ReflectionUtil.CreateObject(type) as TypeConverter;
                        if (typeConverter != null)
                        {
                            return typeConverter.ConvertFrom(null, CultureInfo.InvariantCulture, value);
                        }
                    }
                }
            }
            TypeConverter converter = TypeDescriptor.GetConverter(property.PropertyType);
            if (converter != null && converter.CanConvertFrom(value.GetType()))
            {
                return converter.ConvertFrom(null, CultureInfo.InvariantCulture, value);
            }
            if (value is IConvertible)
            {
                return System.Convert.ChangeType(value, property.PropertyType, CultureInfo.InvariantCulture);
            }
            if (property.PropertyType == typeof(string))
            {
                return System.Convert.ToString(value, CultureInfo.InvariantCulture);
            }
            Sitecore.MainUtil.Warn(string.Concat(new string[]
            {
                "Could not convert property value to correct type in ReflectionUtil.SetProperty. Property type: ",
                property.PropertyType.FullName,
                " (name: ",
                property.Name,
                "). Value type: ",
                value.GetType().FullName
            }));
            return null;
        }
    }
}