﻿using Sitecore.Avanade.Foundation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace Sitecore.Avanade.Foundation.Forms.Extensions
{
    /// <summary>
    /// String Extensions
    /// </summary>
    public static class FormExtensions
    {
        #region ToAttributes
        /// <summary>
        /// Flattern the Dictionary collection for attributes to be outputted
        /// </summary>
        /// <param name="attributeDictionary"></param>
        /// <param name="addFrontPadding">Do we want to add space padding to the front</param>
        /// <param name="addBackPadding">Do we want to add space padding to the end</param>
        /// <returns>Returns the attributes flattered</returns>
        public static MvcHtmlString ToAttributes(this IDictionary<string, object> attributeDictionary, bool addFrontPadding = false, bool addBackPadding = false)
        {
            if (attributeDictionary.Count > 0)
            {
                string attributes = string.Join(" ", attributeDictionary.Select(d =>
                    string.Format("{0}=\"{1}\"", d.Key, System.Web.HttpUtility.HtmlAttributeEncode(d.Value.ToString()))
                    ));

                if (addFrontPadding)
                {
                    attributes = attributes.Insert(0, " ");
                }

                if (addBackPadding)
                {
                    attributes = attributes + " ";
                }

                return MvcHtmlString.Create(attributes);
            }

            return MvcHtmlString.Empty;
        }
        #endregion

        #region HelpBlock
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="html"></param>
        /// <param name="expression"></param>
        /// <param name="model"></param>
        /// <param name="partialViewName"></param>
        public static MvcHtmlString HelpBlock<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, Sitecore.Avanade.Foundation.Forms.Fields.BaseField model, string partialViewName = "", string parameterOverride = "")
        {
            // have we been given an override
            if (!parameterOverride.IsNullOrEmpty() && !string.IsNullOrEmpty(model.Parameters[parameterOverride]))
            {
                // set the override
                model.Information = model.Parameters[parameterOverride];
            }

            // do we have information to show
            if (!model.Information.IsNullOrEmpty())
            {
                // have we set a partial name to override
                if (partialViewName.IsNullOrEmpty())
                {
                    // using defaults
                    partialViewName = "~/views/aiforms/HelpBlock.cshtml";
                }

                // render our validation message
                return html.Partial(partialViewName, model);
            }

            return MvcHtmlString.Empty;
        }
        #endregion

        #region ValidationMessageAI
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="html"></param>
        /// <param name="modelName"></param>
        /// <param name="partialViewName"></param>
        public static MvcHtmlString ValidationMessageAI<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, Sitecore.Avanade.Foundation.Forms.Fields.BaseField model, string partialViewName = "")
        {
            // have we set a partial name to override
            if (partialViewName.IsNullOrEmpty())
            {
                // using defaults
                partialViewName = "~/views/aiforms/ValidationMessage.cshtml";
            }

            // render our validation message
            return html.Partial(partialViewName);
        }
        #endregion

        
        #region LabelFor
        /// <summary>Creates a Label with custom Html before the label text.  Only starting Html is provided.</summary>
        /// <param name="startHtml">Html to preempt the label text.</param>
        /// <returns>MVC Html for the Label</returns>
        public static MvcHtmlString LabelFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, string labelText, string htmlFormatterString)
        {
            return LabelFor(html, expression, labelText, htmlFormatterString, new RouteValueDictionary("new {}"));
        }

        /// <summary>Creates a Label with custom Html before the label text.  Starting Html and a single Html attribute is provided.</summary>
        /// <param name="startHtml">Html to preempt the label text.</param>
        /// <param name="htmlAttributes">A single Html attribute to include.</param>
        /// <returns>MVC Html for the Label</returns>
        public static MvcHtmlString LabelFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, string labelText, string htmlFormatterString, object htmlAttributes)
        {
            return LabelFor(html, expression, labelText, htmlFormatterString, new RouteValueDictionary(htmlAttributes));
        }

        /// <summary>Creates a Label with custom Html before and after the label text.  Starting Html, ending Html, and a collection of Html attributes are provided.</summary>
        /// <param name="startHtml">Html to preempt the label text.</param>
        /// <param name="endHtml">Html to follow the label text.</param>
        /// <param name="htmlAttributes">A collection of Html attributes to include.</param>
        /// <returns>MVC Html for the Label</returns>
        public static MvcHtmlString LabelFor<TModel, TProperty>(this HtmlHelper<TModel> html, Expression<Func<TModel, TProperty>> expression, string labelText, string htmlFormatterString, IDictionary<string, object> htmlAttributes)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, html.ViewData);
            string htmlFieldName = ExpressionHelper.GetExpressionText(expression);

            //Use the DisplayName or PropertyName for the metadata if available.  Otherwise default to the htmlFieldName provided by the user.
            string labelFinalText = labelText ?? metadata.DisplayName ?? metadata.PropertyName ?? htmlFieldName.Split('.').Last();
            if (string.IsNullOrEmpty(labelFinalText))
            {
                return MvcHtmlString.Empty;
            }

            //Create the new label.
            TagBuilder tag = new TagBuilder("label");

            //Add the specified Html attributes
            tag.MergeAttributes(htmlAttributes);

            //Specify what property the label is tied to.
            tag.Attributes.Add("for", html.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldId(htmlFieldName));

            //Run through the various iterations of null starting or ending Html text.
            if (htmlFormatterString == null) tag.InnerHtml = labelFinalText;
            else tag.InnerHtml = string.Format(htmlFormatterString, labelFinalText);

            return MvcHtmlString.Create(tag.ToString());
        }
        #endregion
    }
}
