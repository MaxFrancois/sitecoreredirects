﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Extensions
{
    public static class LabelExtensions
    {
        public static MvcHtmlString Label(this HtmlHelper htmlHelper,
                                             string @for,
                                             string title,
                                             string template,
                                             IDictionary<string,object> htmlAttributes)
        {
            var label = new TagBuilder("label");
            label.Attributes["for"] = TagBuilder.CreateSanitizedId(@for);
            foreach (var attribute in htmlAttributes) {
                label.Attributes.Add(attribute.Key, attribute.Value.ToString());
            }
            label.InnerHtml = string.Format(template, title);
            return MvcHtmlString.Create(label.ToString());
        }

        /// <summary>
        /// Handle text templates for Label html heler
        /// </summary>
        /// <remarks>Translate anonymouse type dictionary to htmlAttributes dictionary</remarks>
        public static MvcHtmlString Label(this HtmlHelper htmlHelper,
                                             string @for,
                                             string title,
                                             string template,
                                             object htmlAttributes)
        {
            return htmlHelper.Label(@for, title, template, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }
    }
}