﻿using Newtonsoft.Json;
using Sitecore.Avanade.Foundation.Forms.Fields.ViewModels;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false), DisplayName("TITLE_ERROR_MESSAGE_RECAPTCHA")]
    public class RecaptchaResponseValidatorAttribute : DynamicValidationBaseAttribute
    {
        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.IsNotNull(model, "model");
            if (value == null)
            {
                return new ValidationResult(this.FormatError(model, new object[]
                {
                    "Invalid captcha text"
                }));
            }

            string downnloadString = string.Empty;

            using (WebClient webClient = new WebClient())
            {
                downnloadString = webClient.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", ((AIFormRecaptchaField)model).SecretKey, value));
            };

            ReCaptchaResponse reCaptchaResponse = JsonConvert.DeserializeObject<ReCaptchaResponse>(downnloadString);
            if (reCaptchaResponse.Success)
            {
                return ValidationResult.Success;
            }
            return new ValidationResult(this.FormatError(model, reCaptchaResponse.ErrorCodes.ToArray()));
        }
    }
}