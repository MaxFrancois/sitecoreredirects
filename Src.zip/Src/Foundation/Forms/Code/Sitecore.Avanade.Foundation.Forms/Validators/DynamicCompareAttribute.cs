﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true), DisplayName("TITLE_ERROR_MESSAGE_COMPARE")]
    public class DynamicCompareAttribute : DynamicValidationBaseAttribute
    {
        public string PasswordTitleProperty
        {
            get;
            set;
        }

        public string CompareTitleProperty
        {
            get;
            set;
        }

        public string OtherProperty
        {
            get;
            set;
        }

        public string OtherPropertyDisplayName
        {
            get;set;
        }

        public DynamicCompareAttribute(string otherProperty, string otherPropertyDisplayName, string passwordTitleProperty = null, string compareTitleProperty = null)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(otherProperty, "otherProperty");
            this.OtherProperty = otherProperty;
            this.OtherPropertyDisplayName = otherPropertyDisplayName.IsNullOrEmpty() ? this.OtherProperty : otherPropertyDisplayName;
            this.PasswordTitleProperty = (passwordTitleProperty ?? string.Empty);
            this.CompareTitleProperty = (compareTitleProperty ?? string.Empty);
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            IBaseField model = base.GetModel<IBaseField>(metadata);
            if (model != null)
            {
                yield return new ModelClientValidationEqualToRule(this.FormatError(model, new object[0]), "*." + this.OtherPropertyDisplayName);
            }
            yield break;
        }

        protected override string FormatError(object model, params object[] parameters)
        {
            string propertyValue = model.GetPropertyValue<string>(this.PasswordTitleProperty);
            string propertyValue2 = model.GetPropertyValue<string>(this.CompareTitleProperty);
            return string.Format(CultureInfo.CurrentCulture, this.GetErrorMessageTemplate(model), new object[]
            {
                propertyValue,
                propertyValue2
            });
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            IBaseField model2 = model as IBaseField;
            PropertyInfo property = validationContext.ObjectType.GetProperty(this.OtherProperty);
            if (property == null)
            {
                return new ValidationResult(string.Format(CultureInfo.CurrentCulture, "Unknown property {0}.", new object[]
                {
                    this.OtherProperty
                }));
            }
            object value2 = property.GetValue(validationContext.ObjectInstance, null);
            if (string.IsNullOrEmpty(value2 as string) && string.IsNullOrEmpty(value as string))
            {
                return null;
            }
            if (!object.Equals(value, value2))
            {
                return new ValidationResult(this.FormatError(model2, new object[0]));
            }
            return ValidationResult.Success;
        }
    }
}
