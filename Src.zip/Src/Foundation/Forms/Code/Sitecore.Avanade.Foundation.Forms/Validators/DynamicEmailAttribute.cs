﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions;
using System.ComponentModel.DataAnnotations;
using Sitecore.Form.Core.Configuration;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field), DisplayName("TITLE_ERROR_MESSAGE_EMAIL")]
    public class DynamicEmailAttribute : DynamicValidationBaseAttribute
    {
        private const string DefaultEmailRegularExpression = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,17}$";

        protected string EmailRegExpProperty
        {
            get;
            private set;
        }

        public DynamicEmailAttribute(string property = "")
        {
            base.EventId = IDs.Analytics.FieldOutOfBoundaryEventId.ToString();
            if (!string.IsNullOrEmpty(property))
            {
                this.EmailRegExpProperty = property;
            }
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            string pattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,17}$";
            IBaseField model = base.GetModel<IBaseField>(metadata);
            if (!string.IsNullOrEmpty(this.EmailRegExpProperty))
            {
                string propertyValue = model.GetPropertyValue<string>(this.EmailRegExpProperty);
                if (!string.IsNullOrEmpty(propertyValue))
                {
                    pattern = propertyValue;
                }
            }
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Compiled);
            yield return new ModelClientValidationRegexRule(this.FormatError(model, new object[0]), regex.ToString());
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");
            if (value == null)
            {
                return ValidationResult.Success;
            }
            string pattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,17}$";
            if (!string.IsNullOrEmpty(this.EmailRegExpProperty))
            {
                string propertyValue = validationContext.ObjectInstance.GetPropertyValue<string>(this.EmailRegExpProperty);
                if (!string.IsNullOrEmpty(propertyValue))
                {
                    pattern = propertyValue;
                }
            }
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.Compiled);
            if (string.IsNullOrEmpty((string)value) || regex.IsMatch((string)value))
            {
                return ValidationResult.Success;
            }
            return new ValidationResult((model != null) ? this.FormatError(model, new object[0]) : base.ErrorMessage);
        }
    }
}