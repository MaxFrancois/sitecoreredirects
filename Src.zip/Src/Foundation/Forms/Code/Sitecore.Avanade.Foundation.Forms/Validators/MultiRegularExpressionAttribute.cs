﻿using Sitecore.Form.Core.Configuration;
using System;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false), DisplayName("TITLE_ERROR_MESSAGE_MULTI_REGULAR_EXPRESSION")]
    public class MultiRegularExpressionAttribute : DynamicRegularExpressionAttribute
    {
        public override string ClientRuleName
        {
            get
            {
                return "multiregex";
            }
        }

        public MultiRegularExpressionAttribute(string pattern, string property) : base(pattern, property)
        {
            base.EventId = IDs.Analytics.FieldOutOfBoundaryEventId.ToString();
        }

        protected override bool IsMatch(string stringValue, string pattern)
        {
            return Regex.IsMatch(stringValue, pattern);
        }
    }
}