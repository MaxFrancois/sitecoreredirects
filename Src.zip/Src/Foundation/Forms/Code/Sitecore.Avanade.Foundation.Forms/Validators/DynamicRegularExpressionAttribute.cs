﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false), DisplayName("TITLE_ERROR_MESSAGE_REGULAR_EXPRESSION")]
    public class DynamicRegularExpressionAttribute : DynamicValidationBaseAttribute
    {
        public string Property
        {
            get;
            private set;
        }

        public string Pattern
        {
            get;
            private set;
        }

        public virtual string ClientRuleName
        {
            get
            {
                return "regex";
            }
        }

        public DynamicRegularExpressionAttribute(string pattern, string property)
        {
            this.Property = property;
            this.Pattern = pattern;
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            IBaseField model = base.GetModel<IBaseField>(metadata);

            string value = model.GetPropertyValue<string>(this.Property) ?? this.Pattern;
            if (!string.IsNullOrEmpty(value))
            {
                ModelClientValidationRule modelClientValidationRule = new ModelClientValidationRule
                {
                    ErrorMessage = this.FormatError(model, new object[0]),
                    ValidationType = this.ClientRuleName
                };
                modelClientValidationRule.ValidationParameters.Add("pattern", value);
                modelClientValidationRule.ValidationParameters.Add("tracking", base.EventId);
                yield return modelClientValidationRule;
            }
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            string text = model.GetPropertyValue<string>(this.Property) ?? this.Pattern;
            string text2 = System.Convert.ToString(value, CultureInfo.CurrentCulture);
            if (string.IsNullOrEmpty(text2) || string.IsNullOrEmpty(text))
            {
                return ValidationResult.Success;
            }
            if (!this.IsMatch(text2, text))
            {
                return new ValidationResult(this.FormatError(model, new object[0]));
            }
            return ValidationResult.Success;
        }

        protected virtual bool IsMatch(string stringValue, string pattern)
        {
            Match match = Regex.Match(stringValue, pattern);
            return match.Success && match.Index == 0 && match.Length == stringValue.Length;
        }
    }
}