﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Sitecore.Avanade.Foundation.Forms.Validation.Rules;
using Sitecore.Form.Core.Configuration;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    /// <summary>
    /// Ensures that any non required fields are not present with empty whitespace
    /// prior or post the data. If the field is full of whitespace or at the start
    /// or end of the string it will not be valid
    /// </summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field), DisplayName("TITLE_ERROR_MESSAGE_NOWHITESPACE")]
    public class DynamicNoWhiteSpaceAttribute : DynamicValidationBaseAttribute
    {
        #region Properties
        /// <summary>
        /// Are we performing strict validation or just making sure data is full of whitespace.
        /// true means strict, false means empty. Default is false
        /// </summary>
        public bool StrictValidation { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public DynamicNoWhiteSpaceAttribute()
        {
            base.EventId = IDs.Analytics.FieldOutOfBoundaryEventId.ToString();
            
        }
        #endregion

        #region GetClientValidationRules
        /// <summary>
        /// Works out the client side validation script to execute
        /// </summary>
        /// <param name="metadata"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            // ensure data is valid
            Sitecore.Diagnostics.Assert.ArgumentNotNull(metadata, "metadata");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(context, "context");

            // get our required field
            IHasIsRequired hasIsRequired = base.GetModel<IHasIsRequired>(metadata);

            if (hasIsRequired != null && !hasIsRequired.IsRequired)
            {
                string errorMessage = this.FormatError(hasIsRequired, new object[0]);

                ModelClientValidationRule modelClientValidationRule = new ModelClientValidationNoWhiteSpaceRule(errorMessage);

                // pass in our strict approach or not
                modelClientValidationRule.ValidationParameters.Add("strict", StrictValidation);
                modelClientValidationRule.ValidationParameters.Add("tracking", base.EventId);
                yield return modelClientValidationRule;
            }
            yield break;
        }
        #endregion

        #region ValidateFieldValue
        /// <summary>
        /// Validates the field value to ensure the data is valid
        /// </summary>
        /// <param name="model"></param>
        /// <param name="value"></param>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            // ensure data is valie
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");

            // convert to our required field
            IHasIsRequired hasIsRequired = model as IHasIsRequired;

            // do we have the required field, skip
            if ((hasIsRequired == null || !hasIsRequired.IsRequired)
                && (value != null && !string.IsNullOrEmpty(value.ToString())))
            {
                // get the value out but make sure we trim it
                string stringValue = value.ToString().Trim();

                // are we running strict or not
                if (StrictValidation)
                {
                    // make sure the data is valid and our original string matches our trimmed version
                    if (string.IsNullOrWhiteSpace(stringValue) ||
                        !stringValue.Equals(value.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        return new ValidationResult(this.FormatError(hasIsRequired, new object[0]));
                    }
                }
                else
                {
                    // data is nothing but whitespace
                    if  (string.IsNullOrEmpty(stringValue))
                    {
                        return new ValidationResult(this.FormatError(hasIsRequired, new object[0]));
                    }
                }
            }

            // return success because it is ok
            return ValidationResult.Success;
        }
        #endregion
    }
}