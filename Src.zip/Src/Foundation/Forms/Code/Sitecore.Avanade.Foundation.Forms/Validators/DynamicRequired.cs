﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using Sitecore.Avanade.Foundation.Forms.Validation.Rules;
using Sitecore.Avanade.Foundation.Forms.Fields.ViewModels;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = true), DisplayName("TITLE_ERROR_MESSAGE_FIELD_REQUIRED")]
    public class DynamicRequiredAttribute : DynamicValidationBaseAttribute
    {
        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(metadata, "metadata");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(context, "context");


            IHasIsRequired model = base.GetModel<IHasIsRequired>(metadata);

            if (model != null && model.IsRequired)
            {
                string errorMessage = this.FormatError(model, new object[0]);

                ModelClientValidationRule modelClientValidationRule;

                if (model is AIFormCheckboxField || model is AIFormCheckboxListField)
                {
                    modelClientValidationRule = new ModelClientValidationCheckedRule(errorMessage);
                }
                else
                {
                    modelClientValidationRule = new ModelClientValidationRequiredRule(errorMessage);
                }

                modelClientValidationRule.ValidationParameters.Add("tracking", base.EventId);
                yield return modelClientValidationRule;
            }
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");
            IHasIsRequired hasIsRequired = model as IHasIsRequired;
            if (hasIsRequired == null || !hasIsRequired.IsRequired)
            {
                return ValidationResult.Success;
            }
            List<string> list = value as List<string>;
            if (list != null)
            {
                if (list.Count > 0 && list.TrueForAll((string x) => !string.IsNullOrWhiteSpace(x)))
                {
                    return ValidationResult.Success;
                }
                
                return new ValidationResult(this.FormatError(hasIsRequired, new object[0]));
            }
            if (value is bool)
            {
                if (!(bool)value)
                {
                    return new ValidationResult(this.FormatError(hasIsRequired, new object[0]));
                }
                return ValidationResult.Success;
            }
            else
            {
                HttpPostedFileBase httpPostedFileBase = value as HttpPostedFileBase;
                if (httpPostedFileBase != null && httpPostedFileBase.ContentLength > 0)
                {
                    return ValidationResult.Success;
                }
                string value2 = (value != null) ? value.ToString() : null;
                if (!string.IsNullOrWhiteSpace(value2))
                {
                    return ValidationResult.Success;
                }
                return new ValidationResult(this.FormatError(hasIsRequired, new object[0]));
            }
        }
    }
}