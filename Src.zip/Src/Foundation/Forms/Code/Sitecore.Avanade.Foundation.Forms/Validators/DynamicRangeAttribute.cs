﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = true), DisplayName("TITLE_ERROR_MESSAGE_RANGE")]
    public class DynamicRangeAttribute : DynamicValidationBaseAttribute
    {
        public string MinValuePropertyName { get; set; }
        public string MaxValuePropertyName { get; set; }


        public DynamicRangeAttribute(string minValuePropertyName, string maxValuePropertyName)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(minValuePropertyName, "minValuePropertyName");
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(maxValuePropertyName, "maxValuePropertyName");
            this.MinValuePropertyName = minValuePropertyName;
            this.MaxValuePropertyName = maxValuePropertyName;
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(metadata, "metadata");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(context, "context");
            IBaseField model = base.GetModel<IBaseField>(metadata);
            if (model != null)
            {
                Tuple<double?, double?> minMaxValues = this.GetMinMaxValues<double?>(model);
                double? item = minMaxValues.Item1;
                double? item2 = minMaxValues.Item2;
                if (item.HasValue && item2.HasValue)
                {
                    yield return new System.Web.Mvc.ModelClientValidationRangeRule(this.FormatError(model, new object[]
                    {
                        item.Value,
                        item2.Value
                    }), item, item2)
                    {
                        ValidationParameters =
                        {
                            {
                                "tracking",
                                base.EventId
                            }
                        }
                    };
                }
            }
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");
            if (value == null)
            {
                return null;
            }
            Tuple<double?, double?> minMaxValues = this.GetMinMaxValues<double?>(model);
            double? item = minMaxValues.Item1;
            double? item2 = minMaxValues.Item2;
            if (!item.HasValue || !item2.HasValue)
            {
                return null;
            }
            double num;
            if (!double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out num))
            {
                return new ValidationResult(this.FormatError(model, new object[]
                {
                    item.Value,
                    item2.Value
                }));
            }
            double num2 = num;
            double? num3 = item;
            bool arg_C7_0;
            if (num2 >= num3.GetValueOrDefault())
            {
                double num4 = num;
                double? num5 = item2;
                arg_C7_0 = (num4 <= num5.GetValueOrDefault());
            }
            else
            {
                arg_C7_0 = false;
            }
            if (!arg_C7_0)
            {
                return new ValidationResult(this.FormatError(model, new object[]
                {
                    item.Value,
                    item2.Value
                }));
            }
            return ValidationResult.Success;
        }

        private Tuple<T, T> GetMinMaxValues<T>(IBaseField fieldModel)
        {
            T propertyValue = fieldModel.GetPropertyValue<T>(this.MinValuePropertyName);
            T propertyValue2 = fieldModel.GetPropertyValue<T>(this.MaxValuePropertyName);
            return new Tuple<T, T>(propertyValue, propertyValue2);
        }

    }
}