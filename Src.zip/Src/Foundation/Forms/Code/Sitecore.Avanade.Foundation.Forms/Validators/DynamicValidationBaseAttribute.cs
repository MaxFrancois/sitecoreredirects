﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Forms.Interfaces;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    public abstract class DynamicValidationBaseAttribute : ValidationAttribute, IClientValidatable
    {
        public string ParameterName
        {
            get;
            set;
        }

        public bool ValidateInvisible
        {
            get;
            set;
        }

        protected abstract ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext);

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            IBaseField viewModel = validationContext.ObjectInstance as IBaseField;
            if (viewModel != null && !this.ValidateInvisible && !viewModel.Visible)
            {
                return null;
            }
            ValidationResult validationResult = this.ValidateFieldValue(viewModel, value, validationContext);
            
            return validationResult;
        }

        public virtual IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            yield break;
        }

        protected TModel GetModel<TModel>(ValidationContext validationContext) where TModel : class
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");
            return validationContext.ObjectInstance as TModel;
        }
        
        protected TModel GetModel<TModel>(ModelMetadata modelMetadata)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(modelMetadata, "modelMetadata");
            return (TModel)((object)(modelMetadata.Container));
        }

        protected virtual string FormatError(object model, params object[] parameters)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            IBaseField fieldViewModel = model as IBaseField;
            string text = string.Empty;
            if (fieldViewModel != null)
            {
                string errorMessageTemplate = this.GetErrorMessageTemplate(fieldViewModel);
                text = fieldViewModel.Title;
                if (!parameters.Any<object>())
                {
                    return string.Format(System.Globalization.CultureInfo.CurrentCulture, errorMessageTemplate, new object[]
                    {
                        text
                    });
                }
            }
            List<object> list = new List<object>
            {
                text
            };
            list.AddRange(parameters);
            return string.Format(System.Globalization.CultureInfo.CurrentCulture, this.GetErrorMessageTemplate(fieldViewModel), list.ToArray());
        }

        public virtual string GetErrorMessageTemplate(object fieldModel)
        {
            string key = string.IsNullOrEmpty(this.ParameterName) ? base.GetType().Name : this.ParameterName;
            IBaseField fieldViewModel = (IBaseField)fieldModel;
            if (fieldViewModel != null && fieldViewModel.Parameters.ContainsKey(key))
            {
                return fieldViewModel.Parameters[key];
            }
        
            return Sitecore.Avanade.Foundation.Dictionary.Translate.Text(base.ErrorMessageString);
        }

        public override object TypeId { get; } = new object();

        public string EventId { get; internal set; }
    }
}