﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Forms.Interfaces;
using Sitecore.Form.Core.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true), DisplayName("TITLE_ERROR_MESSAGE_STRING_LENGTH")]
    public class DynamicStringLengthAttribute : DynamicValidationBaseAttribute
    {
        public string MinimumProperty
        {
            get;
            private set;
        }

        public string Maximum
        {
            get;
            private set;
        }

        public DynamicStringLengthAttribute(string minPropertyLength, string maxPropertyLength)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(minPropertyLength, "minPropertyLength");
            Sitecore.Diagnostics.Assert.ArgumentNotNullOrEmpty(maxPropertyLength, "maxPropertyLength");
            this.MinimumProperty = minPropertyLength;
            this.Maximum = maxPropertyLength;
            base.EventId = IDs.Analytics.FieldOutOfBoundaryEventId.ToString();
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            IBaseField model = base.GetModel<IBaseField>(metadata);
            int? containerPropertyValue = metadata.Container.GetPropertyValue<int>(this.MinimumProperty);
            int? containerPropertyValue2 = metadata.Container.GetPropertyValue<int>(this.Maximum);
            if (containerPropertyValue.HasValue && containerPropertyValue2.HasValue)
            {
                yield return new ModelClientValidationStringLengthRule(this.FormatError(model, new object[]
                {
                    containerPropertyValue.Value,
                    containerPropertyValue2.Value
                }), containerPropertyValue.Value, containerPropertyValue2.Value);
            }
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            try
            {
                int num = model.GetPropertyValue<int>(this.MinimumProperty);
                int propertyValue = model.GetPropertyValue<int>(this.Maximum);
                if (num < 0)
                {
                    num = 0;
                }
                int num2 = (value == null) ? 0 : value.ToString().Length;
                return (value == null || propertyValue == 0 || (num2 >= num && num2 <= propertyValue)) ? ValidationResult.Success : new ValidationResult(this.FormatError(model, new object[]
                {
                    num,
                    propertyValue
                }));
            }
            catch (Exception exception)
            {
                Sitecore.Diagnostics.Log.Error("Dynamic string length validation error occurs", exception, this);
            }
            return new ValidationResult(base.ErrorMessage);
        }
    }
}