﻿using Sitecore.Avanade.Foundation.Forms.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Forms.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false, Inherited = true), DisplayName("TITLE_ERROR_MESSAGE_FIELD_MINAGE")]
    public class DynamicMinAgeAttribute : DynamicValidationBaseAttribute
    {
        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(metadata, "metadata");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(context, "context");

            IHasMinAge model = base.GetModel<IHasMinAge>(metadata);

            if (model != null && model.MinAge > 0)
            {
                string errorMessage = this.FormatError(model, new object[0]);

                // set the valiation input for the jS
                var modelClientValidationRule = new ModelClientValidationRule();
                modelClientValidationRule.ErrorMessage = errorMessage;
                modelClientValidationRule.ValidationType = "minage";
                modelClientValidationRule.ValidationParameters["min"] = model.MinAge;
                yield return modelClientValidationRule;
            }
            yield break;
        }

        protected override ValidationResult ValidateFieldValue(IBaseField model, object value, ValidationContext validationContext)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(model, "model");
            Sitecore.Diagnostics.Assert.ArgumentNotNull(validationContext, "validationContext");
            IHasMinAge hasMinAge = model as IHasMinAge;
            if (hasMinAge == null || hasMinAge.MinAge == 0)
            {
                return ValidationResult.Success;
            }

            if (value is DateTime)
            {
                DateTime date = System.Convert.ToDateTime(value);
                long ticks = DateTime.Now.Ticks - date.Ticks;
                int years = new DateTime(ticks).Year;
                if (years >= hasMinAge.MinAge)
                {
                    return ValidationResult.Success;
                }
            }

            return new ValidationResult(this.FormatError(hasMinAge, new object[0]));

        }
    }
}