﻿using System;
using Sitecore.Avanade.Foundation.CDP.Infrastructure.Interface;
using Sitecore.Web;

namespace Sitecore.Avanade.Foundation.CDP.sitecore.login
{
    public abstract class LoginBase : Sitecore.sitecore.login.Default, ICdpCore
    {
        private const string ENFORCE_PASSWORD_EXPIRATION = "EnforcePasswordExpiration";
        private const string ENFORCE_PASSWORD_COMPLEXITY = "EnforcePasswordComplexity";

        /// <summary>
        /// Gets the value indicating whether the CDP password expiration is being activated
        /// </summary>
        public bool EnforcePasswordExpiration
        {
            get
            {
                return GetProfileBoolCustomPropertyValue(ENFORCE_PASSWORD_EXPIRATION);
            }
        }

        /// <summary>
        /// Gets the value indicating whether the CDP password complexity is being activated
        /// </summary>
        public bool EnforcePasswordComplexity
        {
            get
            {
                return GetProfileBoolCustomPropertyValue(ENFORCE_PASSWORD_COMPLEXITY);
            }
        }

        private bool GetProfileBoolCustomPropertyValue(string propertyName)
        {
            var user = GetLogginInUser();

            if (user == null)
                return true;

            using (new Security.Accounts.UserSwitcher(user))
            {
                var strBool = user.Profile.GetCustomProperty(propertyName);

                return !string.IsNullOrEmpty(strBool) && strBool != "0";
            }
        }

        private Security.Accounts.User GetLogginInUser()
        {
            var fullUsername = WebUtil.HandleFullUserName(UserName.Text);

            if (!Security.Accounts.User.Exists(fullUsername))
                return null;

            var user = Security.Accounts.User.FromName(fullUsername, false);

            return user;
        }
    }
}