﻿using Sitecore.Avanade.Foundation.CDP.Processor;
using Sitecore.Diagnostics;
using Sitecore.Pipelines;
using Sitecore.Security.Authentication;
using Sitecore.Web;
using Sitecore.Web.Authentication;
using System;
using System.Web.Security;
using Sitecore.Configuration;
using Sitecore.SecurityModel.Cryptography;
using System.Text.RegularExpressions;
using Sitecore.Globalization;
using Sitecore.Security.Accounts;
using Sitecore.Text;
using Sitecore.Pipelines.LoggedIn;

namespace Sitecore.Avanade.Foundation.CDP.sitecore.login
{
    public partial class Default : LoginBase
    {
        #region Protected Attributes

        protected string _startUrl = string.Empty;
        protected string _fullUserName = string.Empty;
        protected string _password = string.Empty;

        #endregion

        #region Event Handlers

        protected void Page_Load(object sender, EventArgs e)
        {
            _startUrl = WebUtil.GetQueryString("returnUrl");
            _fullUserName = WebUtil.HandleFullUserName(UserName.Text);
            _password = Password.Text;
        }

        protected void AILoginClicked(object sender, EventArgs e)
        {
            if (!EnforcePasswordExpiration)
                LoginClicked(sender, e);
            else
                DoLogin();
        }

        protected void AIChangePasswordClicked(object sender, EventArgs e)
        {
            var user = Membership.GetUser(_fullUserName);

            Assert.IsNotNull(user, this.GetType());

            if (AreChangePasswordFieldsValid())
            {
                try
                {
                    // Change the password
                    if (!user.ChangePassword(txtCurrentPassword.Text, txtNewPassword.Text))
                        return;

                    // Set the context password to the new password
                    _password = txtNewPassword.Text;
                    Password.Text = txtNewPassword.Text;
                    
                    DoLogin();
                }
                catch (Exception ex)
                {
                    litPasswordExpiredMessage.Text = ex.Message;
                }
            }
        }

        #endregion

        #region Protected Methods
        
        protected virtual bool AILoggingIn()
        {
            if (string.IsNullOrWhiteSpace(UserName.Text))
                return false;

            SuccessHolder.Visible = false;
            FailureHolder.Visible = false;

            if (Settings.Login.RememberLastLoggedInUserName)
                WriteCookie(WebUtil.GetLoginCookieName(), UserName.Text);

            var ailoggingInArgs = new AILoggingInArgs
            {
                Username = _fullUserName,
                Password = _password,
                StartUrl = _startUrl
            };

            Pipeline.Start("loggingin", ailoggingInArgs);

            bool flag = UIUtil.IsIE() || UIUtil.IsIE11();

            if (flag && !Regex.IsMatch(WebUtil.GetHostName(), Settings.HostNameValidationPattern, RegexOptions.ECMAScript))
            {
                RenderError(Translate.Text("Your login attempt was not successful because the URL hostname contains invalid character(s) that are not recognized by IE. Please check the URL hostname or try another browser."));

                return false;
            }

            if (!ailoggingInArgs.Success)
            {
                if (ailoggingInArgs.HasPasswordExpired)
                {
                    litPasswordExpiredMessage.Text = ailoggingInArgs.Message;

                    login.Visible = false;
                    changePassword.Visible = true;
                }
                else
                {
                    Log.Audit(string.Format("Login failed: {0}.", ailoggingInArgs.Username), this);
                    if (!string.IsNullOrEmpty(ailoggingInArgs.Message))
                    {
                        RenderError(Translate.Text(StringUtil.RemoveLineFeeds(ailoggingInArgs.Message)));
                    }
                }
            }

            _startUrl = ailoggingInArgs.StartUrl;

            return ailoggingInArgs.Success;
        }

        /// <summary>
        /// Runs Sitecore's login pipelines
        /// </summary>
        protected void DoLogin()
        {
            if (!AILoggingIn())
                return;

            if (!Login())
                return;

            LoggedIn();

            CheckDomainGuard();

            WebUtil.Redirect(this._startUrl);
        }

        /// <summary>
        /// Checks whether the submitted change password fields are valid
        /// </summary>
        /// <returns></returns>
        protected bool AreChangePasswordFieldsValid()
        {
            if (txtCurrentPassword.Text.Length == 0 || txtNewPassword.Text.Length == 0 || txtConfirmPassword.Text.Length == 0)
            {
                litPasswordExpiredMessage.Text = "All fields are required";

                return false;
            }
            else if (txtConfirmPassword.Text != txtNewPassword.Text)
            {
                litPasswordExpiredMessage.Text = "The confirmation password does not match the new password";

                return false;
            }

            return true;
        }

        #endregion

        #region Copied from base with a slight modification, because one or more required private variable values cannot be accessed

        protected override bool Login()
        {
            if (AuthenticationManager.Login(_fullUserName, _password, !Settings.Login.DisableRememberMe && RememberMe.Checked))
                return true;

            this.RenderError("Your login attempt was not successful. Please try again.");

            return false;
        }

        protected override void LoggedIn()
        {
            User user = Sitecore.Security.Accounts.User.FromName(_fullUserName, false);
            State.Client.UsesBrowserWindows = true;
            var loggedInArgs = new LoggedInArgs
            {
                Username = _fullUserName,
                StartUrl = _startUrl,
                Persist = !Settings.Login.DisableRememberMe && RememberMe.Checked
            };
            Pipeline.Start("loggedin", loggedInArgs);

            var @string = StringUtil.GetString(new string[]
            {
                user.Profile.ClientLanguage,
                Settings.ClientLanguage
            });

            var url = loggedInArgs.StartUrl;
            var urlString = new UrlString(url);

            if (string.IsNullOrEmpty(urlString["sc_lang"]))
                urlString["sc_lang"] = @string;

            _startUrl = urlString.ToString();

            using (new UserSwitcher(user))
            {
                Log.Audit(this, "Login", new string[0]);
            }
        }

        protected void CheckDomainGuard()
        {
            if (!DomainAccessGuard.GetAccess())
            {
                this.LogMaxEditorsExceeded();
#pragma warning disable S1075 // URIs should not be hardcoded
                this._startUrl = WebUtil.GetFullUrl("/sitecore/client/Applications/LicenseOptions/StartPage");
#pragma warning restore S1075 // URIs should not be hardcoded
            }
        }

        /// <summary>
        /// Logs that the maximum number of simultaneously active (logged-in) editors was exceeded. 
        /// </summary>
        protected void LogMaxEditorsExceeded()
        {
            string format = "The maximum number of simultaneously active (logged-in) editors exceeded. The User {0} cannot be logged in to the system. The maximum of editors allowed by license is {1}.";
            Log.Warn(string.Format(format, this._fullUserName, DomainAccessGuard.MaximumSessions), this);
        }

        protected static void WriteCookie(string name, string value)
        {
            Assert.ArgumentNotNull(name, "name");
            Assert.ArgumentNotNull(value, "value");
            if (name == WebUtil.GetLoginCookieName())
            {
                value = MachineKeyEncryption.Encode(value);
            }
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(name, value)
            {
                Expires = System.DateTime.UtcNow.AddMonths(3),
                Path = "/sitecore/login",
                HttpOnly = true
            };
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);
            System.Web.HttpCookie httpCookie = System.Web.HttpContext.Current.Request.Cookies[name];
            if (httpCookie != null)
            {
                httpCookie.Value = value;
            }
        }

        protected void RenderError(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return;
            }
            this.FailureHolder.Visible = true;
            this.FailureText.Text = text;
        }

        #endregion
    }
}