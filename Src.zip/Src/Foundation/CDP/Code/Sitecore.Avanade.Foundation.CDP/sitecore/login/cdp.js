﻿var CDP = {
    Controls: {
        ChangePasswordSubmitButton: $("#changePassword input[type='submit']"),
        CurrentPasswordInput: $("#txtCurrentPassword"),
        NewPasswordInput: $("#txtNewPassword"),
        ConfirmPasswordInput: $("#txtConfirmPassword"),
        ChangePasswordErrorContainer: $("#changePasswordError"),
        ChangePasswordErrorMessage: $("#changePasswordError .scMessageBarText")
    },

    Constant: {
        ErrorMessage: {
            ChangePasswordEmptyFields: "All fields are required",
            ChangePasswordPasswordConfirmDoesNotMatch: "The confirmation password does not match the new password"
        }
    },

    Init: function () {
        this.BindEvents();
    },

    BindEvents: function () {
        this.Controls.ChangePasswordSubmitButton.click(this.EventHandler.ChangePasswordSubmitClick);
    },

    EventHandler: {

        ChangePasswordSubmitClick: function () {
            if (CDP.Controls.CurrentPasswordInput.val().length == 0 ||
                CDP.Controls.NewPasswordInput.val().length == 0 ||
                CDP.Controls.ConfirmPasswordInput.val().length == 0) {

                CDP.Controls.ChangePasswordErrorMessage.text(CDP.Constant.ErrorMessage.ChangePasswordEmptyFields);
                CDP.Controls.ChangePasswordErrorContainer.show();
                return false;

            } else if (CDP.Controls.NewPasswordInput.val() !== CDP.Controls.ConfirmPasswordInput.val()) {

                CDP.Controls.ChangePasswordErrorMessage.text(CDP.Constant.ErrorMessage.ChangePasswordPasswordConfirmDoesNotMatch);
                CDP.Controls.ChangePasswordErrorContainer.show();
                return false;

            } else {

                CDP.Controls.ChangePasswordErrorContainer.hide();
            }
        }
    }
};

jQuery(document).ready(function ($) {
    CDP.Init();
});