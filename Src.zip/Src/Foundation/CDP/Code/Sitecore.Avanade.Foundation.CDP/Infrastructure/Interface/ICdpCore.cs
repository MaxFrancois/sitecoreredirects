﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.CDP.Infrastructure.Interface
{
    public interface ICdpCore
    {
        /// <summary>
        /// Gets the value indicating whether the CDP password expiration is being activated
        /// </summary>
        bool EnforcePasswordExpiration { get; }

        /// <summary>
        /// Gets the value indicating whether the CDP password complexity is being activated
        /// </summary>
        bool EnforcePasswordComplexity { get; }
    }
}