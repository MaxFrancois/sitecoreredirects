﻿using Sitecore.Avanade.Foundation.CDP.Data;
using Sitecore.Avanade.Foundation.CDP.Provider.Helper;
using Sitecore.Diagnostics;
using Sitecore.Pipelines;

namespace Sitecore.Avanade.Foundation.CDP.Processor
{
    /// <summary>
    /// Processor to create a database trigger for the CDP password functionality
    /// </summary>
    public class CreatePasswordHistoryTrigger
    {
        public string ConnectionStringName { get; set; }

        public CreatePasswordHistoryTrigger(string connectionStringName)
        {
            Assert.ArgumentNotNull(connectionStringName, "connectionStringName");

            ConnectionStringName = connectionStringName;
        }

        public void Process(PipelineArgs args)
        {
            // Initiate the database migration process
#pragma warning disable S1481 // Unused local variables should be removed
            var dbContext = new AIProviderContext(ConnectionStringName);
#pragma warning restore S1481 // Unused local variables should be removed

            var command = @"
                IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[trPasswordUpdate]'))
                    DROP TRIGGER [dbo].[trPasswordUpdate]

                exec('CREATE TRIGGER dbo.trPasswordUpdate
			        ON  dbo.aspnet_Membership
				        AFTER UPDATE
			        AS 
				        BEGIN
					        INSERT INTO dbo.aspnet_PasswordHistory 
					        (
						        UserId, 
						        [Password], 
						        PasswordSalt,
                                CreatedDate
					        ) 
					        SELECT
						        deleted.UserId,
						        deleted.[Password], 
						        deleted.PasswordSalt,
                                GETDATE()
					        FROM
						        deleted INNER JOIN inserted ON deleted.UserId = inserted.UserId
					        WHERE
						        (deleted.[Password] <> inserted.[Password]) OR (deleted.PasswordSalt <> inserted.PasswordSalt)
				        END')";

            SqlServerConnector.ExecuteNonQuery(command, ConnectionStringName);
        }
    }
}
