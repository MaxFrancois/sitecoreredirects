﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines.LoggingIn;
using System;
using System.Web.Security;

namespace Sitecore.Avanade.Foundation.CDP.Processor
{
    public class ForcePasswordChange
    {
        protected int MaxPasswordAgeInDays { get; set; }

        public void Process(LoggingInArgs args)
        {
            var aiLoggingInArgs = args as AILoggingInArgs;

            if (aiLoggingInArgs != null && aiLoggingInArgs.CheckPasswordValidity(MaxPasswordAgeInDays))
            {
                aiLoggingInArgs.AddMessage("Your password has expired. Please change your password.");
                aiLoggingInArgs.Success = false;
                aiLoggingInArgs.AbortPipeline();
            }
        }
    }
}
