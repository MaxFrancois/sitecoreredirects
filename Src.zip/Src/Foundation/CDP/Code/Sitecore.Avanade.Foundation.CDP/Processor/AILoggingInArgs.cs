﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines.LoggingIn;
using System;
using System.Runtime.Serialization;
using System.Web.Security;

namespace Sitecore.Avanade.Foundation.CDP.Processor
{
    /// <summary>
    /// A LoggingInArgs objects specifically designed to enforce CDP plan into Sitecore
    /// </summary>
    [Serializable]
    public class AILoggingInArgs : LoggingInArgs
    {
        [NonSerialized]
        protected bool _hasPasswordExpired;

        /// <summary>
        /// Checks whether the current password has expired
        /// </summary>
        /// <param name="passwordAgeInDays">The number of days for a password to expire</param>
        /// <returns>true if the current password has expired; otherwise, false.</returns>
        public bool CheckPasswordValidity(int passwordAgeInDays)
        {
            var user = Membership.GetUser(Username);

            Assert.IsNotNull(user, this.GetType());
                
            var date = user.LastPasswordChangedDate;
            _hasPasswordExpired = Membership.ValidateUser(Username, Password) && (DateTime.Now - date).TotalDays > passwordAgeInDays;
            
            return _hasPasswordExpired;
        }

        /// <summary>
        /// Gets the value indicating whether the current password has expired
        /// </summary>
        public virtual bool HasPasswordExpired { get { return _hasPasswordExpired; } }

        public AILoggingInArgs()
        { }
        protected AILoggingInArgs(SerializationInfo info, StreamingContext context) : base(info,context)
        { }
    }
}