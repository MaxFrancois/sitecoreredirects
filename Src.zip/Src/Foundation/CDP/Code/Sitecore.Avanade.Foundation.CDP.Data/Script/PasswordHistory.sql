﻿IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='dbo.aspnet_PasswordHistory' AND xtype='U')
BEGIN
-- Creates a table which will hold the password history data
exec('CREATE TABLE dbo.aspnet_PasswordHistory
(
PasswordHistoryId INT PRIMARY KEY IDENTITY(1,1),
UserId UNIQUEIDENTIFIER,
[Password] NVARCHAR(128) NOT NULL,
PasswordSalt NVARCHAR(128) NOT NULL,
CreatedDate DATETIME DEFAULT GETDATE()
)')

-- Adds a FK to the aspnet_Users table to identify the user
exec('ALTER TABLE dbo.aspnet_PasswordHistory ADD CONSTRAINT FK_aspnet_PasswordHistory_aspnet_Users_UserId FOREIGN KEY (UserId) REFERENCES dbo.aspnet_Users (UserId)')

-- Creates trigger on the aspnet_Membership, so every update to the password will insert a new record to the dbo.aspnet_PasswordHistory
exec('CREATE TRIGGER dbo.trPasswordUpdate
ON  dbo.aspnet_Membership
AFTER UPDATE
AS
BEGIN
INSERT INTO dbo.aspnet_PasswordHistory
(
UserId,
[Password],
PasswordSalt
)
SELECT
deleted.UserId,
deleted.[Password],
deleted.PasswordSalt
FROM
deleted INNER JOIN inserted ON deleted.UserId = inserted.UserId
WHERE
(deleted.[Password] <> inserted.[Password]) OR (deleted.PasswordSalt <> inserted.PasswordSalt)
END')

-- Creates a Store Procedure to get the n most recent passwords
exec('CREATE PROCEDURE dbo.aspnet_Membership_EnsurePasswordHasNotRecentlyBeenUsed
@userName NVARCHAR(256),
@userPassword NVARCHAR(128),
@numberOfRecentPasswordsToRetrieve INT
AS
BEGIN

DECLARE @userId UNIQUEIDENTIFIER

SELECT @userId = NULL

SELECT
@userId = UserId
FROM
dbo.aspnet_Users
WHERE
UserName = @userName

IF(@userId = NULL)
BEGIN
DECLARE @errorMessage NVARCHAR(256)
SELECT @errorMessage = ''User id not found for user '' + @userName + ''.''
RAISERROR (@errorMessage, 16, 1)
END

SELECT COUNT(result.[Password]) as PasswordUseCount
FROM
(SELECT TOP(@numberOfRecentPasswordsToRetrieve)
[Password],
PasswordSalt
FROM
dbo.aspnet_PasswordHistory
WHERE
UserId = @userId
ORDER BY
CreatedDate DESC) as result
WHERE result.[Password] = @userPassword
END')

-- Creates a Store Procedure to delete the non-relevant password history
exec('CREATE PROCEDURE dbo.aspnet_Membership_PasswordHistoryDeleteNonRecentPasswords
@userName NVARCHAR(256),
@numberOfRecentPasswordsToKeep INT
AS
BEGIN

DECLARE @userId UNIQUEIDENTIFIER

SELECT @userId = NULL

SELECT
@userId = UserId
FROM
dbo.aspnet_Users
WHERE
UserName = @userName

IF(@userId = NULL)
BEGIN
DECLARE @errorMessage NVARCHAR(256)
SELECT @errorMessage = ''User id not found for user '' + @userName + ''.''
RAISERROR (@errorMessage, 16, 1)
END

DECLARE @minimumDate DATETIME

SELECT
@minimumDate = MIN(CreatedDate)
FROM
dbo.aspnet_PasswordHistory
WHERE
UserId = @userId
AND CreatedDate IN
(
SELECT
TOP(@numberOfRecentPasswordsToKeep) CreatedDate
FROM
dbo.aspnet_PasswordHistory
WHERE
UserId = @userId
ORDER BY
CreatedDate DESC
)

IF(@minimumDate IS NOT NULL)
BEGIN
DELETE
FROM
dbo.aspnet_PasswordHistory
WHERE
UserId = @userId
AND CreatedDate < @minimumDate
				END
			END')
END