﻿using System.Data.Entity.Migrations;

namespace Sitecore.Avanade.Foundation.CDP.Data.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<AIProviderContext>
    {
        public Configuration()
        {
            // Set the value to true to enable automatic migration
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(AIProviderContext context)
        {
#pragma warning disable S125 // Sections of code should not be "commented out"
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },

            //      new Person { FullName = "Rowan Miller" }
            //    );
#pragma warning restore S125 // Sections of code should not be "commented out"                            //
        }

    }
}
