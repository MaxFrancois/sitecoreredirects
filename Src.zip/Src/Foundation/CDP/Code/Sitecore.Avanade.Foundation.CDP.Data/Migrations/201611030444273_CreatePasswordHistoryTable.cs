namespace Sitecore.Avanade.Foundation.CDP.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreatePasswordHistoryTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.aspnet_PasswordHistory",
                c => new
                    {
                        PasswordHistoryId = c.Int(nullable: false, identity: true),
                        UserId = c.Guid(nullable: false),
                        Password = c.String(nullable: false),
                        PasswordSalt = c.String(nullable: false),
                        CreatedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.PasswordHistoryId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.aspnet_PasswordHistory");
        }
    }
}
