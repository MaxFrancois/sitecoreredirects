﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace Sitecore.Avanade.Foundation.CDP.Data.Infrastructure
{
    internal class Repository<C, T> : IRepository<T>
        where C : DbContext, new()
        where T : class
    {
        private C _entities;

        public Repository(string connectionString)
        {
            _entities = Activator.CreateInstance(typeof(C), connectionString) as C;
        }

#pragma warning disable S2292 // Trivial properties should be auto-implemented
        public C Context
#pragma warning restore S2292 // Trivial properties should be auto-implemented
        {
            get { return _entities; }
            set { _entities = value; }
        }

        public virtual IQueryable<T> GetAll()
        {
            IQueryable<T> query = _entities.Set<T>();
            return query;
        }

        public virtual IQueryable<T> Find(Expression<Func<T, bool>> predicate)
        {
            IQueryable<T> query = _entities.Set<T>().Where(predicate);
            return query;
        }

        public virtual void Add(T entity)
        {
            _entities.Set<T>().Add(entity);
        }

        public virtual void Delete(T entity)
        {
            _entities.Set<T>().Remove(entity);
        }

        public virtual void Edit(T entity)
        {
            _entities.Entry(entity).State = EntityState.Modified;
        }

        public virtual void Save()
        {
            _entities.SaveChanges();
        }
    }
}
