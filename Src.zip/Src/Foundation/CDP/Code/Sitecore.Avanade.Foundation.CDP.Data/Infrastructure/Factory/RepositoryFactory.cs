﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Data.Entity;

namespace Sitecore.Avanade.Foundation.CDP.Data.Infrastructure.Factory
{
#pragma warning disable S1118 // Utility classes should not have public constructors
                             /// <summary>
                             /// The purpose of the class is to fabricate the instance of a repository,
                             /// to avoid the use of Dependency Injection Container
                             /// </summary>
                             /// <typeparam name="C">EntityFramework DbContext type</typeparam>
                             /// <typeparam name="T">The model type</typeparam>
    internal class RepositoryFactory<C, T>
#pragma warning restore S1118 // Utility classes should not have public constructors
        where C : DbContext, new()
        where T : class
    {
        private static volatile Dictionary<string, IRepository<T>> repositories = new Dictionary<string, IRepository<T>>();
#pragma warning disable S2743 // Static fields should not be used in generic types
        private static object syncRoot = new Object();
#pragma warning restore S2743 // Static fields should not be used in generic types

        /// <summary>
        /// Gets the concrete implementation of the repository
        /// </summary>
        /// <typeparam name="T">The model type</typeparam>
        /// <returns></returns>
        public static IRepository<T> GetRepository(string connectionStringName)
        {
            var repositoryTypeName = typeof(T).ToString();
            var repository = repositories.ContainsKey(repositoryTypeName) ? repositories[repositoryTypeName] : null;

            if (repository == null)
            {
                lock (syncRoot)
                {
                    try
                    {
                        repository = Activator.CreateInstance(
                            typeof(Repository<C, T>), GetConnectionString(connectionStringName))
                            as IRepository<T>;

                        repositories.Add(repositoryTypeName, repository);

                        return repository;
                    }
                    catch (Exception)
                    {
                        return null;
                    }
                }
            }

            return repository;
        }

        /// <summary>
        /// Gets the entity framework qualified connection string value.
        /// EF needs ProviderName attribute to be set. Sitecore does not use ProviderName attribute in its connection string
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <returns></returns>
        private static string GetConnectionString(string connectionStringName)
        {
            var connectionStringObject = ConfigurationManager.ConnectionStrings[connectionStringName];

            if (connectionStringObject == null)
#pragma warning disable S112 // General exceptions should never be thrown
                throw new Exception("connectionString cannot be null");
#pragma warning restore S112 // General exceptions should never be thrown

            return connectionStringObject.ToString();
        }
    }
}
