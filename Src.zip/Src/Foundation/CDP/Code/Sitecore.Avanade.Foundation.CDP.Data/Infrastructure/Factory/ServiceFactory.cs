﻿using Sitecore.Avanade.Foundation.CDP.Data.Service;
using System;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.CDP.Data.Infrastructure.Factory
{
#pragma warning disable S1118 // Utility classes should not have public constructors
    public class ServiceFactory<S>
#pragma warning restore S1118 // Utility classes should not have public constructors
        where S : BaseAIProviderService
    {
        private static volatile Dictionary<string, S> services = new Dictionary<string, S>();
#pragma warning disable S2743 // Static fields should not be used in generic types
        private static object syncRoot = new Object();
#pragma warning restore S2743 // Static fields should not be used in generic types

        public static S GetService(string connectionStringName)
        {
            var serviceTypeName = typeof(S).ToString();
            var service = services.ContainsKey(serviceTypeName) ? services[serviceTypeName] : null;

            if (service == null)
            {
                lock (syncRoot)
                {
                    try
                    {
                        service = Activator.CreateInstance(typeof(S), connectionStringName) as S;

                        services.Add(serviceTypeName, service);

                        return service;
                    }
                    catch (Exception)
                    {
                        return null;
                    }
                }
            }

            return service;
        }
    }
}
