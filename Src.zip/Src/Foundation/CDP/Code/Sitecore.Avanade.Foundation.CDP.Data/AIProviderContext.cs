﻿using Sitecore.Avanade.Foundation.CDP.Data.Migrations;
using Sitecore.Avanade.Foundation.CDP.Data.Model;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Sitecore.Avanade.Foundation.CDP.Data
{
    public class AIProviderContext : DbContext
    {
        public AIProviderContext() { }

        public AIProviderContext(string connectionName)
            : base(connectionName)
        {
            /* UNCOMMENT/COMMENT BELOW LINES TO ENABLE/DISABLE CODEFIRST MIGRATION */
#pragma warning disable S125 // Sections of code should not be "commented out"
            //Database.SetInitializer(new MigrateDatabaseToLatestVersion<AIProviderContext, Configuration>(connectionStringName: connectionName));
            //Database.Initialize(false);
#pragma warning restore S125 // Sections of code should not be "commented out"
        }


        public DbSet<PasswordHistory> PasswordHistory { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Entity<PasswordHistory>();

            base.OnModelCreating(modelBuilder);
        }
    }
}
