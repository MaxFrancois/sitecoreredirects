﻿using Sitecore.Avanade.Foundation.CDP.Data.Infrastructure;
using Sitecore.Avanade.Foundation.CDP.Data.Infrastructure.Factory;

namespace Sitecore.Avanade.Foundation.CDP.Data.Service
{
    public abstract class BaseAIProviderService
    {
        protected string _connectionStringName;

        protected BaseAIProviderService(string connectionStringName)
        {
            _connectionStringName = connectionStringName;
        }

        protected IRepository<T> GetRepository<T>() where T : class
        {
            return RepositoryFactory<AIProviderContext, T>.GetRepository(_connectionStringName);
        }
    }
}
