﻿using Sitecore.Avanade.Foundation.CDP.Data.Infrastructure;
using Sitecore.Avanade.Foundation.CDP.Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sitecore.Avanade.Foundation.CDP.Data.Service
{
    public class PasswordHistoryService : BaseAIProviderService
    {
#pragma warning disable S2933 // Fields that are only assigned in the constructor should be "readonly"
        private IRepository<PasswordHistory> _repository;
#pragma warning restore S2933 // Fields that are only assigned in the constructor should be "readonly"

        public PasswordHistoryService(string connectionStringName)
            : base(connectionStringName)
        {
            _repository = GetRepository<PasswordHistory>();
        }

        /// <summary>
        /// Gets the last n passwords
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="numOfPrevPasswords"></param>
        /// <returns></returns>
        public List<PasswordHistory> GetPasswordHistories(Guid userId, int numOfPrevPasswords)
        {
            if (_repository == null)
            {
                return new List<PasswordHistory>();
            }

            var passwordHistories = _repository.Find(passwordHistory => passwordHistory.UserId == userId);

            if (passwordHistories == null)
            {
                return new List<PasswordHistory>();
            }

            var descOrderedPasswordHistories = passwordHistories.OrderByDescending(passwordHistory => passwordHistory.CreatedDate);

            return descOrderedPasswordHistories.Count() < numOfPrevPasswords
                    ? descOrderedPasswordHistories.ToList()
                    : descOrderedPasswordHistories.Take(numOfPrevPasswords).ToList();
        }

        /// <summary>
        /// Adds a record into the PasswordHistory table
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <param name="salt"></param>
        public void AddPasswordHistory(Guid userId, string password, string salt)
        {
            var passwordHistory = new PasswordHistory
            {
                UserId = userId,
                Password = password,
                PasswordSalt = salt,
                CreatedDate = DateTime.Now
            };

            _repository.Add(passwordHistory);
            _repository.Save();
        }
    }
}
