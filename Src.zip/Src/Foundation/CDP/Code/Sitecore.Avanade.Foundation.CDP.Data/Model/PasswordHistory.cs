﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.Avanade.Foundation.CDP.Data.Model
{
    [Table("dbo.aspnet_PasswordHistory")]
    public class PasswordHistory
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PasswordHistoryId { get; set; }

        [Required]
        public Guid UserId { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public string PasswordSalt { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
    }
}
