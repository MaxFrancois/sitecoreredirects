﻿using Sitecore.Avanade.Foundation.CDP.Provider.Model;
using System;
using System.Collections.Specialized;
using System.Web.Configuration;
using System.Web.Security;

namespace Sitecore.Avanade.Foundation.CDP.Provider.Extension
{
    public static class MembershipProviderExtension
    {
        /// <summary>
        /// Initialises the MembershipProvider configurations
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="config"></param>
        /// <returns></returns>
        public static CdpPasswordConfiguration InitConfig(
            this System.Web.Security.MembershipProvider provider, NameValueCollection config)
        {
            var maxRequiredPasswordLength = 16;
            var numOfPreviousPasswordToCheck = 24;
            var numOfRepeatedCharAllowed = 4;
            var commandTimeout = 30;
            var connectionStringName = string.Empty;
            var membershipPasswordCompatibilityMode = MembershipPasswordCompatibilityMode.Framework20;

            if (!string.IsNullOrEmpty(config["maxRequiredPasswordLength"]))
                Int32.TryParse(config["maxRequiredPasswordLength"], out maxRequiredPasswordLength);

            if (!string.IsNullOrEmpty(config["numOfPreviousPasswordToCheck"]))
                Int32.TryParse(config["numOfPreviousPasswordToCheck"], out numOfPreviousPasswordToCheck);

            if (!string.IsNullOrEmpty(config["numOfRepeatedCharAllowed"]))
                Int32.TryParse(config["numOfRepeatedCharAllowed"], out numOfRepeatedCharAllowed);

            if (!string.IsNullOrEmpty(config["commandTimeout"]))
                Int32.TryParse(config["commandTimeout"], out commandTimeout);

            if (!string.IsNullOrEmpty(config["passwordCompatMode"]))
                membershipPasswordCompatibilityMode = (MembershipPasswordCompatibilityMode)Enum.Parse(typeof(MembershipPasswordCompatibilityMode), config["passwordCompatMode"]);

            connectionStringName = config["connectionStringName"];

            /* This is needed to prevent the exception to be thrown by the base class.
             * This approach is better than rewriting the whole method, since it might change in the future
            */
            config.Remove("maxRequiredPasswordLength");
            config.Remove("numOfPreviousPasswordToCheck");
            config.Remove("numOfRepeatedCharAllowed");

            return new CdpPasswordConfiguration
            {
                ApplicationName = config["applicationName"],
                MinRequiredPasswordLength = provider.MinRequiredPasswordLength,
                MaxRequiredPasswordLength = maxRequiredPasswordLength,
                NumOfPreviousPasswordToCheck = numOfPreviousPasswordToCheck,
                NumOfRepeatedCharAllowed = numOfRepeatedCharAllowed,
                CommandTimeout = commandTimeout,
                MembershipPasswordCompatibilityMode = membershipPasswordCompatibilityMode,
                ConnectionStringName = connectionStringName
            };
        }

        /// <summary>
        /// Validates a password against the CDP plan before committing it to the database
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        public static bool TryCreatePassword(
            this System.Web.Security.MembershipProvider provider,
            string username,
            string password,
            CdpPasswordConfiguration cdpPasswordConfiguration,
            out string errorMessage)
        {
            var userId = GetUserId(username);

            Guid userIdGuid;

            if (!Guid.TryParse(userId, out userIdGuid))
                throw new System.ArgumentException("User Id is not valid");

            return provider.EnsureCDPValid(
                userIdGuid,
                username,
                password,
                cdpPasswordConfiguration,
                out errorMessage);
        }

        /// <summary>
        /// Validates new password against the CDP plan before changing it
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="username"></param>
        /// <param name="newPassword"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <param name="EncryptPassword"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        public static bool TryModifyPassword(
            this System.Web.Security.MembershipProvider provider,
            string username,
            string newPassword,
            CdpPasswordConfiguration cdpPasswordConfiguration,
            Func<byte[], MembershipPasswordCompatibilityMode, byte[]> EncryptPassword,
            out string errorMessage)
        {
            var userId = GetUserId(username);

            Guid userIdGuid;

            if (!Guid.TryParse(userId, out userIdGuid))
                throw new System.ArgumentException("User Id is not valid");

            return provider.EnsureCDPValid(
                userIdGuid,
                username,
                newPassword,
                cdpPasswordConfiguration,
                out errorMessage,
                EncryptPassword: EncryptPassword);
        }

        /// <summary>
        /// Gets the ASP.Net Membership user id
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        private static string GetUserId(string username)
        {
            var membershipUser = Membership.GetUser(username);
            
            if (membershipUser == null)
            {
                throw new ArgumentException("User id cannot be null");
            }

            var providerUserKey = membershipUser.ProviderUserKey;

            if (providerUserKey == null)
            {
                throw new ArgumentException("User Provider id cannot be null");
            }

            Guid userId;
            Guid.TryParse(providerUserKey.ToString(), out userId);

            return userId.ToString();
        }
    }
}
