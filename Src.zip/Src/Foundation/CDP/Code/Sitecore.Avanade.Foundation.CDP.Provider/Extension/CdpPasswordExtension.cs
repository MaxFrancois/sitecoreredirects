﻿using Sitecore.Avanade.Foundation.CDP.Provider.Helper;
using Sitecore.Avanade.Foundation.CDP.Provider.Model;
using System;
using System.Web.Configuration;

namespace Sitecore.Avanade.Foundation.CDP.Provider.Extension
{
    public static class CdpPasswordExtension
    {
        /// <summary>
        /// Ensure that the password used satisfies the Accenture CDP Plan
        /// </summary>
        /// <param name="provider"></param>
        /// <param name="userId"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <param name="errorMessage"></param>
        /// <param name="EncryptPassword"></param>
        /// <param name="useDefaultRegex"></param>
        /// <returns></returns>
        public static bool EnsureCDPValid(
            this System.Web.Security.MembershipProvider provider,
            Guid userId,
            string username,
            string password,
            CdpPasswordConfiguration cdpPasswordConfiguration,
            out string errorMessage,
            Func<byte[], MembershipPasswordCompatibilityMode, byte[]> EncryptPassword = null,
            bool useDefaultRegex = false)
        {
            errorMessage = string.Empty;

            var isValid = false;

            isValid = MembershipProviderHelper.ValidateAgainstGeneralCDPPlan(username, password, cdpPasswordConfiguration, out errorMessage, useDefaultRegex);

            if (EncryptPassword != null)
                isValid = isValid && MembershipProviderHelper.ValidatePasswordAgainstPasswordHistory(userId, username, password, cdpPasswordConfiguration, EncryptPassword, out errorMessage);

            return isValid;
        }
    }
}
