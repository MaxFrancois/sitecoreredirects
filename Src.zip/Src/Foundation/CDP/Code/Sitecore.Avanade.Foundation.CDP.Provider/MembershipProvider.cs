﻿using Sitecore.Avanade.Foundation.CDP.Provider.Extension;
using Sitecore.Avanade.Foundation.CDP.Provider.Model;
using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;

namespace Sitecore.Avanade.Foundation.CDP.Provider
{
    /// <summary>
    /// An SqlMembershipProvider override class which extends the password policy to follow the Accenture CDP plan
    /// There are 3 additional configuration attributes introduced to this class. They are:
    ///     - maxRequiredPasswordLength
    ///     - numOfPreviousPasswordToCheck
    ///     - numOfRepeatedCharAllowed
    /// </summary>
    public class MembershipProvider : SqlMembershipProvider
    {
        private CdpPasswordConfiguration _cdpPasswordConfiguration;

        public override void Initialize(string name, NameValueCollection config)
        {
            _cdpPasswordConfiguration = this.InitConfig(config);

            if (MinRequiredPasswordLength > _cdpPasswordConfiguration.MaxRequiredPasswordLength)
                throw new HttpException("minRequiredPasswordLength cannot be more than maxRequiredPasswordLength");

            base.Initialize(name, config);
        }

        public override MembershipUser CreateUser(
            string username,
            string password,
            string email,
            string passwordQuestion,
            string passwordAnswer,
            bool isApproved,
            object providerUserKey,
            out System.Web.Security.MembershipCreateStatus status)
        {
            var passwordErrorMessage = string.Empty;

            if (!this.TryCreatePassword(username, password, _cdpPasswordConfiguration, out passwordErrorMessage))
            {
                status = MembershipCreateStatus.InvalidPassword;

                return null;
            }

            return base.CreateUser(username, password, email, passwordQuestion, passwordAnswer, isApproved, providerUserKey, out status);
        }

        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
            var passwordErrorMessage = string.Empty;

            if (!this.TryModifyPassword(username, newPassword, _cdpPasswordConfiguration, this.EncryptPassword, out passwordErrorMessage))
                /* The throw statement is there on purpose
                 * This throw statement is required so the sheer UI could display the error message without overriding Sitecore's code
                 */
                throw new ArgumentException(passwordErrorMessage);

            return base.ChangePassword(username, oldPassword, newPassword);
        }
    }
}
