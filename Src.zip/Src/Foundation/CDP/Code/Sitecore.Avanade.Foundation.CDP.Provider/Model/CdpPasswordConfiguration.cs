﻿using System.Web.Configuration;

namespace Sitecore.Avanade.Foundation.CDP.Provider.Model
{
    public class CdpPasswordConfiguration
    {
        /// <summary>
        /// Gets or sets the application name
        /// </summary>
        public string ApplicationName { get; set; }

        /// <summary>
        /// Gets or sets the password min length value
        /// </summary>
        public int MinRequiredPasswordLength { get; set; }

        /// <summary>
        /// Gets or sets the password max length value
        /// </summary>
        public int MaxRequiredPasswordLength { get; set; }

        /// <summary>
        /// Gets or sets the number of previous passwords to check the new password against
        /// </summary>
        public int NumOfPreviousPasswordToCheck { get; set; }

        /// <summary>
        /// Gets or sets the number of consecutively repeated characters allowed in a password
        /// </summary>
        public int NumOfRepeatedCharAllowed { get; set; }

        /// <summary>
        /// Gets or sets the sql command execution timeout
        /// </summary>
        public int CommandTimeout { get; set; }

        /// <summary>
        /// Gets or sets the database connection string name
        /// </summary>
        public string ConnectionStringName { get; set; }

        /// <summary>
        /// Gets or sets the MembershipPasswordCompatibilityMode
        /// </summary>
        public MembershipPasswordCompatibilityMode MembershipPasswordCompatibilityMode { get; set; }
    }
}
