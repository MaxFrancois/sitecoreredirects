﻿using Sitecore.Avanade.Foundation.CDP.Data.Infrastructure.Factory;
using Sitecore.Avanade.Foundation.CDP.Data.Service;
using Sitecore.Avanade.Foundation.CDP.Provider.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Configuration;
using System.Web.Security;

namespace Sitecore.Avanade.Foundation.CDP.Provider.Helper
{
    public enum PasswordStrength
    {
        Blank = 0,
        VeryWeak = 1,
        Weak = 2,
        Medium = 3,
        Strong = 4,
        VeryStrong = 5
    }

    public static class MembershipProviderHelper
    {
        // Pattern for at least one upper-cased letter, one lower-cased letter, one number and one non alpha-numeric character
        public const string DEFAULT_PASSWORD_REGEX_PATTERN = @"(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[^a-zA-Z])(?=.*\d)";

        /// <summary>
        /// Ensure that the new password has not been used before
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="EncryptPassword"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <returns></returns>
        public static bool EnsurePasswordHasNotRecentlyBeenUsed(
            Guid userId,
            string username,
            string password,
            Func<byte[], MembershipPasswordCompatibilityMode, byte[]> EncryptPassword,
            CdpPasswordConfiguration cdpPasswordConfiguration)
        {
            var currentPassword = string.Empty;
            var passwordFormat = 0;
            var passwordSalt = string.Empty;
            DateTime lastLoginDate;
            DateTime lastActivityDate;

            GetPasswordWithFormat(
                username, false,
                cdpPasswordConfiguration.ApplicationName,
                cdpPasswordConfiguration.ConnectionStringName,
                cdpPasswordConfiguration.CommandTimeout,
                out currentPassword,
                out passwordFormat,
                out passwordSalt,
                out lastLoginDate,
                out lastActivityDate);

            var encodedPassword = EncodePassword(
                                    password,
                                    passwordFormat,
                                    passwordSalt,
                                    cdpPasswordConfiguration.MembershipPasswordCompatibilityMode,
                                    EncryptPassword);

            // The new password cannot be the same as the current password
            if (string.Equals(encodedPassword, currentPassword, StringComparison.InvariantCulture))
                return false;

            return PasswordFoundInHistory(
                userId,
                cdpPasswordConfiguration.ConnectionStringName,
                cdpPasswordConfiguration.NumOfPreviousPasswordToCheck,
                encodedPassword);
        }

        /// <summary>
        /// Traces the PasswordHistory table and checks whether the new password has been recorded before
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="connectionStringName"></param>
        /// <param name="numOfPreviousPasswordToCheck"></param>
        /// <param name="encodedPassword"></param>
        /// <returns></returns>
        public static bool PasswordFoundInHistory(Guid userId, string connectionStringName, int numOfPreviousPasswordToCheck, string encodedPassword)
        {
            var passwordHistoryService = ServiceFactory<PasswordHistoryService>.GetService(connectionStringName);

            if (passwordHistoryService == null)
                throw new System.Data.DataException("Service instance(s) cannot be null");

            var passwordHistories = passwordHistoryService.GetPasswordHistories(userId, numOfPreviousPasswordToCheck) ?? new List<Data.Model.PasswordHistory>();

            return !passwordHistories
                    .Any(passwordHistory => string.Equals(passwordHistory.Password, encodedPassword, StringComparison.InvariantCulture));
        }

        /// <summary>
        /// Validates the new password to make sure it follows the Accenture CDP plan
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <param name="errorMessage"></param>
        /// <param name="useDefaultRegex"></param>
        /// <returns></returns>
        public static bool ValidateAgainstGeneralCDPPlan(
            string username,
            string password,
            CdpPasswordConfiguration cdpPasswordConfiguration,
            out string errorMessage,
            bool useDefaultRegex = false)
        {
            errorMessage = string.Empty;

            var validPattern = true;
            var validLength = true;
            string usernameWithoutDomain;

            if (useDefaultRegex)
                validPattern = EnsurePattern(password, DEFAULT_PASSWORD_REGEX_PATTERN);

            if (cdpPasswordConfiguration.MaxRequiredPasswordLength > 0)
                validLength = EnsureValidLength(password, cdpPasswordConfiguration.MinRequiredPasswordLength, cdpPasswordConfiguration.MaxRequiredPasswordLength);

            // Gets the value of username without the domain name
            usernameWithoutDomain = GetUsernameWithoutDomain(username);

            // The new password is not blank
            if (string.IsNullOrEmpty(password))
            {
                errorMessage = "The password cannot be empty";
                return false;
            }

            // The new password meet the length requirements
            if (!validLength)
            {
                errorMessage = "The password is too long";
                return false;
            }

            // The new password satisfies the specified pattern
            if (!validPattern)
            {
                errorMessage = "The password complexity does not meet the requirement";
                return false;
            }

            // The password should has to be a strong password. This also check the standard keyboard pattern
            if (CheckPasswordStrength(password) < PasswordStrength.Strong || !EnsureComplexKeyboardPattern(password))
            {
                errorMessage = "The password is not a strong password";
                return false;
            }

            // The new password is not the same as username nor contains the username in it
            if (string.Equals(username, password, StringComparison.OrdinalIgnoreCase) ||
                password.ToLower().Contains(usernameWithoutDomain.ToLower()))
            {
                errorMessage = "The password cannot contain the username";
                return false;
            }

            // The new password does not have one character repeated more than four times consecutively
            if (!EnsureNoCharRepeat(password, cdpPasswordConfiguration.NumOfRepeatedCharAllowed))
            {
                errorMessage = "Password cannot contain more than " + cdpPasswordConfiguration.NumOfRepeatedCharAllowed + " characters repeated consecutively";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Validates the new password against the PasswordHistory table records, to make sure that the user
        /// is not reusing his n previous password
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="cdpPasswordConfiguration"></param>
        /// <param name="EncryptPassword"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        public static bool ValidatePasswordAgainstPasswordHistory(
            Guid userId,
            string username,
            string password,
            CdpPasswordConfiguration cdpPasswordConfiguration,
            Func<byte[], MembershipPasswordCompatibilityMode, byte[]> EncryptPassword,
            out string errorMessage)
        {
            errorMessage = string.Empty;

            // The new password should not be the same as n previous passwords 
            if (!EnsurePasswordHasNotRecentlyBeenUsed(userId, username, password, EncryptPassword, cdpPasswordConfiguration))
            {
                errorMessage = "The password has previously been used";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the username without the domain prefix
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public static string GetUsernameWithoutDomain(string username)
        {
            if (!string.IsNullOrEmpty(username) && username.Contains("\\"))
            {
                var usernameStartIndex = username.LastIndexOf("\\") + 1;

                return usernameStartIndex > -1
                        ? username.Substring(usernameStartIndex, username.Length - usernameStartIndex)
                        : username;
            }

            return username;
        }

        /// <summary>
        /// Ensure that the new password length is shorter than the minimum number of characters allowed and does not exceed the maximum number of characters allowed
        /// </summary>
        /// <param name="password"></param>
        /// <param name="minLength"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static bool EnsureValidLength(string password, int minLength, int maxLength)
        {
            return password.Length >= minLength && password.Length <= maxLength;
        }

        /// <summary>
        /// Ensure that the new password follows a particular pattern
        /// </summary>
        /// <param name="password"></param>
        /// <param name="regexPattern"></param>
        /// <returns></returns>
        public static bool EnsurePattern(string password, string regexPattern)
        {
            return Regex.Match(password, regexPattern).Success;
        }

        /// <summary>
        /// Ensure that the new password does not have one character repeated more than n times consecutively
        /// </summary>
        /// <param name="password"></param>
        /// <param name="numOfRepeatedCharAllowed">Number of repeats</param>
        /// <returns></returns>
        public static bool EnsureNoCharRepeat(string password, int numOfRepeatedCharAllowed)
        {
            if (numOfRepeatedCharAllowed <= 0 || string.IsNullOrEmpty(password))
                return true;

            var repeatCount = 0;

            for (var i = 0; i < password.Length; i++)
            {
                if (repeatCount > numOfRepeatedCharAllowed)
                    return false;

                if (i > 0)
                {
                    if (password[i] == password[i - 1])
                    {
                        repeatCount++;

                        // The first time a duplicate char is identified means the repeat = 2
                        if (repeatCount == 1)
                            repeatCount++;
                    }
                    else
                        repeatCount = 0;
                }
            }

            return true;
        }

        /// <summary>
        /// Ensure that not more than half of the password characters were contructed from neigbouring characters in a standard keyboard
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static bool EnsureComplexKeyboardPattern(string password, int numOfCharInSequenceAllowed = 3)
        {
            if (string.IsNullOrEmpty(password))
                return false;

            var newPassword = password.ToLower();

            // Standard keyboard chars
            var charsInKeyboardOrder =
                new List<char> { 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p',
                                    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
                                        'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/' };

            var sequenceCount = 0;

            for (var i = 0; i < newPassword.Length; i++)
            {
                if (sequenceCount >= numOfCharInSequenceAllowed)
                    return false;

                if (i > 0)
                {
                    var currentCharIndex = charsInKeyboardOrder.IndexOf(newPassword[i]);
                    var previousCharIndex = charsInKeyboardOrder.IndexOf(newPassword[i - 1]);

                    if (currentCharIndex > -1 && previousCharIndex > -1
                        && (Math.Abs(currentCharIndex - previousCharIndex) == 1 ||
                            Math.Abs(currentCharIndex - previousCharIndex) == 9 ||
                            Math.Abs(currentCharIndex - previousCharIndex) == 10 ||
                            Math.Abs(currentCharIndex - previousCharIndex) == 11))
                    { 
                        sequenceCount++;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// Checks the password strength
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static PasswordStrength CheckPasswordStrength(string password)
        {
            int score = 1;
            if (password.Length < 1)
                return PasswordStrength.Blank;

            if (password.Length < 4)
                return PasswordStrength.VeryWeak;

            if (password.Length >= 6)
                score++;

            if (password.Length >= 12)
                score++;

            if (Regex.Match(password, @"\d+", RegexOptions.ECMAScript).Success)
                score++;

            if (Regex.Match(password, @"[a-z]", RegexOptions.ECMAScript).Success &&
                Regex.Match(password, @"[A-Z]", RegexOptions.ECMAScript).Success)
                score++;

            if (Regex.Match(password, @".[!,@,#,$,%,^,&,*,?,_,~,-,£,(,)]", RegexOptions.ECMAScript).Success)
                score++;

            return (PasswordStrength)score;
        }

        #region Internal Members of System.Web.Security.SqlMembershipProvider
        /// <summary>
        /// [Internal function from MembershipProvider]
        /// Gets the password details from the database
        /// </summary>
        /// <param name="username"></param>
        /// <param name="updateLastLoginActivityDate"></param>
        /// <param name="password"></param>
        /// <param name="passwordFormat">The format to determine the encoding method</param>
        /// <param name="passwordSalt"></param>
        /// <param name="lastLoginDate"></param>
        /// <param name="lastActivityDate"></param>
        internal static void GetPasswordWithFormat(
            string username,
            bool updateLastLoginActivityDate,
            string applicationName,
            string connectionStringName,
            int commandTimeout,
            out string password,
            out int passwordFormat,
            out string passwordSalt,
            out DateTime lastLoginDate,
            out DateTime lastActivityDate)
        {
            SqlCommand sqlCommand = new SqlCommand("dbo.aspnet_Membership_GetPasswordWithFormat");
            sqlCommand.CommandTimeout = commandTimeout;
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.Parameters.Add(SqlServerConnector.CreateInputParam("@ApplicationName", SqlDbType.NVarChar, applicationName));
            sqlCommand.Parameters.Add(SqlServerConnector.CreateInputParam("@UserName", SqlDbType.NVarChar, username));
            sqlCommand.Parameters.Add(SqlServerConnector.CreateInputParam("@UpdateLastLoginActivityDate", SqlDbType.Bit, updateLastLoginActivityDate));
            sqlCommand.Parameters.Add(SqlServerConnector.CreateInputParam("@CurrentTimeUtc", SqlDbType.DateTime, DateTime.UtcNow));

            var sqlParameter = new SqlParameter("@ReturnValue", SqlDbType.Int);
            sqlParameter.Direction = ParameterDirection.ReturnValue;

            sqlCommand.Parameters.Add(sqlParameter);

            var outPassword = string.Empty;
            var outPassFormat = 0;
            var outPassSalt = string.Empty;
            var outLastLoginDate = new DateTime();
            var outLastActivityDate = new DateTime();

            SqlServerConnector.ExecuteReader(
                sqlCommand,
                connectionStringName,
                sqlDataReader =>
                {
                    if (sqlDataReader.HasRows && sqlDataReader.Read())
                    {
                        outPassword = sqlDataReader.GetString(0);
                        outPassFormat = sqlDataReader.GetInt32(1);
                        outPassSalt = sqlDataReader.GetString(2);
                        outLastLoginDate = sqlDataReader.GetDateTime(6);
                        outLastActivityDate = sqlDataReader.GetDateTime(7);
                    }
                },
                CommandBehavior.SingleRow);

            password = outPassword;
            passwordFormat = outPassFormat;
            passwordSalt = outPassSalt;
            lastLoginDate = outLastLoginDate;
            lastActivityDate = outLastActivityDate;
        }

        /// <summary>
        /// [Internal function from MembershipProvider - Modified]
        /// Needed here so we can encrypt the password using salt
        /// </summary>
        /// <param name="pass"></param>
        /// <param name="passwordFormat"></param>
        /// <param name="salt"></param>
        /// <param name="membershipPasswordCompatibilityMode"></param>
        /// <param name="EncryptPassword"></param>
        /// <returns></returns>
        private static string EncodePassword(
            string pass,
            int passwordFormat,
            string salt,
            MembershipPasswordCompatibilityMode membershipPasswordCompatibilityMode,
            Func<byte[], MembershipPasswordCompatibilityMode, byte[]> EncryptPassword)
        {
            if (passwordFormat == 0)
            {
                return pass;
            }
            var bytes = Encoding.Unicode.GetBytes(pass);
            var array = Convert.FromBase64String(salt);

            byte[] inArray = new byte[0];
            if (passwordFormat == 1)
            {
                HashAlgorithm hashAlgorithm = GetHashAlgorithm(membershipPasswordCompatibilityMode);
                if (hashAlgorithm != null
                    && hashAlgorithm is KeyedHashAlgorithm)
                {
                    KeyedHashAlgorithm keyedHashAlgorithm = (KeyedHashAlgorithm)hashAlgorithm;
                    if (keyedHashAlgorithm.Key.Length == array.Length)
                    {
                        keyedHashAlgorithm.Key = array;
                    }
                    else if (keyedHashAlgorithm.Key.Length < array.Length)
                    {
                        byte[] array2 = new byte[keyedHashAlgorithm.Key.Length];
                        Buffer.BlockCopy(array, 0, array2, 0, array2.Length);
                        keyedHashAlgorithm.Key = array2;
                    }
                    else
                    {
                        byte[] array3 = new byte[keyedHashAlgorithm.Key.Length];
                        int num;
                        for (int i = 0; i < array3.Length; i += num)
                        {
                            num = Math.Min(array.Length, array3.Length - i);
                            Buffer.BlockCopy(array, 0, array3, i, num);
                        }
                        keyedHashAlgorithm.Key = array3;
                    }
                    inArray = keyedHashAlgorithm.ComputeHash(bytes);
                }
                else if (hashAlgorithm != null)
                {
                    byte[] array4 = new byte[array.Length + bytes.Length];
                    Buffer.BlockCopy(array, 0, array4, 0, array.Length);
                    Buffer.BlockCopy(bytes, 0, array4, array.Length, bytes.Length);
                    inArray = hashAlgorithm.ComputeHash(array4);
                }
            }
            else
            {
                byte[] array5 = new byte[array.Length + bytes.Length];
                Buffer.BlockCopy(array, 0, array5, 0, array.Length);
                Buffer.BlockCopy(bytes, 0, array5, array.Length, bytes.Length);

                inArray = EncryptPassword(array5, membershipPasswordCompatibilityMode);
            }
            return Convert.ToBase64String(inArray);
        }

        /// <summary>
        /// [Internal function from MembershipProvider - Modified]
        /// Gets the password hash algorithm
        /// </summary>
        /// <param name="membershipPasswordCompatibilityMode"></param>
        /// <returns></returns>
        private static HashAlgorithm GetHashAlgorithm(MembershipPasswordCompatibilityMode membershipPasswordCompatibilityMode)
        {
            var algorithmType = Membership.HashAlgorithmType;
            if (membershipPasswordCompatibilityMode == MembershipPasswordCompatibilityMode.Framework20 && algorithmType != "MD5")
                algorithmType = "SHA1";

            var hashAlgorithm = HashAlgorithm.Create(algorithmType);

            if (hashAlgorithm == null)
                throw new System.Security.Cryptography.CryptographicException("Invalid hash algorithm");

            return hashAlgorithm;
        }
        #endregion
    }
}
