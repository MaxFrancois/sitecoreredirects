﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Sitecore.Avanade.Foundation.CDP.Provider.Helper
{
    public static class SqlServerConnector
    {
        public static SqlParameter CreateInputParam(string paramName, SqlDbType dbType, object objValue)
        {
            var sqlParameter = new SqlParameter(paramName, dbType);
            if (objValue == null)
            {
                sqlParameter.IsNullable = true;
                sqlParameter.Value = DBNull.Value;
            }
            else
            {
                sqlParameter.Value = objValue;
            }
            return sqlParameter;
        }

        public static void ExecuteReader(
            SqlCommand sqlCommand,
            string connectionStringName,
            Action<SqlDataReader> callback,
            CommandBehavior commandBehavior = CommandBehavior.Default)
        {
            if (string.IsNullOrEmpty(connectionStringName))
            {
                throw new System.Data.DataException("Cannot connect to database");
            }

            try
            {
                var connectionString = ConfigurationManager.ConnectionStrings[connectionStringName].ToString();
                var sqlConnection = new SqlConnection(connectionString);

                sqlConnection.Open();

                sqlCommand.Connection = sqlConnection;

                var sqlDataReader = sqlCommand.ExecuteReader(commandBehavior);

                callback(sqlDataReader);

                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
        public static void ExecuteNonQuery(string command, string connectionStringName)
        {
            using (var connection = new SqlConnection(
               ConfigurationManager.ConnectionStrings[connectionStringName].ToString()))
            {
#pragma warning disable S3649 // User-provided values should be sanitized before use in SQL statements
                var sqlCommand = new SqlCommand(command, connection);
#pragma warning restore S3649 // User-provided values should be sanitized before use in SQL statements
                sqlCommand.Connection.Open();
                sqlCommand.ExecuteNonQuery();
            }
        }
    }
}
