﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sitecore.Avanade.Foundation.CDP.Data.Service;
using Sitecore.Avanade.Foundation.CDP.Data.Infrastructure.Factory;
using Sitecore.Avanade.Foundation.CDP.Data.Model;
using Moq;
using Sitecore.Avanade.Foundation.CDP.Data;
using System.Data.Entity;
using System.Collections.Generic;
using Sitecore.Avanade.Foundation.CDP.Provider.Helper;
using System.Web.Configuration;
using Sitecore.Avanade.Foundation.CDP.Provider.Model;

namespace Sitecore.Avanade.Foundation.CDP.UnitTest
{
    [TestClass]
    public class ServiceTest : BaseAIProviderService
    {
        public ServiceTest() : base("core")
        {
            _connectionStringName = "core";
        }

        [TestMethod]
        public void ServiceAndRepositoryFactoriesFunctionAsSingletons()
        {
            var firstPasswordHistoryService = ServiceFactory<PasswordHistoryService>.GetService(_connectionStringName);
            var secondPasswordHistoryService = ServiceFactory<PasswordHistoryService>.GetService(_connectionStringName);

            var firstPasswordHistoryRepository = GetRepository<PasswordHistory>();
            var secondPasswordHistoryRepository = GetRepository<PasswordHistory>();

            // Test whether the repository factory is generating the same instances
            Assert.IsNotNull(firstPasswordHistoryRepository);
            Assert.IsNotNull(secondPasswordHistoryRepository);
            Assert.AreEqual(firstPasswordHistoryRepository, secondPasswordHistoryRepository);

            // Test whether the service factory is generating the same instances
            Assert.IsNotNull(firstPasswordHistoryService);
            Assert.IsNotNull(secondPasswordHistoryService);
            Assert.AreEqual(firstPasswordHistoryService, secondPasswordHistoryService);
        }
    }

    [TestClass]
    public class CDPValidationTest
    {
        private CdpPasswordConfiguration _cdpPasswordConfiguration;

        [TestInitialize]
        public void Setup()
        {
            _cdpPasswordConfiguration = new CdpPasswordConfiguration
            {
                ApplicationName = "test",
                MaxRequiredPasswordLength = 15,
                NumOfPreviousPasswordToCheck = 24,
                NumOfRepeatedCharAllowed = 4,
                CommandTimeout = 30,
                MembershipPasswordCompatibilityMode = MembershipPasswordCompatibilityMode.Framework20,
                ConnectionStringName = "core"
            };
        }

        [TestMethod]
        public void PasswordHasValidLength()
        {
            var minLength = 8;
            var maxLength = 15;
            var validPassword = @"P@$$12345";
            var tooLongPassword = "P@$$1234589101112131415161718192021222324252627282930";
            var tooShortPassword = "a";

            // Valid password
            Assert.IsTrue(MembershipProviderHelper.EnsureValidLength(validPassword, minLength, maxLength));
            
            // Make sure that the validation fails when the password is too long
            Assert.IsFalse(MembershipProviderHelper.EnsureValidLength(tooLongPassword, minLength, maxLength));
            
            // Make sure that the validation fails when the password is too short
            Assert.IsFalse(MembershipProviderHelper.EnsureValidLength(tooShortPassword, minLength, maxLength));
        }

        [TestMethod]
        public void PasswordHasValidNumberOfCharRepeats()
        {
            var numOfRepeatedCharAllowed = 4;
            var validPassword = @"P@$$12345";
            var invalidPassword = "P@$$$$$1234";

            // Valid password
            Assert.IsTrue(MembershipProviderHelper.EnsureNoCharRepeat(validPassword, numOfRepeatedCharAllowed));

            // Make sure that the validation fails when the password repeats one char more than the numOfRepeatedCharAllowed
            Assert.IsFalse(MembershipProviderHelper.EnsureNoCharRepeat(invalidPassword, numOfRepeatedCharAllowed));
        }

        [TestMethod]
        public void PasswordDoesNotContainSimpleKeyboardPattern()
        {
            var validPassword = @"P@$$12345";
            var invalidPassword = "QWeFdSaW";

            // Valid password
            Assert.IsTrue(MembershipProviderHelper.EnsureComplexKeyboardPattern(validPassword));

            // Make sure that the validation fails when a simple keyboard pattern is used
            Assert.IsFalse(MembershipProviderHelper.EnsureComplexKeyboardPattern(invalidPassword));
        }

        [TestMethod]
        public void PasswordIsStrong()
        {
            var strongPassword = @"P@$$12345";
            var weakPassword = "abc123";

            // Strong password
            Assert.IsTrue(MembershipProviderHelper.CheckPasswordStrength(strongPassword) >= PasswordStrength.Strong);

            // Weak password
            Assert.IsFalse(MembershipProviderHelper.CheckPasswordStrength(weakPassword) >= PasswordStrength.Strong);
        }

        [TestMethod]
        public void PasswordIsValidAgainstCDPPlan()
        {
            var username = "username";
            var validPassword = @"P@$$12345";
            var invalidPassword = "password1234";
            var errorMessage = string.Empty;

            // Valid password
            Assert.IsTrue(MembershipProviderHelper.ValidateAgainstGeneralCDPPlan(username, validPassword, _cdpPasswordConfiguration, out errorMessage));

            // Make sure that the validation fails when the password is the same as the username
            Assert.IsFalse(MembershipProviderHelper.ValidateAgainstGeneralCDPPlan(username, username, _cdpPasswordConfiguration, out errorMessage));

            // Make sure that the validation fails when the password does not have enought complexity
            Assert.IsFalse(MembershipProviderHelper.ValidateAgainstGeneralCDPPlan(username, invalidPassword, _cdpPasswordConfiguration, out errorMessage));
        }
    }
}
