﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sitecore.Avanade.Foundation.CDP.UnitTest
{
    [TestClass]
    public class SitecoreTest
    {
    }
}
