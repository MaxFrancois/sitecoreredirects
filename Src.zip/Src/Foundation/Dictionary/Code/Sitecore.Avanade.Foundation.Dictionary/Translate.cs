﻿using Sitecore.Avanade.Foundation.Dictionary.Models;
using Sitecore.Avanade.Foundation.Site.Extensions;
using Sitecore.Data.Items;
using System.Linq;
using System.Web.Mvc;
using Sitecore.ContentSearch;
using Sitecore.Avanade.Foundation.Extensions;
using System.Web.Mvc.Html;

namespace Sitecore.Avanade.Foundation.Dictionary
{
    public static class Translate
    {
        #region GlobalDictionaryRoot
        /// <summary>
        /// Get the Global Dictionary Root Item
        /// </summary>
        /// <returns></returns>
        public static Item GlobalDictionaryRoot()
        {
            if (!Settings.IsEnabled
                && Settings.Global.GlobalIsEnabled
                && !string.IsNullOrEmpty(Settings.Global.GlobalPath))
            {
                return null;
            }

            // has this been fetched already
            var globalSettingsItem = Cache.Cache.Get<Item>(Constants.Dictionary.Caches.GlobalSettingsItemCacheKey);

            if (globalSettingsItem == null)
            {
                // get the avatar cache item
                globalSettingsItem = Sitecore.Context.Database.GetItem(Settings.Global.GlobalPath);

                // add to the cache so we do not have to fetch again
                Cache.Cache.Add(Constants.Dictionary.Caches.GlobalSettingsItemCacheKey, globalSettingsItem);
            }

            return globalSettingsItem;
        }
        #endregion

        #region SiteDictionaryRoot
        /// <summary>
        /// Get the Site Dictionary Root Item
        /// </summary>
        /// <returns></returns>
        public static Item SiteDictionaryRoot()
        {
            if (!Settings.IsEnabled)
            {
                return null;
            }

            // get the site name
            var site = Sitecore.Context.Site.GetValidSiteContext();

            // default
            Item rootSettingsItem = null;

            // get the site
            if (site != null)
            {
                // make sure we set the key once
                string siteKey = $"{Constants.Dictionary.Caches.RootSettingsItemCacheKey}-{site.Name}";

                // has this been fetched already
                rootSettingsItem = Cache.Cache.Get<Item>(siteKey);

                // have we got a cached instance
                if (rootSettingsItem == null)
                {
                    // get the avatar cache item
                    rootSettingsItem = Sitecore.Context.Site.GetValidSiteContext().GetSettings(xPath: $"./*[@@templateid='{Constants.Dictionary.RootTemplateID}']");

                    // add to the cache so we do not have to fetch again
                    Cache.Cache.Add(siteKey, rootSettingsItem);
                }
            }

            return rootSettingsItem;

        }
        #endregion

        #region DictionaryItem
        /// <summary>
        /// Gets the Dictionary Item from the site root or the global location
        /// NOTE: This is not cached, if you need to get a cached instance use the DictionaryModel
        /// </summary>
        /// <param name="key">The unique key</param>
        /// <param name="prefix">The prefix to logically lock down areas that could be duplicates</param>
        /// <returns>Only returns the first found item</returns>
        public static Item DictionaryItem(string key, string prefix = "")
        {
            if (!Settings.IsEnabled)
            {
                return null;
            }

            // set default item to use
            Item dictionaryItem = null;

            // get teh site item
            Item root = SiteDictionaryRoot();

            // create the unique key only for the cache key
            string uniqueKey = prefix.IsNullOrEmpty() ? key : $"{prefix}:{key}";

            // do we have a site
            if (root != null)
            {
                
                // engadge the search manager
                using (var searchContext = Sitecore.ContentSearch.ContentSearchManager.CreateSearchContext(new SitecoreIndexableItem(root)))
                {
                    // search for the query we want
                    var searchResults = searchContext.GetQueryable<Models.DictionarySearchResultItem>().Where(i =>
                        i.Paths.Contains(root.ID)
                        && i.TemplateId != Data.ID.Parse(Constants.Templates.DictionaryContainer.TemplateID)
                        && i.Key == uniqueKey
                        );

                    // do we have any search results
                    if (searchResults != null
                        && searchResults.Count() > 0)
                    {
                        // get the first item
                        dictionaryItem = searchResults.FirstOrDefault()?.GetItem();
                    }
                }
            }

            // have we been able to find an item
            if (dictionaryItem == null)
            {
                // get the global item
                Item global = GlobalDictionaryRoot();

                // double check
                if (global != null)
                {
                    // engadge the search manager
                    using (var searchContext = Sitecore.ContentSearch.ContentSearchManager.CreateSearchContext(new SitecoreIndexableItem(root)))
                    {
                        // search for the query we want
                        var searchResults = searchContext.GetQueryable<Models.DictionarySearchResultItem>().Where(i =>
                            i.Paths.Contains(global.ID)
                            && i.TemplateId != Data.ID.Parse(Constants.Templates.DictionaryContainer.TemplateID)
                            && i.Key == uniqueKey
                            );

                        // do we have any search results
                        if (searchResults != null
                            && searchResults.Count() > 0)
                        {
                            // get the first item
                            dictionaryItem = searchResults.FirstOrDefault()?.GetItem();
                        }
                    }
                }
            }

            return dictionaryItem;
        }
        #endregion

        #region DictionaryModel
        /// <summary>
        /// Gets the Dictionary model of from the key, this does not do any conversions it is up to you
        /// </summary>
        /// <param name="key">The unique key to find</param>
        /// <param name="prefix">The prefix to logically lock down areas that could be duplicates</param>
        /// <returns></returns>
        public static DictionaryModel DictionaryModel(string key, string prefix = "")
        {
            if(!Settings.IsEnabled)
            {
                return null;
            }

            // create the unique key only for the cache key
            string uniqueKey = prefix.IsNullOrEmpty() ? key : $"{prefix}:{key}";

            // get the cache key
            string cacheKey = $"{Constants.Dictionary.Caches.DictionaryModelCacheKey}-{uniqueKey}";

            // has this been fetched already
            DictionaryModel dic = Cache.Cache.Get<DictionaryModel>(cacheKey);

            if (dic == null)
            {
                var dicItm = DictionaryItem(key, prefix);

                // make sure we have a dictionary item
                if (dicItm != null)
                {
                    // get the avatar cache item
                    dic = new Models.DictionaryModel { Item = dicItm, Field = dicItm.TemplateName.Replace("Dictionary", "") };

                    // add to the cache so we do not have to fetch again
                    Cache.Cache.Add(cacheKey, dic);
                }
            }

            // error
            return dic;
        }
        #endregion

        #region DictionaryRender
        /// <summary>
        /// Renders the Dictionary Item
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="html"></param>
        /// <param name="key">The unique key to display</param>
        /// <param name="prefix">The prefix to logically lock down areas that could be duplicates</param>
        /// <param name="partialViewName">Override the partial view default uses the setting: 'AI.Foundation.Dictionary.DefaultView'</param>
        /// <returns>Returns the partial view of the dictionary or empty string</returns>
        public static MvcHtmlString DictionaryRender(this HtmlHelper html, string key, string prefix = "", string partialViewName = "")
        {
            // default just in case
            MvcHtmlString output = null;

            // get the key
            DictionaryModel dic = null;

            // make sure we have data
            if (Settings.IsEnabled)
            {
                dic = DictionaryModel(key, prefix);
            }

            // do we have a key
            if (dic == null)
            {
                // we now have to go to the dictionary to find
                output = new MvcHtmlString(Sitecore.Globalization.Translate.Text(prefix.IsNullOrEmpty() ? key : $"{prefix}:{key}"));
            }
            else
            {
                if (partialViewName.IsNullOrEmpty())
                {
                    partialViewName = Settings.DefaultView;
                }

                output = html.Partial(partialViewName, dic);
            }

            // make sure it is always a valid output
            if (output == null)
            {
                output = MvcHtmlString.Empty;
            }

            return output;
        }
        #endregion

        #region Text
        /// <summary>
        /// Gets the Translated text from either the AI Dictionary or Sitecore Dictionary
        /// </summary>
        /// <param name="key">The unique key</param>
        /// <param name="prefix">The prefix to logically lock down areas that could be duplicates</param>
        /// <returns>Returns pure text of the Sitecore AI Dictionary or Sitecore Dictionary</returns>
        /// <example>If using a prefix the sitecore item key would look like this: "prefix:key"</example>
        public static string Text(string key, string prefix = "")
        {
            // get the key
            DictionaryModel dic = null;
            string outputData = string.Empty;

            // make sure we have data
            if (Settings.IsEnabled)
            {
                dic = DictionaryModel(key, prefix);
            }

            if(dic == null)
            {
                // call the Sitecore Dictionary method
                outputData = Sitecore.Globalization.Translate.Text(prefix.IsNullOrEmpty() ? key : $"{prefix}:{key}");
            }
            else
            {
                outputData = dic.Item.Fields[dic.Field].ValueSafe();
            }

            return outputData;
        }
        #endregion
    }
}