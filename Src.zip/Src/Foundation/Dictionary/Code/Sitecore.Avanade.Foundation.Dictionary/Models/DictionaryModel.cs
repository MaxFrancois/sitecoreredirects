﻿using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Dictionary.Models
{
    /// <summary>
    /// The Dictionary model
    /// </summary>
    public class DictionaryModel
    {
        /// <summary>
        /// The Dictionary Item
        /// </summary>
        public Item Item { get; set; }

        /// <summary>
        /// The Dictionary Field
        /// </summary>
        public string Field { get; set; }
    }
}