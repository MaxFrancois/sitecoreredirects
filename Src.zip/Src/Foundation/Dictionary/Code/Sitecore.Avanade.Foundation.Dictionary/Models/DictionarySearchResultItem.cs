﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;

namespace Sitecore.Avanade.Foundation.Dictionary.Models
{
    public class DictionarySearchResultItem : SearchResultItem
    {
        /// <summary>
        /// The Requested URL
        /// </summary>
        [IndexField(Constants.Templates.DictionaryTemplate.Fields.Key)]
        public string Key { get; set; }
    }
}