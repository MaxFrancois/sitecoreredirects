﻿namespace Sitecore.Avanade.Foundation.Dictionary
{
    public static class Constants
    {
        public static class Dictionary
        {
            public const string RootTemplateID = "{02E33A7C-F86E-4169-A137-D4B275C047BE}";
            public static class Caches
            {
                public const string RootSettingsItemCacheKey = "root-dictionary";
                public const string GlobalSettingsItemCacheKey = "global-dictionary";
                public const string DictionaryModelCacheKey = "dictionaryItem";
            }
        }

        public static class Templates
        {
            public static class DictionaryContainer
            {
                public const string TemplateID = "{AD7FAA4F-55F5-4542-8E0A-A88523B2B30C}";
            }

            public static class DictionaryTemplate
            {
                public static class Fields
                {
                    public const string Key = "key";
                }
            }
        }
    }
}