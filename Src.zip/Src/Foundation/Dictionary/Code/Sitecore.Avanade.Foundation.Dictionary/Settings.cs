﻿namespace Sitecore.Avanade.Foundation.Dictionary
{
    public static class Settings
    {
        #region Private Variables
       
        private static bool? _isEnabled;

        private static bool? _sitecoreDictionaryEnabled;

        private static string _defaultView;
        #endregion

        #region Public Properties
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Dictionary.Enabled", false);

                return _isEnabled.Value;

            }
        }

        public static bool SitecoreDictionaryEnabled
        {
            get
            {
                _sitecoreDictionaryEnabled = _sitecoreDictionaryEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Dictionary.SitecoreDictionaryEnabled", false);

                return _sitecoreDictionaryEnabled.Value;

            }
        }

        public static string DefaultView
        {
            get
            {
                if (string.IsNullOrEmpty(_defaultView))
                {
                    _defaultView = Configuration.Settings.GetSetting("AI.Foundation.Dictionary.DefaultView", string.Empty);
                }

                return _defaultView;
            }
        }
        
        #endregion

        public static class Global
        {
            #region Private Variables
            private static bool? _globalIsEnabled;

            private static string _globalPath;
            #endregion

            #region Public Properties
            public static bool GlobalIsEnabled
            {
                get
                {
                    _globalIsEnabled = _globalIsEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Dictionary.Global.Enabled", false);

                    return _globalIsEnabled.Value;

                }
            }

            public static string GlobalPath
            {
                get
                {
                    if (string.IsNullOrEmpty(_globalPath))
                    {
                        _globalPath = Configuration.Settings.GetSetting("AI.Foundation.Dictionary.Global.Path", string.Empty);
                    }

                    return _globalPath;
                }
            }
            
            #endregion
        }
    }
    
}
