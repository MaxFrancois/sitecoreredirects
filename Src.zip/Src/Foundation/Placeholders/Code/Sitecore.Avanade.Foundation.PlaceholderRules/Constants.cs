﻿namespace Sitecore.Avanade.Foundation.PlaceholderRules
{
    public static class Constants
    {
        public static class PlaceholderSettingsRuleItem
        {
            public const string PlaceholderSettingsRuleTemplateId = "{4C6E07FA-FCD2-4C79-9D1F-C21D776C8D5A}";
        }

        public static class Caches
        {
            public const string PlaceholderSettingsRuleCache = "placeholder-settings-rules";
        }
    }
}
