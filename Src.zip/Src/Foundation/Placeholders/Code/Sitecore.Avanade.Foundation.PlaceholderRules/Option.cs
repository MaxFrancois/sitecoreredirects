﻿using System.ComponentModel;

namespace Sitecore.Avanade.Foundation.PlaceholderRules
{
    public enum Option
    {
        [Description("{7A167EF1-DBCC-4607-9182-99C644FA14A9}")]
        Allow,
        [Description("{699F97FF-BEB3-468D-B973-4D1FD5151356}")]
        DoNotAllow
    }
}