﻿using Sitecore.Rules;
using System.Collections.Generic;
using Sitecore.Data;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.PlaceholderRules
{
    public class PlaceholderSettingsRuleContext : RuleContext
    {
        /// <summary>
        /// What renderings have we allowed
        /// </summary>
        public List<Item> AllowedRenderingItems { get; set; }

        /// <summary>
        /// What is the device id
        /// </summary>
        public ID DeviceId { get; set; }

        /// <summary>
        /// What content database are we working with
        /// </summary>
        public Database ContentDatabase { get; set; }

        /// <summary>
        /// What is the layout definition
        /// </summary>
        public string LayoutDefinition { get; set; }

        /// <summary>
        /// Are we displaying the selection tree
        /// </summary>
        public bool? DisplaySelectionTree { get; set; }

        /// <summary>
        /// The placeholder key we leverage to help with placeholders
        /// </summary>
        public DynamicPlaceholder.Model.PlaceholderKey Placeholder { get; set; }
    }
}