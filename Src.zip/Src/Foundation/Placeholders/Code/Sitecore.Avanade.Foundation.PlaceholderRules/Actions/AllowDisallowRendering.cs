﻿using System.Collections.Generic;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;

using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Rules.Actions;

namespace Sitecore.Avanade.Foundation.PlaceholderRules.Actions
{
    /// <summary>
    /// Custom Sitecore rules engine action that allows or disallows a specific rendering from being added to a placeholder.
    /// </summary>
    public class AllowDisallowRendering<T> : RuleAction<T> where T : PlaceholderSettingsRuleContext
    {
        /// <summary>
        /// Setup default not allowed option
        /// </summary>
        private Option Option = Option.DoNotAllow;

        /// <summary>
        /// The option id
        /// </summary>
        public string OptionId
        {
            get
            {
                return Option.Description();
            }
            set
            {
                if (new ID(value).EqualsTo(Option.Allow.Description()))
                {
                    Option = Option.Allow;
                }
                else
                {
                    Option = Option.DoNotAllow;
                }
                    
            }
        }

        public string RenderingId { get; set; }

        public override void Apply(T ruleContext)
        {
            // Convert the RenderingId string to a Sitecore ID.
            ID renderingId = new ID(RenderingId);

            // Create a new list if one hasn't been created yet.
            if (ruleContext.AllowedRenderingItems == null)
                ruleContext.AllowedRenderingItems = new List<Item>();

            // If the option is set to "allow"...
            if (Option == Option.Allow) 
            {
                // If the specified rendering is already allowed, do nothing.
                if (ruleContext.AllowedRenderingItems.Any(i => i.ID == renderingId)) return;

                // Otherwise, add the rendering to the context.
                ruleContext.AllowedRenderingItems.Add(ruleContext.ContentDatabase.GetItem(renderingId));
            }
            else
            {
                // If the specified rendering already isn't in the context, do nothing.
                Item item = ruleContext.AllowedRenderingItems.FirstOrDefault(i => i.ID == renderingId);
                if (item == null) return;

                // Otherwise, remove the rendering from the context.
                ruleContext.AllowedRenderingItems.Remove(item);
            }
        }
    }
}