﻿using Sitecore.Rules.Actions;

namespace Sitecore.Avanade.Foundation.PlaceholderRules.Actions
{
    /// <summary>
    /// Custom Sitecore rules engine action that allows or disallows a specific rendering from being added to a placeholder.
    /// </summary>
    public class DisallowAllRenderings<T> : RuleAction<T> where T : PlaceholderSettingsRuleContext
    {
        /// <summary>
        /// Apply all 
        /// </summary>
        /// <param name="ruleContext"></param>
        public override void Apply(T ruleContext)
        {
            // Do not allow any renderings at all.
            ruleContext.DisplaySelectionTree = false;
            ruleContext.AllowedRenderingItems.RemoveAll(i => true);
        }
    }
}