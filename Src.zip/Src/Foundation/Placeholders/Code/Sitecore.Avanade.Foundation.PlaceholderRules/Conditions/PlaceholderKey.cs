﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.PlaceholderRules.Conditions
{
    /// <summary>
    /// Condition to determine placeholder key is valid
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PlaceholderKey<T> : WhenCondition<T> where T : PlaceholderSettingsRuleContext
    {
        /// <summary>
        /// The placeholder template
        /// </summary>
        public string PlaceholderKeyName { get; set; }

        /// <summary>
        /// Executes to make sure the placeholder is the same
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valie
            if (ruleContext != null
                && ruleContext.Placeholder != null
                && !ruleContext.Placeholder.PlaceholderName.IsNullOrEmpty()
                && !PlaceholderKeyName.IsNullOrEmpty())
            {
                // get the cache key making sure to cache
                string placeholderKey = Cache.Cache.Get<string>($"Placeholder-{PlaceholderKeyName}", () =>
                {
                    // get the placeholder item
                    var placeholderItem = ruleContext.ContentDatabase.GetItem(PlaceholderKeyName);

                    // make sure we have the item
                    if (placeholderItem != null)
                    {
                        // get the key
                        return placeholderItem.Fields["Placeholder Key"].ValueSafe();
                    }

                    // not found
                    return string.Empty;
                });

                // get the data
                if (!placeholderKey.IsNullOrEmpty())
                {
                    // compare the values
                    return ruleContext.Placeholder.PlaceholderName.Equals(placeholderKey, System.StringComparison.OrdinalIgnoreCase);
                }
            }

            return false;
        }

    }
}