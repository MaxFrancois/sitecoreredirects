﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.PlaceholderRules.Conditions
{
    /// <summary>
    /// Condition to determine placeholder key is valid
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PlaceholderPath<T> : StringOperatorCondition<T> where T : PlaceholderSettingsRuleContext
    {
        /// <summary>
        /// The placeholder string to look for
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// Executes to make sure the placeholder is the same
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valie
            if (ruleContext != null
                && ruleContext.Placeholder != null
                && !ruleContext.Placeholder.PlaceholderPath.IsNullOrEmpty()
                && !Value.IsNullOrEmpty())
            {
                // compare the values
                return base.Compare(ruleContext.Placeholder.PlaceholderPath, Value);
            }

            return false;
        }

    }
}