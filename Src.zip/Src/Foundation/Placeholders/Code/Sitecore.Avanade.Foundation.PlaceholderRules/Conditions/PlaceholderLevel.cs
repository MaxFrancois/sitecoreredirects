﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;
using System.Linq;

namespace Sitecore.Avanade.Foundation.PlaceholderRules.Conditions
{
    /// <summary>
    /// Condition to check the level depths
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PlaceholderLevel<T> : IntegerComparisonCondition<T> where T : PlaceholderSettingsRuleContext
    {
        /// <summary>
        /// Executes to make sure the placehold depth is correct
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            if (ruleContext != null
                && ruleContext.Placeholder != null
                && !ruleContext.Placeholder.PlaceholderPath.IsNullOrEmpty()
                && Value > 0)
            {
                // compare the values
                return base.Compare(ruleContext.Placeholder.PlaceholderPath.SplitString('/').Count());
            }

            return false;
        }

    }
}