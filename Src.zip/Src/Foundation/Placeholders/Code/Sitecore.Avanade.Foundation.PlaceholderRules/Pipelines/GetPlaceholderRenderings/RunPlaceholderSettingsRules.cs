﻿using System.Collections.Generic;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.GetMasters;
using Sitecore.Rules;
using Sitecore.SecurityModel;
using Sitecore.Pipelines.GetPlaceholderRenderings;
using Sitecore.Avanade.Foundation.Extensions;
using System.Linq;


namespace Sitecore.Avanade.Foundation.PlaceholderRules.Pipelines.GetPlaceholderRenderings
{
    /// <summary>
    /// Runs the Sitecore Rules engine over the placeholder settings
    /// </summary>
    public class RunPlaceholderSettingsRules
    {
        /// <summary>
        /// Data populated by Sitecore Configuration
        /// </summary>
        public List<string> Folders { get; set; }

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public RunPlaceholderSettingsRules()
        {
            // make sure we setup initalize just in case
            Folders = new List<string>();
        }
        #endregion

        public void Process(GetPlaceholderRenderingsArgs args)
        {
            Assert.ArgumentNotNull(args, nameof(args));

            // we have the database
            var database = args.ContentDatabase;

            // is it valid
            if (database != null)
            {
                // set our placeholder list
                List<Item> placeholderSettingsRules = Cache.Cache.Get<List<Item>>(Constants.Caches.PlaceholderSettingsRuleCache, () =>
                {
                    // the data we will return
                    var list = new List<Item>();

                    // make sure we disable security for this
                    using (new SecurityDisabler())
                    {
                        // cycle over the rules
                        Folders.ForEach(x =>
                        {
                            // get the item
                            var itm = database.GetItem(x);

                            // make sure it is valid
                            if (itm != null)
                            {
                                // fetch all InsertRuleItems no matter the depth
                                var itms = itm.Axes.SelectItems($".//*[@@templateid='{Constants.PlaceholderSettingsRuleItem.PlaceholderSettingsRuleTemplateId}']");

                                // ensure we have data
                                if (itms != null && itms.Length > 0)
                                {
                                    // increase our list
                                    list.AddRange(itms);
                                }
                            }
                        });
                    }

                    return list;
                }, System.DateTime.Now.AddMinutes(2));

                // make sure we have data
                if (placeholderSettingsRules != null && placeholderSettingsRules.Count > 0)
                {
                    // initilise the rules
                    var rules = RuleFactory.GetRules<PlaceholderSettingsRuleContext>(placeholderSettingsRules, "Rule");

                    // we have an issue so stop
                    if (rules != null)
                    {
                        // make sure w e correctly setup our placeholder settings context of the current item
                        var ruleContext = new PlaceholderSettingsRuleContext
                        {
                            AllowedRenderingItems = args.PlaceholderRenderings,
                            ContentDatabase = args.ContentDatabase,
                            DeviceId = args.DeviceId,
                            LayoutDefinition = args.LayoutDefinition,
                            Placeholder = DynamicPlaceholder.Helpers.Placeholders.GetPlaceholderKey(args.PlaceholderKey)
                        };

                        // run the rules
                        rules.Run(ruleContext);

                        // did the rules run
                        if (ruleContext?.AllowedRenderingItems != null
                            && ruleContext.AllowedRenderingItems.Any())
                        {
                            // override, we sent the list and it may have been removed
                            args.PlaceholderRenderings = ruleContext.AllowedRenderingItems;
                            args.Options.ShowTree = false;
                        }
                    }
                }
            }

            // issue
            return;
        }
    }
}