﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.GetPlaceholderRenderings;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Pipelines.GetPlaceholderRenderings
{
    /// <summary>
    /// Handles changing context to the references dynamic "master" renderings settings for inserting the allowed controls for the placeholder and making it editable
    /// 
    /// In case you are interested in what we changed, we removed the following line:
    ///     args.CustomData["allowedControlsSpecified"] = true;
    /// This line was just above:
    ///     args.Options.ShowTree = false;
    /// </summary>
    public class GetDynamicKeyAllowedRenderings : GetAllowedRenderings
    {
        private Item GetPlaceHolderItem(GetPlaceholderRenderingsArgs args)
        {
            // default
            Item placeholderItem = null;

            // get the placeholder key
            var placeholderKey = Helpers.Placeholders.GetPlaceholderKey(args.PlaceholderKey);

            // make sure we have a key
            if (placeholderKey != null
                && !placeholderKey.PlaceholderName.IsNullOrEmpty())
            {
                // do we have a device set
                if (ID.IsNullOrEmpty(args.DeviceId))
                {
                    // Same as Sitecore.Pipelines.GetPlaceholderRenderings.GetAllowedRenderings but with fake placeholderKey
                    placeholderItem = Client.Page.GetPlaceholderItem(placeholderKey.PlaceholderName,
                        args.ContentDatabase,
                        args.LayoutDefinition);
                }
                else
                {
                    // do we have the right device
                    using (new DeviceSwitcher(args.DeviceId, args.ContentDatabase))
                    {
                        // Same as Sitecore.Pipelines.GetPlaceholderRenderings.GetAllowedRenderings but with fake placeholderKey
                        placeholderItem = Client.Page.GetPlaceholderItem(placeholderKey.PlaceholderName,
                            args.ContentDatabase,
                            args.LayoutDefinition);
                    }
                }
            }

            return placeholderItem;
        }


        public new void Process(GetPlaceholderRenderingsArgs args)
        {
            Assert.IsNotNull(args, "args");

            // get the placeholder item
            Item placeholderItem = GetPlaceHolderItem(args);
            
            // make sure we have a placeholder item before doing any extra processing
            if (placeholderItem != null)
            {
                // setup default
                List<Item> collection = null;

                // output flag
                bool flag;

                // set that we have settings
                args.HasPlaceholderSettings = true;

                // get the collection
                collection = GetRenderings(placeholderItem, out flag);

                // do we have to show the content tree
                args.Options.ShowTree = !flag;

                // have we got data
                if (collection != null)
                {
                    // have we got renderings
                    if (args.PlaceholderRenderings == null)
                    {
                        args.PlaceholderRenderings = new List<Item>();
                    }

                    // set the renderings
                    args.PlaceholderRenderings.AddRange(collection);
                }
            }
        }
    }
}