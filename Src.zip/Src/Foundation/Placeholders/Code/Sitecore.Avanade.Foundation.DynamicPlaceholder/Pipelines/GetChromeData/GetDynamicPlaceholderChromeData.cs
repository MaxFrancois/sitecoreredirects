﻿using Sitecore.Data.Items;
using Sitecore.Pipelines.GetChromeData;
using Sitecore.Web.UI.PageModes;
using System;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Pipelines.GetChromeData
{
    /// <summary>
    /// Replaces the Displayname of the Placeholder rendering with the dynamic "parent"
    /// </summary>
    public class GetDynamicPlaceholderChromeData : GetChromeDataProcessor
    {
        /// <summary>
        /// Get the placeholder details
        /// </summary>
        /// <param name="args"></param>
        public override void Process(GetChromeDataArgs args)
        {
            // we have to make sure the data is valid processing the right type
            if (args?.ChromeData != null
                && !args.ChromeType.IsNullOrEmpty()
                && args.ChromeType.Equals("placeholder", StringComparison.OrdinalIgnoreCase)
                && args.Item != null
                && args.CustomData != null
                && args.CustomData.ContainsKey("placeHolderKey"))
            {
                // get out the placeholder key
                var placeholderKey = Helpers.Placeholders.GetPlaceholderKey(args.CustomData["placeHolderKey"] as string);

                // get the layout defintion
                string layout = ChromeContext.GetLayout(args.Item);

                // have we got any matches
                if (placeholderKey != null
                    && !placeholderKey.PlaceholderName.IsNullOrEmpty()
                    && !layout.IsNullOrEmpty())
                {
                    // get the placeholder item
                    Item item = Client.Page.GetPlaceholderItem(placeholderKey.PlaceholderName, args.Item.Database, layout);

                    // make sure we have data
                    if (item != null)
                    {
                        // set the display name
                        args.ChromeData.DisplayName = item.DisplayName;

                        // have we set a short description
                        if (!item.Appearance.ShortDescription.IsNullOrEmpty())
                        {
                            args.ChromeData.ExpandedDisplayName = item.Appearance.ShortDescription;
                        }
                    }
                }
                
            }
        }
    }
}