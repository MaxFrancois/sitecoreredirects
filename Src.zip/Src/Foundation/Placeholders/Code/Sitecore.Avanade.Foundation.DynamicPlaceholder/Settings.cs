﻿using System;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder
{
    public static class Settings
    {
        #region Private Variables
        /// <summary>
        /// Are the site contexts enabled
        /// </summary>
        private static bool? _isEnabled;
        #endregion

        #region Public Properties
        /// <summary>
        /// Are the Dynamic Placeholders enabled
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.DynamicPlaceholder.Enabled", false);
                

                return _isEnabled.Value;
            }
        }
        
        #endregion

        public static class Formatter
        {

            /// <summary>
            /// The settings path
            /// </summary>
            private static string _pattern = string.Empty;
            private static string _guid = string.Empty;
            private static string _regex = string.Empty;

            /// <summary>
            /// The pattern which will be used
            /// </summary>
            public static string Pattern
            {
                get
                {
                    if (String.IsNullOrEmpty(_pattern))
                    {
                        _pattern = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.DynamicPlaceholder.Formatter.Pattern", "{0}_{1}_{2}");
                    }


                    return _pattern;
                }
            }

            /// <summary>
            /// The format of the guid
            /// </summary>
            public static string Guid
            {
                get
                {
                    if (String.IsNullOrEmpty(_guid))
                    {
                        _guid = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.DynamicPlaceholder.Formatter.Guid", "b");
                    }


                    return _guid;
                }
            }

            /// <summary>
            /// The Regular expression
            /// </summary>
            public static string Regex
            {
                get
                {
                    if (String.IsNullOrEmpty(_regex))
                    {
                        _regex = System.Web.HttpUtility.HtmlDecode(Sitecore.Configuration.Settings.GetSetting("AI.Foundation.DynamicPlaceholder.Formatter.Regex", "%5E(.%2B)%5B_%7C-%5D(%5B%7B(%5D%3F%5B0-9A-Fa-f%5D%7B8%7D%5B-%5D%3F(%3F%3A%5B0-9A-Fa-f%5D%7B4%7D%5B-%5D%3F)%7B3%7D%5B0-9A-Fa-f%5D%7B12%7D%5B)%7D%5D%3F)%5B_%7C-%5D%3F(.*)"));
                    }


                    return _regex;
                }
                
            }
            
        }
    }
}