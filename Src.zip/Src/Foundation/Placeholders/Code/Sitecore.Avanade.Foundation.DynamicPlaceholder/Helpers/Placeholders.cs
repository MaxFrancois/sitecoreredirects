﻿using Sitecore.Avanade.Foundation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Helpers
{
    public static class Placeholders
    {
        /// <summary>
        /// Set the Regex to pull apart the placeholder key, guid and incremental number
        /// </summary>
        private static readonly Regex Regex = new Regex(Settings.Formatter.Regex, RegexOptions.Compiled);

        /// <summary>
        /// Pull apart the Placeholder Key to identify all values
        /// </summary>
        /// <param name="dynamicKey"></param>
        /// <returns></returns>
        public static Model.PlaceholderKey GetPlaceholderKey(string dynamicKey)
        {
            // we want to cache the processing so we don't have to do it again in a short period
            return Cache.Cache.Get<Model.PlaceholderKey>($"placeholderkeys-{dynamicKey}", () =>
            {
                // create the placeholder object
                var placeholder = new Model.PlaceholderKey()
                {
                    PlaceholderPath = dynamicKey,
                    PlaceholderFullName = dynamicKey.SplitString('/').LastOrDefault()
                };

                // cycle over the regex with the supplie dkey
                Match match = Regex.Match(placeholder.PlaceholderFullName);

                // have we got any matches
                if (match.Success && match.Groups.Count > 0)
                {
                    // this is a dynamic placeholder get the placeholder
                    placeholder.PlaceholderName = match.Groups[1].Value;
                    placeholder.Guid = match.Groups[2].Value;
                    placeholder.IsDynamicPlaceholder = true;

                    // we have to make sure we have the incremental valueCac
                    if (match.Groups.Count >= 3)
                    {
                        // set the incremental value
                        placeholder.Incremental = System.Convert.ToInt32(match.Groups[3].Value);
                    }
                }
                else
                {
                    // not a dynamic placeholder
                    placeholder.PlaceholderName = placeholder.PlaceholderFullName;
                }

                return placeholder;
            }, System.DateTime.Now.AddMinutes(5));
        }
    }
}