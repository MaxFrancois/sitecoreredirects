﻿using Sitecore.Mvc.Presentation;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Model
{
    public class DynamicPlaceholderRenderContext
    {
        private PlaceholderParameters parameters;

        public int Index
        {
            get;
            set;
        }

        public string Key
        {
            get;
            set;
        }

        public string DynamicKey
        {
            get;
            set;
        }

        public Rendering Rendering
        {
            get;
            set;
        }

        public int PlaceholdersCount
        {
            get;
            set;
        }

        public PlaceholderParameters Parameters
        {
            get
            {
                if (this.parameters != null)
                {
                    return this.parameters;
                }
                this.parameters = new PlaceholderParameters(this.CommonParameters ?? new Dictionary<string, string>());
                if (this.SpecificParameters != null)
                {
                    foreach (KeyValuePair<string, string> current in this.SpecificParameters)
                    {
                        this.parameters[current.Key] = current.Value;
                    }
                }
                return this.parameters;
            }
        }

        internal Dictionary<string, string> CommonParameters
        {
            get;
            set;
        }

        internal Dictionary<string, string> SpecificParameters
        {
            get;
            set;
        }

        internal DynamicPlaceholderRenderContext()
        {
        }
    }
}
