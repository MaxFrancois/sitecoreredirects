﻿using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Model
{
    public class DynamicPlaceholderDefinition
    {
        private int count = 1;

        private int maxCount;

        private string placeholderKey;

        private int seed;

        public string PlaceholderKey
        {
            get
            {
                return this.placeholderKey;
            }
            set
            {
                Assert.ArgumentNotNullOrEmpty(value, "value");
                this.placeholderKey = value;
            }
        }

        public int Count
        {
            get
            {
                return this.count;
            }
            set
            {
                Assert.ArgumentCondition(value >= 0, "value", "'Count' must be greater or equal to zero.");
                this.count = value;
            }
        }

        public int MaxCount
        {
            get
            {
                return this.maxCount;
            }
            set
            {
                Assert.ArgumentCondition(value >= 0, "value", "'MaxCount' must be greater or equal to zero.");
                this.maxCount = value;
            }
        }

        public int Seed
        {
            get
            {
                return this.seed;
            }
            set
            {
                Assert.ArgumentCondition(value >= 0, "value", "'Seed' must be greater or equal to zero.");
                this.seed = value;
            }
        }

        public Func<HtmlString, DynamicPlaceholderRenderContext, HtmlString> OutputModifier
        {
            get;
            set;
        }

        public DynamicPlaceholderDefinition(string placeholderKey)
        {
            Assert.ArgumentNotNullOrEmpty(placeholderKey, "placeholderKey");
            this.PlaceholderKey = placeholderKey;
        }
    }
}