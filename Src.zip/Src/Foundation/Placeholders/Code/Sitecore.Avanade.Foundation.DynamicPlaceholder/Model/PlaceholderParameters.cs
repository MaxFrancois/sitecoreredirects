﻿using System.Collections;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Model
{
    public class PlaceholderParameters : IReadOnlyDictionary<string, string>
    {
        public static readonly PlaceholderParameters Empty = new PlaceholderParameters(new Dictionary<string, string>());

        private readonly Dictionary<string, string> inner;

        public string this[string key]
        {
            get
            {
                return this.inner[key];
            }
            internal set
            {
                this.inner[key] = value;
            }
        }

        public int Count
        {
            get
            {
                return this.inner.Count;
            }
        }

        public IEnumerable<string> Keys
        {
            get
            {
                return this.inner.Keys;
            }
        }

        public IEnumerable<string> Values
        {
            get
            {
                return this.inner.Values;
            }
        }

        public PlaceholderParameters(IDictionary<string, string> parameters)
        {
            this.inner = new Dictionary<string, string>(parameters);
        }

        public string ValueOrNull(string key)
        {
            string result;
            if (this.TryGetValue(key, out result))
            {
                return result;
            }
            return null;
        }

        public string ValueOrDefault(string key, string defaultValue)
        {
            string result;
            if (this.TryGetValue(key, out result))
            {
                return result;
            }
            return defaultValue;
        }

        public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
        {
            return this.inner.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable)this).GetEnumerator();
        }

        public bool ContainsKey(string key)
        {
            return this.inner.ContainsKey(key);
        }

        public bool TryGetValue(string key, out string value)
        {
            return this.inner.TryGetValue(key, out value);
        }
    }
}
