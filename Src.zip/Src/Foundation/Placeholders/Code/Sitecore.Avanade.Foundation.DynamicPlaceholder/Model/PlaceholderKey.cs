﻿using Sitecore.Avanade.Foundation.Extensions.Converters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Model
{
    public class PlaceholderKey
    {
        /// <summary>
        /// The placeholder path
        /// </summary>
        public string PlaceholderPath { get; set; }

        /// <summary>
        /// The full placeholder name
        /// </summary>
        public string PlaceholderFullName { get; set; }

        /// <summary>
        /// Is the placeholder key a dynamic placeholder
        /// </summary>
        public bool IsDynamicPlaceholder { get; set; } = false;

        /// <summary>
        /// The placeholder name
        /// </summary>
        public string PlaceholderName { get; set; }

        /// <summary>
        /// The unique guide for the placeholder
        /// </summary>
        public string Guid { get; set; }

        /// <summary>
        /// The incremental number for the unique placeholder
        /// </summary>
        [TypeConverter(typeof(IntConverter))]
        public int Incremental { get; set; } = 0;

    }
}