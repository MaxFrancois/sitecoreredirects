﻿using Sitecore.Avanade.Foundation.Images.SrcSet;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Mvc.Helpers;
using Sitecore.Resources.Media;
using System;
using System.Reflection;
using System.Text;
using System.Web;


namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Extensions
{
    public static class SitecoreHelperImageExtension
    {
        public static HtmlString Image(this SitecoreHelper helper, string fieldname, Item item, string[] srcset = null,
            object htmlAttributes = null)
        {
            //run the standard sitecore helper and retrieve the tag based on all other parameters
            var generatedTag = helper.Field(fieldname, item, htmlAttributes);

            //If we are in page editor mode, just return without the src set attribute
            if (Sitecore.Context.PageMode.IsExperienceEditor)
            {
                return generatedTag;
            }

            return new HtmlString(ProcessMediaItem(generatedTag.ToString(), srcset ?? Settings.SrcSetValues, null, item.Fields[fieldname]));
        }

        public static HtmlString Image(this SitecoreHelper helper, MediaItem mediaItem, string[] srcset = null,
            object htmlAttributes = null)
        {
            var sb = new StringBuilder();

            //Open the tag and add the src attribute
            sb.Append("<img src=\"");

            //Apply the source of the image
            sb.Append(String.Concat(HashingUtils.ProtectAssetUrl(MediaManager.GetMediaUrl(mediaItem)), "\" "));

            //Check the media item properties and apply the appropriate attributes
            //Alt
            if (!String.IsNullOrEmpty(mediaItem.Alt))
                sb.AppendFormat("alt=\"{0}\" ", mediaItem.Alt);

            //title
            if (!String.IsNullOrEmpty(mediaItem.Title))
                sb.AppendFormat("title=\"{0}\"", mediaItem.Title);

            if (htmlAttributes != null)
            {
                //cycle through the attributes
                foreach (var prop in htmlAttributes.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                {
                    sb.AppendFormat("{0}=\"{1}\" ", prop.Name, prop.GetValue(htmlAttributes));
                }
            }
            /* Any other tags that I've missed, add check and append here */

            //Close the tag
            sb.Append(" />");

            return new HtmlString(ProcessMediaItem(sb.ToString(), srcset, mediaItem));
        }

        private static string ProcessMediaItem(string generatedTag, string[] srcset, MediaItem mediaItem = null, ImageField field = null)
        {
            //Initialise a string to hold it
            string srcsetValue = string.Empty;

            //If we have passed a field into the function, then grab the mediaitem from it
            if (field != null)
            {
                mediaItem = field.MediaItem;
            }

            if (mediaItem != null)
            {
                //We'll keep a count so we dont append unwanted characters in the loop
                int count = 0;

                //cycle through srcset values, generating media urls for them
                foreach (var s in srcset)
                {
                    int dimValue = 0; //this will hold the integer value
                    string dimName = string.Empty; //this will hold the dimension to change

                    Helper.SplitValues(s, out dimValue, out dimName);

                    //Generate the sitecore media url for this dimension
                    var sitecoreMediaUrl = MediaManager.GetMediaUrl(mediaItem, Helper.GetMediaUrlOptions(dimName, dimValue));

                    //Protect it
                    var protectedMediaUrl = HashingUtils.ProtectAssetUrl(sitecoreMediaUrl);

                    //make the string
                    srcsetValue += String.Format("{0} {1}", protectedMediaUrl, count == (srcset.Length - 1) ? s : String.Concat(s, ", "));

                    //increment count
                    count++;
                }

                //chop off the end of tag ('/>')
                generatedTag = generatedTag.Replace("/>", "");

                //Add the srcset attribute and close the tag
                generatedTag += String.Format("srcset=\"{0}\"//>", srcsetValue);
            }

            return generatedTag;
        }
    }
}