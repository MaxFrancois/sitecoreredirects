﻿using Sitecore.Mvc.Common;
using Sitecore.Mvc.Helpers;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Web;

using Sitecore.Avanade.Foundation.Extensions;
using System.Linq;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.DynamicPlaceholder.Model;
using Sitecore.Diagnostics;

namespace Sitecore.Avanade.Foundation.DynamicPlaceholder.Extensions
{
    public static class SitecoreHelperExtensions
    {
        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="placeholderName">The placeholder name</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        /// <returns></returns>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper,
            string placeholderName,
            int count = 1,
            int maxCount = 0,
            int seed = 0)
        {
            DynamicPlaceholderDefinition definition = new DynamicPlaceholderDefinition(placeholderName)
            {
                Count = count,
                MaxCount = maxCount,
                Seed = seed
            };

            return DynamicPlaceholder(helper, definition);
        }


        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="placeholderName">The placeholder name</param>
        /// <param name="chrome">Not used just added for Sitecore 9 support</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper,
            string placeholderName,
            TagBuilder chrome,
            int count = 1,
            int maxCount = 0,
            int seed = 0)
        {
            return DynamicPlaceholder(helper, placeholderName, delegate (HtmlString html, DynamicPlaceholderRenderContext ctx)
            {
                if (chrome == null)
                {
                    return html;
                }
                return new HtmlString(chrome.ToString(TagRenderMode.StartTag) + html + chrome.ToString(TagRenderMode.EndTag));
            }, count, maxCount, seed);
        }


        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="placeholderName">The placeholder name</param>
        /// <param name="chromeResolver">Not used just added for Sitecore 9 support</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper, string placeholderName, Func<DynamicPlaceholderRenderContext, TagBuilder> chromeResolver, int count = 1, int maxCount = 0, int seed = 0)
        {
            Assert.ArgumentNotNull(chromeResolver, "chromeResolver");
            
            return DynamicPlaceholder(helper, placeholderName, delegate (HtmlString html, DynamicPlaceholderRenderContext ctx)
            {
                TagBuilder tagBuilder = chromeResolver(ctx);
                if (tagBuilder == null)
                {
                    return html;
                }
                return new HtmlString(tagBuilder.ToString(TagRenderMode.StartTag) + html + tagBuilder.ToString(TagRenderMode.EndTag));
            }, count, maxCount, seed);
        }

        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="placeholderName">The placeholder name</param>
        /// <param name="outputModifier">Not used just added for Sitecore 9 support</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper, string placeholderName, Func<HtmlString, HtmlString> outputModifier, int count = 1, int maxCount = 0, int seed = 0)
        {
            return DynamicPlaceholder(helper, placeholderName, (HtmlString html, DynamicPlaceholderRenderContext ctx) => outputModifier(html), count, maxCount, seed);
        }

        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="placeholderName">The placeholder name</param>
        /// <param name="outputModifier">Not used just added for Sitecore 9 support</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper, string placeholderName, Func<HtmlString, DynamicPlaceholderRenderContext, HtmlString> outputModifier, int count = 1, int maxCount = 0, int seed = 0)
        {
            Assert.ArgumentNotNull(outputModifier, "outputModifier");

            DynamicPlaceholderDefinition definition = new DynamicPlaceholderDefinition(placeholderName)
            {
                Count = count,
                MaxCount = maxCount,
                Seed = seed,
                OutputModifier = outputModifier
            };
            return DynamicPlaceholder(helper, definition);
        }

        /// <summary>
        /// Sets the Dynamic Placeholders
        /// NOTE: Updated to support Sitecore 9 approach
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="definition">Define programmatically the placeholder</param>
        public static HtmlString DynamicPlaceholder(this SitecoreHelper helper, DynamicPlaceholderDefinition definition)
        {
            // set our key just in case we don't allow dynamic placeholders
            string placeholderKey = definition.PlaceholderKey;

            // has this been enabled
            if (Settings.IsEnabled)
            {
                // get the key
                placeholderKey = GetDynamicKey(definition.PlaceholderKey, definition.Seed);
            }

            // call Sitecore to get the data
            return Sitecore.Context.Items.Get<HtmlString>($"{placeholderKey}-executed", () =>
            {
                return helper.Placeholder(placeholderKey);
            });
        }


        /// <summary>
        /// Determins if the Dynamic Placholder is valid
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="definition"></param>
        /// <returns>Returns true if the data is valid or false if no renderings produced</returns>
        public static bool IsValidDynamicPlaceholder(this SitecoreHelper helper, DynamicPlaceholderDefinition definition)
        {
            // get the dynamic placeholder data
            var html = DynamicPlaceholder(helper, definition);

            // is the data valid
            if (html != null)
            {
                return true;
            }

            // not valid
            return false;
        }



        /// <summary>
        /// Generates the keys based on the input
        /// </summary>
        /// <param name="placeHolderName">The unique placeholder name</param>
        /// <param name="count">The amount of placeholders to generate/param>
        /// <param name="maxCount">The maximum number of placeholders which can be set via rendering parameters</param>
        /// <param name="seed">Set the starting incremential position of the placeholder</param>
        /// <returns></returns>
        private static string GetDynamicKey(string placeHolderName,
            int seed = 0)
        {
            // the formatted guid
            string currentRenderingId = RenderingContext.Current.Rendering.UniqueId.ToString(Settings.Formatter.Guid);

            // the placeholder key
            string placeholderKey = Settings.Formatter.Pattern.Fmt(placeHolderName, currentRenderingId, "");
            
            // get the placeholder instances
            IEnumerable<PlaceholderContext> myPlaceholders = ContextService.Get().GetInstances<PlaceholderContext>();

            // set the default
            int incrementalStep = seed;

            // cycle over the placeholders
            PlaceholderContext placeholder = myPlaceholders?.Where(x => {
                return x.PlaceholderName.StartsWith(placeholderKey);
            })?.OrderByDescending(o => {
                // make sure we fix the order to ensure that it returns in the correct way
                return o.PlaceholderName;
            })?.FirstOrDefault();

            // make sure we get the right data
            if (placeholder != null
                && !placeholder.PlaceholderName.IsNullOrEmpty())
            {
                // get the incremental step
                incrementalStep = Helpers.Placeholders.GetPlaceholderKey(placeholder.PlaceholderName).Incremental + 1;
            }

            // set the correc tkey
            placeholderKey = Settings.Formatter.Pattern.Fmt(placeHolderName, currentRenderingId, incrementalStep);

            // make sure we always returns a key
            return placeholderKey.IsNullOrEmpty() ? placeHolderName : placeholderKey;
        }
    }
}