﻿using System;
using System.Linq;
using Sitecore.Data.Items;
using Sitecore.Events;

using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.SecurityModel;

namespace Sitecore.Avanade.Foundation.Publish.Restrictions.Events
{
    /// <summary>
    /// The Publish Restrictions event is used to set the automatic publishing of items that need to be published
    /// at set times. It works with language and version.
    /// </summary>
    public class PublishRestrictions
    {
        #region OnItemSaved
        /// <summary>x`x`x`
        /// Run when an item is saved, this can be when updating the version publishing restriction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void OnItemSaved(object sender, EventArgs args)
        {
            //  make sure the publishing foundation is enabled
            if (!Settings.Enabled
                && Sitecore.Context.Job != null
                && Sitecore.Context.Job.Category.EqualsOr(System.StringComparison.OrdinalIgnoreCase, "install", "publish"))
            {
                return;
            }

            // make sure we get the correct data
            SitecoreEventArgs eventArgs = args as SitecoreEventArgs;

            // we have no args stop
            if (eventArgs != null
                && eventArgs.Parameters.Any())
            {
                // get the item
                Item item = eventArgs.Parameters[0] as Item;

                // make sure we are not in core database
                if (item?.Database != null
                    && item.Database.Name.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.MasterDBName, StringComparison.OrdinalIgnoreCase)
                    && item.Template.FullName != "System/Tasks/Schedule")
                {
                    // set the correct user
                    using (new Sitecore.Security.Accounts.UserSwitcher("sitecore\\publishrestrictions", false))
                    {
                        // kill security so we can run the process
                        using (new SecurityDisabler())
                        {
                            // check the database
                            Item command = item.Database.Items["/sitecore/system/Tasks/Commands/publishing/Auto Publish"];

                            // we have to have the command to do something
                            if (command != null)
                            {
                                // go to the schedule task
                                Sitecore.Data.Items.Item schedulesFolder = item.Database.Items["/sitecore/system/Tasks/Publishing"];
                                Sitecore.Diagnostics.Assert.IsNotNull(schedulesFolder, "schedules folder");

                                // set the item name to create
                                string taskName = string.Format("Pub_{0}_{1}_{2}", item.Language.Name, item.Version.Number.ToString(), item.ID.Guid.ToString("N").ToUpper());

                                // do we have the correct publishing
                                if ((item.Publishing.PublishDate != null
                                    && item.Publishing.NeverPublish == false
                                    && item.Publishing.PublishDate > DateTime.Now)
                                    || (item.Publishing.ValidFrom > DateTime.Now))
                                {
                                    // change to the shell site
                                    Sitecore.Context.SetActiveSite("shell");

                                    DateTime publishDate;
                                    DateTime schedulerStartDate = System.DateTime.Now;

                                    if ((item.Publishing.PublishDate != null
                                        && item.Publishing.NeverPublish == false
                                        && item.Publishing.PublishDate > DateTime.Now))
                                    {
                                        publishDate = item.Publishing.PublishDate;

                                        //offset by one minute for midnight runs only to account for interval
                                        if (publishDate.Hour == 0 && publishDate.Minute == 0)
                                        {
                                            schedulerStartDate = publishDate.AddMinutes(1);
                                        }
                                        else
                                        {
                                            schedulerStartDate = publishDate;
                                        }
                                    }
                                    else if (item.Publishing.ValidFrom > DateTime.Now)
                                    {
                                        publishDate = item.Publishing.ValidFrom;

                                        //offset by one minute for midnight runs only to account for interval
                                        if (publishDate.Hour == 0 && publishDate.Minute == 0)
                                        {
                                            schedulerStartDate = publishDate.AddMinutes(1);
                                        }
                                        else
                                        {
                                            // increase so it publishes correctly
                                            schedulerStartDate = publishDate.AddMinutes(1);

                                            // make sure it's not now midnight
                                            if (schedulerStartDate.Hour == 0 && schedulerStartDate.Minute == 0)
                                            {
                                                schedulerStartDate = schedulerStartDate.AddMinutes(1);
                                            }
                                        }
                                    }

                                    string startDate = String.Format("{0:yyyyMMdd}", schedulerStartDate);
                                    string endDate = String.Format("{0:yyyyMMdd}", schedulerStartDate.AddDays(1));
                                    string daysToRun = "127";

                                    // sitecore uses 24 hour date format
                                    string interval = String.Format("{0:HH:mm:ss}", schedulerStartDate);
                                    string publishSchedule = startDate + "|" + endDate + "|" + daysToRun + "|" + interval;

                                    // get the template
                                    Sitecore.Data.Items.TemplateItem scheduleTemplate = item.Database.GetTemplate("System/Tasks/Schedule");
                                    Sitecore.Diagnostics.Assert.IsNotNull(scheduleTemplate, "schedule template");

                                    // try and get the existing task
                                    Sitecore.Data.Items.Item itmTask = schedulesFolder.Axes.GetChild(taskName);

                                    // do we have a task
                                    if (itmTask == null)
                                    {
                                        // no task, create it
                                        itmTask = schedulesFolder.Add(taskName, scheduleTemplate);
                                    }

                                    // we have to update the task
                                    itmTask.Editing.BeginEdit();
                                    try
                                    {
                                        //doesn't find references to the fields?
                                        itmTask.Fields["Command"].Value = command.ID.ToString();
                                        itmTask.Fields["Items"].Value = item.ID.ToString();
                                        itmTask.Fields["Schedule"].Value = publishSchedule;
                                        itmTask.Fields["Last run"].Value = Sitecore.DateUtil.ToIsoDate(new DateTime(schedulerStartDate.Year, schedulerStartDate.Month, schedulerStartDate.Day));
                                    }
                                    catch (Exception ex)
                                    {
                                        Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishRestrictions]: Could not create Auto Publish task: {taskName}", ex, this);
                                    }
                                    finally
                                    {
                                        itmTask.Editing.EndEdit();
                                    }
                                }
                                else
                                {
                                    // check if we have the item
                                    Sitecore.Data.Items.Item itm = schedulesFolder.Axes.GetChild(taskName);

                                    if (itm != null)
                                    {
                                        // delete the item, it is not required
                                        itm.Delete();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}