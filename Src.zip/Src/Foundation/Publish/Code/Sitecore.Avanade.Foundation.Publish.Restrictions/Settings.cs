﻿using System;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Publish.Restrictions
{
    public static class Settings
    {
        #region Private Variable
        /// <summary>
        /// Is the publishing restrictions enabled
        /// </summary>
        private static bool? _isEnabled;
        #endregion

        #region Enabled
        /// <summary>
        /// Are we enabling publishing
        /// </summary>
        public static bool Enabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Publish.Restrictions.Enabled", false);

                return _isEnabled.Value;
            }
        }
        #endregion
        
    }
}