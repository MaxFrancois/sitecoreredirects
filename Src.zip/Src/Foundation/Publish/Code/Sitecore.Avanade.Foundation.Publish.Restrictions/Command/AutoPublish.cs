﻿using System;
using System.Linq;
using Sitecore.Data.Items;
using Sitecore.SecurityModel;
using Sitecore.Diagnostics;

// extension methods
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Publish.Restrictions.Command
{
    /// <summary>
    /// Auto Publish Command
    /// </summary>
    public class AutoPublish
    {
        #region Run
        // this method gets called from a scheduled task command, you define a scheduled task command by navigating to
        // /System/Tasks/Commands and inserting a new command
        public void Run(Sitecore.Data.Items.Item[] items, Sitecore.Tasks.CommandItem command, Sitecore.Tasks.ScheduleItem schedule)
        {
            // make sure we have data
            if (schedule == null
                || items == null || items.Length == 0)
            {
                return;
            }

            // we don't know what user is running
            using (new SecurityDisabler())
            {
                try
                {
                    // set the site to shell
                    Sitecore.Context.SetActiveSite("shell");

                    // process the list of Items, to be safe
                    foreach (Item itemToPublish in items)
                    {
                        // publish the item to all publishing targets
                        itemToPublish.Publish(true, true);

                        // can we show the published action in the logs
                        if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                        {
                            Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishRestrictions]: AutoPublished: '{itemToPublish.Paths.Path}'");
                        }
                    }

                    // remove the item 
                    schedule.Remove();

                }
                catch (Exception ex)
                {
                    // erro log
                    Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishRestrictions]: Command: AutoPublish: schedule:'{schedule.Name}'", ex, this);
                }
            }
        }
        #endregion

    }
}