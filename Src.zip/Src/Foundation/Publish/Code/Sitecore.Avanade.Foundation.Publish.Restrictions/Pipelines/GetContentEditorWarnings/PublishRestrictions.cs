﻿using Sitecore.Pipelines.GetContentEditorWarnings;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Publish.Restrictions.Pipelines.GetContentEditorWarnings
{
    /// <summary>
    /// Set any publish restrictions which may affect deployments / publishes
    /// </summary>
    public class PublishRestrictions
    {
        /// <summary>
        /// The Process to be executed
        /// </summary>
        /// <param name="args"></param>
        public void Process(GetContentEditorWarningsArgs args)
        {
            // make sure this is enabled
            if (!Settings.Enabled)
            {
                return;
            }

            var item = args.Item;

            if (item != null)
            {
                // get the database
                Sitecore.Data.Database database = Sitecore.Context.ContentDatabase;

                // get the folder
                Sitecore.Data.Items.Item schedulesFolder = database.Items["/sitecore/system/Tasks/Publishing"];

                // if we have no folder stop
                if (schedulesFolder == null)
                {
                    return;
                }

                // get the list
                Sitecore.Data.Items.Item[] items = schedulesFolder.Axes.SelectItems("*[contains(@@key,'{0}')]".Fmt(item.ID.Guid.ToString("N").ToLower()), true);

                // process the list
                if (items != null && items.Length > 0)
                {
                    var warning = args.Add();
                    warning.Title = "Publish restrictions scheduled for automatic publishing";
                    warning.Icon = "Network/16x16/download.png";
                    warning.Text += "The following language versions have been identified that an automatic schedule publish will occur. The following details for the current item are listed below:<ul>";
                    warning.IsExclusive = false;

                    // process the list
                    items.ForEach(d =>
                    {
                        string[] itmList = d.Name.Split('_');
                        string[] scheduleField = d.Fields["Schedule"].ValueSafe().Split('|');

                        var schedultItem = new ScheduleItem
                        {
                            Language = itmList[1],
                            Version = System.Convert.ToInt32(itmList[2]),
                            Date = Sitecore.DateUtil.IsoDateToDateTime($"{scheduleField[0]}T{scheduleField[3].Replace(":", "")}Z").UtcDateTimeToDateTime()
                        };

                        warning.Text += $"<li>Language: '{schedultItem.Language}', version: '{schedultItem.Version}', DateTime: '{schedultItem.Date.ToString("dddd, dd MMMM yyyy HH:mm:ss")}'</li>";
                    });
                    warning.Text += "</ul>";
                }

                
            }
        }

        public class ScheduleItem
        {
            public string Language { get; set; }
            public int Version { get; set; }
            public System.DateTime Date { get; set; }
        }
    }
}
