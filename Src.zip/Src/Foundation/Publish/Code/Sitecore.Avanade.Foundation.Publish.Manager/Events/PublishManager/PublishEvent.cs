﻿using System;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Events.PublishManager
{
    /// <summary>
    /// Clears the caching of the custom site caching objects
    /// </summary>
    public class PublishEvent
    {
        #region PublishManagerEvent
        /// <summary>
        /// Executes the Cache Manager to fire it's necessary pipelines
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        public void OnPublishEvent(object sender, EventArgs args)
        {
            //item saved is called when an item is published (because the item is being saved in the web database)
            //when this happens, we don't want our code to move the item anywhere, so escape out of this function.
            if (!Settings.Enabled
                || (Sitecore.Context.Job != null
                && !Sitecore.Context.Job.Category.Equals("publish", StringComparison.OrdinalIgnoreCase)))
            {
                return;
            }

            // run the cache clear pipeline
            Pipelines.PublishManager.CacheClearPipeline.Run(args);
        }
        #endregion
    }
}