﻿using System;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Models
{
    /// <summary>
    /// The HTML Clear model
    /// </summary>
    public class HtmlClear
    {
        /// <summary>
        /// The Sitename fo the HTML Clear
        /// </summary>
        string SiteName { get; set; }

        /// <summary>
        /// The Site Frequency to clear
        /// </summary>
        TimeSpan SiteFrequency { get; set; } = System.TimeSpan.Zero;

        /// <summary>
        /// Are we clearing the Cache Util
        /// </summary>
        bool ClearSitecoreCacheUtil { get; set; } = true;

        /// <summary>
        /// Are we clearing the global Cache Util
        /// </summary>
        bool ClearGlobalSitecoreCacheUtil { get; set; } = false;
    }
}