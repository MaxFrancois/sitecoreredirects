﻿using System;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Publish.Manager
{
    public static class Settings
    {
        private static bool? _isEnabled;
        private static string _containerTemplateId;

        #region Enabled
        /// <summary>
        /// Are we enabling Publishing Manager
        /// </summary>
        public static bool Enabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Publish.Manager.Enabled", false);

                return _isEnabled.Value;
            }
        }
        #endregion

        #region ContainerTemplateId
            
        public static string ContainerTemplateId
        {
            get
            {
                if (string.IsNullOrEmpty(_containerTemplateId))
                {
                    _containerTemplateId = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Publish.PublishManager.ContainerTemplateId", "{0E1BF3A3-ED26-40E2-A263-7A97427F3E85}");
                }

                return _containerTemplateId;
            }
        }
        #endregion

        public static class Rules
        {
            private static bool? _rulesIsEnabled;
            private static string _contextFolderId;

            #region Enabled
            /// <summary>
            /// Are we enabling Publishing Manager
            /// </summary>
            public static bool RulesIsEnabled
            {
                get
                {
                    _rulesIsEnabled = Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Publish.PublishManager.Rules.Enabled", false);

                    return _rulesIsEnabled.Value;
                }
            }
            #endregion

            #region ContextFolderId

            public static string ContextFolderId
            {
                get
                {
                    if (string.IsNullOrEmpty(_contextFolderId))
                    {
                        _contextFolderId = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Publish.PublishManager.Rules.ContextFolderId", "{3F0A7E21-79C4-493D-975F-AC331A2AC803}");
                    }

                    return _contextFolderId;
                }
            }
            #endregion
        }
        
    }
}