﻿using System;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Tasks
{
    public static class ClearHtml
    {
        #region Private Static
        /// <summary>
        /// The listing of nodes to remove from the list that have the correct frequency
        /// </summary>
#pragma warning disable S125 // Sections of code should not be "commented out"
                            //private static readonly System.Xml.XmlNodeList _xSiteList;

        //private static TimeSpan _defaultSiteFrequency;
        //private static bool _defaultClearSitecoreCacheUtil;
        #endregion

        #region Static Constructor
        /// <summary>
        /// Setups the instance to determine if this needs to run
        /// </summary>
        static ClearHtml()
#pragma warning restore S125 // Sections of code should not be "commented out"
        {
#pragma warning disable S125 // Sections of code should not be "commented out"
                            /*
                                        // fetch the sublayouts
                                        _xSiteList = Sitecore.Configuration.Factory.GetConfigNodes(@"/sitecore/pipelines/cacheManagerCacheClear/processor[@type='Sitecore.Ignition.Pipelines.CacheManager.Processors.CacheClear.HTMLClear, Sitecore.Ignition']/features/sites/site[@enabled='true' and @frequency!='00:00:00']");

                                        // set the max time default 1 hour
                                        _defaultSiteFrequency = System.TimeSpan.Zero;
                                        _defaultClearSitecoreCacheUtil = true;

                                        #region Setup Default Site Frequency
                                        // find the correct default time
                                        foreach (System.Xml.XmlNode xSiteNode in _xSiteList)
                                        {
                                            // is the site the correct one
                                            if (Utils.Xml.GetAttributeValue(xSiteNode, "name").Equals("__default", StringComparison.OrdinalIgnoreCase))
                                            {
                                                // get the datetime
                                                _defaultSiteFrequency = Sitecore.DateUtil.ParseTimeSpan(Utils.Xml.GetAttributeValue(xSiteNode, "frequency"), _defaultSiteFrequency);

                                                // is the cache util cleared
                                                _defaultClearSitecoreCacheUtil = Utils.BooleanUtil.ConvertToBoolean(Utils.Xml.GetAttributeValue(xSiteNode, "clearUtils"), _defaultClearSitecoreCacheUtil);

                                                // kill
                                                break;
                                            }
                                        }
                                        #endregion*/
        }
#pragma warning restore S125 // Sections of code should not be "commented out"
        #endregion
    }
}