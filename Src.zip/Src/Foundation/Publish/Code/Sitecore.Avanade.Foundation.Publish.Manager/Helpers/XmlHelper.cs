﻿namespace Sitecore.Avanade.Foundation.Publish.Manager.Helpers
{
    public static class XmlHelper
    {
        #region ReturnXPathNodeIter
        /// <summary>
        /// The read only empty navigator
        /// </summary>
        private static readonly System.Xml.XPath.XPathNavigator _emptyNavigator;

        /// <summary>
        /// Creates an empty navigator when the class is first called
        /// </summary>
        static XmlHelper()
        {
            _emptyNavigator = new System.Xml.XmlDocument().CreateNavigator();
        }

        /// <summary>
        /// Creates an empty Iterator
        /// </summary>
        /// <returns>returns the empty itorator</returns>
        private static System.Xml.XPath.XPathNodeIterator CreateEmptyIterator()
        {
            return _emptyNavigator.Select("*");
        }

        /// <summary>
        /// This is only used for our node creation processes.
        /// </summary>
        /// <param name="itm">The item to return as an xpath node iterator</param>
        /// <returns>Returns an xpath iterator</returns>
        public static System.Xml.XPath.XPathNodeIterator ReturnXPathNodeIter(Sitecore.Data.Items.Item itm)
        {
            // make sure the item exists
            if (itm == null)
            {
                return CreateEmptyIterator();
            }

            // create the navigator
            Sitecore.Xml.XPath.ItemNavigator navigator = Sitecore.Configuration.Factory.CreateItemNavigator(itm);

            // make sure the navigator exists
            if (navigator == null)
            {
                return CreateEmptyIterator();
            }

            // get the item
            return navigator.Select(".");
        }
        #endregion

        #region GetAttributeValue
        /// <summary>
        /// This allows easy access to get an attribute value
        /// </summary>
        /// <param name="xmlAttrCollection">The attribute collection that contains the attribute.</param>
        /// <param name="attributeName">The attribute name we want to retrieve.</param>
        /// <returns>Returns the attribute value or an empty string.</returns>
        public static string GetAttributeValue(System.Xml.XmlAttributeCollection xmlAttrCollection, string attributeName, string defaultValue = "")
        {
            // set default
            string outPutText = string.Empty;

            // make sure it exists first
            if (xmlAttrCollection.GetNamedItem(attributeName) != null)
            {
                outPutText = xmlAttrCollection.GetNamedItem(attributeName).Value;
            }

            if (!string.IsNullOrEmpty(defaultValue) && string.IsNullOrEmpty(outPutText))
            {
                outPutText = defaultValue;
            }

            // return text
            return outPutText;
        }

        /// <summary>
        /// This allows easy access to get an attribute value
        /// </summary>
        /// <param name="xmlAttrCollection">The attribute collection that contains the attribute.</param>
        /// <param name="attributeName">The attribute name we want to retrieve or the xpath expression pointing to an attribute value.</param>
        /// <returns>Returns the attribute value or an empty string.</returns>
        public static string GetAttributeValue(System.Xml.XmlNode xmlNode, string attributeName, string defaultValue = "")
        {
            string outPutText = string.Empty;

            if (xmlNode != null)
            {
                // determine if we have an xpath expression
                if (attributeName.IndexOf("/") != -1 && attributeName.IndexOf("@") != -1)
                {
                    // get our xmlnode from the xpath
                    System.Xml.XmlNode xNodeSelect = xmlNode.SelectSingleNode(attributeName);

                    // make sure it returned something first
                    if (xNodeSelect != null)
                    {
                        // get our value and return
                        outPutText = xNodeSelect.Value;
                    }
                }
                else
                {
                    outPutText = GetAttributeValue(xmlNode.Attributes, attributeName, defaultValue);
                }
            }


            if (!string.IsNullOrEmpty(defaultValue) && string.IsNullOrEmpty(outPutText))
            {
                outPutText = defaultValue;
            }

            // error
            return outPutText;
        }
        #endregion
    }
}