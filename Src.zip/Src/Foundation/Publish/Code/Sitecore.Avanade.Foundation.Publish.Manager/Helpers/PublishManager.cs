﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Rules;
using Sitecore.SecurityModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Helpers
{
    public static class PublishManager
    {
        #region RunRulesContextFolder
        public static void RunRulesContextFolder(Item itm, RuleContext ruleContext, bool executeAll = true)
        {
            // make sure data is valid
            if (itm != null
                && ruleContext != null
                && ruleContext.Item != null
                && itm.TemplateID.EqualsTo("{DDA66314-03F3-4C89-84A9-39DFFB235B06}"))
            {
                // set our insert options list
                var rulesItems = new List<Item>();

                // make sure we disable security for this
                using (new SecurityDisabler())
                {
                    // fetch all InsertRuleItems no matter the depth
                    var itms = itm.Axes.SelectItems($".//*[@@templateid='{Constants.RuleTemplateId}']");

                    // ensure we have data
                    if (itms != null && itms.Length > 0)
                    {
                        // increase our list
                        rulesItems.AddRange(itms);
                    }
                }

                if (rulesItems.IsValid())
                {
                    // get the rule list
                    RuleList<RuleContext> ruleList = RuleFactory.GetRules<RuleContext>(rulesItems, "Rule");

                    // do we have any rules
                    if (ruleList != null
                        && ruleList.Count > 0)
                    {
                        // are we running all rules
                        if (executeAll)
                        {
                            // execute the rule
                            ruleList.Run(ruleContext);
                        }
                        else
                        {
                            // we are only getting the first success
                            var firstRule = ruleList.Rules.FirstOrDefault(x =>
                            {
                                return x.Evaluate(ruleContext);
                            });

                            // only log if debug enabled
                            if (firstRule != null
                                && Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                            {
                                Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishManager]: Executed Publishing Rule: '{firstRule.Name}'", typeof(PublishManager));
                            }
                        }
                    }
                }
            }
        }
        #endregion


        #region RunRulesItem
        /// <summary>
        /// 
        /// </summary>
        /// <param name="itm"></param>
        /// <param name="ruleField"></param>
        /// <param name="ruleContext"></param>
        /// <param name="executeAll"></param>
        public static void RunRulesItem(Item itm, string ruleField, RuleContext ruleContext, bool executeAll = true)
        {
            // make sure data is valid
            if (itm != null
                && !ruleField.IsNullOrEmpty()
                && ruleContext != null
                && ruleContext.Item != null
                && itm.HasField(ruleField))
            {
                // get the rule value
                string ruleValue = itm.Fields[ruleField].ValueSafe();

                // make sure the data is valid
                if (!ruleValue.IsNullOrEmpty()
                    && !ruleValue.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.EmptyRuleFieldValue, StringComparison.OrdinalIgnoreCase))
                {
                    // get the rule list
                    RuleList<RuleContext> ruleList = RuleFactory.ParseRules<RuleContext>(itm.Database, ruleValue);

                    // do we have any rules
                    if (ruleList != null
                        && ruleList.Count > 0)
                    {
                        // are we running all rules
                        if (executeAll)
                        {
                            // execute the rule
                            ruleList.Run(ruleContext);
                        }
                        else
                        {
                            // we are only getting the first success
                            var firstRule = ruleList.Rules.FirstOrDefault(x =>
                            {
                                return x.Evaluate(ruleContext);
                            });

                            // only log if debug enabled
                            if (firstRule != null
                                && Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                            {
                                Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishManager]: Executed Publishing Rule: '{firstRule.Name}'", typeof(PublishManager));
                            }
                        }
                    }
                }
            }
        }
        #endregion
    }
}