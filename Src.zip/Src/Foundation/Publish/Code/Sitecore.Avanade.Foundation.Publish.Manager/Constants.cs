﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Publish.Manager
{
    public static class Constants
    {
        public const string RuleTemplateId = "{D9BDF22F-6E17-47F3-AB64-49C717BA92DA}";
        public static class Caches
        {
            public const string PublishManagerSettingItemCacheKey = "publishmanager-settingitem";
        }
    }
}