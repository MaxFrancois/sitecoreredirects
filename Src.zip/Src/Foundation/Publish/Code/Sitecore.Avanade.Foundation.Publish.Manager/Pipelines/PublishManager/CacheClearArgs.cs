﻿using System;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Pipelines.PublishManager
{
    /// <summary>
    /// The CacheManagerArgs processor arguments
    /// </summary>
    [Serializable]
    public class CacheClearArgs : Sitecore.Pipelines.PipelineArgs
    {
        #region Private Static
        /// <summary>
        /// The Item Processed Type
        /// </summary>
        private readonly Type _itemProcessedType = typeof(Sitecore.Publishing.Pipelines.PublishItem.ItemProcessedEventArgs);

        /// <summary>
        /// The Publish End Remote Type
        /// </summary>
        private readonly Type _publishEndRemoteType = typeof(Sitecore.Data.Events.PublishEndRemoteEventArgs);

        /// <summary>
        /// The Default Evetn Type
        /// </summary>
        private readonly Type _defaultEventType = typeof(Sitecore.Events.SitecoreEventArgs);
        #endregion
        

        #region Public Properties
        /// <summary>
        /// The Publish End Remote Event Arguments
        /// </summary>
        public Sitecore.Data.Events.PublishEndRemoteEventArgs PublishEndRemoteArgs { get; internal set; }
    
        /// <summary>
        /// The Sitecore Item processed Events Args
        /// </summary>
        public Sitecore.Publishing.Pipelines.PublishItem.ItemProcessedEventArgs SitecoreItemProcessedArgs { get; internal set; }


        /// <summary>
        /// The Sitecore Events Args
        /// </summary>
        public Sitecore.Events.SitecoreEventArgs SitecoreEventsArgs { get; internal set; }

        /// <summary>
        /// The Event Type
        /// </summary>
        public EventType EventType { get; internal set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Builds the Arguments for the processor
        /// </summary>
        /// <param name="mediaURL">The Media URL</param>
        /// <param name="itm">The media item</param>
        public CacheClearArgs(System.EventArgs args)
        {
            // is default
            if (args.GetType().Equals(_itemProcessedType))
            {
                SitecoreItemProcessedArgs = (Sitecore.Publishing.Pipelines.PublishItem.ItemProcessedEventArgs)args;
                EventType = PublishManager.EventType.PublishItemProcessed;
            }
            else if (args.GetType().Equals(_publishEndRemoteType))
            {
                PublishEndRemoteArgs = (Sitecore.Data.Events.PublishEndRemoteEventArgs)args;
                EventType = PublishManager.EventType.PublishEndRemote;
            }
            else if (args.GetType().Equals(_defaultEventType))
            {
                // set the default event
                SitecoreEventsArgs = ((Sitecore.Events.SitecoreEventArgs)args);

                // 
                if (SitecoreEventsArgs.EventName.Equals("publish:end", StringComparison.OrdinalIgnoreCase))
                {
                    EventType = PublishManager.EventType.PublishEnd;
                }
                else
                {
                    EventType = PublishManager.EventType.Custom;
                }
            }
        }

        protected CacheClearArgs(SerializationInfo info, StreamingContext context) : base(info, context)
        { }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }
            base.GetObjectData(info, context);
        }

        #endregion
    }

    #region EventType Enum
    /// <summary>
    /// The Evetn Types
    /// </summary>
    public enum EventType
    {
        /// <summary>
        /// Actioned when publish end
        /// </summary>
        PublishEnd,

        /// <summary>
        /// actioned when publish end remote
        /// </summary>
        PublishEndRemote,

        /// <summary>
        /// Actioned when publish item processed
        /// </summary>
        PublishItemProcessed,

        /// <summary>
        /// Event not known
        /// </summary>
        Custom
    }
    #endregion
}