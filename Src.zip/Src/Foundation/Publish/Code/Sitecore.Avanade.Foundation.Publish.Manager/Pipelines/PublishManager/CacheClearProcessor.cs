﻿using System;
using System.Linq;

// extension methods
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Pipelines.PublishManager
{
    /// <summary>
    /// The Cache Manager Processor
    /// </summary>
    public abstract class CacheClearProcessor
    {
        #region FixingSitecoreError
        [Obsolete("Sitecore Required: DO NOT USE", true)]
        public string Features { get; set; }
        #endregion

        #region Constructor
        /// <summary>
        /// Empty Constructor
        /// </summary>
        protected CacheClearProcessor()
        {

        }
        #endregion

        #region Process
        /// <summary>
        /// The processor for the Cache Manager
        /// </summary>
        /// <param name="args"></param>
        public abstract void Process(CacheClearArgs args);
        #endregion

        #region Add Message
        /// <summary>
        /// Add a message to the publishing Job
        /// </summary>
        /// <param name="message"></param>
        public void AddMessage(string message)
        {
            // get the job to process
            var publishJobs = Sitecore.Jobs.JobManager
                        .GetJobs().Where(x => x.Category.Equals("publish"))
                        .ToList();

            // process the jobects
            foreach (Sitecore.Jobs.Job j in publishJobs)
            {
                if (j.Handle.IsLocal)
                {
                    // add th emessage
                    j.Status.Messages.Add(message);
                }

            }
        }
        #endregion
    }
}
