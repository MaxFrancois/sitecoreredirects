﻿using Sitecore.Publishing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Pipelines.PublishManager.Processors.CacheClear
{
    public class Rules : PublishManager.CacheClearProcessor
    {
        #region Process
        /// <summary>
        /// Processes the request to determine if the html cache needs to be cleared
        /// </summary>
        /// <param name="args"></param>
        public override void Process(CacheClearArgs args)
        {
            // complete override no caching has been enabled
            if (args.Aborted
                && !Settings.Enabled
                && !Settings.Rules.RulesIsEnabled)
            {
                return;
            }

            #region Publish End Remote
            if (args.EventType == EventType.PublishEndRemote
                && args.PublishEndRemoteArgs != null
                && args.PublishEndRemoteArgs.Mode == PublishMode.SingleItem)
            {
                // make sure we only run this if the mode is not single
                PublishEnd(args, args.PublishEndRemoteArgs.TargetDatabaseName, args.PublishEndRemoteArgs.LanguageName);

                return;
            }
            #endregion
        }
        #endregion

        private void PublishEnd(CacheClearArgs args, string databaseName, string languageName)
        {
            // get the rules context item
            var itm = Sitecore.Avanade.Foundation.Extensions.Helpers.ItemHelper.GetItem(Settings.Rules.ContextFolderId, databaseName, languageName);

            if (itm != null)
            {
                Helpers.PublishManager.RunRulesContextFolder(itm, new Sitecore.Rules.RuleContext { Item = args.ProcessorItem.InnerItem });
            }
        }
    }
}