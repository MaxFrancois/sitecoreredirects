﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Publishing;
using Sitecore.Events;

namespace Sitecore.Avanade.Foundation.Publish.Manager.Pipelines.PublishManager.Processors.CacheClear
{
    /// <summary>
    /// Processor to clear the HTML cache and from the cache provider
    /// </summary>
    public class HtmlClear : PublishManager.CacheClearProcessor
    {
        #region Process
        /// <summary>
        /// Processes the request to determine if the html cache needs to be cleared
        /// </summary>
        /// <param name="args"></param>
        public override void Process(CacheClearArgs args)
        {
            // complete override no caching has been enabled
            if (args.Aborted)
            {
                return;
            }

            #region Publish End
            if (args.EventType == EventType.PublishEnd)
            {
                // make sure we only run this if the mode is not single
                // get the publisher
                Publisher publisher = Event.ExtractParameter(args.SitecoreEventsArgs, 0) as Publisher;
                if (publisher != null && publisher.Options.PublishingTargets.Count > 0)
                {
                    PublishEnd(args, publisher.Options.TargetDatabase.Name, publisher.Options.Language.Name);
                }
                return;
            }
            #endregion

            #region Publish End Remote
            if (args.EventType == EventType.PublishEndRemote
                && args.PublishEndRemoteArgs != null
                && args.PublishEndRemoteArgs.Mode == PublishMode.SingleItem)
            {
                // make sure we only run this if the mode is not single
                PublishEnd(args, args.PublishEndRemoteArgs.TargetDatabaseName, args.PublishEndRemoteArgs.LanguageName);

                return;
            }
            #endregion

#pragma warning disable S125 // Sections of code should not be "commented out"
            /*
                        if (args.EventType == EventType.Custom)
                        {
                        }*/
#pragma warning restore S125 // Sections of code should not be "commented out"
        }

        #endregion

        #region PublishEnd
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <param name="siteList"></param>
        private void PublishEnd(CacheClearArgs args, string databaseName, string languageName)
        {
            // set the max time default 1 hour
#pragma warning disable S125 // Sections of code should not be "commented out"
                            //TimeSpan defaultSiteFrequency = System.TimeSpan.Zero;
                            //bool defaultClearSitecoreCacheUtil = true;
                            /*

                            // loop through the site listings with cache settings defined
                            Sitecore.Ignition.Configuration.CacheManager.SiteDefinitions(d =>
                            {
                                // is the site in the list
                                if (databaseName.Equals(d.Site.Database, StringComparison.OrdinalIgnoreCase)
                                    && languageName.Equals(d.Site.Language, StringComparison.OrdinalIgnoreCase))
                                {
                                    // set the max value just in case
                                    TimeSpan nextPublishingTime = defaultSiteFrequency;

                                    // is the cache manager running with the HTML provider
                                    if (d.IsEnabled
                                        && !d.HTMLProvider.IsNullOrEmpty()
                                        && Sitecore.Ignition.Configuration.CacheManager.CacheProviders.ContainsKey(d.HTMLProvider))
                                    {
                                        using (Sitecore.Ignition.Sites.SiteContextCreator scc = new Sitecore.Ignition.Sites.SiteContextCreator(d.SiteName))
                                        {
                                            // is the site publishable
                                            bool isPublishable = false;
                                            bool clearSitecoreCacheUtil = defaultClearSitecoreCacheUtil;

                                            // have we got a key
                                            if (!Sitecore.Ignition.Context.Cache.HasKey("HTML_clear", false, d.SiteName, d.Site.Database, d.Site.Language, d.HTMLPrefix, d.HTMLRepository, d.HTMLProvider))
                                            {
                                                // process the site and get out the frequency
                                                foreach (System.Xml.XmlNode xSiteNode in siteList)
                                                {
                                                    string siteNameXml = Utils.Xml.GetAttributeValue(xSiteNode, "name");

                                                    // is the site the correct one
                                                    if (siteNameXml.Equals(d.SiteName, StringComparison.OrdinalIgnoreCase))
                                                    {
                                                        // set the time
                                                        nextPublishingTime = Sitecore.DateUtil.ParseTimeSpan(Utils.Xml.GetAttributeValue(xSiteNode, "frequency"), defaultSiteFrequency); ;

                                                        // are we to clear the sitecore cache util
                                                        clearSitecoreCacheUtil = Utils.BooleanUtil.ConvertToBoolean(Utils.Xml.GetAttributeValue(xSiteNode, "clearUtils"), defaultClearSitecoreCacheUtil);

                                                        // kill
                                                        break;
                                                    }
                                                }

                                                // we have not requested the pubilsh so request this
                                                isPublishable = true;
                                            }
                                            else
                                            {
                                                // reset the cache instance
                                                Sitecore.Ignition.Context.Cache.Add("HTML_Task", true, System.DateTime.Now.AddDays(20), false, false, false, d.SiteName, d.Site.Database, d.Site.Language, d.HTMLPrefix, d.HTMLRepository, null, System.Web.Caching.CacheItemPriority.Normal, null, d.HTMLProvider);
                                            }

                                            // make sure we have a valid provider
                                            if (isPublishable)
                                            {
                                                Sitecore.Sites.SiteContext site = new Sitecore.Sites.SiteContext(d.Site);

                                                if (!d.HTMLIsSitecoreProvider)
                                                {
                                                    // remove all
                                                    Sitecore.Ignition.Context.Cache.RemoveAll(d.SiteName, d.Site.Database, d.Site.Language, d.HTMLPrefix, d.HTMLRepository, false, false, d.HTMLProvider);

                                                    // can we log
                                                    if (Diagnostics.Log.IsInfoEnabled)
                                                    {
                                                        // set the string to produce
                                                        string result = "HTML Clear: Site: '{0}', Mode: CacheManager: {1},{2}".Fmt(d.SiteName, d.HTMLProvider, d.HTMLRepository);

                                                        // add to the output message
                                                        AddMessage(result);

                                                        // log the result
                                                        Sitecore.Diagnostics.Log.Info(result, typeof(HTMLClear));
                                                    }




                                                    // make sure it's not zero
                                                    if (nextPublishingTime > TimeSpan.Zero)
                                                    {
                                                        // add the data
                                                        Sitecore.Ignition.Context.Cache.Add("HTML_clear", nextPublishingTime.ToDateTime(DateTime.Now), nextPublishingTime, false, false, false, d.SiteName, d.Site.Database, d.Site.Language, d.HTMLPrefix, d.HTMLRepository, null, System.Web.Caching.CacheItemPriority.Normal, null, d.HTMLProvider);

                                                        // reset the cache instance
                                                        Sitecore.Ignition.Context.Cache.Add("HTML_Task", false, System.DateTime.Now.AddDays(20), false, false, false, d.SiteName, d.Site.Database, d.Site.Language, d.HTMLPrefix, d.HTMLRepository, null, System.Web.Caching.CacheItemPriority.Normal, null, d.HTMLProvider);
                                                    }
                                                }

                                                // we are dealing with the Sitecore cache
                                                Sitecore.Caching.HtmlCache htmlCache = Sitecore.Caching.CacheManager.GetHtmlCache(site);

                                                // make sure we have the data
                                                if (htmlCache != null)
                                                {
                                                    // remove all html
                                                    htmlCache.Clear(true);

                                                    if (Diagnostics.Log.IsInfoEnabled)
                                                    {
                                                        // set the string to produce
                                                        string result = "HTML Clear: Site: '{0}', Mode: Sitecore".Fmt(d.SiteName);

                                                        // add to the output message
                                                        AddMessage(result);

                                                        // log the result
                                                        Sitecore.Diagnostics.Log.Info(result, typeof(HTMLClear));
                                                    }
                                                }

                                                // kill the xsl reference
                                                Sitecore.Caching.XslCache xslCache = Sitecore.Caching.CacheManager.GetXslCache(site);

                                                if (xslCache != null)
                                                {
                                                    // find the renderings and clear
                                                    xslCache.Clear();

                                                    if (Diagnostics.Log.IsInfoEnabled)
                                                    {
                                                        // set the string to produce
                                                        string result = "XSL Clear: Site: '{0}', Mode: Sitecore".Fmt(d.SiteName);

                                                        // add to the output message
                                                        AddMessage(result);

                                                        // log the result
                                                        Sitecore.Diagnostics.Log.Info(result, typeof(HTMLClear));
                                                    }
                                                }

                                                // do we have the option to clear the sitecore cache util
                                                if (clearSitecoreCacheUtil)
                                                {
                                                    Utils.Cache.ClearCache(d.SiteName, d.Site.Database, d.Site.Language);
                                                }
                                            }
                                        }
                                    }
                                    else // function like the HTMLCacheClear Event
                                    {
                                        Sitecore.Sites.SiteContext site = new Sitecore.Sites.SiteContext(d.Site);

                                        // we are dealing with the Sitecore cache
                                        Sitecore.Caching.HtmlCache htmlCache = Sitecore.Caching.CacheManager.GetHtmlCache(site);

                                        // make sure we have the data
                                        if (htmlCache != null)
                                        {
                                            // remove all html
                                            htmlCache.Clear(true);
                                            if (Diagnostics.Log.IsInfoEnabled)
                                            {
                                                // set the string to produce
                                                string result = "HTML Clear: Site: '{0}', Mode: Sitecore".Fmt(d.SiteName);

                                                // add to the output message
                                                AddMessage(result);

                                                // log the result
                                                Sitecore.Diagnostics.Log.Info(result, typeof(HTMLClear));
                                            }
                                        }

                                        // kill the xsl reference
                                        Sitecore.Caching.XslCache xslCache = Sitecore.Caching.CacheManager.GetXslCache(site);

                                        if (xslCache != null)
                                        {
                                            // find the renderings and clear
                                            xslCache.Clear();

                                            if (Diagnostics.Log.IsInfoEnabled)
                                            {
                                                // set the string to produce
                                                string result = "XSL Clear: Site: '{0}', Mode: Sitecore".Fmt(d.SiteName);

                                                // add to the output message
                                                AddMessage(result);

                                                // log the result
                                                Sitecore.Diagnostics.Log.Info(result, typeof(HTMLClear));
                                            }
                                        }

                                        // do we have the option to clear the sitecore cache util
                                        if (defaultClearSitecoreCacheUtil)
                                        {
                                            Utils.Cache.ClearCache(d.SiteName, d.Site.Database, d.Site.Language);
                                        }
                                    }
                                }
                            });
                            */
        }
#pragma warning restore S125 // Sections of code should not be "commented out"
        #endregion
    }
}