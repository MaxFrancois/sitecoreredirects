﻿namespace Sitecore.Avanade.Foundation.Publish.Manager.Pipelines.PublishManager
{
    /// <summary>
    /// Starts up the pipeline
    /// </summary>
    public static class CacheClearPipeline
    {
        #region Run
        /// <summary>
        /// To run the Cache manager Cache Clear Pipeline
        /// </summary>
        /// <returns>Returns</returns>
        public static CacheClearArgs Run(System.EventArgs args)
        {
            // setup the arguments
            CacheClearArgs pipelineArgs = new CacheClearArgs(args);

            // call our pipeline
            Sitecore.Pipelines.CorePipeline.Run("publishManagerCacheClear", pipelineArgs);

            // was there an error
            if (Diagnostics.Log.IsDebugEnabled
                && pipelineArgs.Aborted
                && !string.IsNullOrEmpty(pipelineArgs.Message))
            {
                // log error
                Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PublishManager]: Debug Message: '{pipelineArgs.Message}", typeof(CacheClearArgs));
            }

            // returns the cache manager url
            return pipelineArgs;
        }
        #endregion
    }
}
