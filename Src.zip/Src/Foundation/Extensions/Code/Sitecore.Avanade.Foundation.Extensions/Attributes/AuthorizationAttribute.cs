﻿using System;
using System.Linq;
using Sitecore.Avanade.Foundation.Extensions;
using System.Web;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Extensions.Attributes
{
    /// <summary>
    /// Override the standard .NET Authorize Attribute to support Sitecore logins
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class SitecoreAuthorizeAttribute : AuthorizeAttribute
    {
        #region Private Variables
        /// <summary>
        /// The listing of domain names
        /// </summary>
        private string _domains;

        /// <summary>
        /// The split listing of domian names
        /// </summary>
        private string[] _domainsSplit = new string[0];
        #endregion

        #region Public Properties
        /// <summary>
        /// Get the Domains or Set the domain listings seperated by comma
        /// </summary>
        public string Domains
        {
            get
            {
                return _domains ?? string.Empty;
            }
            set
            {
                _domains = value;
                _domainsSplit = value.SplitString(',');
            }
        }

        /// <summary>
        /// Do we stop the page from executing, default true
        /// </summary>
        public bool StopPageExecution { get; set; }
        #endregion

        #region AuthorizeCore
        /// <summary>
        /// Override the Authorization approach to work with Sitecore
        /// </summary>
        /// <param name="httpContext">The httpContext that contains the user</param>
        /// <returns>Returns true if the user is authorized or false if not</returns>
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            return base.AuthorizeCore(httpContext)
                || Sitecore.Context.User.IsLoggedInPublic()
                || Sitecore.Context.IsAdministrator
                || Sitecore.Context.PageMode.IsExperienceEditor
                ||  _domainsSplit.Contains(Sitecore.Context.User.GetDomainName(), StringComparer.OrdinalIgnoreCase)
                || Sitecore.Context.User.GetDomainName().Equals("sitecore", StringComparison.OrdinalIgnoreCase);
        }
        #endregion

        #region HandleUnauthorizedRequest
        /// <summary>
        /// Override the Unauthorization request and how this needs to be managed
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (StopPageExecution)
            {
                // are we logged in
                if (Sitecore.Context.IsAdministrator
                    || Sitecore.Context.PageMode.IsExperienceEditor
                    || Sitecore.Context.User.IsLoggedInPublic())
                {
                    // fix up the response
                    filterContext.Result = new System.Web.Mvc.HttpStatusCodeResult((int)System.Net.HttpStatusCode.Forbidden);
                }
                else
                {
                    // call base do nothing for now
                    base.HandleUnauthorizedRequest(filterContext);
                }
            }
            else
            {
                filterContext.Result = new EmptyResult();
            }
        }
        #endregion
    }
}
