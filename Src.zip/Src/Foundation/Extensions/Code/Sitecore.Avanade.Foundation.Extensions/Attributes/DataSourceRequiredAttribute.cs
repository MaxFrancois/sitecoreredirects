﻿using Sitecore.Mvc.Presentation;
using System;
using System.Web.Mvc;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Extensions.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class DataSourceRequiredAttribute : ActionFilterAttribute
    {
        #region Properties
        /// <summary>
        /// Notes to pass to the rendering
        /// </summary>
        public string PageEditorNotes { get; set; }

        /// <summary>
        /// What is the partial view we want to render, defaults to EmptyDataSource.
        /// When setting make sure to set EmptyResults as false
        /// </summary>
        public string PartialView { get; set; } = Constants.DatasourceAttributes.EmptyDatasource;

        /// <summary>
        /// Do we want to show an empty result, defaults to true
        /// </summary>
        public bool EmptyResult { get; set; } = true;

        /// <summary>
        /// If we find no datasource or invalid source do we throw an error
        /// </summary>
        public bool ThrowError { get; set; }
        #endregion

        #region OnActionExecuting
        /// <summary>
        /// Runs when the controller is executed to ensure the datasource is valid
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // get the rendering context
            var renderingContext = RenderingContext.CurrentOrNull;
            
            // what is the rendering
            var rendering = renderingContext == null ? null : renderingContext.Rendering;

            // is the datasource valid
            bool isValid = false;
            bool isValidTemplate = false;

            // do we have data
            if (rendering?.RenderingItem?.InnerItem != null)
            {
                // get the datasource template field
                ReferenceField datasourceTemplateField = rendering.RenderingItem.InnerItem.Fields[Constants.DatasourceAttributes.DatasourceTemplateField];

                // get the template
                Item templateItem = datasourceTemplateField?.TargetItem;

                // we have a datasource
                if (!rendering.DataSource.IsNullOrEmpty())
                {
                    // we do have a target right
                    if (datasourceTemplateField != null
                        && templateItem != null
                        && rendering.Item != null)
                    {
                        // is the item being rendered a base template
                        isValid = rendering.Item.HasBaseTemplate(templateItem.ID);

                        // is it not valid
                        if (!isValid)
                        {
                            // indicate to our log that this is not valid
                            isValidTemplate = false;
                        }
                    }
                    else
                    {
                        // the datasource is valid
                        // we have not set a datasource template
                        isValid = true;
                    }
                }

                // are we valid
                if (!isValid)
                {
                    // when we are in experience editor mode, set to show the issue
                    if (Sitecore.Context.PageMode.IsExperienceEditor)
                    {
                        EmptyResult = false;
                    }

                    // setup our rendering information
                    var model = new RenderingInformation();

                    // Empty datasource information
                    model.RenderingName = rendering.RenderingItem.InnerItem.Paths.Path;
                    model.DataSourceType = templateItem != null
                        ? templateItem.Paths.Path
                        : String.Empty;

                    // Notes from the action attribute
                    model.AdditionalInformation = PageEditorNotes;

                    // are we showing an empty result or our datasource
                    if (EmptyResult)
                    {
                        filterContext.Result = new EmptyResult();
                    }
                    else
                    {
                        // Set the return value for the action
                        filterContext.Result = new PartialViewResult
                        {
                            ViewName = PartialView,
                            ViewData = new ViewDataDictionary(model)
                        };
                    }

                    // make sure we can log and that we are not throwing an error which will be captured
                    if (!ThrowError && Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsWarnEnabled)
                    {
                        // log the warning
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Rendering Datasource Failed: Page - '{renderingContext.ContextItem.Paths.Path}',Rendering - '{model.RenderingName}', Template - '{model.DataSourceType}', Invalid Template - '{isValidTemplate}'", typeof(DataSourceRequiredAttribute));
                    }

                    // are we going to throw an error
                    if (ThrowError)
                    {
                        // throw the error
                        throw new System.DataMisalignedException($"Rendering Datasource Failed: Page - '{renderingContext.ContextItem.Paths.Path}',Rendering - '{model.RenderingName}', Template - '{model.DataSourceType}', Invalid Template - '{isValidTemplate}'");
                    }
                }
            }

            // execute the ono action caller
            base.OnActionExecuting(filterContext);

        }
        #endregion
    }
}