﻿using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;
using System;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Extensions.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class FieldValueRequiredAttribute : ActionFilterAttribute
    {
        // Notes to pass to the empty rendering
        public string FieldName { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Retrieve the rendering context
            Item dataItem = null;
            var renderingContext = RenderingContext.CurrentOrNull;
            var rendering = renderingContext == null ? null : renderingContext.Rendering;

            // Pull the datasource item and fall back to the pagecontext item
            var datasource = rendering == null ? null : rendering.DataSource;

            // If there is no datasource then we're running off the page fields
            if (String.IsNullOrWhiteSpace(datasource))
            {
                var page = renderingContext == null ? null : renderingContext.PageContext;
                if (page != null) dataItem = page.Item;
            }
            // Datasource driven
            else
            {
                ID result;
                if (ID.TryParse(datasource, out result))
                {
                    dataItem = result.ToItem();
                }
            }

            // If we didn't find a datasource
            if (dataItem == null || !dataItem.HasValue(FieldName))
            {
                var model = new RenderingInformation();

                #region Page Editor only processing
                if (Context.PageMode.IsExperienceEditor && rendering != null)
                {
                    // Gleen some information about the rendering
                    var renderingItem = rendering.RenderingItem;

                    if (renderingItem != null)
                    {
                        // The DataSource template item
                        var template = renderingItem.InnerItem["Datasource Template"];

                        if (!String.IsNullOrWhiteSpace(template))
                        {
                            var sourceTemplate = renderingItem.InnerItem != null
                                ? renderingItem.InnerItem.Fields["Datasource Template"].TargetItem()
                                : null;
                            model.DataSourceType = sourceTemplate != null
                                ? sourceTemplate.DisplayName
                                : String.Empty;
                        }

                        // Empty datasource information
                        model.RenderingName = renderingItem.DisplayName;
                    }

                    // Notes from the action attribute
                    model.AdditionalInformation = FieldName;
                }
                #endregion

                // Set the return value for the action
                filterContext.Result = new PartialViewResult
                {
                    ViewName = "FieldMissing",
                    ViewData = new ViewDataDictionary(model)
                };
            }

            base.OnActionExecuting(filterContext);
        }
    }
}