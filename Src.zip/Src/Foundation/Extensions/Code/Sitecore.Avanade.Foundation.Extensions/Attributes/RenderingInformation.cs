﻿namespace Sitecore.Avanade.Foundation.Extensions.Attributes
{
    public class RenderingInformation
    {
        public string RenderingName { get; set; }
        public string DataSourceType { get; set; }
        public string AdditionalInformation { get; set; }
    }
}
