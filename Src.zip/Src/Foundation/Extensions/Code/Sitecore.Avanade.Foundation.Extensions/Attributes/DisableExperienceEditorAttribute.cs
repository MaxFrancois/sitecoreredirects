﻿using System;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Extensions.Attributes
{
    /// <summary>
    /// Disable the controller when in Experience Editor. You can also exclude other Pagemode States
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false)]
    public class DisableExperienceEditorAttribute : ActionFilterAttribute
    {
        #region Public Properties
        /// <summary>
        /// Are we going to disable this controller from Previews
        /// </summary>
        public bool DisableIsPreview { get; set; }

        /// <summary>
        /// Are we going to disable this controller from Debug
        /// </summary>
        public bool DisableIsDebug { get; set; }

        /// <summary>
        /// Are we going to disable this controller from Simulated Device Previews
        /// </summary>
        public bool DisableIsSimulatedDevicePreviewing { get; set; }

        /// <summary>
        /// Are we going to disable this controller from Profiling
        /// </summary>
        public bool DisableIsProfiling { get; set; }
        #endregion

        #region OnActionExecuting
        /// <summary>
        /// On the execution what are we doing
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            #region Disable ExperienceEditor
            // have we indidcated we are 
            if (Context.PageMode.IsExperienceEditor
                || (DisableIsDebug && Context.PageMode.IsDebugging)
                || (DisableIsPreview && Context.PageMode.IsPreview)
                || (DisableIsProfiling && Context.PageMode.IsProfiling)
                || (DisableIsSimulatedDevicePreviewing && Context.PageMode.IsSimulatedDevicePreviewing)
                )
            {
                // Set the return value for the action
                filterContext.Result = new EmptyResult();
            }
            #endregion

            base.OnActionExecuting(filterContext);
        }
        #endregion
    }
}