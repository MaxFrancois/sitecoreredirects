﻿using System;

namespace Sitecore.Avanade.Foundation.Extensions.Helpers
{
    public static class BooleanHelper
    {
        #region ConvertToBoolean
        /// <summary>
        /// This will convert different types of string types to boolean.
        /// This list is:
        ///		- yes/no
        ///		- y/n
        ///		- on/off
        ///		- true/false
        ///		- 0/1
        /// </summary>
        /// <param name="requiredItem">The actual character or word you want to process.</param>
        /// <returns>Returns either true or false in boolean</returns>
        public static bool ConvertToBoolean(object requiredItem, bool defaultValue = false)
        {
            // make sure everything is fine
            if (requiredItem != null)
            {
                // make sure we check that it is a valid bool first
                if (requiredItem is bool)
                {
                    return (bool)requiredItem;
                }

                // set default
                bool itemProcess = defaultValue;

                // get the item type
                Type itemType = requiredItem.GetType();

                // is the item a string type
                if (itemType.Equals(typeof(string)) || itemType.Equals(typeof(System.String)))
                {
                    // set the item as a string
                    string itemString = (string)requiredItem;

                    if (!itemString.IsNullOrEmpty())
                    {
                        string lowerItemString = itemString.ToLower();

                        // if it starts with "o" then we are dealing with on and off.
                        if (lowerItemString.StartsWith("o"))
                        {
                            // what item are we looking at
                            switch (lowerItemString)
                            {
                                case "on": itemProcess = true; break;
                                default: itemProcess = false; break;
                            }
                        }
                        else
                        {
                            // determine what item it is
                            switch (lowerItemString[0].ToString())
                            {
                                case "y":
                                case "t":
                                case "1":
                                    itemProcess = true;
                                    break;

                                default: itemProcess = false; break;
                            }
                        }
                    }

                    // return the data
                    return itemProcess;
                }
                else
                {
                    // we have to try and convert because of issues
                    try
                    {
                        // wrapp a try and catch just in case
                        itemProcess = (bool)System.Convert.ChangeType(requiredItem, typeof(bool));
                    }
                    catch (System.Exception ex)
                    {
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Trying to convert to Bool failed", ex, typeof(BooleanHelper));
                    }

                    return itemProcess;
                }
            }

            // we don't know what it is
            return defaultValue;
        }
        #endregion
    }
}
