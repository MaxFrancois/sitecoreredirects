﻿using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Items;
using System;
using System.Text.RegularExpressions;

namespace Sitecore.Avanade.Foundation.Extensions.Helpers
{
    public static class ItemHelper
    {
               /// <summary>
        /// Gets Single Item by XPath
        /// </summary>
        /// <param name="xPath">The x path.</param>
        /// <returns></returns>
        public static Item GetItemByXPath(string xPath)
        {
            xPath = CleanXPath(xPath);
            return Context.Database.SelectSingleItem(xPath);
        }

        /// <summary>
        /// Cleans xpath and adds # if there are dashs within the xpath.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string CleanXPath(string s)
        {
            var scQuery = s;

            //loop through each match and replace it in the query with the escaped pattern
            char[] splitArr = { '/' };
            var strArr = scQuery.Split(splitArr);

            // search for guid
            string re1 = Constants.RegExStrings.NonGreedyMatch; // Non-greedy match on filler
            string re2 = Constants.RegExStrings.GUID; // GUID

            var regEx = new Regex(re1 + re2, RegexOptions.IgnoreCase | RegexOptions.Singleline);

            for (var z = 0; z <= strArr.Length - 1; z++)
            {
                var m = regEx.Match(strArr[z]);

                //if it contains a dash and it's not a guid
                if (!m.Success && strArr[z].Contains("-"))
                {
                    strArr[z] = "#" + strArr[z] + "#";
                }
            }
            scQuery = string.Join("/", strArr);

            return scQuery;
        }

        /// <summary>
        /// Get a Sitecore item from a Lucene Id
        /// </summary>
        /// <param name="luceneId"></param>
        /// <returns></returns>
        public static Sitecore.Data.Items.Item GetItemFromLuceneId(string luceneId)
        {
            var uri = new ItemUri(luceneId);
            
            return Factory.GetDatabase(uri.DatabaseName).GetItem(uri.ItemID, uri.Language, uri.Version);
        }

        private static Type _stringType = typeof(System.String);

        #region GetItem
        /// <summary>
        /// Gets the item from the iterator
        /// </summary>
        /// <param name="iterator">The iterator to get the item from.</param>
        /// <returns>Returns the item to process.</returns>
        public static Sitecore.Data.Items.Item GetItem(System.Xml.XPath.XPathNodeIterator iterator)
        {

            if (iterator != null && iterator.MoveNext())
            {
                // get the attribute
                System.Xml.XPath.XPathNavigator navItem = iterator.Current;

                // make sure we have data
                if (navItem != null && navItem.HasAttributes)
                {
                    // get the itemid and return the item
                    string itemId = iterator.Current.GetAttribute("id", "");
                    return GetItem(itemId);
                }
            }

            return null;

        }

        /// <summary>
        /// Gets the Item from the necessary database
        /// </summary>
        /// <param name="dataItem">The object to fetch</param>
        /// <param name="databaseName">The name of the database</param>
        /// <returns>Returns the item or an empty Item</returns>
        public static Sitecore.Data.Items.Item GetItem(object dataItem, string databaseName, string languageName = "")
        {
            Sitecore.Globalization.Language lang = null;

            if (!string.IsNullOrEmpty(languageName))
            {
                lang = Sitecore.Globalization.Language.Parse(languageName);
            }

            // is the database valid, might not have to get the data
            if (Sitecore.Context.Database != null && Sitecore.Context.Database.Name.Equals(databaseName, StringComparison.OrdinalIgnoreCase))
            {
                return GetItem(dataItem, Sitecore.Context.Database, lang);
            }

            // get the item
            return GetItem(dataItem, Sitecore.Data.Database.GetDatabase(databaseName), lang);
        }

        /// <summary>
        /// Get the item from a dataItem.
        /// </summary>
        /// <param name="dataItem">The data item we want to get the item from.</param>
        /// <param name="database">The database to use</param>
        /// <param name="lang">The language to use to get the item</param>
        /// <returns>Returns a sitecore item or null.</returns>
        public static Sitecore.Data.Items.Item GetItem(object dataItem, Sitecore.Data.Database database = null, Sitecore.Globalization.Language lang = null)
        {
            // make sure we have a database to work with
            if (database == null
                || Sitecore.Context.Database != null)
            {
                database = Sitecore.Context.Database;
            }

            // default item
            Sitecore.Data.Items.Item item = null;

            if (dataItem != null)
            {
                // what type are we working with
                if (dataItem.GetType().Equals(typeof(System.Collections.DictionaryEntry)))
                {
                    // get the item from the dictionary entry
                    System.Collections.DictionaryEntry dicEntry = (System.Collections.DictionaryEntry)dataItem;
                    item = dicEntry.Value as Sitecore.Data.Items.Item;
                }
                else if (dataItem.GetType().Equals(_stringType))
                {
                    string itm = dataItem.ToString();

                    if (itm.IsNullOrEmpty())
                    {
                        return item;
                    }

                    // make sure we have a path
                    if (itm.StartsWith("/"))
                    {
                        item = GetItemFromPath(itm, database);
                    }
                    else if (itm.IsGuid())
                    {
                        // the item is a string so it must be an id
                        Sitecore.Data.ID itmId = new Sitecore.Data.ID(itm);

                        if (lang != null)
                        {
                            item = database.GetItem(itmId, lang);
                        }
                        else
                        {
                            item = database.GetItem(itmId);
                        }
                    }
                    else if (itm.StartsWith("<"))
                    {
                        // is xml
                        Sitecore.Data.Items.Item[] itmList = Sitecore.Data.Items.ItemSerializer.ParseItemXml(itm, database, false);

                        if (itmList != null && itmList.Length > 0)
                        {
                            item = itmList[0];
                        }
                    }
                }
                else if (dataItem.GetType().Equals(typeof(System.Guid)))
                {
                    if (lang != null)
                    {
                        item = database.GetItem(Sitecore.Data.ID.Parse(dataItem), lang);
                    }
                    else
                    {
                        item = database.GetItem(Sitecore.Data.ID.Parse(dataItem));
                    }
                }
                else if (dataItem.GetType().Equals(typeof(Sitecore.Data.ID)))
                {
                    if (lang != null)
                    {
                        item = database.GetItem((Sitecore.Data.ID)dataItem, lang);
                    }
                    else
                    {
                        item = database.GetItem((Sitecore.Data.ID)dataItem);
                    }
                }
                else
                {
                    // the item is actually an item
                    item = dataItem as Sitecore.Data.Items.Item;
                }
            }

            // always return an item or null
            return item;
        }
        #endregion

        #region GetItemFromPath
        /// <summary>
        /// 
        /// </summary>
        /// <param name="itemPath"></param>
        /// <param name="databaseName"></param>
        /// <returns></returns>
        public static Sitecore.Data.Items.Item GetItemFromPath(string itemPath, Sitecore.Data.Database database)
        {
            if (database != null)
            {
                return database.GetItem(itemPath);
            }

            return GetItemFromPath(itemPath);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="itemPath"></param>
        /// <param name="databaseName"></param>
        /// <returns></returns>
        public static Sitecore.Data.Items.Item GetItemFromPath(string itemPath, string databaseName)
        {
            // make sure we don't have to do any real work
            if (Sitecore.Context.Database != null && Sitecore.Context.Database.Name == databaseName)
            {
                return GetItemFromPath(itemPath);
            }

            // get the database
            Sitecore.Data.Database database = Sitecore.Configuration.Factory.GetDatabase(databaseName);
            return database.GetItem(itemPath);
        }

        /// <summary>
        /// This will get the item from the path. If the path doesn't start with /sitecore then the
        /// method will automatically add the start path.
        /// </summary>
        /// <param name="itemPath">The item path</param>
        /// <returns></returns>
        public static Sitecore.Data.Items.Item GetItemFromPath(string itemPath)
        {
            // does the item start with /sitecore
            if (!itemPath.StartsWith(Sitecore.Constants.SitecorePath))
            {
                // get the correct path
                itemPath = Sitecore.Context.Site.StartPath + itemPath;
            }

            // if we don't have a database set it to the web
            if (Sitecore.Context.Database == null)
            {
                return Sitecore.Context.Site.Database.GetItem(itemPath);
            }
            else
            {
                // return the item
                return Sitecore.Context.Database.GetItem(itemPath);
            }
        }
        #endregion
    }
}
