﻿using System;
using System.Collections.Specialized;
using System.Web;
using System.Web.Routing;
using Sitecore.Diagnostics;

namespace Sitecore.Avanade.Foundation.Extensions.Helpers
{
    public static class UriHelper
    {
        public static string AppendQueryString(Uri uri, string parameter, string value)
        {
            var builder = AppendQueryStringToUri(uri, parameter, value);
            return builder.AbsoluteUri;
        }

        public static Uri AppendQueryStringToUri(Uri uri, string parameter, string value)
        {
            if (uri == null || parameter == null || value == null)
            {
                if (Sitecore.Diagnostics.Log.IsDebugEnabled)
                {
                    Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Sitecore.Avanade.Foundation.Extensions.Helpers.AppendQueryStringToUri : a null parameter was parsed.");
                }
                return null;
            }

            var builder = new UriBuilder(uri);
            builder.Query += (string.IsNullOrWhiteSpace(builder.Query) ? "" : "&amp;") + parameter + "=" + HttpUtility.UrlEncode(value);

            return builder.Uri;
        }

        public static string UpdateOrAppendQueryStrings(Uri uri, object parameters)
        {
            if (uri == null || parameters == null)
            {
                if (Sitecore.Diagnostics.Log.IsDebugEnabled)
                {
                    Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Sitecore.Avanade.Foundation.Extensions.Helpers.UpdateOrAppendQueryStrings : a null parameter was parsed.");
                }
                return string.Empty;
            }

            var builder = new UriBuilder(uri);
            var values = new RouteValueDictionary(parameters);
            var nameValues = HttpUtility.ParseQueryString(builder.Query);

            foreach (var param in values.Keys)
            {
                nameValues.Set(param, values[param] != null ? values[param].ToString() : string.Empty);
            }

            builder.Query = nameValues.ToString();
            return builder.Uri.AbsoluteUri;
        }
        
        public static string UpdateOrAppendQueryStrings(Uri uri, NameValueCollection parameters)
        {
            if (uri == null || parameters == null)
            {
                if (Sitecore.Diagnostics.Log.IsDebugEnabled)
                {
                    Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions] Sitecore.Avanade.Foundation.Extensions.Helpers.UpdateOrAppendQueryStrings : a null parameter was parsed.");
                }
                return string.Empty;
            }

            var builder = new UriBuilder(uri);
            var nameValues = HttpUtility.ParseQueryString(builder.Query);

            foreach (var key in parameters.AllKeys)
            {
                nameValues.Set(key, parameters[key] ?? string.Empty);
            }

            builder.Query = nameValues.ToString();
            return builder.Uri.AbsoluteUri;
        }

        /// <summary>
        /// Gets a Uri from a valid url string, returns null if unable to create uri object
        /// </summary>
        /// <returns></returns>
        public static Uri ToUri(this string url)
        {
            //default uri to null
            Uri uri = null;

            //if we have a url try creating the uri object
            if (!string.IsNullOrWhiteSpace(url))
            {
                try
                {
                    uri = new Uri(url);
                }
                catch (UriFormatException exception)
                {
                    //Invalid uri
                    Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: ToUri - Cannot create uri from url string:" + url, exception);
                }
            }

            return uri;
        }
    }
}
