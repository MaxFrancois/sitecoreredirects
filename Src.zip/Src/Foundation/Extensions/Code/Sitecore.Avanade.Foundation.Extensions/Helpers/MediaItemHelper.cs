﻿using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Globalization;
using Sitecore.IO;
using Sitecore.Resources.Media;
using System;
using System.IO;

namespace Sitecore.Avanade.Foundation.Extensions.Helpers
{
    public static class MediaItemHelper
    {
        #region GetMediaUrl
        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="img">The image to process</param>
        /// <param name="fullURL">Do we need this set as a full url</param>
        /// <param name="options">The Media URL options</param>
        /// <returns>Returns a valid URL</returns>
        public static string GetMediaUrl(FileField flf,
            bool fullURL = false,
            MediaUrlOptions options = null)
        {
            if (flf != null)
            {
                // is the media a full url
                return GetMediaUrl(flf.MediaItem, fullURL, options);
            }

            return string.Empty;
        }
        

        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="img">The image to process</param>
        /// <param name="fullURL">Do we need this set as a full url</param>
        /// <param name="options">The Media URL options</param>
        /// <returns>Returns a valid URL</returns>
        public static string GetMediaUrl(ImageField img,
            bool fullURL = false,
            MediaUrlOptions options = null)
        {
            if (img != null)
            {
                // is the media a full url
                return GetMediaUrl(img.MediaItem, fullURL, options);
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="medItm">The MediaItem to pass in, this can also be a Sitecore Item</param>
        /// <param name="options">The Media URL options</param>
        /// <param name="fullURL">Is the Full URL Required</param>
        /// <returns>Returns the correct path</returns>
        public static string GetMediaUrl(MediaItem medItm,
            bool fullURL = false,
            MediaUrlOptions options = null)
        {
            if (medItm != null)
            {
                if (options == null)
                    options = new MediaUrlOptions();

                options.AlwaysIncludeServerUrl = fullURL;

                // get the media url
                return fullURL ? MediaManager.GetMediaUrl(medItm, options) : StringUtil.EnsurePrefix('/', MediaManager.GetMediaUrl(medItm, options));
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="itm">The item containing the media field</param>
        /// <param name="fieldName">The field that's a media link</param>
        /// <param name="options">The Media URL options</param>
        /// <param name="fullURL">Is the Full URL Required</param>
        /// <returns>Returns the correct path</returns>
        public static string GetMediaUrl(Item itm,
            string fieldName,
            bool fullURL = false,
            MediaUrlOptions options = null)
        {
            if (itm != null && !string.IsNullOrEmpty(fieldName))
            {
                Field fld = itm.Fields[fieldName];

                return GetMediaUrl(fld, fullURL, options);
            }

            return string.Empty;
        }
        
        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="fld">The Field to get the Media URL</param>
        /// <param name="fullURL">Is the Full URL Required</param>
        /// <returns>Returns the correct path</returns>
        public static string GetMediaUrl(Field fld,
            bool fullURL = false,
            MediaUrlOptions options = null)
        {
            if (fld != null)
            {
                // converts to media item
                MediaItem mediaItem = fld.ConvertToMediaItem();

                if (mediaItem != null)
                {
                    // gets the data
                    return GetMediaUrl(mediaItem, fullURL, options);
                }
            }

            // error or not a media item
            return string.Empty;
        }
        #endregion

        #region UploadMedia
        public static Item UploadMedia(byte[] fileBuffer, string fullMediaPath, string fileNameWithExtension, string title, Language language)
        {
            var db = Configuration.Factory.GetDatabase("master");

            var options = new MediaCreatorOptions();
            options.FileBased = false;
            options.IncludeExtensionInItemName = false;
            options.OverwriteExisting = true;
            options.Versioned = true;
            options.Destination = fullMediaPath;
            options.Database = db;
            options.Language = language;

            Item newItem = null;
            try
            {
                
                var fileStream = new MemoryStream(fileBuffer);

                var currentMediaItem = db.GetItem(fullMediaPath, language);
                if (currentMediaItem != null)
                {
                    var mediaItem = new MediaItem(currentMediaItem);
                    if (mediaItem.FileBased)
                    {
                        string uniqueFilename = FileUtil.GetUniqueFilename(FileUtil.MakePath(Configuration.Settings.Media.FileFolder, MediaManager.Creator.GetMediaStorageFolder(mediaItem.ID, fullMediaPath)));
                        using (new SecurityModel.SecurityDisabler())
                        {
                            mediaItem.BeginEdit();
                            mediaItem.FilePath = uniqueFilename;
                            mediaItem.EndEdit();
                        }
                    }
                    Media media = MediaManager.GetMedia(mediaItem);
                    
                    media.SetStream(fileStream, FileUtil.GetExtension(fileNameWithExtension));
                    currentMediaItem.Editing.BeginEdit();
                    currentMediaItem.Fields["Title"].Value = title;
                    currentMediaItem.Editing.EndEdit();
                    return currentMediaItem;
                }
                else
                {
                    var creator = new MediaCreator();
                    //Create a new item
                    newItem = creator.CreateFromStream(fileStream, fileNameWithExtension, options);
                    newItem.Editing.BeginEdit();
                    newItem.Fields["Title"].Value = title;
                    newItem.Editing.EndEdit();
                }
            }
            catch (Exception e)
            {
                if (Log.IsDebugEnabled)
                    Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Error uploading image", e, typeof(MediaItemHelper));
            }

            return newItem;
        }
        #endregion
    }
}
