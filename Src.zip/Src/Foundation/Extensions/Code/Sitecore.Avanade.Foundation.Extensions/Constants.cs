﻿namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class Constants
    {
        public static class SitecoreConstants
        {
            public static readonly string NoDBName = "NoDBName";

            public static readonly string NoLangName = "NoLangName";

            public static readonly string NoSiteName = "NoSiteName";

            /// <summary>
            /// The Visitor Information path
            /// </summary>
            public static readonly string VisitorIdentification = "/layouts/system/visitoridentification";

            /// <summary>
            /// The keep alive that is actioned  internally by Sitecore
            /// </summary>
            public static readonly string KeepAlive = "/keepalive";

#pragma warning disable S1075 // URIs should not be hardcoded
            /// <summary>
            /// The Sitecore Templates path
            /// </summary>
            public static readonly string TemplatePath = "/sitecore/templates/";
#pragma warning restore S1075 // URIs should not be hardcoded

            /// <summary>
            /// The name of the master DB. 
            /// </summary>
            public static readonly string MasterDBName = "master";

            /// <summary>
            /// The name of the web DB
            /// </summary>
            public static readonly string WebDBName = "web";

            /// <summary>
            /// The query string key for the sitecore item ID
            /// </summary>
            public static readonly string SitecoreItemIDQSKey = "sc_item";

            /// <summary>
            /// The Internal Link Property name
            /// </summary>
            public static readonly string InternalLinkPropertyName = "internal link";

            /// <summary>
            /// The General Link Property Name
            /// </summary>
            public static readonly string GeneraLinkPropertyName = "general link";

            /// <summary>
            /// The External Link Type Name
            /// </summary>
            public static readonly string ExternalLinkTypeName = "external";

            /// <summary>
            /// The MailTo Link Type Name
            /// </summary>
            public static readonly string MailtoLinkTypeName = "mailto";

            /// <summary>
            /// The Javascript Link Type Name
            /// </summary>
            public static readonly string JavascriptLinkTypeName = "javascript";

            /// <summary>
            /// The Empty string when no rules are found, this can still be empty so perform this check and empty string
            /// </summary>
            public static readonly string EmptyRuleFieldValue = "<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n<ruleset />";
        }

        public static class DatasourceAttributes
        {
            public static readonly string DatasourceTemplateField = "Datasource Template";
            public static readonly string EmptyDatasource = "EmptyDataSource";
        }

        public static class RegExStrings
        {
            /// <summary>
            /// The RegEx string to detect GUID's
            /// </summary>
            public static readonly string GUID = "([A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12})";

            /// <summary>
            /// The 'Non-Greedy' RegEx string
            /// </summary>
            public static readonly string NonGreedyMatch = ".*?";
        }
    }
}
