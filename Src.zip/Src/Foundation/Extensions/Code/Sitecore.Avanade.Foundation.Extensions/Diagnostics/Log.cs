﻿using System.ComponentModel;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Extensions.Diagnostics
{
    /// <summary>
    /// Indicates basic logger details
    /// </summary>
    public static class Log
    {
        #region Private Variables
        private static bool _isDebugEnabled = false;
        private static bool _isInfoEnabled = false;
        private static bool _isErrorEnabled = false;
        private static bool _isWarnEnabled = false;
        private static bool _isFatalEnabled = false;
        private static string _logPrefix = "[Sitecore AI]: ";
        #endregion

        #region Static Properties
        /// <summary>
        /// The Log Prefix used for any logging within the AI code.
        /// This outputs the followin "[Sitecore AI]: "
        /// </summary>
        public static string LogPrefix { get { return _logPrefix; } }

        /// <summary>
        /// Is debugging logs enabled
        /// </summary>
        public static bool IsDebugEnabled
        {
            get
            {
                return _isDebugEnabled;
            }
        }

        /// <summary>
        /// Is info logs enabled
        /// </summary>
        public static bool IsInfoEnabled
        {
            get
            {
                return _isInfoEnabled;
            }
        }

        /// <summary>
        /// Are errors enabled
        /// </summary>
        public static bool IsErrorEnabled
        {
            get
            {
                return _isErrorEnabled;
            }
        }

        /// <summary>
        /// is Warning enabled
        /// </summary>
        public static bool IsWarnEnabled
        {
            get
            {
                return _isWarnEnabled;
            }
        }

        /// <summary>
        /// Is Fatal enabled
        /// </summary>
        public static bool IsFatalEnabled
        {
            get
            {
                return _isFatalEnabled;
            }
        }
        #endregion

        #region Static Instance
        /// <summary>
        /// Determines if the logger has been enabled
        /// </summary>
        static Log()
        {
            // quickly check to see if logs are enabled
            if (Sitecore.Diagnostics.Log.Enabled)
            {
                // get the logger
                var logger = Sitecore.Diagnostics.LoggerFactory.GetLogger(typeof(Log));

                // make sure we have our logger
                if (logger != null)
                {
                    // double check everything is enabled
                    _isDebugEnabled = logger.IsDebugEnabled;
                    _isErrorEnabled = logger.IsErrorEnabled;
                    _isFatalEnabled = logger.IsFatalEnabled;
                    _isInfoEnabled = logger.IsInfoEnabled;
                    _isWarnEnabled = logger.IsWarnEnabled;
                }
            }
        }
        #endregion

        #region SetRepositoryLevel
        /// <summary>
        /// Set the repository levels required for the appropriate logger or all loggers
        /// </summary>
        /// <param name="level"></param>
        /// <param name="loggerName">If empty all loggers will be set to the level</param>
        /// <returns></returns>
        public static void SetRepositoryLevel(Levels level, string loggerName = "")
        {
            // get the ilogger repositories
            log4net.Repository.ILoggerRepository[] repositories = log4net.LogManager.GetAllRepositories();

            // make sure we have d ata
            if (repositories != null
                && repositories.Length > 0)
            {
                // are we only fixing a single logger
                if (loggerName.IsNullOrEmpty())
                {
                    // get the repo out
                    var repo = repositories.FirstOrDefault(x => x.Name.Equals(loggerName, System.StringComparison.OrdinalIgnoreCase));

                    // set the level for  the logger
                    SetLoggerLevel(repo, level);
                }
                else
                {
                    // cycle over the loggers
                    repositories.ForEach(x =>
                    {
                        SetLoggerLevel(x, level);
                    });
                }
            }
        }

        /// <summary>
        /// Set the Logger Levels
        /// </summary>
        /// <param name="repository"></param>
        /// <param name="level"></param>
        private static void SetLoggerLevel(log4net.Repository.ILoggerRepository repository, Levels level)
        {
            // make sure to set the threshold levels
            repository.Threshold = repository.LevelMap[level.Description()];

            // make sure to find the listin gof loggers
            log4net.Repository.Hierarchy.Hierarchy hier = (log4net.Repository.Hierarchy.Hierarchy)repository;
            
            // get listing of current loggers for this
            log4net.spi.ILogger[] loggers = hier.GetCurrentLoggers();

            // cycle over the loggers
            loggers.ForEach(x =>
            {
                // set the correct level
                ((log4net.Repository.Hierarchy.Logger)x).Level = hier.LevelMap[level.Description()];
            });
        }
        #endregion

        #region Levels
        /// <summary>
        /// Set the Log4Net Levels
        /// </summary>
        public enum Levels
        {
            [Description("DEBUG")]
            Debug,
            [Description("INFO")]
            Info,
            [Description("WARN")]
            Warn,
            [Description("ERROR")]
            Error,
            [Description("FATAL")]
            Fatal
        }
        #endregion
    }
}
