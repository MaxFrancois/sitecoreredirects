﻿using System.ComponentModel;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.Extensions.TypeConverters
{
    public class StringUrlDecodeConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                return System.Web.HttpUtility.HtmlDecode(value as string);
            }

            return base.ConvertFrom(context, culture, value);
        }
    }
}