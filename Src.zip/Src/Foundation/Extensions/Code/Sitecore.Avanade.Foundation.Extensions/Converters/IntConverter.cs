﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.Extensions.Converters
{
    public class IntConverter : TypeConverter
    {
        /// <summary>
        /// This will convert any string over to an int.
        /// If this can not be converted it will default to 0
        /// </summary>
        /// <example>[TypeConverter(typeof(intConverter))]</example>
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
                return true;

            return base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                // default
                int data = 0;
                try
                {
                    data = System.Convert.ToInt32(value);
                }
                catch (System.FormatException fex)
                {
                    Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Format Exception to Int '{value}'", fex, typeof(IntConverter));
                }
                catch (System.InvalidCastException icex)
                {
                    Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Invalid Cast Exception to Int '{value}'", icex, typeof(IntConverter));
                }
                catch (System.OverflowException ofex)
                {
                    Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Overflow Exception to Int '{value}'", ofex, typeof(IntConverter));
                }
                catch (System.Exception ex)
                {
                    Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Exception to Int '{value}'", ex, typeof(IntConverter));
                }

                return data;
            }

            return base.ConvertFrom(context, culture, value);
        }
    }
}
