﻿using System;
using System.ComponentModel;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.Extensions.Converters
{
    /// <summary>
    /// Converts any form of string over to a Boolean.
    /// If the data can not be converted it will default to false
    /// </summary>
    /// <example>[TypeConverter(typeof(BooleanConverter))]</example>
    public class BooleanConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof(string))
                return true;

            return base.CanConvertFrom(context, sourceType);
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                return Helpers.BooleanHelper.ConvertToBoolean(value, false);
            }

            return base.ConvertFrom(context, culture, value);
        }
    }
}
