﻿using System.Reflection;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class ReflectionExtensions
    {
        #region GetPropertyValue
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static T GetPropertyValue<T>(this object entity, string propertyName)
        {
            T result = default(T);
            if (entity == null || string.IsNullOrEmpty(propertyName))
            {
                return result;
            }
            PropertyInfo property = entity.GetType().GetProperty(propertyName);
            if (property != null && typeof(T).IsAssignableFrom(property.PropertyType))
            {
                return (T)(property.GetValue(entity));
            }
            return result;
        }
        #endregion
    }
}
