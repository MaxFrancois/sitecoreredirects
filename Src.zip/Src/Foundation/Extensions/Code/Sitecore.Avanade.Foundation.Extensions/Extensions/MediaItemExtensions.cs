﻿using Sitecore.Data.Items;
using System.IO;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class MediaItemExtensions
    {
        #region IsMediaItem
        /// <summary>
        /// Check if the item specified is a media item
        /// </summary>
        /// <param name="itm">item to check</param>
        /// <returns>true if the specified item is a media item, any issues returns false</returns>
        public static bool IsMediaItem(Sitecore.Data.Items.Item itm)
        {
            if (itm != null)
            {
                return itm.Paths.IsMediaItem;
            }

            return false;
        }
        #endregion

        #region MediaItemUrl
        /// <summary>
        /// Gets the Media URL
        /// </summary>
        /// <param name="item">The Media Item to process</param>
        /// <param name="fullURL">Is the full URL required</param>
        /// <returns>Returns the Valid URL</returns>
        public static string MediaItemUrl(this MediaItem item, bool fullURL = false, Sitecore.Resources.Media.MediaUrlOptions options = null)
        {
            if (item != null)
            {
                return Foundation.Extensions.Helpers.MediaItemHelper.GetMediaUrl(item, fullURL, options);
            }

            return string.Empty;
        }
        #endregion

        #region ReadAllText
        /// <summary>
        /// Read the file from Sitecore
        /// </summary>
        /// <param name="item">The media item to process</param>
        /// <returns>Returns the Text of the Media Item</returns>
        public static string ReadAllText(this MediaItem item)
        {
            // defaults
            string fileOutput = string.Empty;

            // get the file stream
            using (var reader = new StreamReader(item.GetMediaStream()))
            {
                fileOutput = reader.ReadToEnd();
            }

            return fileOutput;
        }
        #endregion
    }
}
