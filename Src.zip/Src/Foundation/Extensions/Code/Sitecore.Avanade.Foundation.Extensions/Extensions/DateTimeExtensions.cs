﻿using Sitecore.Configuration;
using System;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class DateTimeExtensions
    {
        #region UtcDateTimeToDateTime
        /// <summary>
        /// Use this to output the correct DateTime object from a UTC datetime object, which is how Sitecore stores DateTime
        /// </summary>
        /// <param name="dateTime">The DateTime object built from a Sitecore Date field.</param>
        /// <returns></returns>
        public static DateTime UtcDateTimeToDateTime(this DateTime dateTime)
        {
            return DateUtil.ToServerTime(dateTime);
        }
        #endregion

        #region SitecoreDateTime
        /// <summary>
        /// Confirms that the datetime is the correct display datetime.
        /// This will either return the Preview DateTime or the passed in datetime
        /// </summary>
        /// <param name="dt">The DateTime to process</param>
        /// <param name="leaveUtc">Do we leave the format as UTC</param>
        /// <returns>Returns the Preview DateTime or the Supplied DateTime</returns>
        public static DateTime SitecoreDateTime(this DateTime dt, bool leaveUtc = false)
        {
            // are we in preview mode
            if (State.Previewing)
            {
                if (leaveUtc)
                {
                    return State.PreviewDate;
                }

                // make sure it is valid
                return State.PreviewDate.UtcDateTimeToDateTime();
            }

            return dt;
        }
        #endregion
    }
}
