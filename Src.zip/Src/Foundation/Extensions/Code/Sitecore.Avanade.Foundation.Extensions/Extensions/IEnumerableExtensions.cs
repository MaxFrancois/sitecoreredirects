﻿using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;

namespace Sitecore.Avanade.Foundation.Extensions
{
    /// <summary>
    /// IEnumerable Extension methods
    /// </summary>
    public static class IEnumerableExtensions
    {
        #region ForEach
        /// <summary>
        /// Executes a for each under the hood
        /// </summary>
        /// <typeparam name="T">The type to process</typeparam>
        /// <param name="array">The Enumerable to process</param>
        /// <param name="act">The action to perform</param>
        /// <param name="forward">Are we going forward through the list (default) or backwards. If going backwards this can be a minor decrease in speed</param>
        /// <returns>Returns the enumerable</returns>
        public static IEnumerable<T> ForEach<T>(this IEnumerable<T> enumerable, Action<T> act, bool forward = true)
        {
            // make sure we have the data to process
            if (enumerable != null)
            {
                // are we going fowards or backwards
                if (forward)
                {
                    // process each item
                    foreach (T item in enumerable)
                    {
                        act(item);
                    }
                }
                else
                {
                    for (int i = enumerable.Count() - 1; i >= 0; i--)
                    {
                        act(enumerable.ElementAt(i));
                    }
                }
            }

            return enumerable;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="RT"></typeparam>
        /// <param name="array"></param>
        /// <param name="func"></param>
        /// /// <param name="forward">Are we going forward through the list (default) or backwards. If going backwards this can be a minor decrease in speed</param>
        /// <returns></returns>
        public static IEnumerable<RT> ForEach<T, RT>(this IEnumerable<T> array, Func<T, RT> func, bool forward = true)
        {
            var list = new List<RT>();

            // are we going fowards or backwards
            if (forward)
            {
                foreach (var i in array)
                {
                    var obj = func(i);
                    if (obj != null)
                    {
                        list.Add(obj);
                    }
                }
            }
            else
            {
                for (int i = array.Count() - 1; i >= 0; i--)
                {
                    var obj = func(array.ElementAt(i));
                    if (obj != null)
                    {
                        list.Add(obj);
                    }
                }
            }
            return list;
        }
        #endregion

        #region DistinctBy
        /// <summary>
        /// Allows function to determine the distinction between collectino data. You need to source the key you want to use.
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TKey"></typeparam>
        /// <param name="source"></param>
        /// <param name="keySelector"></param>
        /// <returns></returns>
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> knownKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (knownKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }
        #endregion

        #region ToList
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="seq"></param>
        /// <returns>List of {T} or null</returns>
        public static List<T> ToListOrNull<T>(this IEnumerable<T> seq)
        {
            var result = seq.ToList();
            return result.Any() ? result : null;
        }
        #endregion

        #region Convert
        // convert an enumeration of one type into an enumeration of another type
        public static IEnumerable<TOut> Convert<TIn, TOut>(this IEnumerable<TIn> input, Func<TIn, TOut> conversion)
        {
            foreach (TIn value in input)
            {
                yield return conversion(value);
            }
        }
        #endregion

        #region Delimit
        // concatenate the strings in an enumeration separated by the specified delimiter
        public static string Delimit<T>(this IEnumerable<T> input, string delimiter)
        {
            IEnumerator<T> enumerator = input.GetEnumerator();

            if (enumerator.MoveNext())
            {
                StringBuilder builder = new StringBuilder();

                // start off with the first element
                builder.Append(enumerator.Current);

                // append the remaining elements separated by the delimiter
                while (enumerator.MoveNext())
                {
                    builder.Append(delimiter);
                    builder.Append(enumerator.Current);
                }

                return builder.ToString();
            }
            else
            {
                return string.Empty;
            }
        }
        #endregion

        #region ToString
        // concatenate all elements
        public static string ToString<T>(this IEnumerable<T> input)
        {
            return ToString(input, string.Empty);
        }

        // concatenate all elements separated by a delimiter
        public static string ToString<T>(this IEnumerable<T> input, string delimiter)
        {
            return input.Delimit(delimiter);
        }

        // concatenate all elements, each one left-padded to a minimum length
        public static string ToString<T>(this IEnumerable<T> input, int minLength, char paddingChar)
        {
            return input.Convert(i => i.ToString().PadLeft(minLength, paddingChar)).Delimit(string.Empty);
        }
        #endregion

        #region SortBySitecore
        /// <summary>
        /// Sort a list
        /// </summary>
        /// <param name="itemList"></param>
        /// <returns></returns>
        public static IEnumerable<Item> SortBySitecore(this IEnumerable<Item> itemList)
        {
            // sort by sortvalue field, if valu is empty assume set as default sort order value
            // we have to then sort by name when the values are the same
            return itemList
                .OrderBy(itm => itm.Fields["__sortorder"].ValueSafe<int>(Sitecore.Configuration.Settings.DefaultSortOrder))
                .ThenBy(itm=>itm.Name);
        }
        #endregion

        #region Clone
        /// <summary>
        /// Clones the item (as long as data is ICloneable)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="listToClone"></param>
        /// <returns></returns>
        public static IList<T> Clone<T>(this IList<T> listToClone) where T : ICloneable
        {
            return listToClone.Select(item => (T)item.Clone()).ToList();
        }

        /// <summary>
        /// Clones the Dictionary (as long as data is ICloneable)
        /// </summary>
        /// <typeparam name="TKey"></typeparam>
        /// <typeparam name="TValue"></typeparam>
        /// <param name="src"></param>
        /// <returns>Returns cloned Dictionary</returns>
        public static IDictionary<TKey,TValue> Clone<TKey, TValue>(this IDictionary<TKey, TValue> src)
            where TValue    : ICloneable
            where TKey      : ICloneable
        {
            return src.ToDictionary(i => (TKey)i.Key.Clone(), i => (TValue)i.Value.Clone());
        }
        #endregion

        #region IsValid
        /// <summary>
        /// Determines if the ienumberable is valid
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="enumerable"></param>
        /// <returns></returns>
        public static bool IsValid<T>(this IEnumerable<T> enumerable)
        {
            return (enumerable != null  && enumerable.Any());
        }
        #endregion
    }
}
