﻿using System;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class ItemsContext
    {
        private static object _sybcRoot = new object();

        /// <summary>
        /// Gets the Item from the context but allows it to be set
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="context"></param>
        /// <param name="key"></param>
        /// <param name="func"></param>
        /// <returns></returns>
        public static T Get<T>(this Sitecore.Caching.ItemsContext context, string key, Func<T> func)
        {
            // set default data just incase
            T returnData;

            // do we have the item
            if (Sitecore.Context.Items.Contains(key))
            {
                // get the item
                returnData = (T)Sitecore.Context.Items[key];
            }
            else
            {
                // execute the function
                returnData = func();

                // get the returning data
                // but check that we have not had this added prior
                if (returnData != null
                    && !Sitecore.Context.Items.Contains(key))
                {
                    lock (_sybcRoot)
                    {
                        // add the data to the items
                        Sitecore.Context.Items.Add(key, returnData);
                    }
                }
            }

            return returnData != null ? returnData : default(T);
        }
    }
}
