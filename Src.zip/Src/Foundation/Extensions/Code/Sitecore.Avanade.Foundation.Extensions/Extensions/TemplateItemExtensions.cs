﻿using Sitecore.Data.Managers;
using Sitecore.Diagnostics;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class TemplateItemExtensions
    {
        #region Derived Templates
        // return the ID of the template
        // and any templates that inherit from that template
        public static string[] GetSelfAndDerivedTemplates(this Data.Items.TemplateItem template)
        {
            Sitecore.Diagnostics.Assert.IsNotNull(template, "template");
            var results = new List<string> { template.ID.ToString() };
            var links = Sitecore.Globals.LinkDatabase.GetReferrers(
            template);

            if (links != null)
            {
                results.AddRange(from link in links
                                 where link.SourceFieldID == Sitecore.FieldIDs.BaseTemplate
                                 where
                                     string.Compare(link.SourceDatabaseName, template.Database.Name,
                                         StringComparison.OrdinalIgnoreCase) == 0
                                 let referrer = template.Database.GetItem(link.SourceItemID)
                                 where referrer != null && referrer[Sitecore.FieldIDs.BaseTemplate].Contains(template.ID.ToString())
                                 select link.SourceItemID.ToString());
            }

            return results.ToArray();
        }

        /// <summary>
        /// Find out if this template is derived from a given template.
        /// </summary>
        /// <param name="template"></param>
        /// <param name="templateIDItemDerivedFrom">Template ID the item may have derived from.</param>
        /// <returns></returns>
        public static bool IsDerivedFrom(this Sitecore.Data.Templates.Template template, Sitecore.Data.ID templateIDItemDerivedFrom)
        {
            return template.ID == templateIDItemDerivedFrom || template.GetBaseTemplates().Any(baseTemplate => IsDerivedFrom(baseTemplate, templateIDItemDerivedFrom));
        }
        #endregion

        #region GetItem
        /// <summary>
        /// Get the Item of the template field
        /// </summary>
        /// <param name="tmpField"></param>
        /// <returns></returns>
        public static Sitecore.Data.Items.Item GetItem(this Data.Templates.TemplateField tmpField, Sitecore.Data.Database db = null)
        {
            // do we have data
            if (tmpField == null)
            {
                return null;
            }

            if (db == null)
            {
                // this may be wrong at times
                db = Sitecore.Context.Database;
            }

            return db.GetItem(tmpField.ID);
        }
        #endregion

        #region GetItem
        /// <summary>
        /// Get the Item of the template field
        /// </summary>
        /// <param name="tmpField"></param>
        /// <returns></returns>
        public static bool IsStandardTemplateField(this Data.Items.TemplateFieldItem tmpFieldItm)
        { 
            // get the template
            var template = TemplateManager.GetTemplate(Sitecore.Configuration.Settings.DefaultBaseTemplate, tmpFieldItm.Database);

            // make sure we have the template
            Assert.IsNotNull(template, "base template");

            if (template != null)
            {
                return template.ContainsField(tmpFieldItm.ID);
            }

            return false;
        }
        #endregion
    }
}
