﻿using System;

namespace Sitecore.Avanade.Foundation.Extensions
{
    /// <summary>
    /// Sitecore ID Extensions
    /// </summary>
    public static class IDExtensions
    {
        #region ToGuid
        /// <summary>
        /// Returns a string representation of the value of this instance of the System.Guid
        /// class, according to the provided format specifier and culture-specific format
        /// information.
        /// </summary>
        /// <param name="idItem"></param>
        /// <param name="format">
        /// A single format specifier that indicates how to format the value of this
        /// System.Guid. The format parameter can be "N", "D", "B", "P", or "X". If format
        /// is null or an empty string (""), "D" is used.</param>
        /// <param name="provider">(Reserved) An object that supplies culture-specific formatting services.</param>
        /// <returns>A string representation of the value of this System.Guid.</returns>
        /// <exception cref="System.FormatException">
        /// The value of format is not null, an empty string (""), "N", "D", "B", "P", or "X".
        /// </exception>
        public static string ToGuid(this Sitecore.Data.ID idItem, string format, IFormatProvider provider = null)
        {
            // make sure we have data
            if (!Sitecore.Data.ID.IsNullOrEmpty(idItem))
            {
                // do we have a provider
                if (provider != null)
                {
                    // format the data
                    return idItem.ToGuid().ToString(format, provider);
                }

                // format
                return idItem.ToGuid().ToString(format);
            }

            // reutrn the data
            return string.Empty;
        }
        #endregion

        #region EqualsTo
        /// <summary>
        /// Does the ID equal to the string id
        /// </summary>
        /// <param name="idItem">The Sitecore ID</param>
        /// <param name="myId">The Sitecore ID in string form</param>
        /// <returns>Returns true if the ids are a match</returns>
        public static bool EqualsTo(this Sitecore.Data.ID idItem, string myId)
        {
            return (idItem.HasValue() && idItem.ToString().Equals(myId, StringComparison.OrdinalIgnoreCase));
        }
        #endregion

        #region HasValue
        /// <summary>
        /// Determines if the ID has a value
        /// </summary>
        /// <param name="myID">The ID to check</param>
        /// <returns>Returns true if the ID has a value</returns>
        public static bool HasValue(this Sitecore.Data.ID myID)
        {

            return !((myID == (Sitecore.Data.ID)null || myID.IsNull) || myID.ToGuid() == new Guid());
        }
        #endregion

        #region ToLuceneID
        /// <summary>
        /// Converts the Sitecore ID to a lucene ID
        /// </summary>
        /// <param name="myID">The Sitecore ID</param>
        /// <param name="format">
        /// A single format specifier that indicates how to format the value of this
        /// System.Guid. The format parameter can be "N", "D", "B", "P", or "X". If format
        /// is null or an empty string (""), "D" is used.</param>
        /// <returns>Returns the lucene ID</returns>
        public static string ToLuceneID(this Sitecore.Data.ID myID, string format = "D")
        {
            if (myID.HasValue())
            {
                return myID.ToGuid().ToString(format).ToLower();
            }

            return string.Empty;
        }
        #endregion

        #region ToItem
        /// <summary>
        /// Converts the ID to a Sitecore Item
        /// </summary>
        /// <param name="idItem">The ID to convert to an Item</param>
        /// <returns>The Sitecore Item or  null</returns>
        public static Sitecore.Data.Items.Item ToItem(this Sitecore.Data.ID id)
        {
            // make sure we have what we want first
            if (!id.IsNull
                && Context.Database != null)
            {
                // get the item
                return Context.Database.GetItem(id);
            }

            return null;
        }
        #endregion
    }
}