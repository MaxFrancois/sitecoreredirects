﻿using System;
using System.Globalization;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Sitecore.Avanade.Foundation.Extensions
{
    /// <summary>
    /// String Extensions
    /// </summary>
    public static class StringExtensions
    {
        #region Private Variable
        /// <summary>
        /// The regular expression to check if the string is a guid
        /// </summary>
        private static System.Text.RegularExpressions.Regex _isGuidRegExCheck = new System.Text.RegularExpressions.Regex(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", System.Text.RegularExpressions.RegexOptions.Compiled);
        #endregion

        #region IsNullOrEmpty
        /// <summary>
        /// Indicates whether the specified string is null or an System.String.Empty
        /// </summary>
        /// <param name="data">The data to check</param>
        /// <returns>true if the value parameter is null or an empty string (""); otherwise, false</returns>
        public static bool IsNullOrEmpty(this string data)
        {
            return string.IsNullOrEmpty(data);
        }
        #endregion

        #region InstanceCount
        public static int InstanceCount(this string data, char c)
        {
            return data.Count(x => x == c);
        }
        #endregion

        #region Format
        /// <summary>
        /// Formats the string with the supplied data
        /// </summary>
        /// <param name="format">The string requiring formatting</param>
        /// <param name="stringItems">The array of string data</param>
        /// <returns>Returns the collection of data</returns>
        public static string Fmt(this string format, params object[] stringItems)
        {
            return string.Format(format, stringItems);
        }
        #endregion

        #region AppendFormat
        /// <summary>
        /// Appends and formats the data to the end of the string
        /// </summary>
        /// <param name="data">The data which will have the appended text</param>
        /// <param name="dataToAppend">The Data to append</param>
        /// <returns>Returns the image with the appended text</returns>
        public static string AppendFormat(this string data, string dataToAppend, params object[] stringItems)
        {
            return string.Concat(data, dataToAppend.Fmt(stringItems));
        }
        #endregion

        #region Contains
        /// <summary>
        /// Does the current string contain the following text in the required format
        /// </summary>
        /// <param name="source">The source to cehck</param>
        /// <param name="check">The data to find</param>
        /// <param name="comp">The comparision</param>
        /// <returns>Returns true if the data is present</returns>
        public static bool Contains(this string source, string check, StringComparison comp)
        {
            return source.IndexOf(check, comp) >= 0;
        }

        /// <summary>
        /// Does the string contain multiply string items
        /// </summary>
        /// <param name="itm">The string that contains our data</param>
        /// <param name="stringItems">The listing of strings to look for</param>
        /// <returns>Returns true if any of the strings are found</returns>
        public static bool ContainsOr(this string itm, params string[] stringItems)
        {
            // set default valid
            var isValid = false;

            foreach (var itmLookFor in stringItems)
            {
                if (itm.Contains(itmLookFor))
                {
                    isValid = true;
                    break;
                }
            }

            // default
            return isValid;
        }

        /// <summary>
        /// Does the string contain multiply string items
        /// </summary>
        /// <param name="itm">The string that contains our data</param>
        /// <param name="stringItems">The listing of strings to look for</param>
        /// <param name="comp">The comparision</param>
        /// <returns>Returns true if any of the strings are found</returns>
        public static bool ContainsOr(this string itm, StringComparison comparisonType, params string[] stringItems)
        {
            // set default valid
            var isValid = false;

            foreach (var itmLookFor in stringItems)
            {
                if (itm.Contains(itmLookFor, comparisonType))
                {
                    isValid = true;
                    break;
                }
            }

            // default
            return isValid;
        }
        #endregion

        #region SplitString
        /// <summary>
        /// Splits the string ensuring that the data is trimmed and valied
        /// </summary>
        /// <param name="original">The original text to split</param>
        /// <param name="replacer">The character to split on</param>
        /// <returns>Returns the collection of split data with data trimmed and no empty data</returns>
        public static string[] SplitString(this string original, char replacer)
        {
            // do we have data
            if (string.IsNullOrEmpty(original))
            {
                return new string[0];
            }

            // split the data making sure to trim the results
            IEnumerable<string> source = from piece in original.Split(new char[]
            {
                replacer
            })
                                         let trimmed = piece.Trim()
                                         where !string.IsNullOrEmpty(trimmed)
                                         select trimmed;
            return source.ToArray<string>();
        }
        #endregion

        #region ToTitleCase
        /// <summary>
        /// Converts the specified string to title case (except for words that are entirely in uppercase, which are considered to be acronyms).
        /// </summary>
        /// <param name="source">>The string to convert to title case</param>
        /// <returns>The specified string converted to title case.</returns>
        public static string ToTitleCase(this string source)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(source);
        }
        #endregion

        #region Cryptography
        /// <summary>
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <param name="enc"></param>
        /// <returns></returns>
        public static string ToSHA1(this string text, Encoding enc)
        {
            byte[] buffer = enc.GetBytes(text);
            SHA1CryptoServiceProvider cryptoTransformSHA1 =
            new SHA1CryptoServiceProvider();
            string hash = BitConverter.ToString(
            cryptoTransformSHA1.ComputeHash(buffer)).Replace("-", "");
            return hash;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string ToMD5(this string input)
        {
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }

        public static string ToEncryptedString(this string input)
        {
            if (String.IsNullOrEmpty(input))
                return input;

            var encryptedStr = string.Empty;

            const string key = "<RSAKeyValue><Modulus>tuDqxMAmZXsNvFy/tGpQODCZQ2mpHILb+yD1sj7ogt2biTUEN7EXm3Xa7ie8Qd7B0OKG8X8mFfcSbfKt6oGhfUMF31euhbuvwws4DDSWgcsNgzwtOv8iwZNwtIR/4OL7lJyM33UP+qgFVU+BAeEbOc4YpoUh/iPUwY81XLYFoNM=</Modulus><Exponent>AQAB</Exponent><P>7fJDpIxO5e6UCA17ybYeZ7duFNscO5SnRoJ4Vqnr9NC0V0Z6YwJhQoV7UTw+soQwB5KYOhAfy+KogxXtElFiOw==</P><Q>xMEMMfAPhbQZzxx7u3U6Bb7yjQ31fv457LSRVexpsVlwS6jZIFb7kmgTilGio89q5jmPI95jV0xMGj9wb3n6SQ==</Q><DP>r82QJrI31PCJ1M1JiYYSPuUq4yPkXyz8zj61dKqFGFNe+yCqah6nB4Qh0apmVHUQG3g3GqcxJu2nPXrktuUEYw==</DP><DQ>lvDWjzTwY41AQ4BBeBU9lwze/NFZpbwY6fu4h2dfyhuoJ5L4R3QTeUT4wKNSF0NXahl8M3M3WNCCjZxfgFXeaQ==</DQ><InverseQ>msTfkDkiGGiL/gFFIFj5tu7x6egSx7md5NE/B77S9R797P70Cc6s5FWVNJcOvsSCyclWzHmpe+OONuUaZm9hxg==</InverseQ><D>FRPoSyQAaOrdYuvntoIYW9mSGJh5gs08UH30g4ZHoymqjw5avZZ+K49SW+edhZQIj6xENFpcx+RRrfVuARzOwWCZe2u/HZPW5i45Pz4Wok5kqHrSR1VdJdXBX8UB6GfqlbbV5zbFPvyA/YEIsSP9rPyaJH+eqdshwPTRxea9nnk=</D></RSAKeyValue>";

            try
            {
                using (var RSA = new RSACryptoServiceProvider())
                {
                    //Setup the keys
                    RSA.FromXmlString(key);
                    RSA.ImportParameters(RSA.ExportParameters(false));

                    var encryptResult = RSA.Encrypt(Encoding.UTF8.GetBytes(input), false);

                    encryptedStr = System.Convert.ToBase64String(encryptResult);
                }
            }
            catch(Exception e)
            {
                if (Sitecore.Diagnostics.Log.IsDebugEnabled)
                    Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Error encrypting string", e, typeof(StringExtensions));
            }

            return encryptedStr;
        }

        public static string ToDecryptedString(this string input)
        {
            if (String.IsNullOrEmpty(input))
                return input;

            var decryptedStr = string.Empty;
            var byteConverter = new UnicodeEncoding();

            try
            {
                using (var RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSA.ExportParameters(true));

                    var decryptedResult = RSA.Decrypt(byteConverter.GetBytes(input), false);

                    decryptedStr = byteConverter.GetString(decryptedResult);
                }
            }
            catch(Exception e)
            {
                if (Sitecore.Diagnostics.Log.IsDebugEnabled)
                    Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Error decrypting string.", e, typeof(StringExtensions));
            }

            return decryptedStr;
        }
        
        #endregion

        #region HTML And Text
        public static string LineBreaksToParagraphs(this string Value)
        {
            const string Paragraph = "<p>{0}</p>";
            const string Break = "{0}<br />";

            if(String.IsNullOrEmpty(Value))
            {
                return Value;
            }

            //split by line break char's ('\r\n'). We'll remove doubled up ones so that we don't generate empy <p></p> tags
            var normalizedString = Value.Replace("\r\n", "\r").Replace("\r", "\n");
            var splitted = normalizedString.Split(new string[] { "\n" }, StringSplitOptions.None);
            if(!splitted.Any())
            {
                return Value;
            }

            var resultString = new StringBuilder();

            //cycle through and append a break element
            int count = splitted.Count();
            foreach(var x in splitted)
            {
                if (count > 1)
                {
                    resultString.AppendFormat(Break, x);
                }
                else
                {
                    resultString.Append(x);
                }
                count--;
            }

            return Paragraph.Fmt(resultString.ToString());
        }

        public static string ParagraphsToLineBreaks(this string Value)
        {
            if(String.IsNullOrEmpty(Value))
            {
                return Value;
            }

            return Value.Replace("<br /><br />", "\r\n\r\n").Replace("<br />", "\r\n").Replace("<p>", "").Replace("</p>", "");
        }
        #endregion

        #region EqualsOr
        /// <summary>
        /// Does the string equal to a least one of the elements in the list
        /// </summary>
        /// <param name="itm">The string to process</param>
        /// <param name="stringItems">The collection of strings to filter over to see if the itm string is found</param>
        /// <returns>Returns true if the string is in any of these</returns>
        public static bool EqualsOr(this string itm, params string[] stringItems)
        {
            // set default valid
            bool isValid = false;

            foreach (string itmLookFor in stringItems)
            {
                if (itm.Equals(itmLookFor))
                {
                    isValid = true;
                    break;
                }
            }

            // default
            return isValid;
        }

        /// <summary>
        /// Does the string equal at least one of the elements in the string list
        /// </summary>
        /// <param name="itm">The string to process</param>
        /// <param name="comparisonType">The type of comparison</param>
        /// <param name="stringItems">The string to check</param>
        /// <returns>Returns true if any of the strings are found</returns>
        public static bool EqualsOr(this string itm, System.StringComparison comparisonType, params string[] stringItems)
        {
            // set default valid
            bool isValid = false;

            foreach (string itmLookFor in stringItems)
            {
                if (itm.Equals(itmLookFor, comparisonType))
                {
                    isValid = true;
                    break;
                }
            }

            // default
            return isValid;
        }
        #endregion

        #region IsGuid
        /// <summary>
        /// Is the string a guid
        /// </summary>
        /// <param name="stringToCheck">The string to check</param>
        /// <returns>True if the string is a guid and false if anything else</returns>
        public static bool IsGuid(this string stringToCheck)
        {
            if (!string.IsNullOrEmpty(stringToCheck))
            {
                // checks if the string is a guid
                return (_isGuidRegExCheck.IsMatch(stringToCheck));
            }

            return false;
        }
        #endregion
    }
}
