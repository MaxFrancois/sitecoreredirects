﻿using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class RenderingExtensions
    {
        /// <summary>
        /// Checks the Datasource Template set on rendering to ensure the set datasource matches or is compatible 
        /// </summary>
        /// <param name="rendering"></param>
        /// <returns></returns>
        public static bool HasValidDatasource(this Rendering rendering)
        {
            bool response = false;

            if (rendering != null && rendering.RenderingItem != null && rendering.RenderingItem.InnerItem != null)
            {
                ReferenceField datasourceTemplateField
                    = rendering.RenderingItem.InnerItem.Fields["Datasource Template"];

                if (datasourceTemplateField != null && datasourceTemplateField.TargetItem != null)
                {
                    Item templateItem = datasourceTemplateField.TargetItem;
                    if (templateItem == null)
                    {
                        // DataSource Template field empty - no need to check if DataSource item is set
                        response = true;
                    } else if (rendering.Item != null)
                    {
                        // check if the item is set and if its template inherits from configured template
                        response = rendering.Item.HasBaseTemplate(templateItem.ID);
                    }
                }
                
            }
            return response;
        }

        public static string RequiredDatasourceTemplate(this Rendering rendering)
        {
            string response = string.Empty;

            if (rendering != null && rendering.RenderingItem != null && rendering.RenderingItem.InnerItem != null)
            {
                ReferenceField datasourceTemplateField
                    = rendering.RenderingItem.InnerItem.Fields["Datasource Template"];

                if (datasourceTemplateField != null && datasourceTemplateField.TargetItem != null)
                {
                    Item templateItem = datasourceTemplateField.TargetItem;
                    response = templateItem.DisplayName;
                }
                
            }
            return response;
        }

        #region RenderingField
        /// <summary>
        /// Fetch the rendering field
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="render"></param>
        /// <returns></returns>
        public static Sitecore.Data.Fields.Field RenderingField(this Sitecore.Mvc.Presentation.Rendering render, string fieldName)
        {
            // ensure we have data
            if (!fieldName.IsNullOrEmpty()
                && render != null
                && render.RenderingItem != null
                && render.RenderingItem.InnerItem != null)
            {
                // get the field
                return render.RenderingItem.InnerItem.Fields[fieldName];
            }

            return null;
        }
        #endregion

        #region ValueSafe
        /// <summary>
        /// Safely get out the data and convert to basic types
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="renParams"></param>
        /// <param name="propertyName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static T ValueSafe<T>(this Sitecore.Mvc.Presentation.RenderingParameters renParams, string propertyName, T defaultValue = default(T))
        {
            // setup default
            T proposedValue = defaultValue;

            // make sure the fld exists
            if (!propertyName.IsNullOrEmpty()
                && renParams != null
                && renParams.Contains(propertyName))
            {
                // bool not correctly working if 1,0
                if (typeof(T) == typeof(bool))
                {
                    proposedValue = (T)(object)Helpers.BooleanHelper.ConvertToBoolean(renParams[propertyName]);
                }
                else
                {
                    // convert the value
                    proposedValue = (T)System.Convert.ChangeType(renParams[propertyName], typeof(T));
                }

                // is our value null and default value not null 
                if (proposedValue == null)// && defaultValue != null)
                {
                    proposedValue = defaultValue;
                }
            }

            return proposedValue;
        }
        #endregion
    }
}
