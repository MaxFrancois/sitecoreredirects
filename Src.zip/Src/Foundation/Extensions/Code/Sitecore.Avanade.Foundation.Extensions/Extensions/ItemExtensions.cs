﻿using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Links;
using Sitecore.Security.AccessControl;
using Sitecore.SecurityModel;
using System;
using System.Linq;

using System.Collections.Generic;
using Sitecore.Data.Managers;
using Sitecore.Data.Templates;
using Sitecore.Buckets.Managers;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class ItemExtensions
    {
        public static string GetAbsoluteUrl(this Item item)
        {
            if (!item.IsValid())
            {
                return null;
            }
            UrlOptions urlOptions = LinkManager.GetDefaultUrlOptions();
            urlOptions.AlwaysIncludeServerUrl = true;
            return LinkManager.GetItemUrl(item, urlOptions);
        }

        /// <summary>
        /// Compares the Long IDs to check if item is a descendant of the item passed
        /// </summary>
        /// <param name="item"></param>
        /// <param name="suspectedAncestorItem"></param>
        /// <returns></returns>
        public static bool IsDescendantOfItem(this Item item, Item suspectedAncestorItem)
        {
            if (item == null || suspectedAncestorItem == null)
            {
                return false;
            }

            return item.Paths.LongID.Contains(suspectedAncestorItem.Paths.LongID);
        }

        /// <summary>
        /// Compares the Long IDs to check if item is an ancestor of the item passed
        /// </summary>
        /// <param name="item"></param>
        /// <param name="suspectedDescendantItem"></param>
        /// <returns></returns>
        public static bool IsAncestorOfItem(this Item item, Item suspectedDescendantItem)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            if (suspectedDescendantItem == null)
            {
                throw new ArgumentNullException("suspectedDescendantItem");
            }
            return suspectedDescendantItem.Paths.LongID.Contains(item.Paths.LongID);
        }

        public static string GetFileUrl(Item item, string fieldname)
        {
            if (item == null || item.Fields[fieldname] == null)
                return "";

            Sitecore.Data.Fields.FileField field =
             (Sitecore.Data.Fields.FileField)item.Fields[fieldname];
            return Sitecore.Resources.Media.MediaManager.GetMediaUrl(field.MediaItem) ?? "";
        }

        #region IsSecure
        /// <summary>
        /// Is the Item secure for the current users context
        /// </summary>
        /// <param name="itm">The curren item to be processed</param>
        /// <returns>Returns true if the user can see the current item</returns>
        public static bool IsSecure(this Item itm)
        {
            // have we disabled security
            if (SecurityDisabler.CurrentValue == SecurityState.Disabled)
            {
                // we have to re-enable the security to check this is the only way
                using (new SecurityEnabler())
                {
                    // we now have to work out if the user has access to this
                    return !AuthorizationManager.IsAllowed(itm,
                                AccessRight.ItemRead,
                                Context.User) ;
                }
            }

            return !AuthorizationManager.IsAllowed(itm,
                AccessRight.ItemRead,
                Context.User);
        }
        #endregion

        #region IsValid
        /// <summary>
        /// Is the item a valid item for publishing
        /// </summary>
        /// <param name="item">The item to check if it's valid</param>
        /// <param name="templateId">Item's template ID</param>
        /// <returns>Returns true if the item is valid</returns>
        public static bool IsValid(this Item item, string templateId = "")
        {
            // if we don't have a valid item stop
            if (item == null
                || item.Version == null)
            {
                return false;
            }

            // is the item hidden
            if (item.Fields["__Hide version"].IsChecked())
            {
                return false;
            }

            // is the item of template Id
            if (!string.IsNullOrEmpty(templateId) &&
                !templateId.Equals(item.TemplateID.ToString(), StringComparison.InvariantCultureIgnoreCase))
            {
                return false;
            }

            // compare the dates
            DateTime validFrom = !string.IsNullOrEmpty(item["__Valid from"]) ? DateUtil.IsoDateToDateTime(item["__Valid from"]) : DateTime.MinValue;
            DateTime validTo = !string.IsNullOrEmpty(item["__Valid to"]) ? DateUtil.IsoDateToDateTime(item["__Valid to"]) : DateTime.MaxValue;

            // current datetime
            DateTime nowDateTime = DateTime.Now.SitecoreDateTime();

            // make sure the data is valid
            return nowDateTime >= validFrom && nowDateTime <= validTo;
        }
        #endregion

        #region HasValue
        /// <summary>
        /// Checks to see if an item has a field value in the item, standard or default value
        /// </summary>
        /// <param name="item">The item to check for a field value</param>
        /// <param name="fieldName">The name of the field to check</param>
        /// <returns>True if there is a non-whitespace value available</returns>
        public static bool HasValue(this Item item, string fieldName)
        {
            return item != null && item.IsValid() && item.HasField(fieldName) &&
                !string.IsNullOrWhiteSpace(item.Fields[fieldName].GetValue(true, true));
        }
        #endregion

        #region GetRandomChild

        /// <summary>
        /// Get a random child
        /// </summary>
        /// <param name="item"></param>
        /// <param name="templateId"></param>
        /// <returns></returns>
        public static Item GetRandomChild(this Item item, ID templateId = null)
        {
            var list = templateId == (ID)null
                ? item.Children.ToList()
                : item.Children.Where(i => i.TemplateID.Equals(templateId)).ToList();
            Item child = null;
            if (list.Any())
            {
                var rndGenerator = new Random(DateTime.Now.Millisecond);
                child = list[rndGenerator.Next(list.Count)];
            }
            return child;
        }

        #endregion

        #region IsInBucket
        /// <summary>
        /// Determines if the current item is in a bucket
        /// </summary>
        /// <param name="itm">The current item to process</param>
        /// <returns>Returns true if the current item is in a bucket</returns>
        public static bool IsInBucket(this Sitecore.Data.Items.Item itm)
        {
            // we have to have some data
            if (itm == null)
            {
                return false;
            }

            // quick reference to the Bucket Manager
            return Sitecore.Buckets.Managers.BucketManager.IsItemContainedWithinBucket(itm);
        }
        #endregion

        #region IsBucket
        /// <summary>
        /// Determines if the current item is a bucket
        /// </summary>
        /// <param name="itm">The current item to process</param>
        /// <returns>Returns true if the current item is a bucket</returns>
        public static bool IsBucket(this Sitecore.Data.Items.Item itm)
        {
            // we have to have some data
            if (itm == null)
            {
                return false;
            }

            // quick reference to the Bucket Manager
            return Sitecore.Buckets.Managers.BucketManager.IsBucket(itm);
        }
        #endregion

        #region GetParentBucketItemOrParent
        /// <summary>
        /// This method is an extension of Item which will return the first ancestor that is a Bucket
        /// </summary>
        /// <param name="itm">The current item to process</param>
        /// <returns>Returns the parent item bucket or null</returns>
        public static Item GetParentBucketItemOrParent(this Sitecore.Data.Items.Item itm)
        {
            // we have to have some data
            if (itm == null || !itm.IsInBucket())
            {
                return null;
            }

            return itm.Axes.GetAncestors()
                .Where(new Func<Item, bool>(BucketManager.IsBucket))
                .DefaultIfEmpty(itm.Parent)
                .First<Item>();
        }
        #endregion

        #region IsTemplate
        /// <summary>
        /// Determines if the current item is a Template
        /// </summary>
        /// <param name="itm">The current item to process</param>
        /// <returns>Returns true if the current item is a template</returns>
        public static bool IsTemplate(this Sitecore.Data.Items.Item itm)
        {
            // we have to have some data
            if (itm == null)
            {
                return false;
            }

            // quick reference to the Bucket Manager
            return TemplateManager.IsTemplate(itm);
        }
        #endregion

        #region GetAncestorWithField
        /// <summary>
        /// Gets the first ancestor that has the field value set but also matches the required function output
        /// </summary>
        /// <param name="itm">The item to process and from</param>
        /// <param name="fieldName">The field name to look for</param>
        /// <param name="includeSelft">Do we include the current item</param>
        /// <param name="funcToRun">Custom processing that will be required on each process attempt</param>
        /// <param name="reverseOrder">Do we want to reverse the order, default is true</param>
        /// <returns>Cycles up the tree until it finds the home item or the field populated. If nothing found results will be null</returns>
        public static Sitecore.Data.Items.Item GetAncestorWithField(this Sitecore.Data.Items.Item itm, string fieldName, bool includeSelf = true, Func<Item, bool> funcToRun = null, bool reverseOrder = true)
        {
            // the data to return
            Item returnData = null;

            // make sure we have data
            if (itm != null
                && !fieldName.IsNullOrEmpty())
            {
                // make sure we have the field
                if (itm.HasField(fieldName)
                    && itm.Fields[fieldName].HasNoEmptyValue()
                    && (funcToRun == null
                        || funcToRun(itm)))
                {
                    // return data
                    returnData = itm;
                }

                // ensure we have not found our data
                if (returnData == null)
                {
                    // get the ancestor data
                    itm.Axes.GetAncestors(reverseOrder).ForEach<Item>(x =>
                    {
                        if (x != null
                            && returnData == null
                            && x.HasField(fieldName)
                            && x.Fields[fieldName].HasNoEmptyValue()
                            && (funcToRun == null || funcToRun(x)))
                            {
                                // return data
                                returnData = x;
                            }
                    });
                }
            }

            return returnData;
        }
        #endregion


        #region HasLanguage
        /// <summary>
        /// Does the item have the following language
        /// </summary>
        /// <param name="item">The item to check against</param>
        /// <param name="languageName">The language name to look for</param>
        /// <returns>Return true if the language was found</returns>
        public static bool HasLanguage(this Sitecore.Data.Items.Item item, string languageName)
        {
            return ItemManager.GetVersions(item, LanguageManager.GetLanguage(languageName)).Count > 0;
        }

        /// <summary>
        /// Does the item have the following language
        /// </summary>
        /// <param name="item">The item to check against</param>
        /// <param name="language">The language item to find</param>
        /// <returns>Returns true if the language was found</returns>
        public static bool HasLanguage(this Sitecore.Data.Items.Item item, Sitecore.Globalization.Language language)
        {
            return ItemManager.GetVersions(item, language).Count > 0;
        }
        #endregion

        #region LanguageVersionCount
        /// <summary>
        /// The version number of the particular language
        /// </summary>
        /// <param name="item">The item to find</param>
        /// <param name="lang">The language to find</param>
        /// <returns>The language version count</returns>
        public static int LanguageVersionCount(this Sitecore.Data.Items.Item item, Sitecore.Globalization.Language lang)
        {
            // make sure the data is valid
            if (item == null)
            {
                return 0;
            }

            // does the current item have the actual language
            if (HasLanguage(item, lang))
            {
                // get the necessary language
                Sitecore.Data.Items.Item currentItem = item.Database.GetItem(item.ID, lang);

                // return the version
                return currentItem.Versions.Count;
            }

            // no version
            return 0;
        }
        #endregion

        #region Publish
        /// <summary>
        /// Publish the Item
        /// </summary>
        /// <param name="item">The item to publish</param>
        /// <param name="deep">Do we perform a deep publish, including children</param>
        public static void Publish(this Sitecore.Data.Items.Item item, bool deep = false, bool allPublishingTargets = false, Sitecore.Data.Database db = null)
        {
            // no item found
            if (item == null)
            {
                return;
            }

            // are we just publishing to a specific database
            if (!allPublishingTargets)
            {
                // just in case no db set
                if (db == null)
                {
                    db = Sitecore.Data.Database.GetDatabase(Constants.SitecoreConstants.WebDBName);
                }

                // get the publishing options for the system
                Sitecore.Publishing.PublishOptions publishOptions = new Sitecore.Publishing.PublishOptions(item.Database,
                                                    db,
                                                    Sitecore.Publishing.PublishMode.SingleItem,
                                                    item.Language,
                                                    DateTime.Now);

                // get the Sitecore publisher
                Sitecore.Publishing.Publisher publisher = new Sitecore.Publishing.Publisher(publishOptions);
                publisher.Options.RootItem = item; // the item to publish
                publisher.Options.Deep = deep; // are we publishing the children

                // publish
                publisher.Publish();
            }
            else
            {
                // get the databases to process
                Sitecore.Data.Database[] targets = item.PublishingTargetDatabases();

                // publish
                Sitecore.Publishing.PublishManager.PublishItem(item, targets, new Sitecore.Globalization.Language[]
	                    {
		                    item.Language
	                    }, deep, false);
            }
        }
        #endregion

        #region UnPublish
        /// <summary>
        /// UnPublishes the item
        /// </summary>
        /// <param name="item">The item to un-publish</param>
        public static void UnPublish(this Sitecore.Data.Items.Item item)
        {
            // set the correct un-publish date to now
            item.Publishing.UnpublishDate = DateTime.Now;

            // call our publish extension
            Publish(item, deep: true);
        }
        #endregion

        #region Publishing Targets
        /// <summary>
        /// Works out what publishing targets the item is currently belong two.
        /// This will work up the tree getting the targets.
        /// </summary>
        /// <param name="item">The item to find the publishing targets for</param>
        /// <returns>Returns the array of publishing targets for the item</returns>
        public static Sitecore.Data.Items.Item[] PublishingTargets(this Sitecore.Data.Items.Item item)
        {
            // get all ancestors of the current item
            Sitecore.Data.Items.Item[] itmList = item.Axes.GetAncestors();

            // setup the lists
            List<string> list = new List<string>();
            List<Sitecore.Data.Items.Item> listItems = new List<Sitecore.Data.Items.Item>();

            // loop the items
            foreach (Sitecore.Data.Items.Item itm in itmList)
            {
                // make sure we have our data
                Sitecore.Data.Fields.MultilistField mltField = item.Fields["__Publishing groups"].ConvertToMultilistField();

                // make sure we have something
                if (mltField != null && mltField.Count > 0)
                {
                    string[] itmTargets = mltField.Items;

                    // double check we have data
                    if (itmTargets != null && itmTargets.Length > 0)
                    {
                        list.AddRange(itmTargets);
                    }
                }
            }

            // we need to make sure we have oru data
            if (list.Count > 0)
            {
                // get our distinct list
                list.Distinct().ForEach(x =>
                {
                    listItems.Add(item.Database.GetItem(x));
                });
            }
            else
            {
                // get the default publishing target
                listItems.AddRange(item.Database.SelectItems("/sitecore/system/publishing targets/*"));
            }

            // return our items
            return listItems.ToArray();
        }
        #endregion

        #region Publishing Target Databases
        /// <summary>
        /// Gets the listing of Publishing Targets and there Databases
        /// </summary>
        /// <param name="item">The Item to find it's publishing Targets</param>
        /// <returns>Returns an arrary of publishing Targets and there unique Databases</returns>
        public static Sitecore.Data.Database[] PublishingTargetDatabases(this Item item)
        {
            // get the listing of targets
            Item[] targets = item.PublishingTargets();

            // make sure we have data
            if (targets != null && targets.Length > 0)
            {
                // return the data
                return targets.Select(e =>
                {
                    // set default
                    Sitecore.Data.Database database = null;

                    // do we have content
                    if (!e.Fields["Target database"].HasValue)
                    {
                        // get the database
                        database = Sitecore.Configuration.Factory.GetDatabase(e.Fields["Target database"].GetValue(false), false);
                    }

                    // return the data
                    return database;
                }).Where(e => e != null)
                  .DistinctBy(e => e.Name)
                  .ToArray();
            }

            // no data found return empty array
            return new Sitecore.Data.Database[0];
        }
        #endregion

        #region IsPublished
        /// <summary>
        /// Has this item, version, language etc been published
        /// </summary>
        /// <param name="item">The item to check the publishing</param>
        /// <param name="database">The name of the database to compare, if this is empty it will compare it against all publishing targets for this item</param>
        /// <returns>Return true if the item has been published, if anything else false</returns>
        public static bool IsPublished(this Sitecore.Data.Items.Item itm, string database = "")
        {
            // default
            bool isPublished = true;

            // do we have a database to compare with
            if (string.IsNullOrEmpty(database))
            {
                // get the publishing targets for the item
                Sitecore.Data.Items.Item[] publishingTargets = itm.PublishingTargets();

                // make sure we have data
                if (publishingTargets != null && publishingTargets.Length > 0)
                {
                    foreach (Sitecore.Data.Items.Item target in publishingTargets)
                    {
                        string databaseName = target["target database"];

                        // double check
                        if (!string.IsNullOrEmpty(databaseName))
                        {
                            // get the database
                            Sitecore.Data.Database targetDB = Sitecore.Configuration.Factory.GetDatabase(databaseName);

                            // if we have a non published, indicate we have to publish
                            if (!IsPublished(itm, targetDB))
                            {
                                isPublished = false;
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                // check the database
                isPublished = IsPublished(itm, Sitecore.Configuration.Factory.GetDatabase(database));
            }

            return isPublished;
        }

        /// <summary>
        /// Checks the Item against the database
        /// </summary>
        /// <param name="itm"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        private static bool IsPublished(Sitecore.Data.Items.Item itm, Sitecore.Data.Database db)
        {
            // make sure we have the data
            if (itm != null && db != null)
            {
                // get the item with the current version, language etc
                Sitecore.Data.Items.Item webItem = db.GetItem(itm.ID, itm.Language, itm.Version);

                // make sure it's the same item
                if (webItem == null || itm.Statistics.Updated > webItem.Statistics.Updated)
                {
                    // item is different, requires publishing
                    return false;
                }
            }

            return true;
        }

        #endregion
        
        #region IsFinalWorkFlowState
        /// <summary>
        /// Check if an item is in the final workflow state.
        /// </summary>
        /// <param name="currentItem"></param>
        /// <returns>Returns if the current item is in the final workflow state</returns>
        public static bool IsFinalWorkFlowState(this Item currentItem)
        {            
            Sitecore.Workflows.IWorkflow workflow = currentItem.Database.WorkflowProvider.GetWorkflow(currentItem);
            Sitecore.Workflows.WorkflowState state = workflow.GetState(currentItem);
            if (state.FinalState)
                return true;
            return false;            
        }
        #endregion

        #region IsSearchable
        /// <summary>
        /// Is the current item searchable, it will determine based on the a searchable field
        /// </summary>
        /// <param name="itm"></param>
        /// <param name="disableSearchFieldName">The field to use as a disable check. Defaults to "disablesearch"</param>
        /// <returns>Returns true if the item is searchable</returns>
        public static bool IsSearchable(this Sitecore.Data.Items.Item itm, string disableSearchFieldName = "disablesearch")
        {
            if (itm != null
                && !itm.HasField(disableSearchFieldName))
            {
                return !itm.Fields[disableSearchFieldName].IsChecked();
            }

            return true;
        }
        #endregion

        #region HasField
        /// <summary>
        /// Does the field exist and does it contain data
        /// </summary>
        /// <param name="item"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static bool HasField(this Item item, string fieldName)
        {
            // make sure our defaults are set
            if (item == null || fieldName.IsNullOrEmpty())
            {
                return false;
            }

            // we use item.Fields[fieldName] as using item[fieldName] does not return null
            return item.Fields[fieldName] != null;
        }

        public static bool HasField(this Item item, ID fieldId)
        {
            // make sure our defaults are set
            if (item == null || !fieldId.HasValue())
            {
                return false;
            }

            // we use item.Fields[fieldName] as using item[fieldName] does not return null
            return item.Fields[fieldId] != null;
        }
        #endregion

        #region ArchiveItem
        /// <summary>
        /// Archive the Item
        /// </summary>
        /// <param name="itm">The item to archive</param>
        /// <returns>Returns true if the item has been archived</returns>
        public static bool ArchiveItem(this Item itm)
        {
            // get the database to archive
            Sitecore.Data.Archiving.Archive archive = Sitecore.Data.Archiving.ArchiveManager.GetArchive("archive", itm.Database);

            // archive the item
            var hasArchived = archive.ArchiveItem(itm);
            
            // do we have a guid
            return (hasArchived != null);
        }
        #endregion

        #region GetValidURL
        /// <summary>
        /// Gets a valid URL for the Item
        /// </summary>
        /// <param name="itm">Returns valid url</param>
        /// <returns></returns>
        public static string GetValidURL(this Sitecore.Data.Items.Item itm, Sitecore.Links.UrlOptions options = null)
        {
            if (itm != null)
            {
                // have to supplied options if not set default
                if (options == null)
                {
                    // use the default options, but alow for minor overrides
                    options = Sitecore.Links.UrlOptions.DefaultOptions;
                    options.Site = Sitecore.Context.Site;
                }

                // get the link
                return Sitecore.Links.LinkManager.GetItemUrl(itm, options);
            }

            // error or no data set
            return string.Empty;
        }
        #endregion

        #region HasBaseTemplate
        /// <summary>
        /// Does the curren Item inherit from a specific base template
        /// </summary>
        /// <param name="item">The item to confirm has the base template</param>
        /// <param name="baseTemplatID">The base template ID to compare against</param>
        /// <returns>Returns true if the item inherits the base template false for all other instances</returns>
        public static bool HasBaseTemplate(this Item item, string baseTemplateID)
        {
            // make sure we have data
            if (item == null
                && baseTemplateID.IsNullOrEmpty())
            {
                return false;
            }

            // get the base temate
            return HasBaseTemplate(item, Sitecore.Data.ID.Parse(baseTemplateID));
        }

        /// <summary>
        /// Does the curren Item inherit from a specific base template
        /// </summary>
        /// <param name="item">The item to confirm has the base template</param>
        /// <param name="baseTemplatID">The base template ID to compare against</param>
        /// <returns>Returns true if the item inherits the base template false for all other instances</returns>
        public static bool HasBaseTemplate(this Item item, ID baseTemplatID)
        {
            // ensure we have data that is valid
            if (item == null && baseTemplatID.IsNull)
            {
                return false;
            }
            
            // get the template from the item
            Template template = TemplateManager.GetTemplate(item);

            if (template == null)
            {
                return false;
            }

            // does this item inherit the base template
            return template.InheritsFrom(baseTemplatID);
        }
        #endregion

        #region IsStandardValue
        /// <summary>
        /// Is the current item the standard value item
        /// </summary>
        /// <param name="item">The item to check to see is this a standadr value item</param>
        /// <returns>True if the item is a standard value false all other instances</returns>
        public static bool IsStandardValue(this Item item)
        {
            // do we have an item and is it part of the template path
            if (item != null
                && item.Paths.Path.StartsWith(Constants.SitecoreConstants.TemplatePath)
                && item.Template.StandardValues != null)
            {
                return item.Template.StandardValues.ID.EqualsTo(item.ID.ToString());
            }

            return false;
        }
        #endregion

        #region Is Derived From
        /// <summary>
        /// For a given template ID, finds if this item was derived from it
        /// </summary>
        /// <param name="item"></param>
        /// <param name="templateIDItemIsDerivedFrom">The template id this item may have been derived from</param>
        /// <returns></returns>
        public static bool IsDerivedFrom(this Item item, ID templateIDItemIsDerivedFrom)
        {
            var template = TemplateManager.GetTemplate(item);

            return template.ID == templateIDItemIsDerivedFrom || template.GetBaseTemplates().Any(baseTemplate => baseTemplate.ID == templateIDItemIsDerivedFrom);
        }
        #endregion

    }
}
