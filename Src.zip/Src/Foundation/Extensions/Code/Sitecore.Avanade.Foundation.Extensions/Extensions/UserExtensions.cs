﻿using System;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class UserExtensions
    {
        #region IsLoggedInPublic
        /// <summary>
        /// Has the user logged into the public site, not sitecore administrator
        /// </summary>
        /// <param name="user"></param>
        /// <returns>Returns true if the user is logged into the system</returns>
        public static bool IsLoggedInPublic(this Sitecore.Security.Accounts.User user)
        {
            // setup the default response
            return Sitecore.Context.Items.Get<bool>("SitecoreUser", ()=>
            {
                bool defaultResponse = false;

                // make sure we have  data
                if (user != null)
                {
                    // is the user authenticated
                    defaultResponse = user.IsAuthenticated
                        && !user.GetDomainName().Equals("sitecore", StringComparison.OrdinalIgnoreCase);
                }

                // return our data
                return defaultResponse;
            });
        }
        #endregion

        #region ClearUserHtmlCache
        /// <summary>
        /// Clears the user cache. Any cache keys that contain the CONTEXT user's name will be picked up by this.
        /// NOTE: This is only for context user.
        /// </summary>
        /// <param name="user"></param>
        /// <param name="Keys">Pass in text that are part of keys of caches that also need to be removed</param>
        public static void ClearUserHtmlCache(this Sitecore.Security.Accounts.User user, params string[] Keys)
        {
            Sitecore.Context.Site.SiteInfo.HtmlCache.InnerCache.RemoveKeysContaining(user.Name);

           //Remove any other caches with keys that contain passed text
           if(Keys.Any())
            {
                Keys.ForEach(key =>
                    Context.Site.SiteInfo.HtmlCache.InnerCache.RemoveKeysContaining(key)
                );
            }
        }
        #endregion
    }
}
