﻿using System;

namespace Sitecore.Avanade.Foundation.Extensions
{
    /// <summary>
    /// Enum Extensions
    /// </summary>
    public static class EnumExtensions
    {
        #region Description
        /// <summary>
        /// Get the description of the Enum
        /// </summary>
        /// <param name="value">The enum to pass in</param>
        /// <returns>Returns the description string</returns>
        public static string Description(this Enum value)
        {
            // variables  
            var enumType = value.GetType();
            var field = enumType.GetField(value.ToString());
            var attributes = field.GetCustomAttributes(typeof(System.ComponentModel.DescriptionAttribute), false);

            // return  
            return attributes.Length == 0 ? value.ToString() : ((System.ComponentModel.DescriptionAttribute)attributes[0]).Description;
        }
        #endregion
    }
}
