﻿using System.Linq;

namespace Sitecore.Avanade.Foundation.Extensions
{
    /// <summary>
    /// Sitecore Axis Extensions
    /// </summary>
    public static class ItemAxisExtensions
    {
        #region SelectItems
        /// <summary>
        /// Performs a Sitecore XPath query using the source item as context item.
        /// </summary>
        /// <param name="itm">The Sitecore Item</param>
        /// <param name="query">The query</param>
        /// <param name="disableSecurity">Do we want to disable security to fetch all items</param>
        /// <returns>The items</returns>
        public static Sitecore.Data.Items.Item[] SelectItems(this Sitecore.Data.Items.ItemAxes itm, string query, bool disableSecurity = false)
        {
            // make sure we have what is valid
            if (itm == null || query.IsNullOrEmpty())
            {
                return new Data.Items.Item[0];
            }

            // if we have disabled security we need to fetch data differently
            if (disableSecurity)
            {
                // disable the security from sitecore
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    return itm.SelectItems(query);
                }
            }

            return itm.SelectItems(query);
        }
        #endregion

        #region SelectSingleItem
        /// <summary>
        /// Performs a Sitecore XPath query using the source item as context it
        /// </summary>
        /// <param name="itm">The Sitecore item to base the query from</param>
        /// <param name="query">The sitecore query</param>
        /// <param name="disableSecurity">Do we want to disable security to fetch the item</param>
        /// <returns>Returns the item</returns>
        public static Sitecore.Data.Items.Item SelectSingleItem(this Sitecore.Data.Items.ItemAxes itm, string query, bool disableSecurity = false)
        {
            // make sure we have valid data
            if (itm == null || query.IsNullOrEmpty())
            {
                return null;
            }

            // are we do disable the sitecore security to fetch all data
            if (disableSecurity)
            {
                // fully disable the security model within sitecore to fetch the data
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    return itm.SelectSingleItem(query);
                }
            }

            return itm.SelectSingleItem(query);
        }
        #endregion

        #region GetItem
        /// <summary>
        /// Gets an item relative to the source item.
        /// </summary>
        /// <param name="itm">The item to process</param>
        /// <param name="path">The query to execute</param>
        /// <param name="disableSecurity">Do we want to disable security to fetch the item</param>
        /// <returns>Returns the item</returns>
        public static Sitecore.Data.Items.Item GetItem(this Sitecore.Data.Items.ItemAxes itm, string path, bool disableSecurity = false)
        {
            // make sure we have what we need
            if (itm == null || path.IsNullOrEmpty())
            {
                return null;
            }

            // are we disabling th security
            if (disableSecurity)
            {
                // disable the security
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    return itm.GetItem(path);
                }
            }

            return itm.GetItem(path);
        }
        #endregion

        #region GetDescendants
        /// <summary>
        /// Gets a list of items that is in descendant axis of the source item.
        /// </summary>
        /// <param name="itm">The item to process the data from</param>
        /// <param name="disableSecurity">Do we want to disable security to fetch the item</param>
        /// <returns>The descendants</returns>
        public static Sitecore.Data.Items.Item[] GetDescendants(this Sitecore.Data.Items.ItemAxes itm, bool disableSecurity = false)
        {
            // make sure we have what we need
            if (itm == null)
            {
                return new Data.Items.Item[0];
            }

            // are we disabling th security
            if (disableSecurity)
            {
                // disable the security
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    return itm.GetDescendants();
                }
            }

            return itm.GetDescendants();
        }
        #endregion

        #region GetChild
        /// <summary>
        /// Gets a child item.
        /// </summary>
        /// <param name="itm">The item to process</param>
        /// <param name="itemName">The item name to find</param>
        /// <param name="disableSecurity">Do we want to disable security to fetch the item</param>
        /// <returns>Returns an item</returns>
        public static Sitecore.Data.Items.Item GetChild(this Sitecore.Data.Items.ItemAxes itm, string itemName, bool disableSecurity = false)
        {
            // make sure we have the data
            if (itm == null || itemName.IsNullOrEmpty())
            {
                return null;
            }

            // are we disabling th security
            if (disableSecurity)
            {
                // disable the security
                using (new Sitecore.SecurityModel.SecurityDisabler())
                {
                    return itm.GetChild(itemName);
                }
            }

            return itm.GetChild(itemName);
        }
        #endregion

        #region GetAncestors
        /// <summary>
        /// Gets the Ancestors, but can reverse the order
        /// </summary>
        /// <param name="itm">The item that the ancestor list is being processed from</param>
        /// <param name="reverseOrder">Is the order in reverse (default) or parent > parent etc</param>
        /// <returns>The items ancestors</returns>
        public static Sitecore.Data.Items.Item[] GetAncestors(this Sitecore.Data.Items.ItemAxes itm, bool reverseOrder = true)
        {
            if (!reverseOrder)
            {
                return itm.GetAncestors().Reverse().ToArray();
            }

            return itm.GetAncestors();
        }
        #endregion
    }
}
