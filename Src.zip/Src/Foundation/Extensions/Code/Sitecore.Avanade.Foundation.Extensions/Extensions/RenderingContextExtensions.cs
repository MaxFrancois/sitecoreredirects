﻿using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Mvc.Presentation;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class RenderingContextExtensions
    {
        /// <summary>
        /// Used to get the datasource item set on a rendering.
        /// </summary>
        /// <param name="renderingContext"></param>
        /// <returns></returns>
        public static Item GetDataSourceItem(this RenderingContext renderingContext, bool contextNoDatasource = false)
        {
            //Get the rendering from the context
            if (renderingContext == null) return null;
            var rendering = renderingContext.Rendering;
            if (rendering == null) return null;

            //Get the datasource from this rendering
            var datasource = rendering.DataSource;
            
            if (string.IsNullOrWhiteSpace(datasource))
            {
                // no datasource so get the context
                if (contextNoDatasource)
                {
                    return renderingContext.ContextItem;
                }

                //No data source set, return an empty list and log
                Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Datasource not set for rendering {rendering.RenderingItem.Name}", typeof(RenderingContext));
                return null;
            }

            //Get the datasource item
            var dataSourceItem = Context.Database.GetItem(datasource);
            if (dataSourceItem == null)
            {
                //The data source item cannot be found, log and return an empty list
                Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Extensions]: Rendering, {rendering.RenderingItem.Name}, has an invalid datasource set.", typeof(RenderingContext));
                return null;
            }

            //return the datasource item
            return dataSourceItem;
        }
    }
}
