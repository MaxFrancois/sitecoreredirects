﻿using System.Web.SessionState;

namespace Sitecore.Avanade.Foundation.Extensions
{
    public static class HttpSessionStateBaseExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="session"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static T GetValue<T>(this HttpSessionState session, string key)
        {
            return session.GetValue<T>(key, default(T));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="session"></param>
        /// <param name="key"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static T GetValue<T>(this HttpSessionState session, string key, T defaultValue)
        {
            if (session[key] != null)
            {
                return (T)System.Convert.ChangeType(session[key], typeof(T));
            }

            return defaultValue;
        }
    }
}