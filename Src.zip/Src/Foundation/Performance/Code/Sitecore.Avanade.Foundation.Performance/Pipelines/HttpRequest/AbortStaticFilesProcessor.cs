﻿using System;
using System.Linq;

using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.HttpRequest
{
    /// <summary>
    /// Aborts the static files from the processor, this also has an exclude list
    /// just in case we need to abort a certain file to have the security
    /// </summary>
    public class AbortStaticFilesProcessor : Sitecore.Pipelines.HttpRequest.HttpRequestProcessor
    {
        #region Private Variables
        /// <summary>
        /// The executed URLS
        /// </summary>
        private System.Collections.Concurrent.ConcurrentDictionary<string, bool> ExecutedURLs { get; set; } = new System.Collections.Concurrent.ConcurrentDictionary<string, bool>();
        
        /// <summary>
        /// The list of exclusions for static files
        /// </summary>
        private System.Collections.Concurrent.ConcurrentBag<string> Excludes { get; set; } = new System.Collections.Concurrent.ConcurrentBag<string>();

        /// <summary>
        /// The list of dynamic files to include in excluding pipeline calling
        /// </summary>
        private System.Collections.Concurrent.ConcurrentBag<string> DynamicExclude { get; set; } = new System.Collections.Concurrent.ConcurrentBag<string>();

        /// <summary>
        /// Media Paths
        /// </summary>
        private readonly string mediaPath = string.Format("/{0}", Sitecore.Configuration.Settings.Media.MediaLinkPrefix);
        #endregion

        #region Public Properties
        /// <summary>
        /// Adds the exclude item to the list
        /// </summary>
        /// <param name="exclude">The exclude path to add</param>
        public void AddExcludes(string exclude)
        {
            // force to be lower for basic checking
            exclude = exclude.ToLower();

            // does the data contain a comma
            if (exclude.Contains(','))
            {
                foreach (string itm in exclude.Split(','))
                {
                    if (!this.Excludes.Contains(itm))
                    {
                        this.Excludes.Add(itm);
                    }
                }
            }
            else
            {
                if (!this.Excludes.Contains(exclude))
                {
                    this.Excludes.Add(exclude);
                }
            }
        }

        /// <summary>
        /// Adds the dynamic exclude item to the list
        /// </summary>
        /// <param name="dynamicExclude">The dynamic exclude to add</param>
        public void AddDynamicExclude(string dynamicExclude)
        {
            // force to be lower for basic checking
            dynamicExclude = dynamicExclude.ToLower();

            // does the data contain a comma
            if (dynamicExclude.Contains(','))
            {
                foreach (string itm in dynamicExclude.Split(','))
                {
                    if (!this.DynamicExclude.Contains(itm))
                    {
                        this.DynamicExclude.Add(itm);
                    }
                }
            }
            else
            {
                if (!this.DynamicExclude.Contains(dynamicExclude))
                {
                    this.DynamicExclude.Add(dynamicExclude);
                }
            }
        }
        #endregion

        #region IsPhysicalPath
        /// <summary>
        /// Is the Physcial path a valid path
        /// </summary>
        /// <param name="args"></param>
        /// <returns>Returns true if the path is a valid path</returns>
        private bool IsPhysicalPath(Sitecore.Pipelines.HttpRequest.HttpRequestArgs args)
        {
            // have to make sure we pass the correct path length
            if (args.Context.Request.Url.AbsoluteUri.Length <= 247)
            {
                return string.IsNullOrEmpty(args.Context.Request.PhysicalPath);
            }
            else
            {
                // have to make sure it's not the querystring
                if (!string.IsNullOrEmpty(args.Context.Request.Url.Query)
                    && args.Context.Request.Url.AbsoluteUri.Replace(args.Context.Request.Url.Query, "").Length <= 247)
                {
                    return string.IsNullOrEmpty(args.Context.Request.PhysicalPath);
                }
            }

            return true;
        }
        #endregion

        #region IsContextValid
        /// <summary>
        /// Is the current ContextValid to execute
        /// </summary>
        /// <param name="args">The Sitecore HTTP Request Arguments</param>
        /// <returns>Returns true if the context is valid to run</returns>
        private bool IsContextValid(Sitecore.Pipelines.HttpRequest.HttpRequestArgs args)
        {
            // make sure the data is valid
            if (args?.Url?.FilePath == null
                || args.Url.FilePath.IsNullOrEmpty())
            {
                return false;
            }

            bool isLocalPathValid = false;

            // do we high level service check
            if (!args.Url.FilePath.EndsWith(".svc"))
            {
                // this is a known issue it fails under large paths
                try
                {
                    if (args.LocalPath != null)
                    {
                        isLocalPathValid = true;
                    }
                }
                catch (System.Exception ex)
                {
                    // nothing
                    isLocalPathValid = false;

                    // log the error
                    Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Performance]: URL not valid, check - {args.Context.Request.RawUrl}", ex, typeof(AbortStaticFilesProcessor));
                }
            }

            // make sure all is fine
            bool isValid = (args.Context?.Request?.Path != null
                            && !args.Context.Request.Path.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.KeepAlive, StringComparison.OrdinalIgnoreCase)
                            && !args.Context.Request.Path.StartsWith(Sitecore.Constants.SitecorePath)
                            && !args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.TempFolderPath)
                            && !args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.DataFolder)
                            && !args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.MediaFolder)
                            && !Sitecore.Configuration.Factory.GetCustomHandlers().Exists(e => args.Context.Request.Path.StartsWith(string.Format("/{0}", e.Trigger), StringComparison.OrdinalIgnoreCase))
                            && !IsPhysicalPath(args)
                            );

            // determine if we can run this check
            if (isValid
                && isLocalPathValid)
            {
                isValid = !args.LocalPath.StartsWith(mediaPath, StringComparison.OrdinalIgnoreCase);
            }

            return isValid;
        }
        #endregion

        #region Process
        /// <summary>
        /// The initial processor which is used to access the data
        /// </summary>
        /// <param name="args">Sitecore Arguments for the http request</param>
        public override void Process(Sitecore.Pipelines.HttpRequest.HttpRequestArgs args)
        {
            // make sure we have our arguments before we have any issues
            Sitecore.Diagnostics.Assert.ArgumentNotNull(args, "args");

            // make sure we have data to actually process
            if (IsContextValid(args))
            {
                #region Clear Instance
                // do we have our cached instance
                bool? isAbortCached = Cache.Cache.Has("AbortStaticCacheKey", siteName: "Global", databaseName: "DB");

                // do we??
                if (isAbortCached == null || !isAbortCached.Value)
                {
                    // we need to clear the instance
                    ExecutedURLs.Clear();
                
                    if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                    {
                        Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Performance]: AbortStaticFile: Local Cache Cleared", typeof(AbortStaticFilesProcessor));
                    }

                    // set the data so it's always valid this gets overwritten
                    Cache.Cache.Add("AbortStaticCacheKey", true, System.DateTime.MaxValue, siteName: "Global", databaseName: "DB");
                }
                #endregion

                #region Fetch/Create Abort
                // setup defaults
                bool killPipeline = false;
                string urlCacheKey = args.Context.Request.Url.AbsolutePath;
                bool noDataFound = true;

                // has this already been executed
                if (ExecutedURLs != null
                    && !ExecutedURLs.IsEmpty
                    && ExecutedURLs.ContainsKey(urlCacheKey))
                {
                    // gets out the key         `
                    ExecutedURLs.TryGetValue(urlCacheKey, out killPipeline);
                    noDataFound = false;
                }

                if (noDataFound)
                {
                    // do we need to abort the execution
                    System.IO.FileInfo file = new System.IO.FileInfo(args.Context.Request.PhysicalPath);

                    // does the file exist
                    if (file.Exists)
                    {
                        // we want to kill the pipeline
                        killPipeline = true;

                        // do we have any extensions to check
                        if (this.Excludes != null && this.Excludes.Any(e=> args.Context.Request.Path.ToLower().StartsWith(e)))
                        {
                            killPipeline = false;
                        }
                    }
                    else
                    {
                        // is the file part of the dynamic exclude
                        if (this.DynamicExclude.Any(e => args.Context.Request.Path.ToLower().StartsWith(e)))
                        {
                            // kill the pipeline
                            killPipeline = true;
                        }
                    }

                    // add the url so we don't have to process again
                    if (!ExecutedURLs.ContainsKey(urlCacheKey))
                    {
                        ExecutedURLs.TryAdd(urlCacheKey, killPipeline);
                    }
                }
                #endregion

                #region Debug
                // is debug enabled
                if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                {
                    Sitecore.Diagnostics.Log.Debug(string.Format("{0}AbortStaticFile: URL:'{1}', AbortProcessing:'{2}'", Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix, args.Context.Request.Url.PathAndQuery, killPipeline), typeof(AbortStaticFilesProcessor));
                }
                #endregion

                #region Killpipeline Check
                // kill the pipeline
                if (killPipeline)
                {
                    // kill the pipeline
                    args.AbortPipeline();

                    return;
                }
                #endregion
            }
        }
        #endregion
    }
}