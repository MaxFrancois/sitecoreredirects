﻿namespace Sitecore.Avanade.Foundation.Performance.Pipelines.HttpRequest
{
    /// <summary>
    /// Determines if the request is a file or a virtual folder. This has been overridden to resolve
    /// a dynamic virtual folder issue
    /// </summary>
    /// <remarks>This replaces the sitecore default FileResolve as this can introduce errors
    /// which this fixes and resolves</remarks>
    public class FileResolver : Sitecore.Pipelines.HttpRequest.HttpRequestProcessor
    {
        /// <summary>
        /// Runs the File Resolver processor to determine if the file is to be run
        /// </summary>
        /// <param name="args">The arguments.</param>
        public override void Process(Sitecore.Pipelines.HttpRequest.HttpRequestArgs args)
        {
            Sitecore.Diagnostics.Assert.ArgumentNotNull(args, "args");

            // has the processing been aborted
            if (args.Aborted)
            {
                // abort
                return;
            }

            // get the file path
            if (Sitecore.Context.Page.FilePath.Length > 0)
            {
                return;
            }

            // get the file url path
            string text = args.Url.FilePath;

            // does the item exist, this is what causes issues
            if (!string.IsNullOrEmpty(text))
            {
                // does the directory exist
                if (System.Web.Hosting.HostingEnvironment.VirtualPathProvider.DirectoryExists(text))
                {
                    text = Sitecore.IO.FileUtil.MakePath(text, "default.aspx");
                }

                // do we have the correct information
                if (string.CompareOrdinal(text, "/default.aspx") != 0 && System.Web.Hosting.HostingEnvironment.VirtualPathProvider.FileExists(text))
                {
                    Sitecore.Diagnostics.Tracer.Info("Using virtual file \"" + text + "\" instead of Sitecore layout.");
                    Sitecore.Context.Page.FilePath = text;
                }
            }
        }
    }
}
