﻿using Sitecore.Mvc.Pipelines.Response.RenderPlaceholder;
using Sitecore.Avanade.Foundation.Performance.Extensions;
using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Performance.Pipelines.PlaceholderStatistics;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderPlaceholder
{
    public class PlaceholderStatisticsPipeline : RenderPlaceholderProcessor
    {

        public override void Process(RenderPlaceholderArgs args)
        {
            if (args.EnableStats()
                && args.CustomData != null
                && args.CustomData.Count > 0
                && args.CustomData.ContainsKey(Constants.TimerName)
                && args.CustomData.ContainsKey(Constants.ItemsRead))
            {
                PlaceholderStatisticsArgs renderingArgs = new PlaceholderStatisticsArgs(args);

                // run the pipeline
                CorePipeline.Run("mvc.renderPlaceholderStatistics", renderingArgs, false);
            }
        }
    }
}