﻿using Sitecore.Mvc.Pipelines.Response.RenderPlaceholder;
using Sitecore.Diagnostics;
using Sitecore.Avanade.Foundation.Performance.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderPlaceholder
{
    public class InitializePlaceholderStatistics : RenderPlaceholderProcessor
    {
        public override void Process(RenderPlaceholderArgs args)
        {
            if (args.EnableStats())
            {
                args.CustomData.Add(Constants.TimerName, new HighResTimer(true));
                args.CustomData.Add(Constants.ItemsRead, Sitecore.Diagnostics.PerformanceCounters.DataCount.DataItemsAccessed.Value);
            }
        }
    }
}