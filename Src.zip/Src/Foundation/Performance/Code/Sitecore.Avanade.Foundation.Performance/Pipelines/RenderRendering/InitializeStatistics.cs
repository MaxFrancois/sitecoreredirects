﻿using Sitecore.Mvc.Pipelines.Response.RenderRendering;
using Sitecore.Diagnostics;
using Sitecore.Avanade.Foundation.Performance.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderRendering
{
    /// <summary>
    /// Get the results of the Stop watch
    /// </summary>
    public class InitializeStatistics : RenderRenderingProcessor
    {
        public override void Process(RenderRenderingArgs args)
        {
            // are we disabling the stats for this rendering
            if (args.EnableStats()
                && args.CustomData != null)
            {
                args.CustomData.Add(Constants.TimerName, new HighResTimer(true));
                args.CustomData.Add(Constants.ItemsRead, Sitecore.Diagnostics.PerformanceCounters.DataCount.DataItemsAccessed.Value);
            }
        }
    }
}