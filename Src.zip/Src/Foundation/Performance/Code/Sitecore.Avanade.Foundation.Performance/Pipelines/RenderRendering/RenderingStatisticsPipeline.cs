﻿using Sitecore.Mvc.Pipelines.Response.RenderRendering;
using Sitecore.Avanade.Foundation.Performance.Extensions;

using Sitecore.Avanade.Foundation.Performance.Pipelines.RenderingStatistics;
using Sitecore.Pipelines;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderRendering
{
    public class RenderingStatisticsPipeline : RenderRenderingProcessor
    {
        public override void Process(RenderRenderingArgs args)
        {
            if (args.EnableStats()
                && args.CustomData != null
                && args.CustomData.Count > 0
                && args.CustomData.ContainsKey(Constants.TimerName)
                && args.CustomData.ContainsKey(Constants.ItemsRead))
            {
                RenderStatisticsArgs renderingArgs = new RenderStatisticsArgs(args);

                // run the pipeline
                CorePipeline.Run("mvc.renderRenderingStatistics", renderingArgs, false);
            }
        }
    }
}