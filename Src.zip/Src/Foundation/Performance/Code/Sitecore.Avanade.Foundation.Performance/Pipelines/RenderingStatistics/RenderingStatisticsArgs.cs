﻿using Sitecore.Diagnostics;
using Sitecore.Mvc.Pipelines.Response.RenderRendering;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderingStatistics
{
#pragma warning disable S3925 // "ISerializable" should be implemented correctly
    public class RenderStatisticsArgs: Sitecore.Mvc.Pipelines.MvcPipelineArgs
#pragma warning restore S3925 // "ISerializable" should be implemented correctly
    {
        /// <summary>
        /// Returns the HttpRequestArgs supplied
        /// </summary
        [XmlIgnore]
        public RenderRenderingArgs RenderingRenderingArgs { get; internal set; }

        public long ItemsRead { get; internal set; }

        public string TraceName { get; internal set; }

        public double Elapsed { get; internal set; }

        private string GetTraceName(Mvc.Presentation.Rendering rendering)
        {
            return string.Format("{0} ({1})", rendering.Item.DisplayName, rendering.RenderingItem.InnerItem.Paths.Path);
        }

        /// <summary>
        /// Extends the HttpRequestArgs for the Redireciton pipeline
        /// </summary>
        /// <param name="args">The HttpRequestArgs supplied in the pipeline for the HttpRequest Pipeline</param>
        public RenderStatisticsArgs(RenderRenderingArgs args)
        {
            // make sure we have our data
            Assert.ArgumentNotNull(args, "args");

            this.RenderingRenderingArgs = args;

            HighResTimer timer = (args.CustomData[Constants.TimerName] as HighResTimer);

            this.ItemsRead = (Sitecore.Diagnostics.PerformanceCounters.DataCount.DataItemsAccessed.Value - (long)args.CustomData[Constants.ItemsRead]);
            this.TraceName = GetTraceName(args.Rendering);
            this.Elapsed = timer.Elapsed();
        }
    }
}