﻿using Sitecore.Mvc.Pipelines;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderingStatistics
{
    public abstract class RenderingStatisticsProcessor : MvcPipelineProcessor<RenderStatisticsArgs>
    {
        
    }
}