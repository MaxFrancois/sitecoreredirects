﻿using Sitecore.Diagnostics;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.RenderingStatistics
{
    public class RecordStatistics : RenderingStatisticsProcessor
    {
        public override void Process(RenderStatisticsArgs args)
        {
            // has the stats been disable on the rendering
            if (args.RenderingRenderingArgs.Rendering.RenderingField(Constants.RenderingStatsEnabled).ValueSafe<bool>(false, true)
                || args.RenderingRenderingArgs.Rendering.Parameters.ValueSafe<bool>(Constants.RenderingStatsEnabled, true)
                )
            {
                // we need to make sure this works or else
                try
                {
                    // add the rendering data
                    Statistics.AddRenderingData(args.TraceName,
                                                args.Elapsed,
                                                args.ItemsRead,
                                                args.RenderingRenderingArgs.UsedCache);
                }
                catch (System.Exception ex)
                {
                    Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Performance]: Failed to record rendering statistics", ex);
                }
            }
        }
    }
}