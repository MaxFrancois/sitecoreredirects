﻿using Sitecore.Mvc.Pipelines;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.PlaceholderStatistics
{
    public abstract class PlaceholderStatisticsProcessor : MvcPipelineProcessor<PlaceholderStatisticsArgs>
    {
        
    }
}