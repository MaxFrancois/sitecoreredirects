﻿using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Mvc.Pipelines.Response.RenderPlaceholder;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.PlaceholderStatistics
{
#pragma warning disable S3925 // "ISerializable" should be implemented correctly
    public class PlaceholderStatisticsArgs: Sitecore.Mvc.Pipelines.MvcPipelineArgs
#pragma warning restore S3925 // "ISerializable" should be implemented correctly
    {
        /// <summary>
        /// Returns the HttpRequestArgs supplied
        /// </summary
        [XmlIgnore]
        public RenderPlaceholderArgs RenderPlaceholderArgs { get; internal set; }

        public long ItemsRead { get; internal set; }

        public string TraceName { get; internal set; }

        public double Elapsed { get; internal set; }

        public Item Item { get; internal set; }

        private string GetTraceName(string placeholderName)
        {
            return string.Format("Placeholder: {0}", placeholderName);
        }

        /// <summary>
        /// Extends the HttpRequestArgs for the Redireciton pipeline
        /// </summary>
        /// <param name="args">The HttpRequestArgs supplied in the pipeline for the HttpRequest Pipeline</param>
        public PlaceholderStatisticsArgs(RenderPlaceholderArgs args)
        {
            // make sure we have our data
            Assert.ArgumentNotNull(args, "args");

            this.RenderPlaceholderArgs = args;

            HighResTimer timer = (args.CustomData[Constants.TimerName] as HighResTimer);

            this.ItemsRead = (Sitecore.Diagnostics.PerformanceCounters.DataCount.DataItemsAccessed.Value - (long)args.CustomData[Constants.ItemsRead]);
            this.TraceName = GetTraceName(args.PlaceholderName);
            this.Elapsed = timer.Elapsed();
            this.Item = Client.Page.GetPlaceholderItem(args.PlaceholderName, args.PageContext.Database);
        }
    }
}