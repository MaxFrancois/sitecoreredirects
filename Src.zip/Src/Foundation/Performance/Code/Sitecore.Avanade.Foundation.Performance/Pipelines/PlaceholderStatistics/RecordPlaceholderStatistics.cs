﻿using Sitecore.Diagnostics;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Pipelines.PlaceholderStatistics
{
    public class PlaceholderStatisticsPipeline : PlaceholderStatisticsProcessor
    {

        public override void Process(PlaceholderStatisticsArgs args)
        {
            // make sure we have data
            if (args.Item != null
                && args.Item.Fields[Constants.RenderingStatsEnabled].ValueSafe<bool>(false, true))
            {
                try
                {
                    // add the details to the rendering data
                    Statistics.AddRenderingData(args.TraceName,
                        args.Elapsed,
                        args.ItemsRead,
                        false);
                }
                catch (System.Exception ex)
                {
                    Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Performance]: Failed to record placeholder statistics", ex);
                }
            }
        }
    }
}