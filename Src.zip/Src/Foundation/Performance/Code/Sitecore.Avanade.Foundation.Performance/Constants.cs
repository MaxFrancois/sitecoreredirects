﻿namespace Sitecore.Avanade.Foundation.Performance
{
    public static class Constants
    {
        public const string TimerName = "timer";
        public const string ItemsRead = "itemsRead";

        ///sitecore/templates/System/Layout/Device
        public const string DeviceItem = "{B6F7EEB4-E8D7-476F-8936-5ACE6A76F20B}";

        public const string BaseTemplateId = "{34D0FDBB-7E56-4A72-B55E-81445CD9F897}";

        public const string RenderingStatsEnabled = "RenderingStatsEnabled";
    }
}