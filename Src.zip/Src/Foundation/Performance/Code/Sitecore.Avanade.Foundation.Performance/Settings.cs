﻿namespace Sitecore.Avanade.Foundation.Performance
{ 
    public static class Settings
    {
        #region Public Properties
        /// <summary>
        /// Is NewRelic Enabled
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.Performance.Enabled", false,
                    Constants.BaseTemplateId, "Enabled", domainListFilter: true);
            }
        }
        #endregion

        public static class PlaceHolder
        {
            public static class Statistics
            {
                #region Public Properties
                public static bool PlacholderStatisticsIsEnabled
                {
                    get
                    {
                        return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.Performance.PlaceHolder.Statistics.Enabled", false,
                            Constants.BaseTemplateId, "Placeholders Enabled", domainListFilter: true);
                    }
                }
                #endregion
            }
        }

        public static class Rendering
        {
            public static class Statistics
            {
                #region Public Properties
                public static bool RenderingStatisticsIsEnabled
                {
                    get
                    {
                        return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.Performance.Renderings.Statistics.Enabled", false,
                            Constants.BaseTemplateId, "Renderings Enabled", domainListFilter: true);

                    }
                }
                #endregion
            }
        }


    }
}
