﻿using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Performance.Extensions
{
    public static class RenderingArgsExtensions
    {
        /// <summary>
        /// Disable Stats validation checks
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static bool EnableStats(this Sitecore.Mvc.Pipelines.Response.RenderRendering.RenderRenderingArgs args)
        {
            // get the rendering details
            return Sitecore.Context.Items.Get<bool>($"rendering_stats_{args.Rendering.UniqueId.ToString()}", () =>
            {
                // flat out stop
                if (Sitecore.Context.PageMode.IsExperienceEditor
                    || Sitecore.Context.PageMode.IsPreview
                    || Sitecore.Context.PageMode.IsSimulatedDevicePreviewing
                    || Sitecore.Context.PageMode.IsProfiling)
                {
                    return false;
                }

                // get the performance rendering if globally/site enabled
                bool valid = Sitecore.Context.Items.Get<bool>("performance_rendering_enabled", () =>
                {
                    // have we got the stats enabled
                    return (Settings.IsEnabled
                        && Settings.Rendering.Statistics.RenderingStatisticsIsEnabled
                        && (Context.User.IsAuthenticated ? Context.User.IsLoggedInPublic() : true));
                });

                return (valid && args.Rendering.RenderingItem.InnerItem.TemplateID != Data.ID.Parse(Constants.DeviceItem));
            });
        }
    }
}