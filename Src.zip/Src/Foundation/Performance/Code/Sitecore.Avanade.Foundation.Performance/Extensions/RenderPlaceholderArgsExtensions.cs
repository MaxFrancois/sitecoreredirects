﻿using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Performance.Extensions
{
    public static class RenderPlaceholderArgsExtensions
    {
        /// <summary>
        /// Disable Stats validation checks
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static bool EnableStats(this Sitecore.Mvc.Pipelines.Response.RenderPlaceholder.RenderPlaceholderArgs args)
        {
            // get the rendering details
            return Sitecore.Context.Items.Get<bool>($"placeholder_stats_{args.PlaceholderName}", () => {

                // flat out stop
                if (Sitecore.Context.PageMode.IsExperienceEditor
                    || Sitecore.Context.PageMode.IsPreview
                    || Sitecore.Context.PageMode.IsSimulatedDevicePreviewing
                    || Sitecore.Context.PageMode.IsProfiling)
                {
                    return false;
                }

                // get the performance rendering if globally/site enabled
                bool valid = Sitecore.Context.Items.Get<bool>("performance_placeholder_enabled", () =>
                {
                    // have we got the stats enabled
                    return (Settings.IsEnabled
                        && Settings.PlaceHolder.Statistics.PlacholderStatisticsIsEnabled
                        && (Context.User.IsAuthenticated ? Context.User.IsLoggedInPublic() : true));
                });

                // are we allowing for renderings to override.
                return (valid && args.PageContext?.Database != null);
            });
        }
    }
}