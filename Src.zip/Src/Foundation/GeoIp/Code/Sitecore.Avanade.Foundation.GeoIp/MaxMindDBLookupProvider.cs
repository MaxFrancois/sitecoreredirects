﻿using MaxMind.GeoIP2;
using Sitecore.Analytics.Lookups;
using Sitecore.Analytics.Model;
using System;

namespace Sitecore.Avanade.Foundation.GeoIp
{
    public class MaxMindDBLookupProvider : LookupProviderBase, IDisposable
    {
        /// <summary>
        /// The MaxMind DB Reader
        /// </summary>
        private static DatabaseReader Reader { get; set; }

        #region Constructor
        /// <summary>
        /// Load up the Database for easy access
        /// </summary>
        static MaxMindDBLookupProvider()
        {
            // get the database path
            string path = Sitecore.Configuration.Settings.GetFileSetting("AI.Foundation.GeoIp.MaxMind.BDPath.City");

            if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsInfoEnabled)
            {
                // log the DB path
                Sitecore.Diagnostics.Log.Info($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[GeoIP] - Startup, loading DB: '{path}'", typeof(MaxMindDBLookupProvider));
            }

            // do we have the folder
            if (!System.IO.File.Exists(path))
            {
                Sitecore.Diagnostics.Log.Fatal($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[GeoIP] - Startup, MaxMind Database not found: '{path}'", typeof(MaxMindDBLookupProvider));
                return;
            }

            // execute the reader
            Reader = new DatabaseReader(path);
        }
        #endregion

        #region GetInformationByIp
        /// <summary>
        /// Get the information from the users IP
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public override WhoIsInformation GetInformationByIp(string ip)
        {
            // do we have the reader
            if (Reader == null)
            {
                // set empty who is
                return new WhoIsInformation();
            }

            // have we already processed this
            return Cache.Cache.Get<WhoIsInformation>(ip, () =>
            {
                // setup new instance for us to  use
                WhoIsInformation whois = new WhoIsInformation();

                try
                {
                    // get the ip record
                    var city = Reader.City(ip);

                    if (city != null)
                    {

                        whois.AreaCode = city.Continent.Code;
                        whois.BusinessName = city.Traits.Organization;
                        whois.City = city.City.Name;
                        whois.Country = city.Country.IsoCode;
                        whois.Isp = city.Traits.Isp;
                        whois.Latitude = city.Location.Latitude;
                        whois.Longitude = city.Location.Longitude;
                        whois.MetroCode = city.Location.MetroCode.ToString();
                        whois.PostalCode = city.Postal.Code;
                        whois.Region = city.MostSpecificSubdivision.IsoCode;
                        whois.Url = city.Traits.Domain;

                    }
                    else
                    {
                        Sitecore.Diagnostics.Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[GeoIP] - IP Address not found: '{ip}'", typeof(MaxMindDBLookupProvider));
                    }
                }
                catch (Exception ex)
                {
                    Sitecore.Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[GeoIP] - Error processing IP: '{ip}'", ex, typeof(MaxMindDBLookupProvider));
                }

                return whois;
            }, Settings.GeoIpCacheExpiryTime);
        }
        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                if (Reader != null)
                {
                    Reader.Dispose();
                }

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        ~MaxMindDBLookupProvider() {
           // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
           Dispose(false);
         }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);

            GC.SuppressFinalize(this);
        }
        #endregion
        
    }
}