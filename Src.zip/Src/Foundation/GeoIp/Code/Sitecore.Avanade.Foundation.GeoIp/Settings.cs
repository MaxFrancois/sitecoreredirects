﻿using System;
using System.Globalization;

namespace Sitecore.Avanade.Foundation.GeoIp
{
    public static class Settings
    {
        /// <summary>
        /// Sitecore default setting
        /// </summary>
        public static TimeSpan GeoIpCacheExpiryTime
        {
            get
            {
                TimeSpan result;
                if (!TimeSpan.TryParse(Sitecore.Configuration.Settings.GetSetting("CES.GeoIp.Caching.GeoIpCacheExpiryTime"), CultureInfo.InvariantCulture, out result))
                {
                    result = TimeSpan.FromDays(1.0);
                }
                return result;
            }
        }
    }
}