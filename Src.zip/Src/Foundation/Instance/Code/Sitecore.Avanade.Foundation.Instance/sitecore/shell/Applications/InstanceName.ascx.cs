﻿using System;

namespace Sitecore.Avanade.Foundation.Instance.sitecore.shell.Applications
{
    public partial class InstanceName : System.Web.UI.UserControl
    {
        /// <summary>
        /// Load the page and set the instance name details
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // have we enabled the instance name
            plcEnableInstanceName.Visible = Sitecore.Avanade.Foundation.Instance.Settings.Instance.IsEnabled;

            // get he instance name in the config
            litInstanceName.Text = Settings.Instance.BuildConfiguration.ToUpper();
        }
    }
}