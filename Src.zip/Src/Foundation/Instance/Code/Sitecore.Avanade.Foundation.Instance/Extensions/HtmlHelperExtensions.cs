﻿namespace Sitecore.Avanade.Foundation.Instance.Extensions
{
    public static class HtmlHelperExtensions
    {
        /// <summary>
        /// The Build configuration
        /// </summary>
        /// <param name="htmlHelper"></param>
        /// <returns></returns>
        public static string BuildConfiguration(this System.Web.Mvc.HtmlHelper htmlHelper)
        {
            // make sure it is enabled
            if (Settings.Instance.IsEnabled)
            {
                return Settings.Instance.BuildConfiguration;
            }

            return string.Empty;
        }
    }
}
