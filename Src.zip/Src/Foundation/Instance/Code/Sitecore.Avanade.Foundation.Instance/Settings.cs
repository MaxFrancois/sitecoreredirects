﻿namespace Sitecore.Avanade.Foundation.Instance
{ 
    public static class Settings
    {
        #region Instance
        /// <summary>
        /// Caching class
        /// </summary>
        public static class Instance
        {
            #region Private Variables
            /// <summary>
            /// Is the Instance Enabled
            /// </summary>
            private static bool? _isEnabled;

            private static string _buildConfiguration;
            #endregion

            #region Public Properties
            /// <summary>
            /// Is the instance enabled
            /// </summary>
            public static bool IsEnabled
            {
                get
                {
                    if (_isEnabled == null)
                    {
                        _isEnabled = Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Instance.Enabled", false);
                    }

                    return _isEnabled.Value;

                }
            }

            /// <summary>
            /// What build configuration are we using
            /// </summary>
            public static string BuildConfiguration
            {
                get
                {
                    if (string.IsNullOrEmpty(_buildConfiguration))
                    {
                        _buildConfiguration = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Instance.BuildConfiguration", "Debug");
                    }

                    return _buildConfiguration;

                }
            }
            #endregion
        }
        #endregion
    }
}
