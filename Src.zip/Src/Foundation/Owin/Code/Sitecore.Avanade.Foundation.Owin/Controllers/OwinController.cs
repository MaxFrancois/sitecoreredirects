﻿using Microsoft.Owin.Security;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Extensions.Attributes;
using Sitecore.Mvc.Controllers;
using Sitecore.Mvc.Presentation;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace Sitecore.Avanade.Foundation.Owin.Controllers
{
    public class OwinController : SitecoreController
    {
        /// <summary>
        /// Configure the policy, allowing for specific templates
        /// </summary>
        /// <returns></returns>
        [DataSourceRequired]
        public ActionResult ConfigurePolicy()
        {
            // get the rendering context
            var itm = RenderingContext.CurrentOrNull?.GetDataSourceItem();

            // do we have an item
            if (itm != null)
            {
                // get the basic policy details
                string policy = itm.Fields["policy"].ValueSafe<string>();
                string returnUrl = itm.Fields["returnUrl"].ValueSafe<string>();

                // make sure we have the data required
                if (policy.IsNullOrEmpty() || returnUrl.IsNullOrEmpty())
                {
                    return new EmptyResult();
                }

                // is there any requirement for authentication
                if (itm.Fields["isSecure"].IsChecked()
                    && !Sitecore.Context.User.IsLoggedInPublic())
                {
                    return new EmptyResult();
                }

                // set the policy required
                HttpContext.GetOwinContext().Set("Policy", policy);

                // sets the challenge that is required
                HttpContext.GetOwinContext().Authentication.Challenge(new AuthenticationProperties { RedirectUri = returnUrl }, "Default");
            }

            return new EmptyResult();
        }

        public ActionResult SignIn()
        {
            // Send an OpenID Connect sign-in request.
            if (!Request.IsAuthenticated)
            {
                HttpContext.GetOwinContext().Authentication.Challenge();
            }

            return new EmptyResult();
        }

        [SitecoreAuthorize()]
        public ActionResult SignOut()
        {
            IEnumerable<AuthenticationDescription> authTypes = HttpContext.GetOwinContext().Authentication.GetAuthenticationTypes();
            HttpContext.GetOwinContext().Authentication.SignOut(authTypes.Select(t => t.AuthenticationType).ToArray());
            Request.GetOwinContext().Authentication.GetAuthenticationTypes();

            return new EmptyResult();
        }

        [SitecoreAuthorize(StopPageExecution = true)]
        public ActionResult ResetPassword()
        {
            // Let the middleware know you are trying to use the reset password policy (see OnRedirectToIdentityProvider in Startup.Auth.cs)
            HttpContext.GetOwinContext().Set("Policy", "B2C_1A_QBE_PasswordReset");

            // Set the page to redirect to after changing passwords
            var authenticationProperties = new AuthenticationProperties { RedirectUri = "/" };
            HttpContext.GetOwinContext().Authentication.Challenge(authenticationProperties);

            return new EmptyResult();
        }
    }
}