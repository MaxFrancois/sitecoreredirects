﻿using Sitecore.Avanade.Foundation.Analytics.Attributes;
using Sitecore.Services.Infrastructure.Web.Http;
using System.Net.Http;
using System.Web.Http;
using Microsoft.Owin.Security;
using System.Web;
using System.Web.Mvc;
using Sitecore.Mvc.Controllers;

namespace Sitecore.Avanade.Foundation.Owin.Controllers
{
    public class AuthenticationOwinController : SitecoreController
    {
        public JsonResult SignIn()
        {
            var owinUser = HttpContext.GetOwinContext().Authentication.User;
            var sitecoreUser = Sitecore.Context.User;

            var res1 = new System.Text.StringBuilder();
            var res2 = new System.Text.StringBuilder();

            res1.AppendLine("{");
            res2.AppendLine("{");

            res1.AppendLine("OwinContext : {");
            res1.AppendLine($"Name : {owinUser.Identity.Name},");
            res1.AppendLine($"Auth Type : {owinUser.Identity.AuthenticationType}");
            res1.AppendLine("}");

            res2.AppendLine("SitecoreContext : {");
            res2.AppendLine($"Name : {sitecoreUser.Identity.Name}");
            res2.AppendLine($"Auth Type : {sitecoreUser.Identity.AuthenticationType}");
            res2.AppendLine("}");

            res1.AppendLine("}");
            res2.AppendLine("}");

            var res = res1.AppendLine(res2.ToString()).ToString();

            return Json(res, JsonRequestBehavior.AllowGet);
        }
    }
}