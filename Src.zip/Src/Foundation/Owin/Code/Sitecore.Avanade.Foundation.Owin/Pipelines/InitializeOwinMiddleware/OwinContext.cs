﻿using IAppBuilder = Owin.IAppBuilder;
using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Security.Pipelines.InitializeOwinMiddleware;
using Sitecore.Diagnostics;
using System;
using Microsoft.Owin.Security.Cookies;
using Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OpenIdConnect;
using System.Threading.Tasks;
using Microsoft.Owin.Security.Notifications;
using System.IdentityModel.Claims;
using Microsoft.IdentityModel.Protocols;
using System.IdentityModel.Tokens;
using System.Xml;
using System.Collections.Generic;
using Sitecore.Avanade.Foundation.Extensions;
using System.Linq;
using Sitecore.Data;
using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.Owin.Pipelines.InitializeOwinMiddleware
{
    public class OwinContext
    {
        /// <summary>
        /// The database name
        /// </summary>
        protected string DatabaseName { get; set; }


        public void Process(InitializeOwinMiddlewareArgs args)
        {
            Log.Warn($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[OwinContext]: Actioning the Owin Context", typeof(OwinContext));

        }
    }
}