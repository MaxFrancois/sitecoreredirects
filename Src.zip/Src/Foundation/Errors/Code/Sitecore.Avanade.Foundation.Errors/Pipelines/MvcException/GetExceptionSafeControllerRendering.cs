﻿using System;
using Sitecore.Mvc.Presentation;
using Sitecore.Mvc.Pipelines.Response.GetRenderer;


namespace Sitecore.Avanade.Foundation.Errors.Pipelines.MvcException
{
    public class GetExceptionSafeControllerRendering : GetControllerRenderer
    {
        protected override Renderer GetRenderer(Rendering rendering, GetRendererArgs args)
        {
            Tuple<string, string> controllerAndAction = GetControllerAndAction(rendering, args);

            //Return default controller renderer if errors module not enabled or rendering from core or a page layout
            if ((!Settings.IsEnabled ||
                rendering.RenderingType == "Layout" ||
                rendering.RenderingItem == null ||
                rendering.RenderingItem.Database == null ||
                rendering.RenderingItem.Database.Name == "core") ||
                controllerAndAction == null)
            {
                return base.GetRenderer(rendering, args);
            }
            
            //else return custom renderer
            return new Extensions.ExceptionSafeControllerRendering
            {
                ControllerName = controllerAndAction.Item1,
                ActionName = controllerAndAction.Item2
            };
        }                  
    }
}