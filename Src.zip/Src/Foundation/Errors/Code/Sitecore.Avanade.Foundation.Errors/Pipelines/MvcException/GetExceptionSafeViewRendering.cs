﻿using Sitecore.Mvc.Presentation;
using Sitecore.Mvc.Pipelines.Response.GetRenderer;
using Sitecore.Mvc.Extensions;

namespace Sitecore.Avanade.Foundation.Errors.Pipelines.MvcException
{
    public class GetExceptionSafeViewRendering : GetViewRenderer
    {
        protected override Renderer GetRenderer(Rendering rendering, GetRendererArgs args)
        {
            string viewPath = GetViewPath(rendering, args);
            
            //return default view renderer if errors module not enabled or rendering from core or a page layout
            if (!Settings.IsEnabled ||
                rendering.RenderingType == "Layout" ||
                rendering.RenderingItem == null ||
                rendering.RenderingItem.Database == null ||
                rendering.RenderingItem.Database.Name == "core" ||
                viewPath.IsWhiteSpaceOrNull())
            {
               return base.GetRenderer(rendering, args);                
            }           
            
            //else return custom renderer
            return new Extensions.ExceptionSafeViewRendering
            {
                ViewPath = viewPath,
                Rendering = rendering
            };
        }
    }
}