﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Errors
{
    public static class Settings
    {
        private static bool? _isEnabled;

        /// <summary>
        /// Is the MVC rendering error processing module enabled? 
        /// Turn off during development
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                _isEnabled = _isEnabled ?? Sitecore.Configuration.Settings.GetBoolSetting("AI.Foundation.Errors.Enabled", false);

                return _isEnabled.Value;

            }
        }
    }
}