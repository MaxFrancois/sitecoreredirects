﻿using System;   
using System.IO;
using Sitecore.Mvc.Presentation;
using Sitecore.Diagnostics;

using Sitecore.Mvc.Extensions;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Errors.Extensions
{
    internal class ExceptionSafeViewRendering : ViewRenderer
    {
        public override void Render(TextWriter writer)
        {
            try
            {
                //if rendering has been disabled, return empty rendering
                if (Errors.IsRenderingDisabled(Rendering))
                {
                    //do nothing
                }
                else
                {
                    base.Render(writer);
                }
            }
            catch (Exception ex)
            {
                Errors.HandleMVCException(ex, Rendering, writer);
            }
        }
    }
}
