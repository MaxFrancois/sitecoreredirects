﻿using System;
using System.IO;
using Sitecore.Mvc.Presentation;
using Sitecore.Diagnostics;

namespace Sitecore.Avanade.Foundation.Errors.Extensions
{
    internal class ExceptionSafeControllerRendering : ControllerRenderer
    {
        public override void Render(TextWriter writer)
        {
            Rendering rendering = RenderingContext.CurrentOrNull.Rendering;
            try
            {
                //if rendering has been disabled, return empty rendering
                if (Errors.IsRenderingDisabled(rendering))
                {
                    //do nothing
                }
                else
                {
                    base.Render(writer);
                }
            }
            catch (Exception ex)
            {
                Errors.HandleMVCException(ex, rendering, writer);
            }
        }
    }
}