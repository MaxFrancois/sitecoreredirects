﻿using System;
using System.IO;
using Sitecore.Mvc.Presentation;
using Sitecore.Diagnostics;
using Sitecore.Mvc.Extensions;
using Sitecore.Avanade.Foundation.Extensions;


namespace Sitecore.Avanade.Foundation.Errors
{
    public static class Errors
    {
        public static void HandleMVCException(Exception ex, Rendering rendering, TextWriter writer)
        {
            //if in experience editor or preview mode, display brief error on page 
            if (!Sitecore.Context.PageMode.IsNormal)
            {
                writer.Write("<div class='render-exception'>");
                writer.Write("Error in component: {0}. {1} Check log for details.",
                        rendering.RenderingItem.Name, ex.InnerException.Message);

                writer.Write("</div>");
            }
            //if in website mode (normal mode)
            else
            {
                //check if rendering is critical
                bool isEssentialComponent = rendering.RenderingField("EssentialComponent").IsChecked();

                //If component is not critical, log exception, do not render this component & display rest of page normally
                if (!isEssentialComponent)
                {
                    //log exception 
                    Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Error]: Error in component:  " + rendering.RenderingItem.Name + ". " + ex.InnerException, ex);                                     
                }
                //else if component critical - throw exception (redirect to error page)
                else
                {
                    throw ex;
                }
            }

        }

        /// <summary>
        /// Check if rendering has been disabled in presentation rendering parameters or on actual rendering
        /// </summary>
        /// <param name="rendering"></param>
        /// <returns></returns>
        public static bool IsRenderingDisabled(Rendering rendering)
        {
            return rendering != null && (rendering.Parameters["DisableRendering"].ToBool() ||
                rendering.RenderingField("DisableRendering").IsChecked());
        }
    }
}