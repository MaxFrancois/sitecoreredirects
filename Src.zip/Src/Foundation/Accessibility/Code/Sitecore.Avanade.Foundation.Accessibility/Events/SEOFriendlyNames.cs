﻿using System;
using Sitecore.Data.Items;
using Sitecore.Events;

namespace Sitecore.Avanade.Foundation.Accessibility.Events
{
    public class SeoFriendlyNames
    {
        /// <summary>
        /// Handles Item rename or add events to ensure item name is right or updated to the right format
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        protected void HandleItemRenameOrAdd(object sender, EventArgs args)
        {
            if (args == null) return;
            object[] parameters = Event.ExtractParameters(args);
            Item item = parameters[0] as Item;
            string previousItemName = parameters.Length > 1 ? parameters[1] as string : string.Empty;
            RenameItem(item, previousItemName);
        }

        /// <summary>
        /// Handles Item copy event and ensures item name is right or updated to the right format
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        protected void HandleItemCopy(object sender, EventArgs args)
        {
            if (args == null) return;
            object[] parameters = Event.ExtractParameters(args);
            if (parameters.Length > 1)
            {
                Item item = parameters[1] as Item;
                RenameItem(item, null);
            }
        }
        
        private static void RenameItem(Item item, string previousItemName)
        {
            if (item != null)
            {
                if (item.Database.Name != "master"
                    || !item.Paths.Path.StartsWith(Sitecore.Constants.ContentPath, StringComparison.OrdinalIgnoreCase))
                {
                    //Assuming that the content will be edited only in the master and website items will be under /sitecore/content/
                    return;
                }

                //Item name should be set to lower case and spaces replaced with hyphens to enable SEO friendly urls
                string correctItemName = item.Name.Replace(' ', '-').ToLowerInvariant();

                //Average word length for the English language, it makes 5.1 letters
                //The optimum sentence length for the English language is roughly between 15 and 25 words
                //Given we want short headline sentences for item names lets go max 10 words
                //Therefore 8 words * 5 char each = 40 character limit 
                //Basically we don't want item path length >256 char length item names so this is precautinary measure
                int maxItemLength = Sitecore.Configuration.Settings.GetIntSetting("AI.Foundation.Accessibility.SEO.FriendlyNames.Length", 40);

                if (correctItemName.Length > maxItemLength)
                {
                    //item name is too long
                    string shortenedName = correctItemName;
                    while (shortenedName.Contains("-") && (shortenedName.LastIndexOf('-') > maxItemLength || shortenedName.Length > maxItemLength))
                    {
                        //shorten by removing last word
                        int lengthRemovingLastWord = shortenedName.LastIndexOf('-');
                        shortenedName = shortenedName.Substring(0, lengthRemovingLastWord);
                    }

                    if (shortenedName.Length > maxItemLength)
                    {
                        //could not shorten without breaking words
                        shortenedName = correctItemName.Substring(0, maxItemLength);
                    }

                    correctItemName = shortenedName.Trim('-');
                }

                bool isItemNameRight = string.Compare(item.Name, correctItemName, StringComparison.Ordinal) == 0;
                if (isItemNameRight && (string.IsNullOrEmpty(previousItemName) || string.Compare(item.Appearance.DisplayName, previousItemName, StringComparison.Ordinal) == 0))
                {
                    //Please note since this EventHandler is called on item rename or add, there will be scenarios 
                    //when this event will trigger itself due to a item name being corrected below. 
                    //In those cases check if the  item name is already in the right format and 
                    //if display name was same as previous item name then no updates required
                    return;
                }

                item.Editing.BeginEdit();
                try
                {
                    //We want to keep the display name same as what the user intended but correct the item name to reflect the right format
                    item.Appearance.DisplayName = item.Name;
                    if (!isItemNameRight)
                        item.Name = correctItemName;
                }
                finally
                {
                    item.Editing.EndEdit();
                }
            }
        }
    }
}