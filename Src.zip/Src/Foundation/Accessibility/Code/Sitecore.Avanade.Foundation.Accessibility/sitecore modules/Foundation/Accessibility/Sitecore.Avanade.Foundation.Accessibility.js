﻿define(["sitecore", "/-/speak/v1/ExperienceEditor/ExperienceEditor.js"], function (Sitecore, ExperienceEditor) {
    Sitecore.Commands.AIFoundationAccessibility =
    {
        canExecute: function (context) {
            return true;
        },
        execute: function (context) {
            var dataSCID = context.button.viewModel.$el[0].getAttribute('data-sc-id');

            if (dataSCID.indexOf('_-') > 0) {
                dataSCID = dataSCID.substring(0, dataSCID.indexOf('_-'));
            }
            context.currentContext.argument = dataSCID;

            if (context.currentContext.argument != '') {
                ExperienceEditor.PipelinesUtil.generateRequestProcessor("ExperienceEditor.HiddenFields.GetDialogUrl", function (response) {
                    var dialogUrl = response.responseValue.value;
                    var dialogFeatures = "header: " + context.button.viewModel.$el[0].title + "; dialogHeight: 250px;dialogWidth: 520px; edge:raised; center:yes; help:no; resizable:yes; status:no; scroll:no";
                    ExperienceEditor.Dialogs.showModalDialog(dialogUrl, '', dialogFeatures, null);
                }).execute(context);
            }

        }
    };
});