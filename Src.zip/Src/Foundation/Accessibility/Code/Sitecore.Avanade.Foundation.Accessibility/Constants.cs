﻿namespace Sitecore.Avanade.Foundation.Accessibility
{
    public static class Constants
    {
        public static class DeviceExtensions
        {
            /// <summary>
            /// The private constant for the device extension
            /// </summary>
            public const string DeviceExtensionContext = "DeviceExtensionContext";

            public const string DeviceExtensionContextAvailable = "DeviceExtensionAvailable";

            public const string DeviceExtensionFoundationTemplateId = "{A87A00B1-E6DB-45AB-8B54-636FEC3B5523}";
        }

        public static class Templates
        {
            public static class TemplateField
            {
                public static class Fields
                {
                    public const string HiddenDialogTag = "HiddenDialogTag";
                }
            }
        }
    }
}