﻿using System;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.HttpRequest;

namespace Sitecore.Avanade.Foundation.Accessibility.Pipelines.HttpRequest
{
    /// <summary>
    /// End Device Extension Processor to format the output content type
    /// </summary>
    public class EndDeviceExtensionProcessor : HttpRequestProcessor
    {
        #region Process
        /// <summary>
        /// Processes the specified args.
        /// </summary>
        /// <param name="args">The args.</param>
        public override void Process(HttpRequestArgs args)
        {
            // make sure we have our arguments before we have any issues
            Assert.ArgumentNotNull(args, "args");

            // stop execution as quickly as possible
            if (args.Context.Items[Constants.DeviceExtensions.DeviceExtensionContext] == null)
            {
                // error so just stop
                return;
            }

            // get the data out
            Tuple<string, string, string, Sitecore.Data.Items.DeviceItem> matchedDevice = args.Context.Items[Constants.DeviceExtensions.DeviceExtensionContext] as Tuple<string, string, string, Sitecore.Data.Items.DeviceItem>;

            // does the system match
            if (matchedDevice != null)
            {
                // set the data
                args.Context.Response.ContentType = matchedDevice.Item2;
                args.Context.Response.ContentEncoding = DetermineEncoding(matchedDevice.Item3);
            }
            else
            {
                // default
                args.Context.Response.ContentType = "text/html";
                args.Context.Response.ContentEncoding = System.Text.Encoding.UTF8;

                // is debug logs enabled
                if (Diagnostics.Log.IsDebugEnabled)
                {
                    // log
                    Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Accessibility]: Device Extension  : Content Type|Encoding not correctly matched");
                }
            }
        }
        #endregion

        #region DetermineEncoding
        /// <summary>
        /// Return Encoding enumeration based on given string argument
        /// </summary>
        /// <param name="encoding">encoding in string format</param>
        /// <returns>Return encoding enumerable (Default value is UTF-8)</returns>
        private System.Text.Encoding DetermineEncoding(string input)
        {
            try
            {
                var encoding = (System.Text.Encoding)Enum.Parse(typeof(System.Text.Encoding), input, true);
                return encoding;
            }
            catch (Exception)
            {
                return System.Text.Encoding.UTF8; // return UTF-8 encoding if input is not specified or in the wrong format.
            }
        }
        #endregion
    }
}
