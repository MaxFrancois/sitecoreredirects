﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.HttpRequest;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Accessibility.Pipelines.HttpRequest
{
    /// <summary>
    /// Device Extension Processor
    /// </summary>
    public class DeviceExtensionProcessor : HttpRequestProcessor
    {
        #region Private Variables
        /// <summary>
        /// The executed URLS
        /// </summary>
        private System.Collections.Concurrent.ConcurrentDictionary<string, bool> ProcessedURL { get; } = new System.Collections.Concurrent.ConcurrentDictionary<string, bool>();

        private static string _mediaLinkPrefix = string.Format("/{0}", Sitecore.Configuration.Settings.Media.MediaLinkPrefix);
        #endregion

        #region GetDeviceMappings
        /// <summary>
        /// Get the list of devices mappings with its extension and mime type.
        /// </summary>
        /// <returns>list of devices in tuple structure.
        /// Where : first element contains the extension value
        ///         second element contains mime type 
        ///         third element contains specifed encodng type
        ///         fourth element contains specifed device item object
        /// </returns>
        private List<Tuple<string, string, string, DeviceItem>> GetDeviceMappings()
        {
            // get the cached data
            List<Tuple<string, string, string, DeviceItem>> deviceMappings = Cache.Cache.Get<List<Tuple<string, string, string, DeviceItem>>>(Constants.DeviceExtensions.DeviceExtensionContext, () =>
            {
                var deviceMappingList = new List<Tuple<string, string, string, DeviceItem>>();

                // get the device extension item
                Item deviceExtensionItem = Sitecore.Avanade.Foundation.Bedrock.Helpers.FindFoundationItem(Constants.DeviceExtensions.DeviceExtensionFoundationTemplateId);

                // do we have data
                if (deviceExtensionItem != null && deviceExtensionItem.HasChildren)
                {
                    deviceExtensionItem.Children.ForEach(x =>
                    {
                        // get out the data
                        string extensionItemValue = x.Fields["Extension"]?.Value.ToLower();
                        string mimeTypeValue = x.Fields["Mime Type"]?.Value.ToLower();
                        string encodingItemValue = x.Fields["Encoding"]?.Value.ToLower();
                        DeviceItem device = x.Fields["Device"]?.TargetItem(true);

                        // we need the extension for this to work
                        if (!extensionItemValue.IsNullOrEmpty())
                        {
                            // add the data to the collection
                            deviceMappingList.Add(new Tuple<string, string, string, DeviceItem>(extensionItemValue,
                                                                                             mimeTypeValue,
                                                                                             encodingItemValue, device));
                        }
                    });
                }

                return deviceMappingList;
            });
            
            // return the data
            return deviceMappings;
        }
        #endregion

        #region Process
        /// <summary>
        /// Processes the specified args.
        /// </summary>
        /// <param name="args">The args.</param>
        public override void Process(HttpRequestArgs args)
        {
            // stop execution as quickly as possible
            if (Sitecore.Configuration.State.Previewing
                || Sitecore.Configuration.State.WebEditing
                || Sitecore.Configuration.State.DebugMode
                || args == null
                || args.Aborted
                || Sitecore.Context.Site == null
                || Sitecore.Context.Database == null
                || Sitecore.Context.Device == null
                || args.LocalPath.IsNullOrEmpty()
                || args.LocalPath.Equals(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.KeepAlive, StringComparison.OrdinalIgnoreCase)
                || args.LocalPath.StartsWith(Sitecore.Avanade.Foundation.Extensions.Constants.SitecoreConstants.VisitorIdentification)
                || args.Context == null
                || args.Context.Request == null
                || args.Context.Request.Path.IsNullOrEmpty()
                || args.Context.Request.Path.StartsWith(Sitecore.Constants.SitecorePath)
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.TempFolderPath)
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.DataFolder)
                || args.Context.Request.Path.StartsWith(Sitecore.Configuration.Settings.MediaFolder)
                || args.LocalPath.StartsWith(_mediaLinkPrefix, StringComparison.OrdinalIgnoreCase)
                || Sitecore.Configuration.Factory.GetCustomHandlers().Exists(e => args.Context.Request.Path.StartsWith(string.Format("/{0}", e.Trigger), StringComparison.OrdinalIgnoreCase))
                || System.Web.Hosting.HostingEnvironment.VirtualPathProvider.FileExists(args.Url.FilePath)
                )
            {
                // error so just stop
                return;
            }

            #region CheckDeviceAndArgument
            List<Tuple<string, string, string, DeviceItem>> deviceMappings = GetDeviceMappings();

            // make sure we have data
            if (deviceMappings != null && deviceMappings.Count > 0)
            {
                #region Clear Instance
                // do we have our cached instance
                bool? isAbortCached = Cache.Cache.Has(Constants.DeviceExtensions.DeviceExtensionContextAvailable, siteName: "Global", databaseName: "DB");

                // do we??
                if (isAbortCached == null || !isAbortCached.Value)
                {
                    // we need to clear the instance
                    ProcessedURL.Clear();

                    if (Log.IsDebugEnabled)
                    {
                        Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Accessiblity]: DeviceExtension: Local Cache Cleared", typeof(DeviceExtensionProcessor));
                    }

                    // set the data so it's always valid
                    Cache.Cache.Add(Constants.DeviceExtensions.DeviceExtensionContextAvailable, true, System.DateTime.Now.AddMinutes(30), siteName: "Global", databaseName: "DB");
                }
                #endregion

                // get the unique cache key
                string urlCacheKey = args.Context.Request.Url.AbsolutePath;
                bool executeDeviceCheck = true;

                // has this already been executed
                if (ProcessedURL != null
                    && !ProcessedURL.IsEmpty
                    && ProcessedURL.ContainsKey(urlCacheKey))
                {
                    // gets out the key         `
                    ProcessedURL.TryGetValue(urlCacheKey, out executeDeviceCheck);
                }

                // do we need to process
                if (executeDeviceCheck)
                {
                    // get out the extension
                    string extension = Path.GetExtension(args.Context.Request.FilePath);

                    if (!string.IsNullOrEmpty(extension))
                    {
                        #region Get Device
                        if (extension[0] == '.')
                        {
                            extension = extension.Substring(1);
                        }

                        // reset to lower
                        extension = extension.ToLower();

                        // do we have a match
                        if (deviceMappings.Exists(x => x.Item1.Equals(extension)))
                        {
                            // get the device item
                            Tuple<string, string, string, DeviceItem> matchedDevice =
                                deviceMappings.FirstOrDefault(x => x.Item1.Equals(extension));

                            // get the match
                            if (matchedDevice != null)
                            {
                                // get out the item
                                DeviceItem matchedDeviceItem = matchedDevice.Item4;

                                // make sure to check the extension
                                if (matchedDeviceItem != null)
                                {
                                    Sitecore.Context.Device = matchedDeviceItem;
                                    args.Context.Items.Add(Constants.DeviceExtensions.DeviceExtensionContext, matchedDevice);

                                    // set to execute
                                    executeDeviceCheck = true;

                                    // can we log
                                    if (Diagnostics.Log.IsDebugEnabled)
                                    {
                                        // setup trace
                                        Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Accessibility]: Device Extension: Device set to '" + Sitecore.Context.Device.Name + "'.");
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    // do we want to enable
                    if (!args.Context.Items.Contains(Constants.DeviceExtensions.DeviceExtensionContext))
                    {
                        executeDeviceCheck = false;
                    }

                    // add the url so we don't have to process again
                    if (ProcessedURL != null
                        && !ProcessedURL.ContainsKey(urlCacheKey))
                    {
                        ProcessedURL.TryAdd(urlCacheKey, executeDeviceCheck);
                    }
                }
            }
            else
            {
                // is debug logs enabled
                if (Diagnostics.Log.IsDebugEnabled)
                {
                    // log
                    Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Accessibility]: AI Device Extension: No Device Extensions found, using default extension");
                }
            }
            #endregion
        }
        #endregion
    }
}