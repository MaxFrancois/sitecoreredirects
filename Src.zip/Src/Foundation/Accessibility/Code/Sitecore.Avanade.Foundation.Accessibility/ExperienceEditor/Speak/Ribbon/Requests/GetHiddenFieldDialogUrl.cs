﻿using System.Collections.Generic;
using Sitecore.Data;
using Sitecore.ExperienceEditor.Speak.Server.Contexts;
using Sitecore.ExperienceEditor.Speak.Server.Requests;
using Sitecore.ExperienceEditor.Speak.Server.Responses;
using Sitecore.Shell.Applications.ContentEditor;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Accessibility.ExperienceEditor.Speak.Ribbon.Requests
{
    /// <summary>
    /// Get Meta data dialog
    /// </summary>
    public class GetHiddenFieldDialogUrl : PipelineProcessorRequest<ItemContext>
    {
        #region GenerateUrl
        /// <summary>
        /// Generate the URL
        /// </summary>
        /// <returns></returns>
        public string GenerateUrl()
        {
            // get the field tag data
            string fieldHiddenDialogTag = RequestContext.Argument;

            // make sure we have data to check
            if (!fieldHiddenDialogTag.IsNullOrEmpty())
            {
                List<FieldDescriptor> fieldList = null;

                // cycle over the fields
                RequestContext.Item.Template.Fields.ForEach(x =>
                {
                    // only cycle if non standard field
                    if (!x.IsStandardTemplateField())
                    {
                        // if this throws and error it is a big problem
                        string fieldValue = x.InnerItem.Fields[Constants.Templates.TemplateField.Fields.HiddenDialogTag].ValueSafe();
                        
                        // make sure we have data and that it matches
                        if (!fieldValue.IsNullOrEmpty()
                            && fieldValue.Contains(fieldHiddenDialogTag, System.StringComparison.OrdinalIgnoreCase))
                        {
                            // create the collection if not already done
                            if (fieldList == null)
                            {
                                fieldList = new List<FieldDescriptor>();
                            }
                            // add our list
                            fieldList.Add(new FieldDescriptor(RequestContext.Item, x.Name));
                        }
                    }
                });

                // get the field list
                if (fieldList != null && fieldList.Count > 0)
                {
                    // create a field editor
                    var fieldeditorOption = new FieldEditorOptions(fieldList);

                    // save the item when the OK button is pressed
                    fieldeditorOption.SaveItem = true;

                    // setup the return URI
                    return fieldeditorOption.ToUrlString().ToString();
                }
            }

            return string.Empty;
        }
        #endregion


        #region ProcessRequest
        /// <summary>
        /// The ProcessRequest that is called by Sitecore
        /// </summary>
        /// <returns></returns>
        public override PipelineProcessorResponseValue ProcessRequest()
        {
            // initialise the pipeline processor response required
            return new PipelineProcessorResponseValue
            {
                Value = GenerateUrl(),
            };
        }
        #endregion
    }
}