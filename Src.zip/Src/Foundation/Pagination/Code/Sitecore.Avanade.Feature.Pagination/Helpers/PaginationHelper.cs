﻿using Sitecore.Avanade.Foundation.Pagination.Models;
using System;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.Pagination.Helpers
{
    public static class PaginationHelper
    {
        public static int CalculateTotalPageCount(int totalRecordCount, int pageSize)
        {
            double dblPageCount = (double)totalRecordCount / pageSize;
            int totalPageCount = (int)Math.Ceiling(dblPageCount);

            return totalPageCount;
        }

        public static IEnumerable<PagingLink> GeneratePagingLinks(int pageNumber, int totalPageCount, int maxPageCount)
        {
            int startPageNumber;
            int endPageNumber;
            CalculatePageNumberRange(pageNumber, totalPageCount, maxPageCount, out startPageNumber, out endPageNumber);

            PagingLink pagingLink = null;
            for (int i = startPageNumber; i <= endPageNumber; i++)
            {
                pagingLink = new PagingLink();
                pagingLink.PageNumber = i;
                pagingLink.IsSelected = (pagingLink.PageNumber == pageNumber);

                yield return pagingLink;
            }
        }

        /// <summary>
        /// Calculates the start page number and end page number for the pager.
        /// The total number of paging links will always be equal to or less than maxPageCount
        /// </summary>
        /// <param name="pageNumber"></param>
        /// <param name="totalPageCount"></param>
        /// <param name="maxPageCount"></param>
        /// <param name="startPageNumber"></param>
        /// <param name="endPageNumber"></param>
        private static void CalculatePageNumberRange(int pageNumber, int totalPageCount, int maxPageCount, out int startPageNumber, out int endPageNumber)
        {
            if (pageNumber > (totalPageCount - maxPageCount))
            {
                startPageNumber = (pageNumber - (maxPageCount + (pageNumber - totalPageCount))) + 1;
                if (startPageNumber == pageNumber)
                    startPageNumber = (int)(Math.Floor((double)(pageNumber / maxPageCount)) * maxPageCount);
            }
            else
                startPageNumber = (int)(Math.Floor((double)(pageNumber / maxPageCount)) * maxPageCount);

            if (startPageNumber <= 0)
                startPageNumber = 1;

            endPageNumber = (startPageNumber + maxPageCount) - 1;
            if (endPageNumber < totalPageCount &&
                endPageNumber == pageNumber)
            {
                startPageNumber = endPageNumber;
                endPageNumber = (startPageNumber + maxPageCount) - 1;
            }
            else if (totalPageCount < endPageNumber)
                endPageNumber = totalPageCount;

        }
    }
}