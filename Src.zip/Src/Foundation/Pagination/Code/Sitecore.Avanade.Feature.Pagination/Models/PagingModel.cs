﻿using Sitecore.Avanade.Foundation.Pagination.Helpers;
using System.Collections.Generic;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Pagination.Models
{
    public class PagingModel
    {
        #region Fields

        private List<PagingLink> _pagingLinks = null;

        #endregion

        #region Constructor

        public PagingModel(int currentPageNumber, int totalResultCount)
        {
            CurrentPageNumber = currentPageNumber;
            TotalResultCount = totalResultCount;
        }

        public PagingModel(int currentPageNumber, int totalResultCount, int pageSize)
            : this(currentPageNumber, totalResultCount)
        {
            PageSize = pageSize;
        }

        public PagingModel(int currentPageNumber, int totalResultCount, int pageSize, int maxPageCount)
            : this(currentPageNumber, totalResultCount)
        {
            PageSize = pageSize;
            MaxPageCount = maxPageCount;
        }

        public PagingModel(string previousLinkTitle, string nextLinkTitle, int currentPageNumber, int totalResultCount, int pageSize, int maxPageCount)
            : this(currentPageNumber, totalResultCount, pageSize, maxPageCount)
        {
            PreviousLinkTitle = previousLinkTitle;
            NextLinkTitle = nextLinkTitle;
        }

        #endregion

        #region Properties

        public List<PagingLink> PagingLinks
        {
            get
            {
                if (_pagingLinks == null)
                {
                    int pageCount = PaginationHelper.CalculateTotalPageCount(TotalResultCount, PageSize);
                    _pagingLinks = PaginationHelper.GeneratePagingLinks(CurrentPageNumber, pageCount, MaxPageCount).ToList();
                }
                return _pagingLinks;
            }
        }

        public int MaxPageCount { get; internal set; } = 5;

        public int PageSize { get; internal set; } = 5;

        public int CurrentPageNumber { get; internal set; }

        public int TotalResultCount { get; internal set; }

        public bool IsPreviousEnabled
        {
            get
            {
                return CurrentPageNumber > 1;
            }
        }

        public bool IsNextEnabled
        {
            get
            {
                if (PagingLinks == null || PagingLinks.Count == 0)
                    return false;

                PagingLink pagingLink = PagingLinks.Last();
                return pagingLink.PageNumber > CurrentPageNumber;
            }
        }

        public bool IsPagingRequired
        {
            get
            {
                return PagingLinks.Any();
            }
        }

        public string PreviousLinkTitle { get; internal set; } = "Previous";

        public string NextLinkTitle { get; internal set; } = "Next";

        #endregion
    }
}