﻿namespace Sitecore.Avanade.Foundation.Pagination.Models
{
    public class PagingLink
    {
        public int PageNumber { get; set; }
        public bool IsSelected { get; set; }
    }
}