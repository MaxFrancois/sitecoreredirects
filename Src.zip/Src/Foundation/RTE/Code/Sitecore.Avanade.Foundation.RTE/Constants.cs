﻿namespace Sitecore.Avanade.Foundation.RTE
{
    public static class Constants
    {
        public static class StyleSheet
        {
            public static class Template
            {
                public const string ID = "{DC2B86E1-CA2D-4038-B8D9-0176DD70C8A9}";
            }
        }

        public static class RichText
        {
            public static class Template
            {
                public const string Id = "{D18504D3-A64A-458A-A4DF-38DBCBBCCE14}";
            }
        }
    }
}