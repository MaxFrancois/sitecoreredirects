﻿using Sitecore.Data.Items;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Web;
using Sitecore.Avanade.Foundation.Site.Extensions;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.RTE.Helpers
{
    /// <summary>
    /// Rich Text Editor extensions
    /// </summary>
    internal static class RichTextEditorHelper
    {
        #region GetRichTextItem
        /// <summary>
        /// Get the Rich Text Setting Item, if the setting has been disabled it will return null
        /// </summary>
        /// <returns>Get the Rich Text item</returns>
        internal static Item GetRichTextItem()
        {
            // set the item
            Item richTextSetting = null;

            // get the id out of the query supplied
            string id = WebUtil.GetQueryString("id");

            if (!id.IsNullOrEmpty())
            {
                // get the current item
                var itm = Sitecore.Context.ContentDatabase.GetItem(id);

                // ensure we have the data required
                if (itm != null)
                {
                    // process
                    richTextSetting = Sitecore.Avanade.Foundation.Site.Helpers.Bedrock.FindFoundationItem(itm, Constants.RichText.Template.Id);

                    // not enabled
                    if (richTextSetting != null
                        && !richTextSetting.Fields["Enabled"].IsChecked())
                    {
                        // lets check the foundation


                        richTextSetting = null;
                    }
                }
            }

            return richTextSetting;
        }
        #endregion

        #region GetSiteRichTextSetting
        /// <summary>
        /// Returns the rich text editor profile allowing it to be overridden by site settings
        /// </summary>
        /// <param name="profile"></param>
        /// <returns>Returns the Rich Text setting</returns>
        internal static Item GetSiteRichTextSetting(Item profile)
        {
            var returnData = profile;

            // get the rich text setting
            var richTextSetting = GetRichTextItem();

            // do we have data
            if (richTextSetting != null)
            {
                // get the rich text field
                string overriddenRichText = richTextSetting.Fields["DefaultRichText"].ValueSafe();

                // do we have anything, and is it the supplied profile
                if (!overriddenRichText.IsNullOrEmpty()
                    && !profile.ID.EqualsTo(overriddenRichText))
                {
                    // override the data
                    returnData = Configuration.Factory.GetDatabase(Sitecore.Constants.CoreDatabaseName).GetItem(overriddenRichText);
                }
            }

            return returnData;
        }
        #endregion

        #region GetStyleSheets
        /// <summary>
        /// Gets the listing of stylesheets
        /// </summary>
        /// <returns></returns>
        internal static List<string> GetStyleSheets()
        {
            // setup default
            var listing = new List<string>();

            // get the rich text item
            var richTextSetting = Helpers.RichTextEditorHelper.GetRichTextItem();

            // have we got the setting
            if (richTextSetting != null
                && richTextSetting.Fields["OverrideStyleSheet"].IsChecked()
                && richTextSetting.HasChildren)
            {
                // get t he stylesheet container
                var styleSheetContainerItem = richTextSetting.Axes.SelectSingleItem("./stylesheets");

                // we something below our container right
                if (styleSheetContainerItem != null && styleSheetContainerItem.HasChildren)
                {
                    // get the stylesheet item
                    var styleSheet = styleSheetContainerItem.Axes.SelectSingleDomainItem(true);

                    // make sure we have data and children to process
                    if (styleSheet != null && styleSheet.HasChildren)
                    {
                        // select all the items
                        var styleSheetAssets = styleSheet.Axes.SelectItems($"./*[@@templateid='{Constants.StyleSheet.Template.ID}']");

                        // make sure we have the setting required
                        if (styleSheetAssets != null && styleSheetAssets.Length > 0)
                        {
                            // cycle over the stylesheets
                            styleSheetAssets.ForEach(x =>
                            {
                                // have we uploaded the file into Sitecore
                                if (x.Fields["SitecoreFile"].IsChecked())
                                {
                                    // make sure the file has data
                                    if (x.Fields["File"].HasValue)
                                    {
                                        listing.Add(x.Fields["File"].ConvertToFileField().GetValidURL());
                                    }
                                }
                                else
                                {
                                    // have we got data
                                    if (x.Fields["RelativeFilePath"].HasValue)
                                    {
                                        listing.Add(x.Fields["RelativeFilePath"].ValueSafe());
                                    }
                                }
                            });
                        }
                    }
                }
            }

            return listing;
        }
        #endregion
    }
}