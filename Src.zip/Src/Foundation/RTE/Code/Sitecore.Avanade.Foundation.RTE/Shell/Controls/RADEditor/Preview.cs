﻿using System;

namespace Sitecore.Avanade.Foundation.RTE.Shell.Controls.RADEditor
{
    /// <summary>
    /// Override the Sitecore preview to use our site specific stylesheets only if this is enabled
    /// </summary>
    public class Preview : Sitecore.Shell.Controls.RADEditor.Preview
    {
        #region Override the OnLoad
        protected override void OnLoad(EventArgs e)
        {
            // load the base first we want it to setup everything then we fix the stylesheets
            base.OnLoad(e);
            
            // get the listing of stylesheets
            var styleSheets = Helpers.RichTextEditorHelper.GetStyleSheets();

            // if any style sheets clear
            if (styleSheets != null && styleSheets.Count > 0)
            {
                // we have stylesheets remove the default
                this.Stylesheets.Controls.Clear();

                // cycle over the style sheets
                styleSheets.ForEach(x =>
                {
                    // add the style sheets
                    this.Stylesheets.Controls.Add(new System.Web.UI.LiteralControl($"<link href=\"{x}\" rel=\"stylesheet\" type=\"text/css\" />"));
                });
            }
        }
        #endregion
    }
}