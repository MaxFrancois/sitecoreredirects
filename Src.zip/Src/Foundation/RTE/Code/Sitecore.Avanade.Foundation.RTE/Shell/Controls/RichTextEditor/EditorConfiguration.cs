﻿using Sitecore.Data.Items;

namespace Sitecore.Avanade.Foundation.RTE.Shell.Controls.RichTextEditor
{
    /// <summary>
    /// Override the default behaviour allowing for selection of default editor and stylesheets from a site
    /// </summary>
    public class EditorConfiguration : Sitecore.Shell.Controls.RichTextEditor.EditorConfiguration
    {
        #region Constructor
        /// <summary>
        /// Override the default site that has been set if required
        /// </summary>
        /// <param name="profile"></param>
        public EditorConfiguration(Item profile) : base(Helpers.RichTextEditorHelper.GetSiteRichTextSetting(profile))
        {
        }
        #endregion

        #region SetupStylesheets
        /// <summary>
        /// Override the styles sheets for the site if present
        /// </summary>
        protected override void SetupStylesheets()
        {
            // we want to add the base always
            base.SetupStylesheets();

            // get the listing of stylesheets
            var styleSheets = Helpers.RichTextEditorHelper.GetStyleSheets();

            // if any style sheets clear
            if (styleSheets != null && styleSheets.Count > 0)
            {
                // we have stylesheets remove the default
                this.Editor.CssFiles.Clear();

                // cycle over the style sheets
                styleSheets.ForEach(x =>
                {
                    // add the style sheets
                    this.Editor.CssFiles.Add(x);
                });
            }
        }
        #endregion

        
    }
}