﻿using Sitecore.Mvc.Controllers;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.ContentListing
{
    public class ContentListingController : SitecoreController
    {
        public ActionResult BasicListing()
        {
            return PartialView("~/Views/ContentListing/BasicListing.cshtml");
        }       

    }
}