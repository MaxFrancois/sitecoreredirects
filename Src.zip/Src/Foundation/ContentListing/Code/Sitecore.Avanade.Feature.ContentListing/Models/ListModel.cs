﻿using Sitecore.Avanade.Foundation.Pagination.Models;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Data.Items;
using System.Collections.Generic;

namespace Sitecore.Avanade.Foundation.ContentListing.Models
{
    public class ListModel
    {
        public ListModel(string listTitle,
                         Item item,
                         int itemsPerPage,
                         IDictionary<string, IList<Item>> listDictionary,
                         int page,
                         int resultCount)
        {
            ListTitle = listTitle;
            ListingPageItem = item;
            ListDictionary = listDictionary;

            //Listing Page settings controlled in CMS
            var isDisabled = ListingPageItem.Fields["DisablePaging"].As<bool>(false); //Is pagingation disabled for this listing page
            var linksPerPage = ListingPageItem.Fields["MaxPageLinksPerPage"].As<int>(5); //Links to show in pagination navigation per page
            var nextLinkTitle = ListingPageItem.Fields["NextText"].As<string>("Next"); //The next link text to display. Defaults to 'Next'
            var prevLinkTitle = ListingPageItem.Fields["PreviousText"].As<string>("Previous"); //The previous link text to display. Defaults to 'Previous'

            Pagination = isDisabled ? null : new PagingModel(prevLinkTitle, nextLinkTitle, page, resultCount, itemsPerPage, linksPerPage);
        }

        // Context Items
        public string ListTitle { get; set; }
        public Item ListingPageItem { get; set; }

        // Navigation Items
        public IDictionary<string, IList<Item>> ListDictionary { get; set; }
        public PagingModel Pagination { get; set; }
    }
}