﻿using System.Linq;
using Sitecore.Data.Items;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Bedrock
{
    public static class Helpers
    {
        #region FoundationSettingItem
        /// <summary>
        /// The Foundation Setting Item
        /// </summary>
        /// <returns></returns>
        public static Item FoundationSettingItem(Item itm = null, Data.Database db = null)
        {
            if (Settings.FoundationSettingsPath.IsNullOrEmpty()
                || (Sitecore.Context.Database == null && db == null))
            {
                return null;
            }

            // get the data out
            return Cache.Cache.Get<Item>(Constants.Caches.FoundationSettingItem, () =>
            {
                // get the db out
                var dbCheck = db ?? (itm == null ? Sitecore.Context.Database : itm.Database);

                // get the settings item
                return dbCheck.GetItem(Sitecore.Avanade.Foundation.Bedrock.Settings.FoundationSettingsPath); 
            });
            
        }
        #endregion

        #region FindFoundationItem
        /// <summary>
        /// Find the Foundation item based on it's base tmeplate
        /// </summary>
        /// <param name="baseTemplateId"></param>
        /// <returns></returns>
        public static Item FindFoundationItem(string baseTemplateId)
        {
            if (string.IsNullOrEmpty(baseTemplateId))
            {
                return null;
            }

            // has this been fetched already
            return Cache.Cache.Get<Item>($"{Constants.Caches.FoundationSettingItem}-{baseTemplateId}", () =>
            {
                var foundation = FoundationSettingItem();

                // make sure we have data
                if (foundation != null
                    && foundation.HasChildren)
                {
                    // get the global settings item
                    return foundation.Children.FirstOrDefault(x => x.HasBaseTemplate(baseTemplateId));
                }

                return null;
            });
        }
        #endregion 

        #region FeatureSettingItem
        /// <summary>
        /// The Feature Setting Item
        /// </summary>
        /// <returns></returns>
        public static Item FeatureSettingItem()
        {
            if (string.IsNullOrEmpty(Settings.FeatureSettingsPath))
            {
                return null;
            }

            return Cache.Cache.Get<Item>(Constants.Caches.FeatureSettingItem, () =>
            {
                return Sitecore.Context.Database.GetItem(Sitecore.Avanade.Foundation.Bedrock.Settings.FeatureSettingsPath);
            });
        }
        #endregion

        #region FindFeatureItem
        /// <summary>
        /// Find the Feature item based on it's base tmeplate
        /// </summary>
        /// <param name="baseTemplateId"></param>
        /// <returns></returns>
        public static Item FindFeatureItem(string baseTemplateId)
        {
            if (string.IsNullOrEmpty(baseTemplateId))
            {
                return null;
            }
            
            // has this been fetched already
            return Cache.Cache.Get<Item>($"{Constants.Caches.FeatureSettingItem}-{baseTemplateId}", ()=>
            {
                var feature = FeatureSettingItem();

                // make sure we have data
                if (feature != null
                    && feature.HasChildren)
                {
                    // get the global settings item
                    return feature.Children.FirstOrDefault(x => x.HasBaseTemplate(baseTemplateId));
                }

                return null;
            });
        }
        #endregion 
    }
}