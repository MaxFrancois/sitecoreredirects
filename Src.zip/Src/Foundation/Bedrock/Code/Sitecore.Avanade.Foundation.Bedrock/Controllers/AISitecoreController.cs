﻿using System;
using System.Web;
using System.Web.Mvc;
using Sitecore.Avanade.Foundation.Extensions;

namespace Sitecore.Avanade.Foundation.Bedrock.Controllers
{
    /// <summary>
    /// Override the Sitecore base controller
    /// </summary>
    public class AISitecoreController: Sitecore.Mvc.Controllers.SitecoreController
    {
        /// <summary>
        /// override the index to run basic code on every request
        /// </summary>
        /// <returns></returns>
        public override ActionResult Index()
        {
            // make sure the request has not been disabled
            if (!Disabled())
            {
                // make sure the header is set to secure
                if (Request.IsSecureConnection)
                {
                    Response.AddHeader("Strict-Transport-Security", "max-age=300");
                }

                // for some reason Sitecore does not map this back correctly
                if (Sitecore.Context.User.IsLoggedInPublic())
                {
                    // we cycle over the profile custom data and set into profile data for the request
                    Sitecore.Context.User.Profile.GetCustomPropertyNames().ForEach(x =>
                    {
                        Sitecore.Context.User.Profile[x] = Sitecore.Context.User.Profile.GetCustomProperty(x);
                    });

                    // make sure we do n ot cache anything while we are logged in
                    Response.Cache.SetCacheability(HttpCacheability.NoCache);           //Cache-Control :   no-cache, Pragma : no-cache
                    Response.Cache.SetExpires(DateTime.Now.AddDays(-1));                //Expires :         date time
                    Response.Cache.SetNoStore();                                        //Cache-Control :   no-store
                    Response.Cache.SetProxyMaxAge(new TimeSpan(0, 0, 0));               //Cache-Control:    s-maxage=0
                    Response.Cache.SetValidUntilExpires(false);
                    Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);    //Cache-Control:    must-revalidate

                    // if the user is logged in we need to make sure it is secure
                    if (!Request.IsLocal)
                    {
                        string path = "https://" + Request.Url.Host + Request.Url.PathAndQuery;
                        Response.Status = "301 Moved Permanently";
                        Response.AddHeader("Location", path);
                    }
                }

                #region Debug URI Request
                #if DEBUG
                // log the request only when it is in debug mode
                if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                {
                    Sitecore.Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}Requested URI '{HttpContext.Request.RawUrl}'");
                }
                #endif
                #endregion
            }
            
            // call the base to ensure everything runs as expected
            return base.Index();
        }
    }
}