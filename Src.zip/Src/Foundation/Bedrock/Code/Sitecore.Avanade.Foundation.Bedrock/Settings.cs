﻿using System;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Bedrock
{
    public static class Settings
    {
        #region Private Variable

        private static string _foundationSettingsPath;

        private static string _featureSettingsPath;
        #endregion

        #region Public Properties
        
        public static string FoundationSettingsPath
        {
            get
            {
                if (string.IsNullOrEmpty(_foundationSettingsPath))
                {
                    _foundationSettingsPath = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Bedrock.Settings.Foundation", "/sitecore/system/settings/foundation");
                }

                return _foundationSettingsPath;
            }
        }

        public static string FeatureSettingsPath
        {
            get
            {
                if (string.IsNullOrEmpty(_featureSettingsPath))
                {
                    _featureSettingsPath = Sitecore.Configuration.Settings.GetSetting("AI.Foundation.Bedrock.Settings.Feature", "/sitecore/system/settings/feature");
                }

                return _featureSettingsPath;
            }
        }
        #endregion

    }
}