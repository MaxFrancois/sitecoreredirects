﻿namespace Sitecore.Avanade.Foundation.Bedrock
{
    public static class Constants
    {
        public static class Bedrock
        {
            #region Field Names
            public const string PageHeadingField = "PageHeading";
            public const string PageTitleField = "PageTitle";
            public const string PageSummaryField = "PageSummary";
            public const string PageContentField = "PageContent";
            #endregion

            #region Template Names
            public const string BedrockPageTemplate = "BedrockPage";
            public const string BedrockContentTemplate = "BedrockContent";
            #endregion
        }


        public static class InsertRuleItem
        {
            public const string InsertRuleTemplateId = "{664E5035-EB8C-4BA1-9731-A098FCC9127A}";
        }

        public static class Caches
        {
            public const string FoundationSettingItem = "foundation-setting-item";
            public const string FeatureSettingItem = "feature-setting-item";
            public const string InsertOptionsRulesCache = "insert-options-rules";
        }
    }
}
