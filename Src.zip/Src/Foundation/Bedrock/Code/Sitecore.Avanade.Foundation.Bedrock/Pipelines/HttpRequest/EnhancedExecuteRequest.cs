﻿using Sitecore.Abstractions;


namespace Sitecore.Avanade.Foundation.Bedrock.Pipelines.HttpRequest
{
    /// <summary>
    /// Overide the Execute Request processor and enhance for more added security
    /// </summary>
    public class EnhancedExecuteRequest : Sitecore.Pipelines.HttpRequest.ExecuteRequest
    {
        /// <summary>
        /// Base class which is used to ensure the default depency injection works
        /// </summary>
        /// <param name="baseSiteManager"></param>
        /// <param name="baseItemManager"></param>
        public EnhancedExecuteRequest(BaseSiteManager baseSiteManager, BaseItemManager baseItemManager) : base(baseSiteManager, baseItemManager)
        { 
            // need information here
        }

        protected override string GetNoAccessUrl(out bool loginPage)
        {
            return base.GetNoAccessUrl(out loginPage);
        }

        protected override void RedirectOnItemNotFound(string url)
        {
            base.RedirectOnItemNotFound(url);
        }

        protected override void RedirectOnLayoutNotFound(string url)
        {
            base.RedirectOnLayoutNotFound(url);
        }

        protected override void RedirectOnNoAccess(string url)
        {
            base.RedirectOnNoAccess(url);
        }
        protected override void RedirectOnSiteAccessDenied(string url)
        {
            base.RedirectOnSiteAccessDenied(url);
        }

        protected override void RedirectToLoginPage(string url)
        {
            base.RedirectToLoginPage(url);
        }
    }
}