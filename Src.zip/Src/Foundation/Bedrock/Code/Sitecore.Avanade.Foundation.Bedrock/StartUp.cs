﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

[assembly: PreApplicationStartMethod(typeof(Sitecore.Avanade.Foundation.Bedrock.StartUp), "Start")]
namespace Sitecore.Avanade.Foundation.Bedrock
{
#pragma warning disable S1118 // Utility classes should not have public constructors
    public class StartUp
#pragma warning restore S1118 // Utility classes should not have public constructors
    {
        public static void Start()
        {
            // Do Something
        }
    }
}