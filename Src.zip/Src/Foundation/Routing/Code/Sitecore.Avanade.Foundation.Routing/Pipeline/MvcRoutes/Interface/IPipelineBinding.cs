﻿using Sitecore.Pipelines;

namespace Sitecore.Avanade.Foundation.Routing.Pipeline.Interface
{
    interface IPipelineBinding
    {
        /// <summary>
        /// The name of the route
        /// </summary>
        string Name { get; set; }
        /// <summary>
        /// The route address template
        /// </summary>
        string RouteTemplate { get; set; }
        /// <summary>
        /// Default values for the routing parameters
        /// </summary>
        object Defaults { get; set; }

        /// <summary>
        /// Add the configuration to the routing map
        /// </summary>
        void Process(PipelineArgs args);

        /// <summary>
        /// Has the session been enabled for this rout
        /// </summary>
        bool SessionEnabled { get; set; }

        /// <summary>
        /// Add the configuration to the routing map
        /// </summary>
        void Process(PipelineArgs args, string bindingTypeName);

        /// <summary>
        /// Construct dynamice keyvalue pair for mvc defaults
        /// </summary>
        void AddDefault(System.Xml.XmlNode node);

        /// <summary>
        /// If the session is enabled this sets the route to support sessions
        /// </summary>
        /// <param name="route"></param>
        void IsSessionRoute(System.Web.Routing.Route route = null);
    }
}
