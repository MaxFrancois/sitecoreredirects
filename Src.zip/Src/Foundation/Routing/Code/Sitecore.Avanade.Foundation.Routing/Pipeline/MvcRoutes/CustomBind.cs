﻿using Sitecore.Pipelines;
using System.Web.Mvc;
using System.Web.Routing;

namespace Sitecore.Avanade.Foundation.Routing.Pipeline.MvcRoutes
{
    public class CustomBind : ProcessorBind
    {
        /// <summary>
        /// Add the configuration to the routing map
        /// </summary>
        public override void Process(PipelineArgs args)
        {
            // call base
            base.Process(args, "CustomBind");

            // has sessions been enabled
            base.IsSessionRoute(RouteTable.Routes.MapRoute(Name, RouteTemplate, Defaults));
        }
    }
}