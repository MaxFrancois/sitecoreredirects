﻿using Sitecore.Pipelines;
using System.Web.Http;

namespace Sitecore.Avanade.Foundation.Routing.Pipeline.MvcRoutes
{
    /// <summary>
    /// Process single configurations added to the mvc.routes pipeline
    /// </summary>
    public class AutomaticBind : ProcessorBind
    {
        /// <summary>
        /// Add the configuration to the routing map
        /// </summary>
        public override void Process(PipelineArgs args)
        {
            // call the base
            base.Process(args, "AutomaticBind");

            // set the configuration
            GlobalConfiguration.Configure(c => c.Routes.MapHttpRoute(Name, RouteTemplate, Defaults));

            // has analytics been enabled
            base.IsSessionRoute();
        }
        
    }
}
