﻿using Sitecore.Avanade.Foundation.Routing.Pipeline.Interface;
using Sitecore.Pipelines;
using Sitecore.Xml;
using System.Collections.Generic;
using System.Dynamic;
using System.Web.Mvc;

namespace Sitecore.Avanade.Foundation.Routing.Pipeline.MvcRoutes
{
    public class ProcessorBind : IPipelineBinding
    {
        /// <summary>
        /// The name of the route
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// The route address template
        /// </summary>
        public string RouteTemplate { get; set; }
        /// <summary>
        /// Default values for the routing parameters
        /// </summary>
        public object Defaults { get; set; } = new ExpandoObject();

        /// <summary>
        /// Have we enabled analytics
        /// </summary>
        public bool SessionEnabled { get; set; }

        public virtual void Process(PipelineArgs args)
        {
            // this is processed by it's parent
        }

        /// <summary>
        /// Add the configuration to the routing map
        /// </summary>
        public virtual void Process(PipelineArgs args, string bindingTypeName)
        {
            if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsInfoEnabled)
            {
                Diagnostics.Log.Info($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Routes]: '{Name}' - Adding to collection '{bindingTypeName}', Routing Template: '{RouteTemplate}', Session Enabled: '{SessionEnabled}'", typeof(ProcessorBind));
            }
        }

        /// <summary>
        /// Determines if the analytics route has been set
        /// </summary>
        /// <param name="route"></param>
        public virtual void IsSessionRoute(System.Web.Routing.Route route = null)
        {
            // is the analytics enabled
            if (SessionEnabled)
            {
                // have we got a route set
                if (route == null)
                {
                    // get the route if not found
                    route = System.Web.Routing.RouteTable.Routes[Name] as System.Web.Routing.Route;
                }

                // double check
                if (route != null)
                {
                    // set the session
                    route.RouteHandler = new Handler.SessionRouteHandler();
                }
            }
        }

        /// <summary>
        /// Construct dynamice keyvalue pair for mvc defaults
        /// </summary>
        public virtual void AddDefault(System.Xml.XmlNode node)
        {
            if (node != null)
            {
                // Locally reference the defaults object as a key value pair collection
                var obj = Defaults as ICollection<KeyValuePair<string, object>>;
                var key = node.Name;
                var value = XmlUtil.GetChildValue("default", node) as object; // Strings should be implicitly cast

                if (value != null)
                {
                    if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsDebugEnabled)
                    {
                        Diagnostics.Log.Debug($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Routes]: Adding key value [ {key}, {value.ToString()} ] to defaults");
                    }

                    // Check if the optional Parameter string is used 
                    // [note: this object can't be dynamically created using a sitecore config ref]
                    if (value.Equals(Constants.OptionalParameter)) value = UrlParameter.Optional;
                    obj.Add(new KeyValuePair<string, object>(key, value));
                }
            }
        }
    }
}