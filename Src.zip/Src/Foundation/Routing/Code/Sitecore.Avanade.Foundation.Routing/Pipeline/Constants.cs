﻿namespace Sitecore.Avanade.Foundation.Routing.Pipeline
{
    public static class Constants
    {
        public const string RoutesPipeline = "mvc.routes";
        public const string OptionalParameter = "UrlParameter:Optional";
    }
}
