﻿using Sitecore.Diagnostics;
using Sitecore.Pipelines;

namespace Sitecore.Avanade.Foundation.Routing.Pipeline.Initialize
{
    public class LoaderRoutes
    {
        /// <summary>
        /// Run the mvc routing pipelines
        /// </summary>
        public void Process(PipelineArgs args)
        {
            if (Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.IsInfoEnabled)
            {
                Log.Info($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[Routes]: Initilising AI Routes", this);
            }

            CorePipeline.Run(Constants.RoutesPipeline, args, false);
        }
    }
}