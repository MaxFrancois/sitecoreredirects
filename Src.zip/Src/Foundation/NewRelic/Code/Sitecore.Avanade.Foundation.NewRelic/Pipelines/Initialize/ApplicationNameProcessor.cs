﻿using Sitecore.Pipelines;
using Sitecore.Avanade.Foundation.Extensions;

// NewRelic Reference to make sure it does not affect with the namespace
using NR = NewRelic;

namespace Sitecore.Avanade.Foundation.NewRelic.Pipelines.Initialize
{
    public class ApplicationNameProcessor
    {
        /// <summary>
        /// Workout if the NewRelic Application name needs to be set
        /// </summary>
        /// <param name="args"></param>
        public void Process(PipelineArgs args)
        {
            // make sure we have data
            if (Sitecore.Configuration.Settings.GetAppSetting(Settings.ApplicationSettingName).IsNullOrEmpty()
                && Settings.IsEnabled
                && !Settings.ApplicationName.IsNullOrEmpty())
            {
                // set the NewRelic Agent
                NR.Api.Agent.NewRelic.SetApplicationName(Settings.ApplicationName);
            }
        }
    }
}