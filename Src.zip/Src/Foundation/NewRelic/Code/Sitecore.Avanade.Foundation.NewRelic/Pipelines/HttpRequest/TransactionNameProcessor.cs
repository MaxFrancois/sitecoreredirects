﻿using Sitecore.Pipelines.HttpRequest;
using Sitecore.Avanade.Foundation.Extensions;
using NR = NewRelic;

namespace Sitecore.Avanade.Foundation.NewRelic.Pipelines.HttpRequest
{
    public class TransactionNameProcessor : HttpRequestProcessor
    {
        /// <summary>
        /// Work out the transaction name to leverage
        /// </summary>
        /// <param name="args"></param>
        public override void Process(HttpRequestArgs args)
        {
            if (Settings.IsEnabled
                && !string.IsNullOrEmpty(Sitecore.Context.Item?.TemplateName)
                && (Context.User.IsAuthenticated ? Context.User.IsLoggedInPublic() : true))
            {
                // we the web page as the template name
                NR.Api.Agent.NewRelic.SetTransactionName("Webpage", $"{Sitecore.Context.Site.Name}-{(Sitecore.Context.RawUrl.Equals("/") ? "/home" : Sitecore.Context.RawUrl)}");

                // make sure we can log this
                if (Settings.CustomParametersIsEnabled)
                {
                    // custom parameters
                    NR.Api.Agent.NewRelic.AddCustomParameter("UserLoggedIn", Sitecore.Context.IsLoggedIn.ToString());
                    NR.Api.Agent.NewRelic.AddCustomParameter("UserAdmin", Sitecore.Context.IsAdministrator.ToString());

                    if (Sitecore.Context.Site != null)
                    {
                        NR.Api.Agent.NewRelic.AddCustomParameter("Site", Sitecore.Context.Site.Name);
                    }

                    if (Sitecore.Context.Language != null)
                    {
                        NR.Api.Agent.NewRelic.AddCustomParameter("Language", Sitecore.Context.Language.Name);
                    }

                    if (Sitecore.Context.Database != null)
                    {
                        NR.Api.Agent.NewRelic.AddCustomParameter("Database", Sitecore.Context.Database.Name);
                    }

                    if (Sitecore.Context.Device != null)
                    {
                        NR.Api.Agent.NewRelic.AddCustomParameter("Device", Sitecore.Context.Device.Name);
                    }

                    if (Sitecore.Context.Domain != null)
                    {
                        NR.Api.Agent.NewRelic.AddCustomParameter("Domain", Sitecore.Context.Domain.Name);
                    }
                }
            }
        }
    }
}