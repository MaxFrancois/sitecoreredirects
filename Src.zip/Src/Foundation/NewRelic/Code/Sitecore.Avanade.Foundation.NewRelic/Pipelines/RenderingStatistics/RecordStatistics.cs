﻿using NR = NewRelic;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Performance.Pipelines.RenderingStatistics;

namespace Sitecore.Avanade.Foundation.NewRelic.Pipelines.RenderingStatistics
{
    public class RecordStatistics : RenderingStatisticsProcessor
    {
        public override void Process(RenderStatisticsArgs args)
        {
            // has the stats been disable on the rendering
            if (Settings.IsEnabled
                && Settings.Rendering.Statistics.RenderingStatisticsIsEnabled
                && args.RenderingRenderingArgs.Rendering.RenderingField(Constants.NewRelicEnabled).ValueSafe<bool>(false, true)
                && args.RenderingRenderingArgs.Rendering.Parameters.ValueSafe<bool>(Constants.NewRelicEnabled, true)
                )
            {
                // we need to make sure this works or else
                NR.Api.Agent.NewRelic.RecordResponseTimeMetric($"Custom/Placeholder/{args.TraceName}", System.Convert.ToInt64(args.Elapsed));
            }
        }
    }
}