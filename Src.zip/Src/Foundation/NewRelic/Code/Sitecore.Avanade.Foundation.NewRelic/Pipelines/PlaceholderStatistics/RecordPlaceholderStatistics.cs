﻿using NR = NewRelic;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Avanade.Foundation.Performance.Pipelines.PlaceholderStatistics;

namespace Sitecore.Avanade.Foundation.NewRelic.Pipelines.PlaceholderStatistics
{
    public class PlaceholderStatisticsPipeline : PlaceholderStatisticsProcessor
    {

        public override void Process(PlaceholderStatisticsArgs args)
        {
            // make sure we have data
            if (Settings.IsEnabled
                && Settings.PlaceHolder.Statistics.PlacholderStatisticsIsEnabled
                && args.Item != null
                && args.Item.Fields[Constants.NewRelicEnabled].ValueSafe<bool>(false, true))
            {
                // recorod the response
                NR.Api.Agent.NewRelic.RecordResponseTimeMetric($"Custom/Placeholder/{args.TraceName}", System.Convert.ToInt64(args.Elapsed));
            }
        }
    }
}