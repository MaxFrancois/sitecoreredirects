﻿namespace Sitecore.Avanade.Foundation.NewRelic
{ 
    public static class Settings
    {
        #region Public Properties
        /// <summary>
        /// Is NewRelic Enabled
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.NewRelic.Enabled", false,
                    Constants.BaseTemplateId, "Enabled", domainListFilter: true);
            }
        }

        /// <summary>
        /// Are the custom parameters enabled
        /// </summary>
        public static bool CustomParametersIsEnabled
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.NewRelic.CustomParametersEnabled", false,
                    Constants.BaseTemplateId, "CustomParametersEnabled", domainListFilter: true);
            }
        }
        

        /// <summary>
        /// The application name
        /// </summary>
        public static string ApplicationName
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting("AI.Foundation.NewRelic.AppName", string.Empty,
                    Constants.BaseTemplateId, "ApplicationName", domainListFilter: true);
            }
        }

        /// <summary>
        /// The Application Setting Name used in AppSettings
        /// </summary>
        public static string ApplicationSettingName
        {
            get
            {
                return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetSetting("AI.Foundation.NewRelic.AppSettingName", string.Empty,
                    Constants.BaseTemplateId, "AppSettingName", domainListFilter: true);
            }
        }

        #endregion

        
        public static class PlaceHolder
        {
            public static class Statistics
            {
                #region Public Properties
                /// <summary>
                /// Are the Rendering Metrics Enabled
                /// </summary>
                public static bool PlacholderStatisticsIsEnabled
                {
                    get
                    {
                        return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.NewRelic.Placeholder.Statistics.Enabled", false,
                            Constants.BaseTemplateId, "PlaceholderEnabled", domainListFilter: true);
                    }
                }
                #endregion
            }
        }

        public static class Rendering
        {
            public static class Statistics
            {
                #region Public Properties
                /// <summary>
                /// Are the Rendering Metrics Enabled
                /// </summary>
                public static bool RenderingStatisticsIsEnabled
                {
                    get
                    {
                        return Sitecore.Avanade.Foundation.Site.Configuration.Settings.GetBoolSetting("AI.Foundation.NewRelic.Rendering.Statistics.Enabled", false,
                            Constants.BaseTemplateId, "RenderingEnabled", domainListFilter: true);
                    }
                }
                #endregion
            }
        }
    }
}
