﻿namespace Sitecore.Avanade.Foundation.NewRelic
{
    public static class Constants
    {
        public const string NewRelicEnabled = "NewRelicEnabled";

        public const string BaseTemplateId = "{6E0C8E64-9858-4932-AE97-1DA134417FDA}";
    }
}