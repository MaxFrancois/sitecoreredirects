﻿using System;
using System.Collections.Generic;
using log4net.Appender;
using log4net.spi;

// NewRelic Reference to make sure it does not affect with the namespace
using NR = NewRelic;

namespace Sitecore.Avanade.Foundation.NewRelic.Logging.Appender
{
    /// <summary>
    /// Custom NewRelic Log Appender
    /// </summary>
    public class NewRelicLogAppender : AppenderSkeleton
    {
        /// <summary>
        /// Setup the Appender
        /// </summary>
        /// <param name="loggingEvent"></param>
        protected override void Append(LoggingEvent loggingEvent)
        {
            // is this enabled and we want to log
            if (!Settings.IsEnabled
                || loggingEvent.Level < Level.WARN)
            {
                return;
            }

            // Skip exceptions
            var isException = !string.IsNullOrEmpty(loggingEvent.GetExceptionStrRep());

            // we should not log this as it was a thrown exception
            if (isException)
            {
                return;
            }

            // build our dictionary of parameters to add
            IDictionary<string, string> parameters = new Dictionary<string, string>();

            // add the informaiton
            parameters.Add("Level", loggingEvent.Level.ToString());
            parameters.Add("LoggerName", loggingEvent.LoggerName);
            parameters.Add("ThreadName", loggingEvent.ThreadName);
            parameters.Add("Machine", Environment.MachineName);
            parameters.Add("Identity", loggingEvent.Identity);
            
            // sitecore parameters
            parameters.Add("UserLoggedIn", Sitecore.Context.IsLoggedIn.ToString());
            parameters.Add("UserAdmin", Sitecore.Context.IsAdministrator.ToString());
            parameters.Add("IsBackgroundThread", Sitecore.Context.IsBackgroundThread.ToString());
            parameters.Add("RawURL", Sitecore.Context.RawUrl);

            if (Sitecore.Context.Site != null)
            {
                parameters.Add("Site", Sitecore.Context.Site.Name);
            }

            if (Sitecore.Context.Language != null)
            {
                parameters.Add("Language", Sitecore.Context.Language.Name);
            }

            if (Sitecore.Context.Database != null)
            {
                parameters.Add("Database", Sitecore.Context.Database.Name);
            }

            if (Sitecore.Context.Device != null)
            {
                parameters.Add("Device", Sitecore.Context.Device.Name);
            }

            if (Sitecore.Context.Domain != null)
            {
                parameters.Add("Domain", Sitecore.Context.Domain.Name);
            }

            if (Sitecore.Context.Item != null)
            {
                // add the Item Path
                parameters.Add("ItemPath", Sitecore.Context.Item.Paths.FullPath);

                // create the custom transaction so we can logg correctly
                NR.Api.Agent.NewRelic.SetTransactionName("Custom", $"{Sitecore.Context.Item.Name}-{Sitecore.Context.GetDeviceName()}");
            }
            
            // log the details
            NR.Api.Agent.NewRelic.NoticeError(loggingEvent.MessageObject.ToString(), parameters);
        }
    }
}