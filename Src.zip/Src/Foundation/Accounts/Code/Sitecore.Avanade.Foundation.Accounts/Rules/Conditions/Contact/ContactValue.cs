﻿using Sitecore.Rules.Conditions;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Rules;
using Sitecore.Analytics;
using Sitecore.Avanade.Foundation.Accounts.Extensions;

namespace Sitecore.Avanade.Foundation.Accounts.Rules.Conditions.Contact
{
    /// <summary>
    /// Rule to execute the facet path such as "Personal.FirstName" or "Addresses.Entries.Mailing.City"
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ContactValue<T> : StringOperatorCondition<T> where T : RuleContext
    {
        /// <summary>
        /// The facet path which the user has set
        /// </summary>
        public string FacetPath { get; set; }

        /// <summary>
        /// The value which we are wanting to validate against
        /// </summary>
        public string Value { get; set; }
        
        /// <summary>
        /// Executes the facet path
        /// </summary>
        /// <param name="ruleContext"></param>
        /// <returns></returns>
        protected override bool Execute(T ruleContext)
        {
            // make sure data is valie
            if (ruleContext != null
                && ruleContext.Item != null
                && !FacetPath.IsNullOrEmpty())
            {
                // get the current users contact details
                Analytics.Tracking.Contact contact = null;

                // make sure we have a tracker enabled and contact
                if (Tracker.Enabled
                    && Tracker.IsActive
                    && Tracker.Current?.Session?.Contact != null)
                {
                    contact = Tracker.Current.Session.Contact;
                }

                // make sure we have a tracker
                if (contact != null)
                {
                    string facetValue = string.Empty;

                    // get the 
                    string facetPathValue = Sitecore.Context.Database.GetItem(new Sitecore.Data.ID(FacetPath)).Fields["Value"].Value;

                    // get the facet object
                    var contactData = contact.GetFacetObject(facetPathValue);

                    // do we have data
                    if (contactData?.Value != null)
                    {
                        try
                        {
                            facetValue = System.Convert.ToString(contactData.Value);
                        }
                        catch (System.Exception ex)
                        {
                            Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[ContactValue Rule]: Unable to convert Contact Value", ex, typeof(ContactValue<T>));
                        }
                    }

                    // compare the values
                    return base.Compare(facetValue, Value);
                }

                
            }

            return false;
        }

    }
}