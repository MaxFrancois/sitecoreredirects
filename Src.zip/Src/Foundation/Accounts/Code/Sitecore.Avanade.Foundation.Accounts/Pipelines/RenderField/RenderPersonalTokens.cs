﻿using Sitecore.Avanade.Foundation.Extensions.TypeConverters;
using Sitecore.Avanade.Foundation.Extensions;
using Sitecore.Pipelines.RenderField;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken;
using Sitecore.Pipelines;
using System.Linq;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.RenderField
{
    public class RenderPersonalTokens
    {
        /// <summary>
        /// The unique token identifier used, potentially the data can be url encoded and this will decode it
        /// </summary>
        [TypeConverter(typeof(StringUrlDecodeConverter))]
        public string TokenIdentifier { get; set; }

        public void Process(RenderFieldArgs args)
        {
            // make sure we do not run if required
            if (!(Context.PageMode.IsExperienceEditor ||
                Context.PageMode.IsPreview ||
                Context.PageMode.IsDebugging ||
                Context.PageMode.IsProfiling ||
                Context.PageMode.IsSimulatedDevicePreviewing ||
                args.Aborted ||
                args.Suspended ||
                args.Result.IsEmpty ||
                !Sitecore.Context.User.IsLoggedInPublic()))
            {
                // set the regex required
                var regEx = new Regex(TokenIdentifier, RegexOptions.Multiline
                            | RegexOptions.ECMAScript
                            | RegexOptions.Compiled);

                // process the first part
                args.Result.FirstPart = TokenFilter(args, regEx, args.Result.FirstPart, "first");

                // process the last part
                args.Result.LastPart = TokenFilter(args, regEx, args.Result.LastPart, "last");
            }
        }

        /// <summary>
        /// Processes the Token Filter and runs the pipeline
        /// </summary>
        /// <param name="args"></param>
        /// <param name="regEx">The regular expression to use</param>
        /// <param name="result">The results we are processing</param>
        /// <param name="identifier">The unique identifier such as "First", "Last"</param>
        /// <returns></returns>
        private string TokenFilter(RenderFieldArgs args, Regex regEx, string result, string identifier)
        {
            // double chcek
            if (!result.IsNullOrEmpty())
            {
                // get the collection out
                MatchCollection ms = regEx.Matches(result);

                // process to see what we have
                if (ms != null && ms.Count > 0)
                {
                    PersonalisationTokensArgs renderingArgs = new PersonalisationTokensArgs(args, identifier, result);

                    // cycle over the list and get out the type
                    foreach (Match match in ms)
                    {
                        // make sure we have data
                        if (match.Success && match.Groups.Count > 0)
                        {
                            // get the groups from this list, should only be two
                            GroupCollection groups = match.Groups;

                            // make sure we do not have this
                            if (!renderingArgs.Tokens.Any(x => x.CompleteMatch.Equals(match.Value, System.StringComparison.OrdinalIgnoreCase)))
                            {
                                // add our rendering
                                renderingArgs.Tokens.Add(new PersonalisationTokenItem { CompleteMatch = match.Value, Value = groups[0].Value, Group = groups[1].Value, Path = groups[2].Value });
                            }
                        }
                    }

                    // run the pipeline
                    CorePipeline.Run("personalisationToken", renderingArgs, false);

                    // return the updated results
                    return renderingArgs.Result;
                }
            }

            return result;
        }
    }
}