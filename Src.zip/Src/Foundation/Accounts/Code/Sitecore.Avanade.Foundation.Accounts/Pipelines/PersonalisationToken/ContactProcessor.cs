﻿using Sitecore.Analytics;
using Sitecore.Analytics.Tracking;
using System.Linq;
using Sitecore.Avanade.Foundation.Accounts.Extensions;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken
{
    /// <summary>
    /// Replaces any contact data
    /// </summary>
    public class ContactProcessor : BaseProcessor
    {
        /// <summary>
        /// The processor to process the contact
        /// </summary>
        /// <param name="args"></param>
        public override void Process(PersonalisationTokensArgs args)
        {
            // call the base processor
            base.Process(args);

            // just make sure
            if (Tokens.Any())
            {
                // get the current users contact details
                Analytics.Tracking.Contact contact = null;

                // make sure we have a tracker enabled and contact
                if (Tracker.Enabled
                    && Tracker.IsActive
                    && Tracker.Current?.Session?.Contact != null)
                {
                    contact = Tracker.Current.Session.Contact;
                }

                // process the tokens to fix the tokens
                Tokens.ForEach(x =>
                {
                    // if already processed ignore
                    if (!x.Processed)
                    {
                        string facetValue = string.Empty;

                        // make sure we do not have to do any processing
                        if (contact != null)
                        {
                            // get the facet object
                            var contactData = contact.GetFacetObject(x.Path);

                            // do we have data
                            if (contactData?.Value != null)
                            {
                                try
                                {
                                    facetValue = System.Convert.ToString(contactData.Value);
                                }
                                catch (System.Exception ex)
                                {
                                    Diagnostics.Log.Error($"{Sitecore.Avanade.Foundation.Extensions.Diagnostics.Log.LogPrefix}[PersonalisationProcessor]: Unable to convert Contact Value", ex, typeof(ContactProcessor));
                                }
                            }
                        }

                        // we can replace this with empty
                        args.Result = args.Result.Replace(x.CompleteMatch, facetValue);
                        x.Processed = true;
                    }
                });

            }
        }
    
    }
}