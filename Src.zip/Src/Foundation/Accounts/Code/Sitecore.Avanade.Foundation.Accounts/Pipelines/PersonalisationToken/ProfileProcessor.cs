﻿using System.Linq;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken
{
    /// <summary>
    /// Replaces any profile data
    /// </summary>
    public class ProfileProcessor : BaseProcessor
    {
        /// <summary>
        /// The processor to process the profile
        /// </summary>
        /// <param name="args"></param>
        public override void Process(PersonalisationTokensArgs args)
        {
            // call the base processor
            base.Process(args);

            // just make sure
            if (Tokens.Any())
            {
                // process the tokens to fix the tokens
                Tokens.ForEach(x =>
                {
                    if (!x.Processed)
                    {
                        // we can replace this with empty
                        args.Result = args.Result.Replace(x.CompleteMatch, Context.User.Profile[x.Path]);
                        x.Processed = true;
                    }
                });
            }
        }
    }
}