﻿using System.Linq;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken
{
    /// <summary>
    /// Processor to fix no matches
    /// </summary>
    public class NoMatchProcessor : BaseProcessor
    {
        /// <summary>
        /// The processor to process non matched results
        /// </summary>
        /// <param name="args"></param>
        public override void Process(PersonalisationTokensArgs args)
        {
            // call the base processor
            base.Process(args);

            // just make sure
            if (args.Tokens.Any())
            {
                // process the tokens to fix the tokens
                args.Tokens.ForEach(x =>
                {
                    if (!x.Processed)
                    {
                        // we can replace this with empty
                        args.Result = args.Result.Replace(x.CompleteMatch, string.Empty);
                        x.Processed = true;
                    }
                });
            }
        }
    }
}