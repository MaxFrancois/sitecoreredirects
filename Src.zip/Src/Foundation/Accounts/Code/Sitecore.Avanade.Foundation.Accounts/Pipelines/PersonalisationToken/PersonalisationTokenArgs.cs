﻿using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Pipelines.RenderField;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken
{
#pragma warning disable S3925 // "ISerializable" should be implemented correctly
    public class PersonalisationTokensArgs : Sitecore.Mvc.Pipelines.MvcPipelineArgs
#pragma warning restore S3925 // "ISerializable" should be implemented correctly
    {
        /// <summary>
        /// The token listing to leverage
        /// </summary>
        public List<PersonalisationTokenItem> Tokens { get; set; }

        /// <summary>
        /// The result we are process
        /// </summary>
        public string Result { get; set; }

        /// <summary>
        /// The initial identifier such as First, Last so we know what aspect of the FieldRender we are modifying
        /// </summary>
        public string Identifier { get; set; }

        /// <summary>
        /// Extends the HttpRequestArgs for the Redireciton pipeline
        /// </summary>
        /// <param name="args">The RenderFieldArgs supplied in the pipeline for the HttpRequest Pipeline</param>
        /// <param name="identifier">The initial identifier such as First, Last so we know what aspect of the FieldRender we are modifying</param>
        /// <param name="result">The result we are process</param>
        public PersonalisationTokensArgs(RenderFieldArgs args, string identifier, string result)
        {
            // make sure we have our data
            Assert.ArgumentNotNull(args, "args");

            // setup empty
            Tokens = new List<PersonalisationTokenItem>();
            Result = result;
            Identifier = identifier;
        }
    }

    /// <summary>
    /// The Token Item to be replaced
    /// </summary>
    public class PersonalisationTokenItem
    {
        /// <summary>
        /// The Value, complete output
        /// </summary>
        /// <example>Contact.Personal.FirstName</example>
        public string Value { get; set; }

        /// <summary>
        /// The complete string that was matched which needs to be replaced which was matched and found in the regular expression
        /// </summary>
        /// <example>{{Contact.Personal.FirstName}}</example>
        public string CompleteMatch { get; set; }

        /// <summary>
        /// The Group such as "Contact"
        /// </summary>
        public string Group { get; set; }

        /// <summary>
        /// The remaining path such as "Personal.FirstName"
        /// </summary>
        public string Path { get; set; }

        /// <summary>
        /// Has this been processed
        /// </summary>
        public bool Processed { get; set; }
    }
}