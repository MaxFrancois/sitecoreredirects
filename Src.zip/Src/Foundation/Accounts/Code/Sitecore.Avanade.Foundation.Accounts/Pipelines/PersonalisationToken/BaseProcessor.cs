﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sitecore.Avanade.Foundation.Accounts.Pipelines.PersonalisationToken
{
    /// <summary>
    /// Replaces any profile data
    /// </summary>
    public class BaseProcessor
    {
        /// <summary>
        /// The identifier we are using
        /// </summary>
        public string Identifier { get; internal set; }

        /// <summary>
        /// The list of tokens based on the identifier
        /// </summary>
        public List<PersonalisationTokenItem> Tokens { get; internal set; }


        /// <summary>
        /// The processor to process the Identifier Details
        /// </summary>
        /// <param name="args"></param>
        public virtual void Process(PersonalisationTokensArgs args)
        {
            // make sure we have something to process
            if (args?.Tokens == null
                || args.Aborted
                || args.Suspended
                || args.Tokens.Any())
            {
                return;
            }

            // only get the tokens
            Tokens = args.Tokens.Where(x => x.Group.Equals(Identifier, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    }
}