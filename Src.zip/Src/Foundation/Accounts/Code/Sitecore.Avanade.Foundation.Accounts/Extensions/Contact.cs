﻿using Sitecore.Avanade.Foundation.Extensions;
using System.Collections;
using Sitecore.Analytics.Model.Framework;

using System.Linq;

namespace Sitecore.Avanade.Foundation.Accounts.Extensions
{
    public static class ContactExtenions
    {
        /// <summary>
        /// Get the Facet Values using a query such as "Personal.FirstName", "Addresses.Entries.Mailing.Country"
        /// </summary>
        /// <param name=""></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static IModelAttributeMember GetFacetObject(this Sitecore.Analytics.Tracking.Contact contact, string query)
        {
            // make sure we have the that we require
            if (contact == null
                || query.IsNullOrEmpty())
            {
                return null;
            }
            
            // split the data such as "Personal.FirstName"
            string[] propertyPathArr = query.Split('.');

            // we just want to make sure we have data
            if (propertyPathArr.Length == 0)
            {
                return null;
            }

            // set into queue to allow us to get the data out in a standard flow
            Queue propertyQueue = new Queue(propertyPathArr);

            // get the first member
            string facetName = propertyQueue.Dequeue().ToString();

            // do we have a facet for this
            IFacet facet = contact.Facets[facetName];

            // if no facet stop
            if (facet == null)
            {
                return null;
            }

            // next get the property or sub mmeber
            var datalist = facet.Members[propertyQueue.Dequeue().ToString()];

            // are we already an attribute member
            if (datalist != null && datalist is IModelAttributeMember)
            {
                return (IModelAttributeMember)datalist;
            }
            // are we in a dictionary member
            else if (datalist != null && datalist is IModelDictionaryMember)
            {
                var dictionaryMember = (IModelDictionaryMember)datalist;
                return dictionaryMember.GetIModelDictionaryMember(propertyQueue.Dequeue().ToString(), propertyQueue.Dequeue().ToString());
            }
            // are we in a model collection
            else if (datalist != null && datalist is IModelCollectionMember)
            {
                var collectionMember = (IModelCollectionMember)datalist;
                return collectionMember.GetIModelCollectionMember(propertyQueue.Dequeue().ToString());
            }

            return null;
        }

        /// <summary>
        /// Get the IModelAttributeMember based on  th e element name and member name we are accessing
        /// </summary>
        /// <param name="mod"></param>
        /// <param name="elementName"></param>
        /// <param name="memberName"></param>
        /// <returns></returns>
        private static IModelAttributeMember GetIModelDictionaryMember(this IModelDictionaryMember mod, string elementName, string memberName)
        {
            // make sure we have data
            if (mod != null
                && !mod.IsEmpty
                && mod.Elements.Keys.Count > 0
                && mod.Elements.Contains(elementName))
            {
                var element = mod.Elements[elementName];

                // make sure we have data and what we want
                if (element != null
                    && !element.IsEmpty
                    && element.Members.Count > 0
                    && element.Members.Contains(memberName))
                {
                    return (IModelAttributeMember)element.Members[memberName];
                }
            }

            return null;
        }

        /// <summary>
        /// Gets the IModelAttributeMember from the Model Collection
        /// </summary>
        /// <param name="mod"></param>
        /// <param name="memberName"></param>
        /// <returns></returns>
        private static IModelAttributeMember GetIModelCollectionMember(this IModelCollectionMember mod, string memberName)
        {
            // make sure we have data
            if (mod != null
                && !mod.IsEmpty
                && mod.Elements.Count > 0)
            {
                // do we have an element which has our property
                IElement element = mod.Elements.FirstOrDefault(x =>
                {
                    if (!x.IsEmpty
                        && x.Members.Count > 0
                        && x.Members.Contains(memberName))
                    {
                        return true;
                    }

                    return false;
                });

                if (element != null)
                {
                    // return our property
                    return (IModelAttributeMember)element.Members[memberName];
                }
            }

            return null;
        }

    }
}